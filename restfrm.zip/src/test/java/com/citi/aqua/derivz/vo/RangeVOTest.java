package com.citi.aqua.derivz.vo;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

public class RangeVOTest {

	private RangeVO rangeVO;
	@Before
	public void setUp() throws Exception {
		rangeVO= new RangeVO<>();
	}

	@Test
	public void testGetStart() {
		RangeVO vo= new RangeVO<>();
		rangeVO.setEnd(vo.getEnd());
		rangeVO.setStart(vo.getStart());
		assertNotNull(rangeVO.toString());
	}

}
