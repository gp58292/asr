package com.citi.aqua.derivz.services.grid;

import com.citi.aqua.frm.ceft.CeftDataSetType;
import com.citi.aqua.frm.framework.grid.User;
import com.citi.aqua.frm.framework.grid.data.DataSetId;
import com.citi.aqua.frm.framework.grid.data.DataSetVersion;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/17/2019
 */
public class TestObjectProvider {
    public static final String SAMPLE_SOE_ID = "tu00001";
    public static final User SAMPLE_FRM_USER = new User(SAMPLE_SOE_ID, false);
    public final static CeftDataSet SAMPLE_CEFT_DATA_SET = new CeftDataSet(SAMPLE_SOE_ID, 10L, CeftDataSetType.FMTM);
    public final static CeftDataSet SAMPLE_CEFT_DATA_SET_2 = new CeftDataSet(SAMPLE_SOE_ID, 11L, CeftDataSetType.FMTM);
    public static final String SAMPLE_UUID = "sampleUUID";
    public static final String SAMPLE_UUID_2 = "sampleUUID2";
    public static final long SAMPLE_VERSION = 1L;
    public static final DataSetId SAMPLE_FRM_DATA_SET_ID=SAMPLE_CEFT_DATA_SET.toDataSetId();
    public static final DataSetVersion SAMPLE_FRM_DATA_SET_VERSION=new DataSetVersion(SAMPLE_FRM_DATA_SET_ID, SAMPLE_VERSION);

}
