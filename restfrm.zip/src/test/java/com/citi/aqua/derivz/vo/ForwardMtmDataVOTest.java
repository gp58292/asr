package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ForwardMtmDataVOTest {

	ForwardMtmDataVO frwdMTMDataVO;

	@Before
	public void setUp() throws Exception {
		frwdMTMDataVO = new ForwardMtmDataVO();
	}

	@Test
	public void testGetCollateralTypeName() {

		ForwardMtmDataVO vo = new ForwardMtmDataVO();
		vo.setCustomerName("TEST");
		frwdMTMDataVO.setFwdMtmKey(vo.getFwdMtmKey());
		frwdMTMDataVO.setAgreementId(vo.getAgreementId());
		frwdMTMDataVO.setAgreementKey(vo.getAgreementKey());
		frwdMTMDataVO.setBusDate(vo.getBusDate());
		frwdMTMDataVO.setUnderlyingTenor(vo.getUnderlyingTenor());
		frwdMTMDataVO.setUnderlyingene(vo.getUnderlyingene());
		frwdMTMDataVO.setUnderlyingepe(vo.getUnderlyingepe());
		frwdMTMDataVO.setFwdCollExposure(vo.getFwdCollExposure());
		frwdMTMDataVO.setFwdCollExposurePostConcentration(vo.getFwdCollExposurePostConcentration());
		frwdMTMDataVO.setClearingAgreement(vo.getClearingAgreement());
		frwdMTMDataVO.setCollateralTypeName(vo.getCollateralTypeName());
		frwdMTMDataVO.setConsentToSubstitution(vo.getConsentToSubstitution());
		frwdMTMDataVO.setCounterPartyName(vo.getCounterPartyName());
		frwdMTMDataVO.setCpMarginType(vo.getCpMarginType());
		frwdMTMDataVO.setCsaDescription(vo.getCsaDescription());
		frwdMTMDataVO.setCsaMarginType(vo.getCsaMarginType());
		frwdMTMDataVO.setCsaStatus(vo.getCsaStatus());
		frwdMTMDataVO.setCustodianRequired(vo.getCustodianRequired());
		frwdMTMDataVO.setCustomerName(vo.getCustomerName());
		frwdMTMDataVO.setExchangeClearedAgreement(vo.getExchangeClearedAgreement());
		frwdMTMDataVO.setGfcid(vo.getGfcid());
		frwdMTMDataVO.setGfcidType(vo.getGfcidType());
		frwdMTMDataVO.setGfcidDescription(vo.getGfcidDescription());
		frwdMTMDataVO.setGoverningLaw(vo.getGoverningLaw());
		frwdMTMDataVO.setImVm(vo.getImVm());
		frwdMTMDataVO.setIncorporatedCountry(vo.getIncorporatedCountry());
		frwdMTMDataVO.setIndustrySector(vo.getIndustrySector());
		frwdMTMDataVO.setMasterAgreement(vo.getMasterAgreement());
		frwdMTMDataVO.setMasterAgreementStatus(vo.getMasterAgreementStatus());
		frwdMTMDataVO.setMgdSegLevel5Desc(vo.getMgdSegLevel5Desc());
		frwdMTMDataVO.setPartyLegalEntity(vo.getPartyLegalEntity());
		frwdMTMDataVO.setPledgor(vo.getPledgor());
		frwdMTMDataVO.setResolvedBusinessUnit(vo.getResolvedBusinessUnit());
		frwdMTMDataVO.setSme(vo.getSme());
		frwdMTMDataVO.setSaTriggerEvent(vo.getSaTriggerEvent());
		frwdMTMDataVO.setSixCApplies(vo.getSixCApplies());
		frwdMTMDataVO.setTriggerEvent(vo.getTriggerEvent());
		frwdMTMDataVO.setTypeOfCollateral(vo.getTypeOfCollateral());
		frwdMTMDataVO.setUnderlyingBusinessUnit(vo.getUnderlyingBusinessUnit());
		frwdMTMDataVO.setLvidName(vo.getLvidName());
		frwdMTMDataVO.setMandatoryMarkFrequency(vo.getMandatoryMarkFrequency());
		frwdMTMDataVO.setInterCompanyAgreement(vo.getInterCompanyAgreement());
		frwdMTMDataVO.setPartyCustodianRequired(vo.getPartyCustodianRequired());
		frwdMTMDataVO.setCounterPartyCustodianRequired(vo.getCounterPartyCustodianRequired());
		frwdMTMDataVO.setBusinessDate(vo.getBusinessDate());
		frwdMTMDataVO.setUnderlyingTenorDesc(vo.getUnderlyingTenorDesc());
		frwdMTMDataVO.equals(vo);
		frwdMTMDataVO.hashCode();
		frwdMTMDataVO.toString();
		assertEquals("TEST",frwdMTMDataVO.getCustomerName());

	}
}
