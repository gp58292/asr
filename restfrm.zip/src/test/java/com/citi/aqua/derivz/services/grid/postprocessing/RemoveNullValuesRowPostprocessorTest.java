package com.citi.aqua.derivz.services.grid.postprocessing;

import org.junit.Test;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 9/27/2019
 */
public class RemoveNullValuesRowPostprocessorTest {

    RemoveNullValuesRowPostprocessor instance = new RemoveNullValuesRowPostprocessor();


    @Test
    public void processRow() {
        assertTrue(instance.processRow(Collections.emptyMap()).isEmpty());

        Map<String, Object> input = Collections.singletonMap("col", 1);
        assertEquals(input, instance.processRow(input));

        assertTrue(instance.processRow(Collections.singletonMap("col", null)).isEmpty());

    }

    @Test
    public void processRowComplex() {
        HashMap<String, Object> input = new HashMap<>();

        input.put("col1", 1.0);
        input.put("col2", "val");
        input.put("col3", null);
        input.put("col4", emptyList());

        Map<String, Object> res = instance.processRow(input);
        assertEquals(3, res.size());
        asList("col1", "col2", "col4").forEach(c->assertEquals(input.get(c), res.get(c)));
    }
}