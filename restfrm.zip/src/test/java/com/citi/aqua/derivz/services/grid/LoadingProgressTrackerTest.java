package com.citi.aqua.derivz.services.grid;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;

import static com.citi.aqua.derivz.services.grid.TestObjectProvider.SAMPLE_UUID;
import static com.citi.aqua.derivz.services.grid.TestObjectProvider.SAMPLE_UUID_2;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class LoadingProgressTrackerTest {

    private final String frmSetId = TestObjectProvider.SAMPLE_CEFT_DATA_SET.toDataSetId().getSetId();
    private LoadingProgressTracker instance;

    @Before
    public void setUp() {
        instance = new LoadingProgressTracker();
    }

    @After
    public void tearDown() {
    }

    @Test
    public void registerUUID() {
        assertNull(instance.findDataSet(frmSetId));
        instance.registerWebSocketUUID(TestObjectProvider.SAMPLE_CEFT_DATA_SET, SAMPLE_UUID);
        assertEquals(TestObjectProvider.SAMPLE_CEFT_DATA_SET, instance.findDataSet(frmSetId));
    }

    @Test
    public void deregisterUUID() {
        instance.registerWebSocketUUID(TestObjectProvider.SAMPLE_CEFT_DATA_SET, SAMPLE_UUID);
        assertEquals(Collections.singleton(SAMPLE_UUID), instance.findUUID(frmSetId));
        instance.deregisterWebSocketUUID(SAMPLE_UUID);
        assertNull(instance.findDataSet(SAMPLE_UUID));
    }


    @Test
    public void findUUID() {
        instance.registerWebSocketUUID(TestObjectProvider.SAMPLE_CEFT_DATA_SET, SAMPLE_UUID);
        assertEquals(Collections.singleton(SAMPLE_UUID), instance.findUUID(frmSetId));
        instance.registerWebSocketUUID(TestObjectProvider.SAMPLE_CEFT_DATA_SET, SAMPLE_UUID_2);
        assertEquals(new HashSet(Arrays.asList(SAMPLE_UUID, SAMPLE_UUID_2)), instance.findUUID(frmSetId));
    }

    @Test
    public void findDataSet() {
        assertNull(instance.findDataSet(frmSetId));
        instance.registerWebSocketUUID(TestObjectProvider.SAMPLE_CEFT_DATA_SET, SAMPLE_UUID);
        assertEquals(TestObjectProvider.SAMPLE_CEFT_DATA_SET, instance.findDataSet(frmSetId));
    }
}