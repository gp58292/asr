
package com.citi.aqua.derivz.services.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;
import com.citi.aqua.derivz.data.repository.BaseRepository;
import com.citi.aqua.derivz.data.repository.DatasetRepository;
import com.citi.aqua.derivz.model.Dataset;

@RunWith(SpringRunner.class)
public class DatasetServiceImplTest {

	@InjectMocks
	DatasetServiceImpl datasetServiceImpl;

	@Mock
	DatasetRepository datasetRepository;

	@Mock
	BaseRepository baseRepository;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testFindAll()  {
		List<Dataset> datasetList = new ArrayList<>();
		Dataset dataset = new Dataset();
		datasetList.add(dataset);
		when(datasetRepository.findAll()).thenReturn(datasetList);

		assertEquals(1, datasetServiceImpl.findAll().size());

	}
	@Test
	public void testFindByName() {
		Dataset dataset = new Dataset();
		dataset.setName("Test");
		when(datasetRepository.findByName("Test")).thenReturn(dataset);

		assertEquals("Test", datasetServiceImpl.findByName("Test").getName());

	}
	
	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	public void testGetDataset() {
		List datasetList= new ArrayList<>();
		Dataset dataset = new Dataset();
		datasetList.add(dataset);
		when(baseRepository.getDataset("Test", "", 1)).thenReturn(datasetList);

		assertEquals(1, datasetServiceImpl.getDataset("Test", "", 1).size());

	}

}
