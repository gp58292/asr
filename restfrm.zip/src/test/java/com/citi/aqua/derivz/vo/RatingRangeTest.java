package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class RatingRangeTest {

	private RatingRange ratingRange;

	@Before
	public void setUp() throws Exception {
		ratingRange = new RatingRange();
	}

	@Test
	public void testGetAgencyName() {
		RatingRange range= new RatingRange();
		range.setAgencyName("TEST");
		ratingRange.setAgencyName(range.getAgencyName());
		ratingRange.setOperation(range.getOperation());
		ratingRange.setPeriod(range.getPeriod());
		ratingRange.setValue(range.getValue());
		ratingRange.equals(range);
		ratingRange.hashCode();
		ratingRange.toString();
		ratingRange.builder().build();
		assertEquals("TEST",ratingRange.getAgencyName());
	}

}
