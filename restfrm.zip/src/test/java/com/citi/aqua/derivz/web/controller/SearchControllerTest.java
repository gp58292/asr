package com.citi.aqua.derivz.web.controller;

import java.util.*;
import java.util.stream.Collectors;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.citi.aqua.derivz.commons.exceptions.CEFTException;
import com.citi.aqua.derivz.data.cache.eh.StaticCacheKeys;
import com.citi.aqua.derivz.dto.RetrievedDataResponseDTO;
import com.citi.aqua.derivz.model.columns.mapping.FieldDataType;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.services.service.impl.CacheServiceImpl;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;
import com.citi.aqua.derivz.web.utils.*;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.support.membermodification.MemberModifier;
import com.citi.aqua.derivz.dto.ListedResponseDTO;
import com.citi.aqua.derivz.services.service.BookmarkService;
import com.citi.aqua.derivz.services.service.ExportService;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.services.service.impl.BookmarkServiceImpl;
import com.citi.aqua.derivz.services.service.impl.ExportServiceImpl;
import com.citi.aqua.derivz.services.service.impl.UserSearchCriteriaServiceImpl;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import junit.framework.TestCase;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import reactor.core.publisher.Flux;

import static org.easymock.EasyMock.*;

public class SearchControllerTest extends TestCase {

    private SearchController searchController;

    private UserSearchCriteriaService userSearchCriteriaService;
    private BookmarkService bookmarkService;
    private ExportService exportService;

    private DerivzBookmarkRestRequest bookmarkRequest;
    private HttpServletResponse response;
    private HttpServletRequest request;
    private DerivzListSearchRestRequest searchSaveCriteriaRequest;
    private DerivzNonListSearchRestRequest searchSaveCriteriaNonListRequest;

    private CacheService cacheService;
    private MockCSVExporter csvExporter;

    private static final String exportRequestType = "listed";
    private static final String expectedExportResult = "c1,c2\n123,Export works fine!";

    public SearchControllerTest() {
    }

    @Before
    public void setUp() throws Exception {
        bookmarkService = EasyMock.createMockBuilder(BookmarkServiceImpl.class).createMock();
        searchController = EasyMock.createMockBuilder(SearchController.class).createMock();
        userSearchCriteriaService = EasyMock.createMockBuilder(UserSearchCriteriaServiceImpl.class).createMock();
        exportService = EasyMock.createMockBuilder(ExportServiceImpl.class).createMock();
        searchSaveCriteriaRequest = EasyMock.createMockBuilder(DerivzListSearchRestRequest.class).createMock();
        request = EasyMock.createMock(HttpServletRequest.class);
        response = EasyMock.createMock(HttpServletResponse.class);
        searchSaveCriteriaNonListRequest = EasyMock.createMockBuilder(DerivzNonListSearchRestRequest.class)
                .createMock();
        userSearchCriteriaService = EasyMock.mock(UserSearchCriteriaServiceImpl.class);
        MemberModifier.field(SearchController.class, "userSearchCriteriaService").set(searchController,
                userSearchCriteriaService);
        bookmarkService = EasyMock.mock(BookmarkServiceImpl.class);
        MemberModifier.field(SearchController.class, "bookmarkService").set(searchController, bookmarkService);
        SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken("", "", new ArrayList<>()));
        cacheService = EasyMock.createMock(CacheServiceImpl.class);
        csvExporter = EasyMock.createMockBuilder(MockCSVExporter.class).createMock();
        csvExporter.setExpectedResult(expectedExportResult);
        MemberModifier.field(SearchController.class, "cacheService").set(searchController,
                cacheService);
        MemberModifier.field(SearchController.class, "csvExporter").set(searchController,
                csvExporter);
    }

    @Test
    public void testSearchCollateralByCriteria() throws Exception {

        ListedResponseDTO listedResponseDTO = createMockListedResponseDTO();
        EasyMock.expect(userSearchCriteriaService.findUserFilterSearch(searchSaveCriteriaRequest.getCriteria()))
                .andReturn(listedResponseDTO);
        EasyMock.replay(userSearchCriteriaService);

        EasyMock.replay(searchController);
        DerivzRestResponse<ListedResponseDTO> actualBuilder = searchController
                .searchCollateralByCriteria(searchSaveCriteriaRequest);
        EasyMock.verify(searchController);
        assertEquals("20180101", actualBuilder.getResponseData().getCobDate());

    }

    @Test
    public void testExportCsv() throws CEFTException {
        CEFTDataSetRequest ceftDataSetRequest = new CEFTDataSetRequest();
        ceftDataSetRequest.setType(exportRequestType);
        ceftDataSetRequest.setBookmarkId(12345L);
        EnterpriseGetRowsRequest enterpriseGetRowsRequest = new EnterpriseGetRowsRequest();
        enterpriseGetRowsRequest.setEndRow(-1);
        ceftDataSetRequest.setGridRequest(enterpriseGetRowsRequest);
        ceftDataSetRequest.setAgreementKeys(Arrays.asList("key1", "key2"));

        Map<String,Object> resultMap = new HashMap<>();
        resultMap.put("col1", "AAA");
        resultMap.put("col2", new Integer(2));
        RetrievedDataResponseDTO responseDto = new RetrievedDataResponseDTO();
        responseDto.setCount(1L);
        responseDto.setListOfRecords(Arrays.asList(resultMap));

        EasyMock.expect(userSearchCriteriaService.searchDatasetResults(anyObject(), anyObject(),
                anyObject(), anyObject(), anyObject())).andReturn(responseDto);

        EasyMock.replay(userSearchCriteriaService);

        SearchResultColumns sc = new SearchResultColumns();
        sc.setFieldName("col1");
        sc.setDisplayName("col1");
        sc.setFieldType(FieldDataType.valueOf("STRING"));
        sc.setFieldOrder(1);
        sc.setTabId(exportRequestType);
        sc.setIsEnabled(true);
        sc.setIsDefaultDisplay(true);
        sc.setTabId(exportRequestType);
        EasyMock.expect(cacheService.getAllSearchResultColumns(anyObject(StaticCacheKeys.class)))
                .andReturn(Arrays.asList(sc));
        EasyMock.replay(cacheService);
        EasyMock.replay(csvExporter);

        ResponseEntity<Flux<String>> exportResult = searchController.exportToCsv(ceftDataSetRequest, "file1.csv");

        EasyMock.verify(userSearchCriteriaService);
        EasyMock.verify(cacheService);
        EasyMock.verify(csvExporter);

        assert(exportResult.getStatusCode().is2xxSuccessful());

        String res = exportResult.getBody().collect(Collectors.joining()).block();
        System.out.println("Result:\n" + res);
        assertEquals(expectedExportResult, res);
    }


    @Test
    public void testFindPredefinedColumns() throws Exception {

        List<SearchFieldVO> searchCriteriaVOList = createMockSearchCriteriaVO();

        EasyMock.expect(userSearchCriteriaService.findPredefinedResultSet()).andReturn(searchCriteriaVOList);
        EasyMock.replay(userSearchCriteriaService);

        EasyMock.replay(searchController);
        DerivzRestResponse<List> actualBuilder = searchController.findPredefinedColumns();
        EasyMock.verify(searchController);
        assertEquals(1, actualBuilder.getResponseData().size());

    }


    @Test
    public void testGetCollateralLookupColumns() throws Exception {

        List<SearchFieldVO> searchFieldVOList = new ArrayList<>();
        SearchFieldVO seachFieldVO = new SearchFieldVO();
        searchFieldVOList.add(seachFieldVO);
        EasyMock.expect(userSearchCriteriaService.getCollateralLookupColumns()).andReturn(searchFieldVOList);
        EasyMock.replay(userSearchCriteriaService);

        EasyMock.replay(searchController);
        DerivzRestResponse<List> actualBuilder = searchController.getCollateralLookupColumns();
        EasyMock.verify(searchController);
        assertEquals(1, actualBuilder.getResponseData().size());
    }

    private List<SearchFieldVO> createMockSearchCriteriaVO() {
        List<SearchFieldVO> searchCriteriaVOList = new ArrayList<>();
        SearchFieldVO e = new SearchFieldVO<>();
        e.setFieldName("TestField");
        e.setNodeName("TestNode");
        searchCriteriaVOList.add(e);

        return searchCriteriaVOList;
    }

    private ListedResponseDTO createMockListedResponseDTO() {
        ListedResponseDTO listedResponseDTO = new ListedResponseDTO();
        listedResponseDTO.setCobDate("20180101");
        return listedResponseDTO;
    }
}
