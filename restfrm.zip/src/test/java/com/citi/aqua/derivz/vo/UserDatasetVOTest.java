package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class UserDatasetVOTest {

	private UserDatasetVO userDatasetVO;

	@Before
	public void setUp() throws Exception {
		userDatasetVO= new UserDatasetVO();
	}

	@Test
	public void testGetDisplayName() {
		UserDatasetVO vo= new UserDatasetVO();
		vo.setShortName("TEST");
		userDatasetVO.setShortName(vo.getShortName());
		userDatasetVO.setDatasetId(vo.getDatasetId());
		userDatasetVO.setDisplayFlag(vo.getDisplayFlag());
		userDatasetVO.setDisplayName(vo.getDisplayName());
		userDatasetVO.toString();
		userDatasetVO.equals(vo);
		userDatasetVO.hashCode();
		assertEquals("TEST",userDatasetVO.getShortName());
	}

}
