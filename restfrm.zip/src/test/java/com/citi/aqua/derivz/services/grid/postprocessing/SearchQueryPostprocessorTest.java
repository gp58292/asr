package com.citi.aqua.derivz.services.grid.postprocessing;

import com.citi.aqua.derivz.services.grid.model.SearchQueryResult;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/5/2019
 */
public class SearchQueryPostprocessorTest {
    private String[][] input = {
            {"a", "av"},
            {"b", "bv"},
            {"c", "cv"},
            {"d", "dv"},
            {"null", null},
    };
    private List<Map<String, Object>> inputList = IntStream.range(0, 10)
            .mapToObj(i -> Arrays.stream(input)
                    .collect(HashMap<String, Object>::new,
                            (m, e)->m.put(e[0],e[1]!=null?(Object)(e[1] + i):null),
                            HashMap::putAll))
            .collect(Collectors.toList());


    @Test
    public void processQueryResult() {
        RowPostprocessor deleteD = input -> {
            HashMap<String, Object> res = new HashMap<>(input);
            res.remove("d");
            return res;
        };
        ColumnNamePostprocessor uppercase = new ColumnNamePostprocessor(String::toUpperCase);
        RowPostprocessor delete9Row = input-> input.get("A").equals("av9") ? null : input;
        SearchQueryPostprocessor instance = new SearchQueryPostprocessor(Arrays.asList(deleteD, uppercase, delete9Row));
        SearchQueryResult result = instance.processQueryResult(new SearchQueryResult(inputList,null, 10, 0, false));
        assertEquals(10, result.getLimit());
        assertEquals(0, result.getOffset());
        List<Map<String, Object>> rv = result.getValues();
        assertEquals(9,rv.size());
        assertTrue(rv.stream().noneMatch(m-> m.containsKey("D")));
        assertTrue(rv.stream().allMatch(m->m.keySet().stream().allMatch(k->k.equals(k.toUpperCase()))));
    }

    @Test
    public void processRowNullTerminatesProcessing() {
        RowPostprocessor p1 = mock(RowPostprocessor.class);
        when(p1.processRow(any())).thenReturn(null);
        RowPostprocessor p2 = mock(RowPostprocessor.class);
        SearchQueryPostprocessor instance = new SearchQueryPostprocessor(Arrays.asList(p1, p2));
        instance.processRow(inputList.get(0));
        verify(p1, times(1)).processRow(any());
        verify(p2, never()).processRow(any());
    }
}