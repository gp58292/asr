package com.citi.aqua.derivz.web.controller;

import static org.mockito.Mockito.when;

import org.apache.http.HttpStatus;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.services.service.AgreementService;

import junit.framework.TestCase;

public class AgreementControllerTest extends TestCase {

	@InjectMocks
	private AgreementController agreementController;
	@Mock
	private AgreementService agreementService;

	public AgreementControllerTest() {

	}

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetAgreementDetailsStatusNotFound() throws Exception {
		when(agreementService.getAgreementDetails(Matchers.anyLong())).thenThrow(DerivzApplicationException.class);
		assertEquals(HttpStatus.SC_NOT_FOUND,
				agreementController.getAgreementDetails(new Long(803778)).getResponseStatus());

	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testGetAgreementDetails() throws Exception {
		assertEquals(HttpStatus.SC_OK,
				agreementController.getAgreementDetails(new Long(803778)).getResponseStatus());

	}
	@SuppressWarnings("unchecked")
	@Test
	public void testGetCsaDetailsStatusNotFound() throws Exception {
		when(agreementService.getCsaTypeDetails(Matchers.anyLong(),Matchers.anyString())).thenThrow(DerivzApplicationException.class);
		assertEquals(HttpStatus.SC_NOT_FOUND,
				agreementController.getCsaTypeDetails(new Long(803778),"").getResponseStatus());

	}
}
