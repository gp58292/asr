package com.citi.aqua.derivz.web.utils;

import com.citi.aqua.derivz.model.columns.mapping.FieldDataType;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import org.junit.Test;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static org.junit.Assert.assertEquals;

public class ExportColumnDescriptionTest {
    private static final String requestType = "listed";
    private static final int numberOfColumns = 5;

    @Test
    public void testCreateColumnDefinitions() {
        List<SearchResultColumns> staticResultColumns = generateSearchResultColumns(numberOfColumns);

        List<ExportColumnDescription> columnDescriptions = ExportColumnDescription.MakeExportColumnDescriptions(staticResultColumns, requestType);

        assert(columnDescriptions.size() == numberOfColumns);
        assert(columnDescriptions.get(0).getName().equals("0"));
        assert(columnDescriptions.get(0).getDisplayName().equals("0"));
        assert(columnDescriptions.get(0).getFieldOrder() == 0);
        assert(columnDescriptions.get(0).getType().equals(FieldDataType.valueOf("STRING").toString()));
    }

    @Test
    public void testFilterExtraColumns() {
        int nOfColumns = 10;
        List<SearchResultColumns> staticResultColumns = generateSearchResultColumns(nOfColumns);
        staticResultColumns.get(0).setIsEnabled(false);
        staticResultColumns.get(1).setIsDefaultDisplay(false);
        staticResultColumns.get(2).setTabId("SomeOtherTab");

        List<ExportColumnDescription> columnDescriptions = ExportColumnDescription.MakeExportColumnDescriptions(staticResultColumns, requestType);

        assert(columnDescriptions.size() == nOfColumns - 3);
    }

    private List<SearchResultColumns> generateSearchResultColumns(int nColumns) {
        return IntStream.range(0, nColumns)
                .mapToObj(Integer::toString)
                .map(i -> {
                    SearchResultColumns sc = new SearchResultColumns();
                    sc.setFieldName(i);
                    sc.setTabId(requestType);
                    sc.setDisplayName(i);
                    sc.setFieldType(FieldDataType.valueOf("STRING"));
                    sc.setFieldOrder(Integer.parseInt(i));
                    sc.setIsDefaultDisplay(true);
                    sc.setIsEnabled(true);
                    return sc;
                })
                .collect(Collectors.toList());
    }

    @Test
    public void testEncodeTextAsCsvNoLeadingZero() {
        Object[][] data = new Object[][]{
                {"", ""},
                {"\"", "\"\"\"\""},
                {"a, b", "\"a, b\""},
                {"12", "12"},
                {"012", "012"},
                {"1e2", "1e2"},
                {"01E2", "01E2"},
                {"a01E2", "a01E2"},
                {Integer.valueOf(12), "12"},
                {new String("Encode me"), "Encode me"},
        };
        for (Object[] condition : data) {
            assertEquals(condition[1], ExportColumnDescription.encodeTextAsCsvNoLeadingZero(condition[0]));
        }
    }


}
