package com.citi.aqua.derivz.services.grid;

import com.citi.aqua.frm.framework.grid.data.*;
import org.junit.Test;

import java.time.Duration;
import java.time.Instant;

import static com.citi.aqua.derivz.services.grid.TestObjectProvider.SAMPLE_FRM_DATA_SET_ID;
import static com.citi.aqua.derivz.services.grid.TestObjectProvider.SAMPLE_FRM_DATA_SET_VERSION;
import static com.citi.aqua.derivz.services.grid.TestObjectProvider.SAMPLE_SOE_ID;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/17/2019
 */
public class CeftDataSetStatusTest {

    LoadingProcessStatus lastOperationStateCompleted = new LoadingProcessStatus(
            Instant.now().minusSeconds(10L), Duration.ofSeconds(10L), 100L, 100L, true, LoadingStatus.SUCCESS,
            null);
    LoadingProcessStatus lastOperationStateRunning = new LoadingProcessStatus(
            Instant.now().minusSeconds(10L), Duration.ofSeconds(10L), 100L, 10L, true, LoadingStatus.SUCCESS,
            null);

    @Test
    public void testStatus() {

        DataSetStatus dataSetStatus = new DataSetStatus(SAMPLE_FRM_DATA_SET_ID,
                SAMPLE_FRM_DATA_SET_VERSION,
                DataSetStatusCode.READY, 100L, lastOperationStateCompleted, false);

        CeftDataSetStatus completeStatus = new CeftDataSetStatus(dataSetStatus, SAMPLE_SOE_ID);
        assertTrue(completeStatus.isReady());
        assertEquals(1.0, completeStatus.getLoadingProgress(), 0.0000001);


        CeftDataSetStatus runningStatus = new CeftDataSetStatus(dataSetStatus
                .toBuilder()
                .status(DataSetStatusCode.LOADING)
                .lastOperationState(lastOperationStateRunning)
                .build(),
                SAMPLE_SOE_ID);
        assertFalse(runningStatus.isReady());
        assertEquals(0.1, runningStatus.getLoadingProgress(), 0.0000001);

        CeftDataSetStatus emptyStatus = new CeftDataSetStatus(dataSetStatus.toBuilder()
                .status(DataSetStatusCode.NOT_LOADED)
                .lastOperationState(null)
                .build(), SAMPLE_SOE_ID);
        assertFalse(emptyStatus.isReady());
        assertNull(emptyStatus.getLoadingProgress());
    }

    @Test
    public void testGetLoadingProgress() {
        LoadingProcessStatus state = new LoadingProcessStatus(
                Instant.now().minusSeconds(10L), Duration.ofSeconds(10L), -1L, 0L, true, LoadingStatus.SUCCESS,
                null);

        DataSetStatus dataSetStatus = new DataSetStatus(SAMPLE_FRM_DATA_SET_ID,
                SAMPLE_FRM_DATA_SET_VERSION,
                DataSetStatusCode.READY, -1L, state, false);

        CeftDataSetStatus completeStatus = new CeftDataSetStatus(dataSetStatus, SAMPLE_SOE_ID);
        assertEquals(1.0, completeStatus.getLoadingProgress(), Double.MIN_VALUE);
    }
}