package com.citi.aqua.derivz.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.LinkedList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit4.SpringRunner;
import com.citi.aqua.derivz.vo.ReferenceDataVO;

@RunWith(SpringRunner.class)
public class ReferenceUtilsTest {

	@InjectMocks
	ReferenceUtils referenceUtils;

	@Test
	public void testFindSearchedList() {
		List<ReferenceDataVO> referenceResponseData = new LinkedList<>();
		ReferenceDataVO referenceDataVO1 = new ReferenceDataVO();
		referenceDataVO1.setValue("Test1");
		ReferenceDataVO referenceDataVO2 = new ReferenceDataVO();
		referenceDataVO2.setValue("Test2");
		ReferenceDataVO referenceDataVO3 = new ReferenceDataVO();
		referenceDataVO3.setValue("3_Test");
		ReferenceDataVO referenceDataVO4 = new ReferenceDataVO();
		referenceDataVO4.setValue("Exempt");
		referenceResponseData.add(referenceDataVO1);
		referenceResponseData.add(referenceDataVO2);
		referenceResponseData.add(referenceDataVO3);
		referenceResponseData.add(referenceDataVO4);

		assertNotNull("The collateral lookup column list is not null",
				referenceUtils.findSearchedList(referenceResponseData, "Test"));
		assertEquals(3, referenceUtils.findSearchedList(referenceResponseData, "Test").size());
	}

}
