package com.citi.aqua.derivz.utils;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.Test;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.assertEquals;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 9/26/2019
 */
public class LogUtilsTest {

    @Test
    public void listForLogging() {
        assertEquals("[[NULL LIST]]", LogUtils.listForLogging(null));
        assertEquals("[]", LogUtils.listForLogging(emptyList()));
        assertEquals("[1, 2, \"3\"]", LogUtils.listForLogging(asList(1, 2, "3")));
        assertEquals("[1, 2, 3, 4, 5, ...(2 items more)]", LogUtils.listForLogging(asList(1, 2, 3, 4, 5, 6, 7)));
        String longString = IntStream.range(0, 2 * LogUtils.MAX_STRING_ENTRY_LENGTH).mapToObj(i -> "" + i % 10).collect(
                Collectors.joining());
        assertEquals("[1, \"" + longString.substring(0, LogUtils.MAX_STRING_ENTRY_LENGTH - 3) + "...\"]",
                LogUtils.listForLogging(asList(1, longString)));
    }


    private Map<String, Object> asMap(List<String> keys, List<Object> values) {
        return IntStream.range(0, keys.size())
                .mapToObj(i -> new ImmutablePair<>(keys.get(i), values.get(i)))
                .collect(Collectors.toMap(ImmutablePair::getLeft, ImmutablePair::getRight));
    }

    @Test
    public void mapForLogging() {
        assertEquals("{{NULL MAP}}", LogUtils.mapForLogging(null));
        assertEquals("{}", LogUtils.mapForLogging(emptyMap()));
        assertEquals("{x=1, y=\"2\"}", LogUtils.mapForLogging(asMap(asList("x", "y"), asList(1, "2"))));
        assertEquals("{x=1, y=\"123...\"}", LogUtils.mapForLogging(asMap(asList("x", "y"), asList(1, "12345678")), 6));

        Map<String, String> m = IntStream.range(0, LogUtils.MAX_LOGGED_MAP_ENTRIES + 2)
                .mapToObj(i -> String.format("%03d", i))
                .collect(Collectors.toMap(s -> s, s -> s));

        String overflowLog = LogUtils.mapForLogging(m);
        assertTrue(overflowLog.endsWith(" ...(2 entries more)}"));
    }


    @Test
    public void overflowEllipsis() {
        assertEquals("", LogUtils.overflowEllipsis(0, "any"));
        assertEquals("", LogUtils.overflowEllipsis(-10, "any"));
        assertEquals(", ...(1 more)", LogUtils.overflowEllipsis(1, null));
        assertEquals(", ...(10 items more)", LogUtils.overflowEllipsis(10, "items"));
    }

    @Test
    public void queryResultMapToString() {
        assertEquals("NULL RESULT", LogUtils.queryResultMapToString(null));
        assertEquals("[[Total 1 rows: { row 1: [col1=1, col2=\"2\"]}]]",
                LogUtils.queryResultMapToString(
                        Collections.singletonList(asMap(asList("col1", "col2"), asList(1, "2")))));
    }


    @Test
    public void mapValue() {
        assertEquals("1", LogUtils.mapValue(1, 10));
        assertEquals("null", LogUtils.mapValue(null, 10));
        assertEquals("\"aa\"", LogUtils.mapValue("aa", 10));
        assertEquals("\"123...\"", LogUtils.mapValue("1234567890", 6));
        assertEquals("123...", LogUtils.mapValue(1234567890, 6));
    }
}