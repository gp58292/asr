package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class RatingFieldVOTest {
	
	private RatingFieldVO ratingFieldVO;

	@Before
	public void setUp() throws Exception {
		ratingFieldVO= new RatingFieldVO<>();
	}

	@Test
	public void testGetIssuerFlag() {
		RatingFieldVO vo= new RatingFieldVO<>();
		vo.setAndOr("AND");
		ratingFieldVO.setAndOr(vo.getAndOr());
		ratingFieldVO.setIssuerFlag(vo.getIssuerFlag());
		ratingFieldVO.setRatingEnd(vo.getRatingEnd());
		ratingFieldVO.setRatingStart(vo.getRatingStart());
		ratingFieldVO.setSeq(vo.getSeq());
		ratingFieldVO.toString();
		ratingFieldVO.equals(vo);
		ratingFieldVO.hashCode();
		ratingFieldVO.builder().build();
		assertEquals("AND",ratingFieldVO.getAndOr());
	}

}
