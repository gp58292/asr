package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TableNodeVOTest {

	private TableNodeVO tableNodeVO;

	@Before
	public void setUp() throws Exception {
		tableNodeVO= new TableNodeVO();
	}

	@Test
	public void testGetName() {
		TableNodeVO vo= new TableNodeVO();
		vo.setName("TEST");
		tableNodeVO.setName(vo.getName());
		tableNodeVO.setChildren(vo.getChildren());
		tableNodeVO.equals(vo);
		tableNodeVO.hashCode();
		tableNodeVO.toString();
		assertEquals("TEST",tableNodeVO.getName());
	}

}
