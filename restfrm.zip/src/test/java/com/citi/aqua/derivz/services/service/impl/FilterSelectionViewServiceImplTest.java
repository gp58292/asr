
package com.citi.aqua.derivz.services.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import com.citi.aqua.derivz.data.repository.CustomFieldRepository;
import com.citi.aqua.derivz.data.repository.SelectionFiltersRepository;
import com.citi.aqua.derivz.model.CustomAttributes;
import com.citi.aqua.derivz.model.SelectionFilters;

@RunWith(SpringRunner.class)
public class FilterSelectionViewServiceImplTest {

	@InjectMocks
	FilterSelectionViewServiceImpl filterSelectionViewServiceImpl;

	@Mock
	CombinedColumnsImpl combinedColumns;
	

	@Mock
	SelectionFiltersRepository selectionFiltersRepo;
	  
	@Mock
	CustomFieldRepository customFieldRepository;
	  
	// @Mock
	// HttpServletResponse response;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testFindFlatViewFilterList() throws IOException {

		final List<SelectionFilters> filterSelectionList = new ArrayList<>();
		final List<CustomAttributes> customAttributeList = new ArrayList<>();

		SelectionFilters selectionFilter = new SelectionFilters();

		filterSelectionList.add(selectionFilter);
		when(selectionFiltersRepo.findAll()).thenReturn(filterSelectionList);
        when(customFieldRepository.findAll()).thenReturn(customAttributeList);;
		when(combinedColumns.findAll(false)).thenReturn(filterSelectionList);
		
		
		assertEquals(1, filterSelectionViewServiceImpl.findFlatViewFilterList().size());

	}
	@Test
	public void testFindTreeViewFilterList() throws IOException {

		final List<SelectionFilters> filterSelectionList = new ArrayList<>();
		final List<CustomAttributes> customAttributeList = new ArrayList<>();

		SelectionFilters selectionFilter = new SelectionFilters();

		filterSelectionList.add(selectionFilter);
		when(selectionFiltersRepo.findAll()).thenReturn(filterSelectionList);
        when(customFieldRepository.findAll()).thenReturn(customAttributeList);
		when(combinedColumns.findAll(true)).thenReturn(filterSelectionList);

		assertEquals(1, filterSelectionViewServiceImpl.findTreeViewFilterList().size());

	}

}
