package com.citi.aqua.derivz.commons.utils;

import static org.junit.Assert.assertEquals;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

public class DBCommonUtilsTest {
	DBCommonUtils dBCommonUtils = new DBCommonUtils();

	DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	DateTimeFormatter fullDateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss Z yyyy");

	LocalDate localDate = LocalDate.now();

	@Test
	public void testconvertDateToString() throws Exception {
		Date inputDate = new Date();
		assertEquals(dateFormat.format(localDate), dBCommonUtils.convertDateToString(inputDate));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	public void testcreateInValueForProc() throws Exception {
		List valueList = new ArrayList<>();
		valueList.add("testvalue");
		assertEquals("'testvalue'|~", dBCommonUtils.createInValueForProc(valueList));
	}
	
	@Test
	public void testCreateNumberRangeValueForProc() throws Exception {
		Object numberStartRangeValue = "test";
		Object numberEndRangeValue  = "test";
		String result=dBCommonUtils.creatRangeValueForProc(numberStartRangeValue, numberEndRangeValue);
		assertEquals("test|~test|~",result);
	}
	
	
	@Test
	public void testCreateDateRangeValueForProc() throws Exception {
		Date dateStartRangeValue = new Date();
		Date dateEndRangeValue = new Date();
		StringBuilder sb = new StringBuilder();
		sb.append("'" + dateFormat.format(localDate) + "'|~");
		sb.append("'" + dateFormat.format(localDate) + "'|~");
		String result=dBCommonUtils.creatRangeValueForProc(dateStartRangeValue, dateEndRangeValue);
		assertEquals(sb.toString(), result);
	}

//	@Test
//	public void testcreateIncludeExcludeValue() throws Exception {
//		Date dateStartRangeValue = new Date();
//		Date dateEndRangeValue = new Date();
//		StringBuilder sb = new StringBuilder();
//		sb.append("'" + dateFormat.format(localDate) + "'|~");
//		sb.append("'" + dateFormat.format(localDate) + "'|~");
//		assertEquals(sb.toString(), dBCommonUtils.createRangeConditioneForProc(dateStartRangeValue, dateEndRangeValue));
//	}

	@SuppressWarnings("static-access")
	@Test
	public void testformattingString() throws Exception {
		String input = "s_m_e";
		assertEquals("sme", dBCommonUtils.formattingString(input));
	}

	@Test
	public void testreplaceCamelCaseToUnderscoreSeparated() throws Exception {
		String input = "currentCode";
		assertEquals("current_code", dBCommonUtils.replaceCamelCaseToUnderscoreSeparated(input));
	}

	@Test
	public void testcreateNumberRangeConditioneForProc() throws Exception {
		Object numberStartRangeValue = "test";
		Object numberEndRangeValue = "test";
		String result=dBCommonUtils.createRangeConditioneForProc(numberStartRangeValue, numberEndRangeValue);
		assertEquals(">=|~<=|~",result );		
	}

	@Test
	public void testconvertTimeStamptoDateFormat() throws Exception {
		Date inputDate = new Date();				
		Timestamp timestamp = new Timestamp(inputDate.getTime());
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
		final String timeStampToString = simpleDateFormat.format(inputDate);
		assertEquals(simpleDateFormat.parse(timeStampToString), dBCommonUtils.convertTimeStamptoDateFormat(timestamp));
	}

	@Test
	public void testcreateDateRangeConditioneForProc() throws Exception {
		Date dateStartRangeValue= new Date();
		Date dateEndRangeValue= new Date();
		assertEquals(">=|~<=|~", dBCommonUtils.createRangeConditioneForProc(dateStartRangeValue, dateEndRangeValue));			
	}

	@Test
	public void testcreateIncludeExcludeCondition() throws Exception {
		List orValuesList = new ArrayList<>();
		orValuesList.add("test");
		List andValueList = new ArrayList<>();
		andValueList.add("test");
		List butNotValuesList = new ArrayList<>();
		butNotValuesList.add("test");
		assertEquals("AND|~NOT IN|~", dBCommonUtils.createIncludeExcludeCondition(andValueList, orValuesList, butNotValuesList));		
	}
}
