package com.citi.aqua.derivz.services.grid.impl;

import com.citi.aqua.derivz.services.grid.CeftDataSet;
import com.citi.aqua.derivz.services.grid.CeftFrmQueryService;
import com.citi.aqua.derivz.services.grid.model.SecondaryColumnEntry;
import com.citi.aqua.derivz.vo.aggrid.filter.ColumnFilter;
import com.citi.aqua.derivz.vo.aggrid.filter.SetColumnFilter;
import com.citi.aqua.derivz.vo.aggrid.request.ColumnVO;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;
import com.citi.aqua.frm.ceft.CeftDataSetType;
import com.citi.aqua.frm.framework.grid.DataSetQueryService;
import com.citi.aqua.frm.framework.grid.query.DirectSqlQuery;
import com.citi.aqua.frm.framework.grid.query.QueryResult;
import com.citi.aqua.frm.framework.grid.tools.FrmGrid;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

import static java.util.Arrays.asList;
import static java.util.Collections.*;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/10/2019
 */
@RunWith(MockitoJUnitRunner.class)
public class CeftFrmGroupingPivotQueryServiceImplTest {

    private static final List<ColumnVO> SAMPLE_PIVOT_COLUMNS = Arrays.asList(
            new ColumnVO("f1", null, "f1", null),
            new ColumnVO("f2", null, "f2", null),
            new ColumnVO("f3", null, "f3", null)
    );
    private static final List<ColumnVO> SAMPLE_GROUP_COLUMNS = singletonList(new ColumnVO("gf1_a1", null, "gf1", null));
    private static final List<String> SAMPLE_GROUP_VALUES = singletonList("gf1_v1");
    private static final List<ColumnVO> SAMPLE_AGG_COLUMNS = singletonList(new ColumnVO("af1", null, "af1", "sum"));

    private final CeftDataSet testCeftDataSet = new CeftDataSet("testSoeId", 10L, CeftDataSetType.FMTM);
    private EnterpriseGetRowsRequest samplePivotRequest = null;
    @Mock
    FrmGrid grid;

    @Mock
    DataSetQueryService queryService;

    @Mock
    CeftFrmQueryService ceftQueryService;

    CeftFrmGroupingPivotQueryServiceImpl instance;


    @Before
    public void setup() {
        instance=new CeftFrmGroupingPivotQueryServiceImpl(grid, null, ceftQueryService, 100);
        when(grid.connectQueryService()).thenReturn(queryService);
        when(queryService.getDataSetSQLNamespace(any(), any())).thenReturn("namespace");
        when(queryService.getDataSetSQLTableName(any(), any())).thenReturn("table");

        when(queryService.queryDatasetDirect(any(), any())).thenReturn(
                new QueryResult(Duration.ofSeconds(1L), new ArrayList<>()));

//        when(queryService.getCacheNameForDataset(any(), any())).thenReturn("cache");
        when(ceftQueryService.distinctValuesQuery(any(), anyMap(), eq("f1"))).thenReturn(Arrays.asList("f1v1", "f1v2"));
        when(ceftQueryService.distinctValuesQuery(any(), anyMap(), eq("f2"))).thenReturn(singletonList("f2v1"));
        when(ceftQueryService.distinctValuesQuery(any(), anyMap(), eq("f3"))).thenReturn(Arrays.asList("f3v1", "f3v2"));

        samplePivotRequest = new EnterpriseGetRowsRequest();
        samplePivotRequest.setValueCols(SAMPLE_AGG_COLUMNS);
        samplePivotRequest.setStartRow(10);
        samplePivotRequest.setEndRow(20);
        samplePivotRequest.setPivotCols(SAMPLE_PIVOT_COLUMNS);
        samplePivotRequest.setRowGroupCols(SAMPLE_GROUP_COLUMNS);
        samplePivotRequest.setGroupKeys(SAMPLE_GROUP_VALUES);
        samplePivotRequest.setPivotMode(true);

    }

    @Test
    public void buildAggregateQuery() {
        EnterpriseGetRowsRequest request = new EnterpriseGetRowsRequest();
        request.setRowGroupCols(asList(new ColumnVO("a_1", null, "a", null),
                new ColumnVO("b_1", null, "b", null))
        );
        request.setGroupKeys(singletonList("v2"));

        request.setValueCols(Arrays.asList(
                new ColumnVO("col1_1", null, "col1", "sum"),
                new ColumnVO("col2_1", null, "col2", "count")
        ));
        Map<String, ColumnFilter> filterMap = new HashMap<>();
        filterMap.put("fc1", new SetColumnFilter(Arrays.asList("fv1", null)));
        filterMap.put("fc2", new SetColumnFilter(Collections.singletonList("fv2")));
        request.setFilterModel(filterMap);
        request.setStartRow(0);
        request.setEndRow(10);
        String res = instance.buildAggregateQuery(request, testCeftDataSet);
        assertEquals(
                "SELECT a AS a_1, b AS b_1, SUM(col1) AS col1_1, COUNT(col2) AS col2_1, COUNT(*) AS __child_count  "
                        + "FROM namespace.table WHERE a='v2' "
                        + "AND (fc1='fv1' OR (fc1='' OR fc1 IS NULL)) "
                        + "AND fc2='fv2' GROUP BY a, b LIMIT 10 OFFSET 0",
                res
        );
    }


    @Test
    public void testCartesian() {

        List<Object> c1 = asList(1, 2, null);
        List<Object> c2 = asList("a", "b");
        List<Object> c3 = Collections.singletonList(12L);

        List<List<Object>> expRes = asList(
                asList(1, "a", 12L),
                asList(1, "b", 12L),
                asList(2, "a", 12L),
                asList(2, "b", 12L),
                asList(null, "a", 12L),
                asList(null, "b", 12L)
        );
        assertEquals(expRes, CeftFrmGroupingPivotQueryServiceImpl.cartesian(asList(c1, c2, c3)));

        //test on empty:
        assertEquals(emptyList(), CeftFrmGroupingPivotQueryServiceImpl.cartesian(emptyList()));
        //test on one list:
        expRes = asList(
                Collections.singletonList("1"),
                Collections.singletonList("2")
        );
        assertEquals(expRes, CeftFrmGroupingPivotQueryServiceImpl.cartesian(Collections.singletonList(asList("1", "2"))));
    }

    @Test
    public void buildFromClause() {
        String from = instance.buildFromClause(testCeftDataSet);
        assertEquals(" FROM namespace.table", from);
    }

    @Test
    public void isAggregate() {
        EnterpriseGetRowsRequest request = new EnterpriseGetRowsRequest();

        request.setRowGroupCols(asList(new ColumnVO("a_1", null, "a", null)
                , new ColumnVO("b_1", null, "b", null))
        );
        request.setGroupKeys(emptyList());
        assertTrue(instance.isAggregate(request));

        request.setGroupKeys(Collections.singletonList("v2"));
        assertTrue(instance.isAggregate(request));

        request.setGroupKeys(asList("v2", "v2"));
        assertFalse(instance.isAggregate(request));
    }

    @Test
    public void testEqClause() {
        assertEquals("col='val'", CeftFrmGroupingPivotQueryServiceImpl.buildEqCondition("col", "val"));
        assertEquals("(col='' OR col IS NULL)", CeftFrmGroupingPivotQueryServiceImpl.buildEqCondition("col", null));
        assertEquals("(col='' OR col IS NULL)", CeftFrmGroupingPivotQueryServiceImpl.buildEqCondition("col", ""));
    }

    @Test
    public void testSelectClause() {

        String q1 = CeftFrmGroupingPivotQueryServiceImpl.buildSelectClause(true,
                Arrays.asList(
                        new ColumnVO("acol1", null, "col1", null),
                        new ColumnVO("acol1_1", null, "col1", null),
                        new ColumnVO("acol2", null, "col2", null)
                ),
                Arrays.asList(
                        new ColumnVO("acol1", null, "col1", null),
                        new ColumnVO("acol3", null, "col3", null)
                )
        );
        assertEquals("SELECT col1 AS acol1, col1 AS acol1_1, col2 AS acol2, col3 AS acol3, *", q1);
        try {
            CeftFrmGroupingPivotQueryServiceImpl.buildSelectClause(true,
                    Arrays.asList(
                            new ColumnVO("acol1", null, "col1", null),
                            new ColumnVO("acol1_1", null, "col1", null),
                            new ColumnVO("acol2", null, "col2", null)
                    ),
                    Arrays.asList(
                            new ColumnVO("acol1", null, "col1", "sum"),
                            new ColumnVO("acol3", null, "col3", null)
                    )
            );
            fail("Passed two times same alias.");
        } catch (IllegalArgumentException ie) {
            //that's OK
        }
        try {
            CeftFrmGroupingPivotQueryServiceImpl.buildSelectClause(true,
                    Arrays.asList(
                            new ColumnVO("acol1", null, "col1", null),
                            new ColumnVO("acol1_1", null, "col1", null),
                            new ColumnVO("acol2", null, "col2", null)
                    ),
                    Arrays.asList(
                            new ColumnVO("acol1", null, "col2", null),
                            new ColumnVO("acol3", null, "col3", null)
                    )
            );
            fail("Passed two times same alias.");
        } catch (IllegalArgumentException ie) {
            //that's OK
        }

    }

    @Test
    public void buildSecondaryPivotColumnHierarchy() {
        List<ColumnVO> columns = Arrays.asList(
                new ColumnVO("f1_id", "Field 1", "f1", null),
                new ColumnVO("f2_id", "Field 2", "f2", null),
                new ColumnVO("f3_id", "Field 3", "f3", null)
        );
        List<List<Object>> rawValues = Arrays.asList(
                Arrays.asList("v1_1", "v1_2"),
                Arrays.asList("v2_1", "v2_2"),
                Arrays.asList(1, 2)
        );
        List<List<Object>> colValues = CeftFrmGroupingPivotQueryServiceImpl.cartesian(rawValues);
        ColumnVO aggregations = new ColumnVO("agf", "Aggregation field", "agf", "sum");
        List<CeftFrmGroupingPivotQueryServiceImpl.PivotColumnEntry> pivotCols = colValues
                .stream()
                .map(valList -> new CeftFrmGroupingPivotQueryServiceImpl.PivotColumnEntry(columns, valList,
                        aggregations, valList.stream().map(v -> "" + v).collect(
                        Collectors.joining("|"))))
                .collect(Collectors.toList());

        List<SecondaryColumnEntry> res =
                CeftFrmGroupingPivotQueryServiceImpl.buildSecondaryPivotColumnHierarchy(pivotCols);
        assertEquals(2, res.size());

        SecondaryColumnEntry h1 = res.get(0);
        assertEquals("v1_1", h1.getHeaderName());

        SecondaryColumnEntry h2 = h1.getChildren().get(0);
        assertEquals("v2_1", h2.getHeaderName());

        SecondaryColumnEntry h3 = h2.getChildren().get(0);
        assertEquals("1", h3.getHeaderName());

        assertEquals(1, h3.getChildren().size());

        SecondaryColumnEntry finalCol = h3.getChildren().get(0);
        assertNull(finalCol.getChildren());
        assertEquals("sum(Aggregation field)", finalCol.getHeaderName());
    }


    @Test
    public void testColumnPivotGeneration() {
        CeftFrmGroupingPivotQueryServiceImpl.PivotColumnEntry entry =
                new CeftFrmGroupingPivotQueryServiceImpl.PivotColumnEntry(SAMPLE_PIVOT_COLUMNS,
                        Arrays.asList("v1", 2, null),
                        new ColumnVO("af_alias", null, "af", "sum"),
                        "col_alias");
        String clause = entry.pivotColumnSelectClause();
        assertNotNull(clause);
        assertEquals("sum(CASE WHEN (f1='v1' AND f2=2 AND (f3='' OR f3 IS NULL)) THEN af END) AS \"col_alias\"",
                clause);
    }

    @Test
    public void testSearchGroupingPivotQueryAsPivot() {
        final ArgumentCaptor<DirectSqlQuery> captor = ArgumentCaptor.forClass(DirectSqlQuery.class);
        instance.searchGroupingPivotQuery(samplePivotRequest, testCeftDataSet);
        verify(queryService).queryDatasetDirect(captor.capture(), eq(testCeftDataSet.toUser()));
        DirectSqlQuery directSqlQuery = captor.getValue();
        String sqlQuery = directSqlQuery.getSqlQuery();
        assertTrue(sqlQuery.matches(
                "SELECT gf1 AS gf1_a1, "
                        + "sum\\(CASE WHEN \\(f1='f1v1' AND f2='f2v1' AND f3='f3v1'\\) THEN af1 END\\) AS "
                        + "\"PIVOT\\|f1v1\\|f2v1\\|f3v1\\|sum\\(af1\\)\", "
                        + ".* "
                        + "FROM namespace.table WHERE gf1='gf1_v1' GROUP BY gf1 LIMIT 10 OFFSET 10"));
    }

    @Test
    public void testSearchGroupingPivotQueryAsPlain() {
        samplePivotRequest.setPivotMode(false);
        final ArgumentCaptor<DirectSqlQuery> captor = ArgumentCaptor.forClass(DirectSqlQuery.class);
        instance.searchGroupingPivotQuery(samplePivotRequest, testCeftDataSet);
        verify(queryService).queryDatasetDirect(captor.capture(), eq(testCeftDataSet.toUser()));
        DirectSqlQuery directSqlQuery = captor.getValue();
        String sqlQuery = directSqlQuery.getSqlQuery();
        assertEquals("SELECT gf1 AS gf1_a1, af1 AS af1, * FROM namespace.table WHERE gf1='gf1_v1' LIMIT 10 OFFSET 10",
                sqlQuery);
    }

    @Test
    public void testSearchGroupingPivotQueryAsGrouping() {
        samplePivotRequest.setPivotMode(false);
        samplePivotRequest.setGroupKeys(emptyList());
        final ArgumentCaptor<DirectSqlQuery> captor = ArgumentCaptor.forClass(DirectSqlQuery.class);
        instance.searchGroupingPivotQuery(samplePivotRequest, testCeftDataSet);
        verify(queryService).queryDatasetDirect(captor.capture(), eq(testCeftDataSet.toUser()));
        DirectSqlQuery directSqlQuery = captor.getValue();
        String sqlQuery = directSqlQuery.getSqlQuery();
        assertEquals("SELECT gf1 AS gf1_a1, SUM(af1) AS af1, COUNT(*) AS __child_count  "
                        + "FROM namespace.table  GROUP BY gf1 LIMIT 10 OFFSET 10",
                sqlQuery);
    }

    @Test
    public void testCountGroupingPivotQueryAsPivot() {
        final ArgumentCaptor<DirectSqlQuery> captor = ArgumentCaptor.forClass(DirectSqlQuery.class);
        when(queryService.queryDatasetDirect(any(), any())).thenReturn(
                new QueryResult(Duration.ofSeconds(1), new ArrayList<>(singletonList(singletonMap("count", 101L)))));
        long res = instance.countGroupingPivotQuery(samplePivotRequest, testCeftDataSet);
        assertEquals(101L, res);
        verify(queryService).queryDatasetDirect(captor.capture(), eq(testCeftDataSet.toUser()));
        DirectSqlQuery directSqlQuery = captor.getValue();
        String sqlQuery = directSqlQuery.getSqlQuery();
        assertTrue(sqlQuery.matches("SELECT COUNT\\(\\*\\) FROM \\(SELECT 1\\s+FROM .*GROUP BY gf1\\)"));
    }


    @Test
    public void testSearchGroupingPivotQueryAsPivotFailsOnIncomplete() {

        samplePivotRequest.setGroupKeys(emptyList());
        samplePivotRequest.setRowGroupCols(emptyList());
        try {
            instance.searchGroupingPivotQuery(samplePivotRequest, testCeftDataSet);
            fail("Passed incomplete request");
        } catch (RuntimeException re) {
            //expected
        }

    }

}