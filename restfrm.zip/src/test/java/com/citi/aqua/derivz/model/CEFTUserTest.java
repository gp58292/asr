package com.citi.aqua.derivz.model;

import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

public class CEFTUserTest {

	private static final String TEST = "test";
	private static final Long ID = new Long(0);
	private CEFTUser ceftUser;
	@Before
	public void setUp() throws Exception {
		ceftUser= new CEFTUser();
	}

	@Test
	public void testGetId() {
		ceftUser.setId(ID);
		assertEquals(ID,ceftUser.getId());
	}

	@Test
	public void testGetSoeid() {
		ceftUser.setSoeid(TEST);
		assertEquals(TEST,ceftUser.getSoeid());
	}

	@Test
	public void testGetFriendlyName() {
		ceftUser.setFriendlyName(TEST);
		assertEquals(TEST,ceftUser.getFriendlyName());
	}

	@Test
	public void testGetDomainName() {
		ceftUser.setDomainName(TEST);
		assertEquals(TEST,ceftUser.getDomainName());
	}

	@Test
	public void testGetEmail() {
		ceftUser.setEmail(TEST);
		assertEquals(TEST,ceftUser.getEmail());
	}

	@Test
	public void testGetGroupName() {
		ceftUser.setGroupName(TEST);
		assertEquals(TEST,ceftUser.getGroupName());
	}

	@Test
	public void testGetGroupEmail() {
		ceftUser.setGroupEmail(TEST);
		assertEquals(TEST,ceftUser.getGroupEmail());
	}

	@Test
	public void testGetManagerSoeId() {
		ceftUser.setManagerSoeId(TEST);
		assertEquals(TEST,ceftUser.getManagerSoeId());
	}

	@Test
	public void testGetCreatedTime() {
		ceftUser.setCreatedTime(new Timestamp(new Date().getTime()));
		assertNotNull(ceftUser.getCreatedTime());
	}

	@Test
	public void testGetCreatedBy() {
		ceftUser.setCreatedBy(TEST);
		assertEquals(TEST,ceftUser.getCreatedBy());
	}

	@Test
	public void testGetModifiedBy() {
		ceftUser.setModifiedBy(TEST);
		assertEquals(TEST,ceftUser.getModifiedBy());
	}

	@Test
	public void testGetModifiedTime() {
		ceftUser.setModifiedTime(new Timestamp(new Date().getTime()));
		assertNotNull(ceftUser.getModifiedTime());
	}

	@Test
	public void testGetStatus() {
		ceftUser.setStatus(TEST);
		assertEquals(TEST,ceftUser.getStatus());
	}

	@Test
	public void testGetUserRole() {
		ceftUser.setUserRole(TEST);
		assertEquals(TEST,ceftUser.getUserRole());
	}

	@Test
	public void testGetCeftAccess() {
		ceftUser.setCeftAccess(TEST);
		assertEquals(TEST,ceftUser.getCeftAccess());
	}

	@Test
	public void testGetVoyagerAccess() {
		ceftUser.setVoyagerAccess(TEST);
		assertEquals(TEST,ceftUser.getVoyagerAccess());
	}

	@Test
	public void testToString() {
		assertNotNull(ceftUser.toString());
	}
}
