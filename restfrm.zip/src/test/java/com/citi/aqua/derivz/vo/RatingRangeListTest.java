package com.citi.aqua.derivz.vo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;


public class RatingRangeListTest {
	RatingRangeList ratingRangeList;

	@Before
	public void setUp() throws Exception {
		ratingRangeList=new RatingRangeList();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetValueList() {
		RatingRangeList list=new RatingRangeList();
		//list.setInValueList(new RatingRange[] {});
		list.setValueList(new RatingRange[] {});
		ratingRangeList.setValueList(list.getValueList());
		ratingRangeList.builder().build();
		ratingRangeList.toString();
		ratingRangeList.hashCode();
		ratingRangeList.equals(list);
		assertEquals(0,ratingRangeList.getValueList().length);
	}

}
