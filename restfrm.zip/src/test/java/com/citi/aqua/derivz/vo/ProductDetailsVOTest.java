package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ProductDetailsVOTest {
	
	private static final String TEST = "TEST";
	ProductDetailsVO productDetailsVO;

	@Before
	public void setUp() throws Exception {
		productDetailsVO= new ProductDetailsVO();
	}

	@Test
	public void testGetInstrumentCode() {
		ProductDetailsVO vo= new ProductDetailsVO();
		vo.setInstrumentCode(4);
		vo.setCovProdType(TEST);
		vo.setIncludeExclude(TEST);
		vo.setInstrumentName(TEST);
		vo.setParentInstrCode(4);
		productDetailsVO.setCovProdType(vo.getCovProdType());
		productDetailsVO.setIncludeExclude(vo.getIncludeExclude());
		productDetailsVO.setInstrumentCode(vo.getInstrumentCode());
		productDetailsVO.setInstrumentName(vo.getInstrumentName());
		productDetailsVO.setParentInstrCode(vo.getParentInstrCode());
		
		productDetailsVO.hashCode();
		productDetailsVO.toString();
		productDetailsVO.equals(vo);
		assertEquals(new Integer(4),productDetailsVO.getInstrumentCode());
	}

}
