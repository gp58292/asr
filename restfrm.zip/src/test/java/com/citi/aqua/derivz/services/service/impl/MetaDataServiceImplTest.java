
package com.citi.aqua.derivz.services.service.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.citi.aqua.derivz.data.repository.SelectionFiltersRepository;
import com.citi.aqua.derivz.data.repository.TableMetadataRepository;
import com.citi.aqua.derivz.model.SelectionFilters;
import com.citi.aqua.derivz.model.TableMetaData;

@RunWith(SpringRunner.class)
public class MetaDataServiceImplTest {

	@InjectMocks
	MetaDataServiceImpl metaDataServiceImpl;

	@Mock
	TableMetadataRepository tableMetadataRepository;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testFindAll() throws IOException {
		List<TableMetaData> tableList = new ArrayList<>();
		TableMetaData tableData = new TableMetaData();
		tableList.add(tableData);
		when(tableMetadataRepository.findAll()).thenReturn(tableList);

		assertEquals(1, metaDataServiceImpl.findAll().size());

	}
	@Test
	public void testFindTreeViewFilterList() throws IOException {
		List<TableMetaData> tableList = new ArrayList<>();
		TableMetaData tableData = new TableMetaData();
		tableList.add(tableData);
		when(tableMetadataRepository.findByTableName("Test")).thenReturn(tableList);

		assertEquals(1, metaDataServiceImpl.findMetadataByTableName("Test").size());

	}

}
