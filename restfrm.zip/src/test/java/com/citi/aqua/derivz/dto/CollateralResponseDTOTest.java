package com.citi.aqua.derivz.dto;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CollateralResponseDTOTest {

	private CollateralResponseDTO collateralResponseDTO;
	@Before
	public void setUp() throws Exception {
		collateralResponseDTO= new CollateralResponseDTO();
	}

	@Test
	public void testSetSmcp() {
		CollateralResponseDTO dto= new CollateralResponseDTO();
		dto.setSmcp("TEST");
		collateralResponseDTO.setSmci(dto.getSmci());
		collateralResponseDTO.setStateCode(dto.getStateCode());
		collateralResponseDTO.setCollateralTypeName(dto.getCollateralTypeName());
		collateralResponseDTO.setCountryCode(dto.getCountryCode());
		collateralResponseDTO.setCurrencyCode(dto.getCurrencyCode());
		collateralResponseDTO.setGuarantor(dto.getGuarantor());
		collateralResponseDTO.setIncludeExclude(dto.getIncludeExclude());
		collateralResponseDTO.setInclusionIndicator(dto.getInclusionIndicator());
		collateralResponseDTO.setIndexExcluded(dto.getIndexExcluded());
		collateralResponseDTO.setIndexName(dto.getIndexName());
		collateralResponseDTO.setIndustryClass(dto.getIndustryClass());
		collateralResponseDTO.setIndustryCode(dto.getIndustryCode());
		collateralResponseDTO.setIsinCode(dto.getIsinCode());
		collateralResponseDTO.setMarketSectorCode(dto.getMarketSectorCode());
		collateralResponseDTO.setSectypeLevel1Code(dto.getSectypeLevel1Code());
		collateralResponseDTO.setSectypeLevel2Code(dto.getSectypeLevel2Code());
		collateralResponseDTO.setSectypeLevel3Code(dto.getSectypeLevel3Code());
		collateralResponseDTO.setTypeOfCollateral(dto.getTypeOfCollateral());
		collateralResponseDTO.setSmcp(dto.getSmcp());
		assertEquals("TEST",collateralResponseDTO.getSmcp());
	}


}
