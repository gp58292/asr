package com.citi.aqua.derivz.model;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class SelectionFiltersTest {
	private SelectionFilters selectionFilters;

	@Before
	public void setUp() throws Exception {
		selectionFilters = new SelectionFilters();
	}

	@Test
	public void testGetFilterKey() {
		SelectionFilters filters = new SelectionFilters();
		filters.setFieldName("TEST");
		filters.toString();

		selectionFilters.setAttributeDatatype(filters.getAttributeDatatype());
		selectionFilters.setCollateralLookup(filters.getCollateralLookup());
		selectionFilters.setComponentType(filters.getComponentType());
		selectionFilters.setDefaultSelected(filters.getDefaultSelected());
		selectionFilters.setDisplayName(filters.getDisplayName());
		selectionFilters.setDistinctRequired(filters.getDistinctRequired());
		selectionFilters.setFieldName(filters.getFieldName());
		selectionFilters.setFilterKey(filters.getFilterKey());
		selectionFilters.setIsDisplayed(filters.getIsDisplayed());
		selectionFilters.setLogicalGroup(filters.getLogicalGroup());
		selectionFilters.setNodeDisplayName(filters.getNodeDisplayName());
		selectionFilters.setNodeName(filters.getNodeName());
		selectionFilters.setSchemaName(filters.getSchemaName());
		selectionFilters.setWhoHasFlag(filters.getWhoHasFlag());

		assertEquals("TEST", selectionFilters.getFieldName());
	}

	}
