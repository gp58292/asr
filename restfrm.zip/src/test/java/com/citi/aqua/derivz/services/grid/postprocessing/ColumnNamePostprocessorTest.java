package com.citi.aqua.derivz.services.grid.postprocessing;

import org.junit.Test;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;
import static junit.framework.TestCase.assertTrue;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/5/2019
 */
public class ColumnNamePostprocessorTest {

    @Test
    public void processRow() {
        Function<String, String> f = s->s.toUpperCase();
        ColumnNamePostprocessor instance = new ColumnNamePostprocessor(f);
        
        String[][] input = {{"a", "a_val"}, {"B", "BVal"}};
        Map<String, Object> rowMap = Arrays.stream(input).collect(Collectors.toMap(r -> r[0], r -> r[1]));
        Map<String, Object> res = instance.processRow(rowMap);
        assertTrue(res.containsKey("A"));
        assertFalse(res.containsKey("a"));
        assertEquals(rowMap.get("a"), res.get("A"));
        assertEquals(2, res.size());
        assertTrue(res.containsKey("B"));
        assertEquals(rowMap.get("B"), res.get("B"));
    }

}