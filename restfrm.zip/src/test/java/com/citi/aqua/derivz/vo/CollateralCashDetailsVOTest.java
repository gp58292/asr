package com.citi.aqua.derivz.vo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class CollateralCashDetailsVOTest {
	private static final String TEST = "TEST";
	CollateralCashDetailsVO collateralCashDetailsVO;

	@Before
	public void setUp() throws Exception {
		collateralCashDetailsVO= new CollateralCashDetailsVO();
	}

	@Test
	public void testGetAccCurrency() {
		CollateralCashDetailsVO vo= new CollateralCashDetailsVO();
		vo.setAccCurrency("USD");
		vo.setAccCompounding(TEST);
		vo.setAccInterestMatrix(TEST);
		vo.setAccInterestSpread(TEST);
		vo.setAccPaymentFrequency(TEST);
		vo.setAccRanking(TEST);
		vo.setAccResetFrequency(TEST);
		collateralCashDetailsVO.setAccCurrency(vo.getAccCurrency());
		collateralCashDetailsVO.setAccCompounding(vo.getAccCompounding());
		collateralCashDetailsVO.setAccInterestMatrix(vo.getAccInterestMatrix());
		collateralCashDetailsVO.setAccInterestSpread(vo.getAccInterestSpread());
		collateralCashDetailsVO.setAccPaymentFrequency(vo.getAccPaymentFrequency());
		collateralCashDetailsVO.setAccRanking(vo.getAccRanking());
		collateralCashDetailsVO.setAccResetFrequency(vo.getAccResetFrequency());
		collateralCashDetailsVO.hashCode();
		collateralCashDetailsVO.toString();
		collateralCashDetailsVO.equals(vo);
		assertEquals("USD",collateralCashDetailsVO.getAccCurrency());
	}

}
