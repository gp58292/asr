package com.citi.aqua.derivz.web.quartz.job;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;

import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.model.BatchProcessAudit;
import com.citi.aqua.derivz.services.service.CacheService;

@RunWith(MockitoJUnitRunner.class)
public class ReferenceDataRefreshCacheJobTest {

	@Mock
	private JobExecutionContext ctx;
	// @Mock
	// private SpringInjectQuartz springInjectQuartzJobBean;
	private JobDataMap dataMap = new JobDataMap();
	@Mock
	private Scheduler scheduler;
	@Mock
	private CacheService cachingService;
	@InjectMocks
	private ReferenceDataRefreshCacheJob ReferenceDataRefreshCacheJob;
	@Mock
	private JobDetail jobDetail;

	@Before
	public void setUp() throws SchedulerException {
		
		JobKey jobKey = new JobKey("Test");
		when(ctx.getJobDetail()).thenReturn(jobDetail, jobDetail);
		when(ctx.getJobDetail().getJobDataMap()).thenReturn(dataMap);
		when(ctx.getJobDetail().getKey()).thenReturn(jobKey);

		when(ctx.getMergedJobDataMap()).thenReturn(dataMap);
		when(ctx.getScheduler()).thenReturn(scheduler);
		when(scheduler.getContext()).thenReturn(null);
	}

	/**
	 * @throws SchedulerException
	 */
	@Test
	public void testReferenceDataRefreshJob() throws IOException, SchedulerException {
		Timestamp timeStamp = new Timestamp(new Date().getTime());
		dataMap.put("count", 1);
		dataMap.put("cachingService", cachingService);
		dataMap.put("LOCAL_CACHE_UPDATED_TIME", timeStamp);
		
		BatchProcessAudit batchProcessAudit = new BatchProcessAudit();
		batchProcessAudit.setFlag(1);
		batchProcessAudit.setBatchUpdatedTime(timeStamp);
		batchProcessAudit.setCacheUpdatedTime(timeStamp);
		when(cachingService.getBatchProcessAuditByModule(DerivzCommonConstants.MAC_MODULE)).thenReturn(batchProcessAudit);
		//Mockito.doNothing().when(cachingService).evictReferenceDataCache();
		//when(cachingService.loadReferenceData()).thenReturn(null);
		//when(cachingService.updateCacheUpdatedTimeForModule(timeStamp, DerivzCommonConstants.MAC_MODULE)).thenReturn(1);
		ReferenceDataRefreshCacheJob.execute(ctx);
		assertEquals(2, dataMap.get("count"));
	}
}
