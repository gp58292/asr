package com.citi.aqua.derivz.web.controller;

import java.util.ArrayList;
import java.util.List;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.support.membermodification.MemberModifier;

import com.citi.aqua.derivz.model.Bookmark;
import com.citi.aqua.derivz.services.service.BookmarkService;
import com.citi.aqua.derivz.services.service.FilterSelectionViewService;
import com.citi.aqua.derivz.services.service.impl.BookmarkServiceImpl;
import com.citi.aqua.derivz.services.service.impl.FilterSelectionViewServiceImpl;
import com.citi.aqua.derivz.vo.GroupVO;
import com.citi.aqua.derivz.vo.TableNodeVO;
import com.citi.aqua.derivz.web.controller.SearchSettingsController;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import com.citi.aqua.derivz.web.utils.DerivzSettingsRestRequest;

import junit.framework.TestCase;

public class SearchSettingsControllerTest extends TestCase {

	private SearchSettingsController searchSettingsController ;
	private BookmarkService bookmarkService;
	private FilterSelectionViewService filterSelectionViewService;

	public SearchSettingsControllerTest() {
	}

	@Before
	public void setUp() throws Exception {
		searchSettingsController = EasyMock.createMockBuilder(SearchSettingsController.class).createMock();
		bookmarkService = EasyMock.mock(BookmarkServiceImpl.class);
		MemberModifier.field(SearchSettingsController.class, "bookmarkService").set(searchSettingsController, bookmarkService);
		filterSelectionViewService = EasyMock.mock(FilterSelectionViewServiceImpl.class);
		MemberModifier.field(SearchSettingsController.class, "filterSelectionViewService").set(searchSettingsController, filterSelectionViewService);
	}


	@Test
	public void testGetColumnsTreeView() throws Exception {
		
		List<GroupVO> groupVOList= new ArrayList<GroupVO>();
		GroupVO groupVO= new GroupVO();
		groupVOList.add(groupVO);
		EasyMock.expect(filterSelectionViewService.findTreeViewFilterList()).andReturn(groupVOList);
		EasyMock.replay(filterSelectionViewService);
		DerivzRestResponse<List<GroupVO>> actualBuilder = searchSettingsController.getColumnsTreeView();
		
		EasyMock.replay(searchSettingsController);
		assertEquals(1,actualBuilder.getResponseData().size());
	}
	@Test
	public void testGetColumnsFlatView() throws Exception {
		
		List<TableNodeVO> tableNodeList= new ArrayList<TableNodeVO>();
		TableNodeVO tableNodeVO= new TableNodeVO();
		tableNodeList.add(tableNodeVO);
		EasyMock.expect(filterSelectionViewService.findFlatViewFilterList()).andReturn(tableNodeList);
		EasyMock.replay(filterSelectionViewService);
		DerivzRestResponse<List<TableNodeVO>> actualBuilder = searchSettingsController.getColumnsFlatView();
		
		EasyMock.replay(searchSettingsController);
		assertEquals(1,actualBuilder.getResponseData().size());
	}
	
	@Test
	public void testSaveUserColumns() throws Exception {
		
		Bookmark value= new Bookmark();
		
		EasyMock.expect(bookmarkService.findUserSettingsColumns("")).andReturn(value);
		EasyMock.expect(bookmarkService.updateSettingsColumnList(null, null)).andReturn(true);
		EasyMock.replay(bookmarkService);
		DerivzSettingsRestRequest settingsSaveRequest= EasyMock.createMock(DerivzSettingsRestRequest.class);
		DerivzRestResponse<DerivzSettingsRestRequest> actualBuilder = searchSettingsController.saveUserColumns(settingsSaveRequest);
		
		EasyMock.replay(searchSettingsController);
		assertNotNull(actualBuilder.getResponseData());
	}

	
	}
