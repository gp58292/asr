package com.citi.aqua.derivz.web.controller;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import org.apache.http.HttpStatus;
import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.powermock.api.support.membermodification.MemberModifier;
import org.springframework.mock.web.MockHttpServletRequest;
import com.citi.aqua.derivz.model.RatingRankings;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.services.service.ReferenceDataProviderService;
import com.citi.aqua.derivz.services.service.impl.CacheServiceImpl;
import com.citi.aqua.derivz.services.service.impl.ReferenceDataProviderServiceImpl;
import com.citi.aqua.derivz.vo.ReferenceDataVO;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import com.citi.aqua.derivz.web.utils.ResponseBuilder;
import junit.framework.TestCase;

public class ReferenceDataControllerTest extends TestCase {

	private ReferenceDataController referenceDataController;
	private CacheService cachingService;
	private ReferenceDataProviderService referenceDataProviderService;

	public ReferenceDataControllerTest() {
	}

	@Before
	public void setUp() throws Exception {
		cachingService = EasyMock.createMockBuilder(CacheServiceImpl.class).createMock();
		referenceDataController = EasyMock.createMockBuilder(ReferenceDataController.class).createMock();
		referenceDataProviderService = EasyMock.createMockBuilder(ReferenceDataProviderServiceImpl.class).createMock();
	}

	Map<Long, List<ReferenceDataVO>> referenceMap = createCacheMap();

	@Test
	public void testGetReferenceDataForDropDown() throws Exception {
		referenceDataController = EasyMock.mock(ReferenceDataController.class);
		List<ReferenceDataVO> referenceList = referenceMap.get(1l);
		DerivzRestResponse<List<ReferenceDataVO>> builder = ResponseBuilder.build(referenceList, HttpStatus.SC_OK);
		EasyMock.expect(referenceDataController.getReferenceDataForDropDown(1l)).andReturn(builder);
		EasyMock.replay(referenceDataController);
		assertNotNull(referenceDataController.getReferenceDataForDropDown(1l));
	}

	@Test
	public void testGetTypeAheadListByPastedValues() throws Exception {
		referenceDataProviderService= EasyMock.createMock(ReferenceDataProviderServiceImpl.class);
		MemberModifier.field(ReferenceDataController.class, "referenceDataProviderService").set(referenceDataController, referenceDataProviderService);
		String[] str= {"Test"};
		EasyMock.expect(referenceDataProviderService.findTypeAheadReferenceListByPastedValues(new Long(11),str)).andReturn(createReferenceDataMap());
		EasyMock.replay(referenceDataProviderService);
		HttpServletRequest request= EasyMock.createMock(HttpServletRequest.class);
		EasyMock.replay(referenceDataController);
		
		DerivzRestResponse<Map<String,List<ReferenceDataVO>>> actualBuilder = referenceDataController.getTypeAheadListByPastedValues(request, new Long(11), str);
		EasyMock.verify(referenceDataController);
		assertEquals(true,actualBuilder.getResponseData().containsKey("Test"));
	}
	
	@Test
	public void testGetTypeAheadListByPastedValuesConditional() throws Exception {
		referenceDataProviderService= EasyMock.createMock(ReferenceDataProviderServiceImpl.class);
		MemberModifier.field(ReferenceDataController.class, "referenceDataProviderService").set(referenceDataController, referenceDataProviderService);
		String[] str= {};
		HttpServletRequest request= EasyMock.createMock(HttpServletRequest.class);
		DerivzRestResponse<Map<String,List<ReferenceDataVO>>> actualBuilder = referenceDataController.getTypeAheadListByPastedValues(request, new Long(11), str);
		assertNotNull(actualBuilder);
	}

	private Map<Long, List<ReferenceDataVO>> createCacheMap() {
		Map<Long, List<ReferenceDataVO>> referenceMap = new HashMap<>();
		final List<ReferenceDataVO> referenceDataElementsList = new LinkedList<ReferenceDataVO>();
		final ReferenceDataVO referenceDataElement1 = new ReferenceDataVO(1l, "ELIGIBLE_CURRENCY_MISMATCH");
		final ReferenceDataVO referenceDataElement2 = new ReferenceDataVO(3l, "TERMINATION_CURRENCY_MISMATCH");
		referenceDataElementsList.add(referenceDataElement1);
		referenceDataElementsList.add(referenceDataElement2);
		referenceMap.put(1l, referenceDataElementsList);
		return referenceMap;
	}
	
	private Map<String, List<ReferenceDataVO>> createReferenceDataMap() {
		Map<String, List<ReferenceDataVO>> referenceMap = new HashMap<>();
		final List<ReferenceDataVO> referenceDataElementsList = new LinkedList<ReferenceDataVO>();
		final ReferenceDataVO referenceDataElement1 = new ReferenceDataVO(1l, "ELIGIBLE_CURRENCY_MISMATCH");
		final ReferenceDataVO referenceDataElement2 = new ReferenceDataVO(3l, "TERMINATION_CURRENCY_MISMATCH");
		referenceDataElementsList.add(referenceDataElement1);
		referenceDataElementsList.add(referenceDataElement2);
		referenceMap.put("Test", referenceDataElementsList);
		return referenceMap;
	}
	
	@Test
	public void testGetTypeAheadList() throws Exception {
		List<ReferenceDataVO> referenceList = mockDataForTypeAhead();
		referenceDataProviderService = EasyMock.mock(ReferenceDataProviderServiceImpl.class);
		MemberModifier.field(ReferenceDataController.class, "referenceDataProviderService").set(referenceDataController, referenceDataProviderService);
		EasyMock.expect(referenceDataProviderService.findTypeAheadReferenceList(3l, "FOR L")).andReturn(referenceList);
		EasyMock.replay(referenceDataProviderService);

		EasyMock.replay(referenceDataController);
		DerivzRestResponse<List<ReferenceDataVO>> actualBuilder = referenceDataController.getTypeAheadList(3l, "FOR L");
		EasyMock.verify(referenceDataController);
		assertEquals(true, actualBuilder.getResponseData().contains(referenceList.get(0)));
	}
	
	@Test
	public void testGetTypeAheadListWithConditions() throws Exception {
		List<ReferenceDataVO> referenceList = mockDataForTypeAhead();
		referenceDataProviderService = EasyMock.mock(ReferenceDataProviderServiceImpl.class);
		MemberModifier.field(ReferenceDataController.class, "referenceDataProviderService").set(referenceDataController, referenceDataProviderService);
		EasyMock.expect(referenceDataProviderService.findTypeAheadReferenceList(3l, "")).andReturn(referenceList);
		EasyMock.replay(referenceDataProviderService);

		EasyMock.replay(referenceDataController);
		DerivzRestResponse<List<ReferenceDataVO>> actualBuilder = referenceDataController.getTypeAheadList(3l, "");
		EasyMock.verify(referenceDataController);
		assertEquals(false, actualBuilder.getResponseData().contains(referenceList.get(0)));
	}
	@Test
	public void testGetRatingRankings() throws Exception{
		Set<RatingRankings> list= new HashSet<>();
		referenceDataProviderService = EasyMock.mock(ReferenceDataProviderServiceImpl.class);
		MemberModifier.field(ReferenceDataController.class, "referenceDataProviderService").set(referenceDataController, referenceDataProviderService);
		EasyMock.expect(referenceDataProviderService.getRatingRankings()).andReturn(list);
		EasyMock.replay(referenceDataProviderService);
		EasyMock.replay(referenceDataController);
		MockHttpServletRequest request=EasyMock.mock(MockHttpServletRequest.class);
		DerivzRestResponse<Set<RatingRankings>> actualBuilder = referenceDataController.getRatingRankings(request);
		EasyMock.verify(referenceDataController);
		assertEquals(HttpStatus.SC_OK, actualBuilder.getResponseStatus());
		
	}
	private List<ReferenceDataVO> mockDataForTypeAhead() {
		final List<ReferenceDataVO> referenceDataElementsList = new LinkedList<ReferenceDataVO>();
		final ReferenceDataVO referenceDataElement1 = new ReferenceDataVO(417l,
				" FOR LEGAL NOTICIES:  ONE CANADA SQUARE, LONDON E14 5AL, UNITED KINGDOM  FOR INSTRUCTIONS:  RUE MONTOYERSTRAAT 46, B-1000 BRUSSELS, BELGIUM");
		final ReferenceDataVO referenceDataElement2 = new ReferenceDataVO(708l,
				"FOR LEGAL NOTICIES:  ONE CANADA SQUARE, LONDON E14 5AL, UNITED KINGDOM  FOR INSTRUCTIONS:  RUE MONTOYERSTRAAT 46, B-1000 BRUSSELS, BELGIUM");
		referenceDataElementsList.add(referenceDataElement1);
		referenceDataElementsList.add(referenceDataElement2);
		return referenceDataElementsList;
	}

}
