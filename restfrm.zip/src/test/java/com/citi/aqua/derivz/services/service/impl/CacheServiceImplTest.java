
package com.citi.aqua.derivz.services.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.data.cache.eh.ReferenceCacheKeys;
import com.citi.aqua.derivz.data.cache.eh.StaticCacheKeys;
import com.citi.aqua.derivz.data.repository.BatchProcessAuditRepository;
import com.citi.aqua.derivz.data.repository.CustomFieldRepository;
import com.citi.aqua.derivz.data.repository.DistinctValuesRepository;
import com.citi.aqua.derivz.data.repository.RatingRankingRepository;
import com.citi.aqua.derivz.data.repository.SelectionFiltersRepository;
import com.citi.aqua.derivz.model.BatchProcessAudit;
import com.citi.aqua.derivz.model.CustomAttributes;
import com.citi.aqua.derivz.model.DistinctValues;
import com.citi.aqua.derivz.model.RatingRankings;
import com.citi.aqua.derivz.model.SelectionFilters;

@RunWith(SpringRunner.class)
public class CacheServiceImplTest {

	private static final Long KEY = new Long(1);

	@InjectMocks
	CacheServiceImpl cacheServiceImpl;

	@Mock
	private DistinctValuesRepository distinctValuesRepository;

	@Mock
	CombinedColumnsImpl combinedColumns;
	

	@Mock
	SelectionFiltersRepository selectionFiltersRepository;
	  
	@Mock
	CustomFieldRepository customFieldRepository;

	@Mock
	private BatchProcessAuditRepository batchProcessAuditRepository;
	
	@Mock
	private RatingRankingRepository ratingRankingRepository;

	final List<String> filterKeyList = Arrays.asList(DerivzCommonConstants.DROPDOWN_COMPONENT_TYPE,
			DerivzCommonConstants.INCLUDE_EXCLUDE_COMPONENT_TYPE);

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testLoadReferenceData() throws IOException {
		List<SelectionFilters> selectionFilterList = new ArrayList<>();
		final List<CustomAttributes> customAttributeList = new ArrayList<>();
		SelectionFilters selectionFilter = new SelectionFilters();
		selectionFilterList.add(selectionFilter);
		when(selectionFiltersRepository.findByComponentTypeIn(filterKeyList)).thenReturn(selectionFilterList);
        when(customFieldRepository.findByComponentTypeIn(filterKeyList)).thenReturn(customAttributeList);
		when(combinedColumns.findByComponentTypeIn(filterKeyList)).thenReturn(selectionFilterList);

		assertEquals(0, cacheServiceImpl.loadReferenceData().size());
	}

	@Test
	public void testLoadAllReferenceData() throws IOException {

		List<DistinctValues> distinctValuesList = new ArrayList<>();
		DistinctValues distinctValues = new DistinctValues();
		distinctValuesList.add(distinctValues);
		when(distinctValuesRepository.findAll()).thenReturn(distinctValuesList);

		assertEquals(1, cacheServiceImpl.loadAllReferenceData(ReferenceCacheKeys.ALL_REFRENCE).size());
	}

	@Test
	public void testCreateReferenceData() throws IOException {

		List<DistinctValues> distinctValuesList = new ArrayList<>();
		DistinctValues distinctValues = new DistinctValues();
		distinctValues.setCompositeKey(KEY);
		distinctValuesList.add(distinctValues);
		assertEquals(1,
				cacheServiceImpl.createReferenceData(distinctValuesList, ReferenceCacheKeys.ALL_REFRENCE).size());
	}

	@Test
	public void testGetReferenceDataByKey() throws IOException {

		List<DistinctValues> distinctValuesList = new ArrayList<>();
		DistinctValues distinctValues = new DistinctValues();
		distinctValues.setCompositeKey(KEY);
		distinctValuesList.add(distinctValues);
		when(distinctValuesRepository.findDistinctValueByKey(KEY)).thenReturn(distinctValuesList);
		assertEquals(1, cacheServiceImpl.getReferenceDataByKey(KEY, ReferenceCacheKeys.ALL_REFRENCE).size());
	}

	@Test
	public void testGetBatchProcessAuditByModule() {
		BatchProcessAudit batchProcessAudit = new BatchProcessAudit();
		when(batchProcessAuditRepository.findByModule("Test")).thenReturn(batchProcessAudit);
		assertNotNull(cacheServiceImpl.getBatchProcessAuditByModule("Test"));

	}

	@Test
	public void testGetBatchProcessAudit() {
		BatchProcessAudit batchProcessAudit = new BatchProcessAudit();
		List<BatchProcessAudit> batchProcessAuditList = new ArrayList<>();
		batchProcessAuditList.add(batchProcessAudit);
		when(batchProcessAuditRepository.findAll()).thenReturn(batchProcessAuditList);
		assertEquals(1, cacheServiceImpl.getBatchProcessAudit().size());
	}

	@Test
	public void testUpdateCacheUpdatedTimeForModule() {
		Timestamp timeStamp = new Timestamp(new Date().getTime());
		when(batchProcessAuditRepository.updateCacheUpdatedTimeForModule(timeStamp, "Module")).thenReturn(1);
		assertEquals(1, cacheServiceImpl.updateCacheUpdatedTimeForModule(timeStamp, "Module"));
	}
	@Test
	public void testFindStaticComponentData() {
		List<SelectionFilters> selectionFilterList = new ArrayList<>();
		SelectionFilters selectionFilter = new SelectionFilters();
		selectionFilterList.add(selectionFilter);
		when(selectionFiltersRepository.findAll()).thenReturn(selectionFilterList);
		assertEquals(1,cacheServiceImpl.findStaticComponentData(StaticCacheKeys.STATIC_COMPONENT_DATA).size());
	}

	@Test
	public void testFindElementWithFilterKey() {
		List<SelectionFilters> selectionFilterList = new ArrayList<>();
		SelectionFilters selectionFilter = new SelectionFilters();
		selectionFilter.setFilterKey(KEY);
		selectionFilterList.add(selectionFilter);
		when(selectionFiltersRepository.findAll()).thenReturn(selectionFilterList);
		assertEquals(KEY, cacheServiceImpl.findElementWithFilterKey(KEY).getFilterKey());
	}

	@Test
	public void testGetRatingRankings(){
		
		List<RatingRankings> rankingsList=new ArrayList<>();
		when(ratingRankingRepository.findAll()).thenReturn(rankingsList);
		assertEquals(0,cacheServiceImpl.getRatingRankings(ReferenceCacheKeys.RATING_RANKINGS).size());
		}
}
