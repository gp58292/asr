package com.citi.aqua.derivz.web.controller;

import com.citi.aqua.frm.framework.export.CsvExporter;
import com.citi.aqua.frm.framework.export.DisplayableColumnDescription;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class MockCSVExporter extends CsvExporter {
    private String expectedResult = "";

    public void setExpectedResult(String expectedResult) {
        this.expectedResult = expectedResult;
    }

    @Override
    public Flux<String> streamCsv(Supplier<Iterator<Map<String, Object>>> resultIterator,
                                  List<? extends DisplayableColumnDescription> columnDescriptions) {
        return Flux.just(expectedResult).subscribeOn(Schedulers.elastic());
    }
}
