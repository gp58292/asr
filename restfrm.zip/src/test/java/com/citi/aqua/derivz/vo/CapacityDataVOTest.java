package com.citi.aqua.derivz.vo;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CapacityDataVOTest {
	private CapacityDataVO capacityDataVO;
	
	@Before
	public void setUp() throws Exception {
		capacityDataVO = new CapacityDataVO();
	}
	
	@Test
	public void testSetCounterPartyCustodianRequired() {
		CapacityDataVO capacityObj = new CapacityDataVO();		
		int agreementId = 1;
		capacityObj.setAgreementId(agreementId );		
		capacityDataVO.setAgreementId(capacityObj.getAgreementId());		
		capacityDataVO.setClearingAgreement(capacityObj.getClearingAgreement());
		capacityDataVO.setCollateralApplied(capacityObj.getCollateralApplied());
		capacityDataVO.setCollateralCcy(capacityObj.getCollateralCcy());
		capacityDataVO.setCollateralParty(capacityObj.getCollateralParty());
		capacityDataVO.setCollateralType(capacityObj.getCollateralType());		
		capacityDataVO.setCollSourceSystem(capacityObj.getCollSourceSystem());
		capacityDataVO.setConsentToSubstitution(capacityObj.getConsentToSubstitution());
		capacityDataVO.setCounterPartyCustodianRequired(capacityObj.getCounterPartyCustodianRequired());
		capacityDataVO.setCounterPartyName(capacityObj.getCounterPartyName());
		capacityDataVO.setCpMarginType(capacityObj.getCpMarginType());
		capacityDataVO.setCsaDescription(capacityObj.getCsaDescription());
		capacityDataVO.setCsaMarginType(capacityObj.getCsaMarginType());
		capacityDataVO.setCsaStatus(capacityObj.getCsaStatus());
		capacityDataVO.setCustodianRequired(capacityObj.getCustodianRequired());
		capacityDataVO.setCustomerName(capacityObj.getCustomerName());		
		capacityDataVO.setExchangeClearedAgreement(capacityObj.getExchangeClearedAgreement());
		capacityDataVO.setGfcid(capacityObj.getGfcid());
		capacityDataVO.setGfcidType(capacityObj.getGfcidType());
		capacityDataVO.setGfcidTypeDescription(capacityObj.getGfcidTypeDescription());
		capacityDataVO.setCurrentCollateralReceived(capacityObj.getCurrentCollateralReceived());
		capacityDataVO.setCurrentPosting(capacityObj.getCurrentPosting());		
		capacityDataVO.toString();
		capacityDataVO.setGoverningLaw(capacityObj.getGoverningLaw());
		capacityDataVO.setImVm(capacityObj.getImVm());
		capacityDataVO.setIncorporatedCountry(capacityObj.getIncorporatedCountry());
		capacityDataVO.setIncrementalCapacity(capacityObj.getIncrementalCapacity());
		capacityDataVO.setIncrementalCapacityConc(capacityObj.getIncrementalCapacityConc());
		capacityDataVO.setIncrementalExposure(capacityObj.getIncrementalExposure());
		capacityDataVO.setIncrementalExposureConc(capacityObj.getIncrementalExposureConc());
		capacityDataVO.setIndustrySector(capacityObj.getIndustrySector());
		capacityDataVO.setInterCompanyAgreement(capacityObj.getInterCompanyAgreement());
		capacityDataVO.setLiquidityType(capacityObj.getLiquidityType());		
		capacityDataVO.setMandatoryMarkFrequency(capacityObj.getMandatoryMarkFrequency());
		capacityDataVO.setMasterAgreement(capacityObj.getMasterAgreement());
		capacityDataVO.setMasterAgreementStatus(capacityObj.getMasterAgreementStatus());
		capacityDataVO.setMaxCapacity(capacityObj.getMaxCapacity());
		capacityDataVO.setMaxCapacityConc(capacityObj.getMaxCapacityConc());
		capacityDataVO.setMaxExposure(capacityObj.getMaxExposure());
		capacityDataVO.setMaxExposureConc(capacityObj.getMaxExposureConc());
		capacityDataVO.setMgdSegLevel5Desc(capacityObj.getMgdSegLevel5Desc());
		capacityDataVO.setMtm(capacityObj.getMtm());
		capacityDataVO.setPartyCustodianRequired(capacityObj.getPartyCustodianRequired());		
		capacityDataVO.setPartyLegalEntity(capacityObj.getPartyLegalEntity());
		capacityDataVO.setPledgor(capacityObj.getPledgor());
		capacityDataVO.setPostedReceivedcode(capacityObj.getPostedReceivedcode());		
		capacityDataVO.setSaTriggerEvent(capacityObj.getSaTriggerEvent());
		capacityDataVO.setSegNonseg(capacityObj.getSegNonseg());
		capacityDataVO.setSixCApplies(capacityObj.getSixCApplies());
		capacityDataVO.setSme(capacityObj.getSme());
		capacityDataVO.setTriggerEvent(capacityObj.getTriggerEvent());
		capacityDataVO.setTypeOfCollateral(capacityObj.getTypeOfCollateral());				
		assertEquals(agreementId, capacityDataVO.getAgreementId());			
	}
 

}
