package com.citi.aqua.derivz.services.grid.impl;

import com.citi.aqua.derivz.services.grid.LoadingProgressTracker;
import com.citi.aqua.derivz.services.grid.TestObjectProvider;
import com.citi.aqua.frm.ceft.CeftDataSetType;
import com.citi.aqua.frm.framework.grid.DataLoadingService;
import com.citi.aqua.frm.framework.grid.User;
import com.citi.aqua.frm.framework.grid.data.DataSetStatus;
import com.citi.aqua.frm.framework.grid.data.DataSetStatusCode;
import com.citi.aqua.frm.framework.grid.data.LoadingProcessStatus;
import com.citi.aqua.frm.framework.grid.data.LoadingStatus;
import com.citi.aqua.frm.framework.grid.tools.FrmGrid;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.Duration;
import java.time.Instant;

import static com.citi.aqua.derivz.services.grid.TestObjectProvider.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/17/2019
 */
@RunWith(MockitoJUnitRunner.class)
public class LoadingStatusServiceImplTest {

    public static final String ATMOSPHERE_RESOURCE_UUID = "sampleSocket";
    @Mock
    FrmGrid gridMock;

    @Mock
    DataLoadingService loadingService;

    @Mock
    LoadingProgressTracker tracker;

    @InjectMocks
    LoadingStatusServiceImpl instance;

    @Before
    public void setup() {
        Mockito.when(gridMock.connectLoadingService()).thenReturn(loadingService);

        Mockito.when(loadingService.getDataSetStatus(any(), any())).thenReturn(DataSetStatus.ofUnknown(SAMPLE_FRM_DATA_SET_ID));

    }

    @Test
    public void loadData() {
        instance.loadData(SAMPLE_CEFT_DATA_SET);
        verify(loadingService).loadDataSet(TestObjectProvider.SAMPLE_FRM_DATA_SET_ID,
                new User(TestObjectProvider.SAMPLE_SOE_ID, false));
    }

    @Test
    public void requestDataSetIgnoresLoadedSet() {
        long sampleSize = 100L;
        DataSetStatus dataSetStatus =
                new DataSetStatus(SAMPLE_FRM_DATA_SET_ID, SAMPLE_FRM_DATA_SET_VERSION, DataSetStatusCode.READY,
                        sampleSize,
                        new LoadingProcessStatus(Instant.now().minusSeconds(10), Duration.ofSeconds(10), sampleSize,
                                sampleSize,
                                true,
                                LoadingStatus.SUCCESS, null), false);
        Mockito.when(loadingService.getDataSetStatus(SAMPLE_FRM_DATA_SET_ID, SAMPLE_FRM_USER)).thenReturn(dataSetStatus);
        instance.requestDataSet(SAMPLE_CEFT_DATA_SET, "sampleSocket");

        verify(loadingService, Mockito.never()).loadDataSet(any(), any());
        verify(loadingService).validateDataSetVersion(SAMPLE_FRM_DATA_SET_ID, SAMPLE_FRM_USER);
        //now
    }
    @Test
    public void requestDataSetLoadsSet() {
        long sampleSize = 100L;
        DataSetStatus dataSetStatus =
                new DataSetStatus(SAMPLE_FRM_DATA_SET_ID, SAMPLE_FRM_DATA_SET_VERSION, DataSetStatusCode.READY,
                        sampleSize,
                        new LoadingProcessStatus(Instant.now().minusSeconds(10), Duration.ofSeconds(10), sampleSize,
                                sampleSize,
                                true,
                                LoadingStatus.SUCCESS, null), false);
        Mockito.when(loadingService.getDataSetStatus(SAMPLE_FRM_DATA_SET_ID, SAMPLE_FRM_USER)).thenReturn(
                DataSetStatus.ofUnknown(SAMPLE_FRM_DATA_SET_ID),
                dataSetStatus);
        instance.requestDataSet(SAMPLE_CEFT_DATA_SET, ATMOSPHERE_RESOURCE_UUID);

        verify(loadingService).loadDataSet(SAMPLE_FRM_DATA_SET_ID, SAMPLE_FRM_USER);
        verify(loadingService).validateDataSetVersion(SAMPLE_FRM_DATA_SET_ID, SAMPLE_FRM_USER);
        verify(tracker).registerWebSocketUUID(SAMPLE_CEFT_DATA_SET, ATMOSPHERE_RESOURCE_UUID);
        //now
    }

    @Test
    public void testIsDataSetReady() {
        instance.isDataSetReady(SAMPLE_CEFT_DATA_SET);
        verify(loadingService).isDataSetReady(SAMPLE_FRM_DATA_SET_ID, SAMPLE_FRM_USER);
    }

    @Test
    public void testDataSetStatusForBookmark() {
        instance.dataSetStatusForBookmark(SAMPLE_SOE_ID, 10L);
        verify(loadingService, Mockito.times(CeftDataSetType.values().length)).getDataSetStatus(any(), any());
    }

    @Test
    public void testForceGridCleanup() {
        instance.forceGridCleanup();
        verify(loadingService).clearAllCaches();
    }
}