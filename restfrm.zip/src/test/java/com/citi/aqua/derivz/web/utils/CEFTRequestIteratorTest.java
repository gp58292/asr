package com.citi.aqua.derivz.web.utils;

import com.citi.aqua.derivz.commons.exceptions.CEFTException;
import com.citi.aqua.derivz.dto.RetrievedDataResponseDTO;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class CEFTRequestIteratorTest {
    private CEFTDataSetRequest request;
    private UserSearchCriteriaService userSearchCriteriaService = Mockito.mock(UserSearchCriteriaService.class);
    private RetrievedDataResponseDTO responseDTO;

    private static final int nColumns = 10;

    @Before
    public void setUp() {
        request = new CEFTDataSetRequest();
        EnterpriseGetRowsRequest gridRequest = new EnterpriseGetRowsRequest();
        request.setGridRequest(gridRequest);

        responseDTO = new RetrievedDataResponseDTO();
    }

    @Test
    public void testNoRows() {
        setStartEndRows(0,0);
        CEFTRequestIterator ceftRequestIterator = CEFTRequestIterator.getCETRequestIterator(request,
                "", userSearchCriteriaService);
        assert(!ceftRequestIterator.hasNext());
    }

    @Test
    public void testNumberOfRowsFitInTheWindow() throws CEFTException {
        testXRows(0, 20, 20, 3000);
        testXRows(0, 1, 1, 3000);
        testXRows(10, 100, 90, 3000);
        testXRows(0, 3000, 3000, 3000);
        testXRows(100000, 200000, 100000, 200000);
    }

    @Test
    public void testNumberOfRowsWithWindow() throws CEFTException {
        testXRows(0, 20, 20, 10);
        testXRows(10000, 20000, 10000, 2000);
    }

    @Test
    public void testNumberOfRowsMinusOneEndRow() throws CEFTException {
        int startRow = 0;
        int endRow = -1;
        int numRows = 200;

        generateTestData(numRows);
        setStartEndRows(startRow, endRow);

        Mockito.when(userSearchCriteriaService.searchDatasetResults(request.getType(), "",
                request.getBookmarkId(),
                request.getGridRequest(),
                request.getAgreementKeys())).thenReturn(responseDTO);
        CEFTRequestIterator ceftRequestIterator = CEFTRequestIterator.getCETRequestIterator(request,
                "", userSearchCriteriaService);

        int rowsCount = countRows(ceftRequestIterator);
        System.out.println("Rows returned: " + rowsCount);

        assert(rowsCount == numRows);
    }

    @Test
    public void testNumberOfRowsSomeExtraAfterWindow() throws CEFTException {
        int startRow = 0;
        int endRow = 210;
        int numRows = 210;
        int windowSize = 100;

        generateTestData(numRows);
        setStartEndRows(startRow, endRow);

        Mockito.when(userSearchCriteriaService.searchDatasetResults(request.getType(), "",
                request.getBookmarkId(),
                request.getGridRequest(),
                request.getAgreementKeys())).thenReturn(responseDTO);

        CEFTDataSetRequest extraRequest = new CEFTDataSetRequest();
        EnterpriseGetRowsRequest extraGridRequest = new EnterpriseGetRowsRequest();
        extraGridRequest.setStartRow(200);
        extraGridRequest.setEndRow(210);
        extraRequest.setGridRequest(extraGridRequest);

        RetrievedDataResponseDTO extraResponseDTO = new RetrievedDataResponseDTO();
        generateTestData(extraResponseDTO, 10);

        Mockito.when(userSearchCriteriaService.searchDatasetResults(request.getType(), "",
                extraRequest.getBookmarkId(),
                extraRequest.getGridRequest(),
                extraRequest.getAgreementKeys())).thenReturn(extraResponseDTO);

        CEFTRequestIterator ceftRequestIterator = CEFTRequestIterator.getCETRequestIterator(request,
                "", userSearchCriteriaService);
        ceftRequestIterator.setWindowSize(windowSize);

        int rowsCount = countRows(ceftRequestIterator);
        System.out.println("Rows returned: " + rowsCount);

        assert(rowsCount == numRows);
    }


    private void setStartEndRows(int startRow, int endRow) {
        request.getGridRequest().setStartRow(startRow);
        request.getGridRequest().setEndRow(endRow);
    }

    private int countRows(CEFTRequestIterator ceftRequestIterator) {
        int count = 0;
        while (ceftRequestIterator.hasNext()) {
            ceftRequestIterator.next();
            count++;
        }
        return count;
    }

    private void generateTestData(int rowsToReturn) {
        generateTestData(responseDTO, rowsToReturn);
    }

    private void generateTestData(RetrievedDataResponseDTO currentResponseDTO, int rowsToReturn) {
        Map<String, Object> testRow = IntStream.range(0, nColumns)
                .mapToObj(Integer::toString)
                .collect(Collectors.toMap(Object::toString, Function.identity()));

        currentResponseDTO.setListOfRecords(IntStream.range(0, rowsToReturn)
                .boxed()
                .map(r -> testRow)
                .collect(Collectors.toList()));
    }

    private void testXRows(int startRow, int endRow, int eXpectedRows, int windowSize) throws CEFTException {
        setStartEndRows(startRow, endRow);
        int rowsToReturnBySearchService;
        if (endRow > 0) {
            rowsToReturnBySearchService = Integer.min(endRow - startRow, windowSize);
        }
        else {
            rowsToReturnBySearchService = windowSize;
        }

        generateTestData(rowsToReturnBySearchService);

        Mockito.when(userSearchCriteriaService.searchDatasetResults(request.getType(), "",
                request.getBookmarkId(),
                request.getGridRequest(),
                request.getAgreementKeys())).thenReturn(responseDTO);
        CEFTRequestIterator ceftRequestIterator = CEFTRequestIterator.getCETRequestIterator(request,
                "", userSearchCriteriaService);
        if (windowSize > 0) {
            ceftRequestIterator.setWindowSize(windowSize);
        }

        int rowsCount = countRows(ceftRequestIterator);
        System.out.println("Rows returned: " + rowsCount);

        assert(rowsCount == eXpectedRows);
    }
}
