package com.citi.aqua.derivz.vo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class MTMDataVOTest {
	private MTMDataVO mtmVO;

	@Before
	public void setUp() throws Exception {
		mtmVO = new MTMDataVO();
	}

	@Test
	public void testGetBusinessDate() {
		MTMDataVO vo = new MTMDataVO();
		vo.setCsaType("TEST");
		mtmVO.toString();
		mtmVO.setBusinessDate(vo.getBusinessDate());
		mtmVO.setAgreementId(vo.getAgreementId());
		mtmVO.setPartyLegalEntity(vo.getPartyLegalEntity());
		mtmVO.setBuckets(vo.getBuckets());
		mtmVO.setCounterParty(vo.getCounterParty());
		mtmVO.setCounterPartyGFCId(vo.getCounterPartyGFCId());
		mtmVO.setCsaDescription(vo.getCsaDescription());
		mtmVO.setCsaType(vo.getCsaType());
		mtmVO.setExtension(vo.getExtension());
		mtmVO.setInterCompanyAgreementCP(vo.getInterCompanyAgreementCP());
		mtmVO.setMnemonic(vo.getMnemonic());
		mtmVO.setShelf(vo.getShelf());
		mtmVO.setMgdSegLevel5Desc(vo.getMgdSegLevel5Desc());
		mtmVO.setMgdSegLevel6Desc(vo.getMgdSegLevel6Desc());
		mtmVO.setMgdSegLevel7Desc(vo.getMgdSegLevel7Desc());
		mtmVO.setMtmUsd(vo.getMtmUsd());
		assertEquals("TEST", mtmVO.getCsaType());
	}
}
