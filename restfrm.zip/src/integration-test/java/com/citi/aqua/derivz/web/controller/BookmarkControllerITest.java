package com.citi.aqua.derivz.web.controller;

import static junit.framework.TestCase.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.enums.ComponentType;
import com.citi.aqua.derivz.model.Bookmark;
import com.citi.aqua.derivz.services.service.BookmarkService;
import com.citi.aqua.derivz.vo.BookmarkVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import com.citi.aqua.derivz.web.utils.DerivzBookmarkRestRequest;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@AutoConfigureMockMvc
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, value = { "spring.profiles.active=test" })
public class BookmarkControllerITest {

	@LocalServerPort
	private int port;

	private URL base;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private FilterChainProxy springSecurityFilterChain;

	@Autowired
	private WebApplicationContext wac;

	protected MockHttpSession session;

	protected MockHttpServletRequest request;

	@Autowired
	private TestRestTemplate template;

	@Autowired
	BookmarkService bookmarkService;

	public BookmarkControllerITest() {
	}

	public URL getBase() {
		return base;
	}

	// setting base
	public void setBase(URL base) {
		try {
			this.base = new URL("http:localhost:" + port + "/api/");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).addFilters(this.springSecurityFilterChain).build();
		if (template == null) {
			throw new Exception("Test rest template not defined");
		}
		this.getBase();
		session = new MockHttpSession();
	}

	@Test
	public void testGetBookmarkValue() throws Exception {
		mockMvc.perform(get(DerivzAPIUriConstants.BOOKMARK_API_URI + "/bookmark/30287")
				.accept(MediaType.APPLICATION_JSON).session(session)).andExpect(status().isOk());
	}

	// Test to check if the get bookmark result after hitting the API's URI is as. We need to decide on how we will test this bookmarks. As 
	// expected
	@Test
	public void testGetbookmarkValueURIResult() throws Exception {
		List<Bookmark> actual = bookmarkService.getSearchCriteriaList("AK92283", "Search");
		Bookmark actualBookmark = actual.stream().filter(bookmark -> bookmark.getName().equalsIgnoreCase("default"))
				.collect(Collectors.toList()).get(0);
		mockMvc.perform(get(DerivzAPIUriConstants.BOOKMARK_API_URI + "/bookmark/"+actualBookmark.getKey())
				.accept(MediaType.APPLICATION_JSON).session(session))
				.andExpect(status().isOk());
		//String expected = "{\"responseStatus\":200,\"responseData\":[{\"fieldName\":\"agreement_id\",\"nodeName\":\"vw_ceft_dim_agreement\",\"componentType\":\"TYPEAHEAD_TEXTBOX\",\"dataType\":\"INTEGER\",\"logicalGroupName\":\"MAC Attributes\",\"name\":\"Agreement Id\",\"schemaName\":\"dz\",\"nodeDisplayName\":\"Master Agreement\",\"distinctRequired\":0,\"key\":4,\"value\":\"\",\"whoHasFlag\":0},{\"fieldName\":\"additional_haircut_criteria\",\"nodeName\":\"dim_agreement_collateral_rule\",\"componentType\":\"DROPDOWN\",\"dataType\":\"string\",\"logicalGroupName\":\"MAC Attributes\",\"name\":\"Additional Haircut Criteria\",\"schemaName\":\"dz\",\"nodeDisplayName\":\"Collateral Rule\",\"distinctRequired\":0,\"key\":1,\"value\":[{\"key\":1,\"value\":\"ELIGIBLE_CURRENCY_MISMATCH\",\"selected\":true}],\"whoHasFlag\":0}]}";
		//JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
	}

//	@Test
	public void testGetBookmarkForGivenId() throws Exception {
		List<SearchFieldVO> mock = createMockDataForBookmarkwithGivenId();
		List<SearchFieldVO> actual = bookmarkService.getBookmarkForGivenId("vn06956",new Long(10093));
		assertEquals(mock.get(2).getFieldName().contains("Country Code"),
				actual.get(2).getFieldName().contains("Country Code"));
	}

	private List<SearchFieldVO> createMockDataForBookmarkwithGivenId() {

		List<SearchFieldVO> bookmarkDataForSearch = new LinkedList<SearchFieldVO>();
		SearchFieldVO searchFieldVO1 = new SearchFieldVO();
		SearchFieldVO searchFieldVO2 = new SearchFieldVO();
		SearchFieldVO searchFieldVO = new SearchFieldVO();
		searchFieldVO.setName("country_code");
		searchFieldVO.setComponentType(ComponentType.DROPDOWN);
		searchFieldVO.setDataType("string");
		searchFieldVO.setFieldName("country_code");
		searchFieldVO.setDefaultSelected(null);
		searchFieldVO.setWhoHasFlag(1);
		searchFieldVO.setLogicalGroupName("MAC Attributes");
		searchFieldVO.setKey(new Long(63));
		searchFieldVO.setNodeDisplayName("Collateral Issuer Country States");
		searchFieldVO.setSchemaName("dz");
		bookmarkDataForSearch.add(searchFieldVO1);
		bookmarkDataForSearch.add(searchFieldVO2);
		bookmarkDataForSearch.add(searchFieldVO);

		return bookmarkDataForSearch;
	}

	@Test
	public void testGetBookmarkForUser() throws Exception {
		mockMvc.perform(get(DerivzAPIUriConstants.BOOKMARK_API_URI + "/bookmarks/AK92283")
				.accept(MediaType.APPLICATION_JSON).session(session)).andExpect(status().isOk());
	}

	@Test
	public void testGetSearchCriteriaList() throws Exception {
		List<Bookmark> actual = bookmarkService.getSearchCriteriaList("AK92283", "Search");
		Bookmark mockBookmark = createMockDataForBookmarkForGivenUser();
		Bookmark actualBookmark = actual.stream().filter(bookmark -> bookmark.getName().equalsIgnoreCase("default"))
				.collect(Collectors.toList()).get(0);
		assertEquals(mockBookmark.getName(), actualBookmark.getName());
	}

	private Bookmark createMockDataForBookmarkForGivenUser() {
		Bookmark bookmark = new Bookmark();
		bookmark.setKey(new Long(1));
		bookmark.setName("default");
		bookmark.setUserId("AK92283");
		bookmark.setType("Search");
		return bookmark;
	}

	
	@Test
	public void test2UpdateBookMark() throws Exception {
		List<Bookmark> bookmarkList1 = bookmarkService.getSearchCriteriaList("AK92283",
				DerivzCommonConstants.SEARCH_TYPE_LIST);
		if (null != bookmarkList1 && !bookmarkList1.isEmpty()) {
			List<Bookmark> evaluatedList = bookmarkList1.stream()
					.filter(bookmark -> bookmark.getName().equalsIgnoreCase("Unit_Case_bookmark"))
					.collect(Collectors.toList());
			if (null != evaluatedList && !evaluatedList.isEmpty()) {
				Bookmark bookmarkItemToUpdate = evaluatedList.get(0);
				Long bookmarkIdToUpdate = bookmarkItemToUpdate.getKey();
				if (null != bookmarkIdToUpdate) {
					DerivzBookmarkRestRequest mockBookmarkToUpdate = new DerivzBookmarkRestRequest();
					mockBookmarkToUpdate.setUserId(bookmarkItemToUpdate.getUserId());
					mockBookmarkToUpdate.setBookmarkName(bookmarkItemToUpdate.getName());
					mockBookmarkToUpdate.setBookmarkId(bookmarkIdToUpdate);

					BookmarkVO bookmark1 = new BookmarkVO();
					bookmark1.setKey(new Long(1));
					bookmark1.setValue(new BookmarkDataIT(new Long(1), "TERMINATION_CURRENCY_MISMATCH", true));
					bookmark1.setWhoHasFlag(0);
					List<BookmarkVO> bookmarkList = new LinkedList<>();
					bookmarkList.add(bookmark1);
					mockBookmarkToUpdate.setBookmarkData(bookmarkList);

					RequestBuilder requestBuilder = MockMvcRequestBuilders.put("/api/finder/bookmark")
							.contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(mockBookmarkToUpdate));

					mockMvc.perform(put("/api/finder/bookmark").contentType(MediaType.APPLICATION_JSON)
							.content(convertObjectToJsonBytes(mockBookmarkToUpdate))).andExpect(status().isOk());
				}
			}
		}
	}

	@Test
	public void test3DeleteBookmarksById() throws Exception {
		List<Bookmark> bookmarkList1 = bookmarkService.getSearchCriteriaList("AK92283",
				DerivzCommonConstants.SEARCH_TYPE_LIST);
		if (null != bookmarkList1 && !bookmarkList1.isEmpty()) {
			List<Bookmark> evaluatedList = bookmarkList1.stream()
					.filter(bookmark -> bookmark.getName().equalsIgnoreCase("Unit_Case_bookmark"))
					.collect(Collectors.toList());
			if (null != evaluatedList && !evaluatedList.isEmpty()) {
				Bookmark bookmarkItemToDelete = evaluatedList.get(0);
				Long bookmarkIdToDelete = bookmarkItemToDelete.getKey();
				if (null != bookmarkIdToDelete) {
					this.mockMvc
							.perform(MockMvcRequestBuilders
									.delete("/api/finder/bookmark/{bookmarkId}", bookmarkIdToDelete)
									.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
							.andExpect(status().isOk());
				}
			}
		}
	}

	public static byte[] convertObjectToJsonBytes(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsBytes(object);
	}

	public static String convertObjectToJson(Object object) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
		return mapper.writeValueAsString(object);
	}

	private List<BookmarkVO> convertJsonToObject(final String json) throws Exception {
		List<BookmarkVO> bookmarkData = new LinkedList<BookmarkVO>();
		try {
			final ObjectMapper objectMapper = new ObjectMapper();
			final TypeReference<List<BookmarkVO>> mapType = new TypeReference<List<BookmarkVO>>() {
			};
			String jsonString = json;
			bookmarkData = objectMapper.readValue(jsonString, mapType);
		} catch (JsonProcessingException e) {
			throw e;
		} catch (Exception e) {
			throw e;
		}
		return bookmarkData;
	}

}

class BookmarkDataIT {
	private Long key;
	private String value;
	private Boolean selected;

	public BookmarkDataIT() {
	}

	public BookmarkDataIT(Long key, String value, Boolean selected) {
		super();
		this.key = key;
		this.value = value;
		this.selected = selected;
	}

	/**
	 * @return the key
	 */
	public Long getKey() {
		return key;
	}

	/**
	 * @param key
	 *            the key to set
	 */
	public void setKey(Long key) {
		this.key = key;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the selected
	 */
	public Boolean getSelected() {
		return selected;
	}

	/**
	 * @param selected
	 *            the selected to set
	 */
	public void setSelected(Boolean selected) {
		this.selected = selected;
	}

}
