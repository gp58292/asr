package com.citi.aqua.derivz.web.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.MalformedURLException;
import java.net.URL;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.services.service.AgreementService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, value = { "spring.profiles.active=test" })
@AutoConfigureMockMvc
public class AgreementControllerITest {

	@LocalServerPort
	private int port;

	private URL base;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private FilterChainProxy springSecurityFilterChain;

	@Autowired
	private WebApplicationContext wac;

	protected MockHttpSession session;

	protected MockHttpServletRequest request;

	@Autowired
	private TestRestTemplate template;

	public AgreementControllerITest() {
	}

	public URL getBase() {
		return base;
	}

	// setting base
	public void setBase(URL base) {
		try {
			this.base = new URL("http:localhost:" + port + "/api/");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).addFilters(this.springSecurityFilterChain).build();
		if (template == null) {
			throw new Exception("Test rest template not defined");
		}
		this.getBase();
		session = new MockHttpSession();
	}

	@Test
	public void testGetAgreementDetails() throws Exception {
		mockMvc.perform(get(DerivzAPIUriConstants.AGREEMENT_API_URI + "/getAgreementDetails/803778")
				.contentType(MediaType.APPLICATION_JSON).session(session)).andExpect(status().isOk());
	}
	
	@Test
	public void testGetCsaTypeDetails() throws Exception {
		mockMvc.perform(get(DerivzAPIUriConstants.AGREEMENT_API_URI + "/getCsaTypeDetails/185623/CSA_CLEARING")
				.contentType(MediaType.APPLICATION_JSON).session(session)).andExpect(status().isOk());
	}
}
