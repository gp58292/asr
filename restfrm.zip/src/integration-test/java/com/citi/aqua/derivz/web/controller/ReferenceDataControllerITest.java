package com.citi.aqua.derivz.web.controller;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.web.FilterChainProxy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.services.service.ReferenceDataProviderService;
import com.citi.aqua.derivz.vo.ReferenceDataVO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
@AutoConfigureMockMvc
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT, value = { "spring.profiles.active=test" })
public class ReferenceDataControllerITest {

	@LocalServerPort
	private int port;

	private URL base;

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private FilterChainProxy springSecurityFilterChain;

	@Autowired
	private WebApplicationContext wac;

	protected MockHttpSession session;

	protected MockHttpServletRequest request;

	@Autowired
	private TestRestTemplate template;

	@Autowired
	ReferenceDataProviderService referenceDataProviderService;

	@Autowired
	CacheService cachingService;

	public ReferenceDataControllerITest() {
	}

	public URL getBase() {
		return base;
	}

	// setting base
	public void setBase(URL base) {
		try {
			this.base = new URL("http:localhost:" + port + "/api/");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	@Before
	public void setUp() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).addFilters(this.springSecurityFilterChain).build();
		if (template == null) {
			throw new Exception("Test rest template not defined");
		}
		this.getBase();
		session = new MockHttpSession();
	}

	@Test
	public void testGetReferenceDataForDropDown() throws Exception {
		mockMvc.perform(get(DerivzAPIUriConstants.REFERENCE_API_URI + "/dropdown/1").accept(MediaType.APPLICATION_JSON)
				.session(session)).andExpect(status().isOk());
	}

	@Test
	public void testGetTypeAheadList() throws Exception {
		mockMvc.perform(get(DerivzAPIUriConstants.REFERENCE_API_URI + "/typeahead/12/A")
				.accept(MediaType.APPLICATION_JSON).session(session)).andExpect(status().isOk());
	}

	@Test
	public void testGetReferenceData() throws Exception {
		List<ReferenceDataVO> mockData = createMockDataForReferenceElements();
		List<ReferenceDataVO> actualData = referenceDataProviderService.findDistinctReferenceData(new Long(31));
		assertNotNull(actualData);
	}

	private List<ReferenceDataVO> createMockDataForReferenceElements() {
		List<ReferenceDataVO> referenceDataList = new LinkedList<>();
		ReferenceDataVO referenceDataVO = new ReferenceDataVO();
		referenceDataVO.setKey(new Long(1870216));
		referenceDataVO.setValue("(null)");
		referenceDataList.add(referenceDataVO);
		return referenceDataList;

	}

	@Test
	public void testFindTypeAheadReferenceList() throws Exception {
		List<ReferenceDataVO> mockData = createMockDataForTypeAheadData();
		List<ReferenceDataVO> actualData = referenceDataProviderService.findTypeAheadReferenceList(new Long(64), "UN");
		assertEquals(mockData.get(0).getValue(), actualData.get(0).getValue());
	}

	private List<ReferenceDataVO> createMockDataForTypeAheadData() {
		Map<Long, List<ReferenceDataVO>> refereneDataMap = new HashMap<>();
		List<ReferenceDataVO> referenceDataList = new LinkedList<>();
		ReferenceDataVO referenceDataVO = new ReferenceDataVO();
		referenceDataVO.setKey(new Long(2037653));
		referenceDataVO.setValue("BRUNEI DARUSSALAM");

		ReferenceDataVO referenceDataVO1 = new ReferenceDataVO();
		referenceDataVO1.setKey(new Long(2037634));
		referenceDataVO1.setValue("United Arab Emirates");

		ReferenceDataVO referenceDataVO2 = new ReferenceDataVO();
		referenceDataVO2.setValue("United Kingdom");
		referenceDataVO2.setKey(new Long(2037723));

		ReferenceDataVO referenceDataVO3 = new ReferenceDataVO();
		referenceDataVO3.setKey(new Long(2037724));
		referenceDataVO3.setValue("United States");

		ReferenceDataVO referenceDataVO4 = new ReferenceDataVO();
		referenceDataVO4.setKey(new Long(2037725));
		referenceDataVO4.setValue("UNITED STATES MINOR OUTLYING ISLANDS");
		
		referenceDataList.add(referenceDataVO1);
		referenceDataList.add(referenceDataVO2);
		referenceDataList.add(referenceDataVO3);
		referenceDataList.add(referenceDataVO4);
		referenceDataList.add(referenceDataVO);

		return referenceDataList;

	}

}
