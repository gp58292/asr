package com.citi.aqua.derivz.web.controller;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.dto.AgreementResponseDTO;
import com.citi.aqua.derivz.dto.CSAResponseDTO;
import com.citi.aqua.derivz.services.service.AgreementService;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import com.citi.aqua.derivz.web.utils.ResponseBuilder;

@RestController
@RequestMapping(DerivzAPIUriConstants.AGREEMENT_API_URI)
public class AgreementController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AgreementController.class);

	@Autowired
	AgreementService agreementService;

	@RequestMapping(value = DerivzAPIUriConstants.SEARCH_AGREEMENT_DETAILS_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<AgreementResponseDTO> getAgreementDetails(@PathVariable("agreementKey") final Long agreementKey) {
		try {
			return ResponseBuilder.build(agreementService.getAgreementDetails(agreementKey), HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("AgreementController::getAgreementDetails() :: Error " + de, de);
			return ResponseBuilder.build(null, HttpStatus.SC_NOT_FOUND,	"Failed to get agreement details for agreementKey.", "DS100");
		} 
	}
	
	@RequestMapping(value = DerivzAPIUriConstants.SEARCH_CSA_TYPE_DETAILS_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<CSAResponseDTO> getCsaTypeDetails(@PathVariable("agreementId") final Long agreementId,@PathVariable("csaType") final String csaType) {
		try {
			return ResponseBuilder.build(agreementService.getCsaTypeDetails(agreementId,csaType), HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("AgreementController::getCsaTypeDetails() :: Error " + de, de);
			return ResponseBuilder.build(null, HttpStatus.SC_NOT_FOUND,	"Failed to get CSA Type details for agreementId and CSA Type.", "DS101");
		} 
	}
	
}
