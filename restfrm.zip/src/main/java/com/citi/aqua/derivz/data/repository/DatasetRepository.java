package com.citi.aqua.derivz.data.repository;

import org.springframework.data.repository.CrudRepository;

import com.citi.aqua.derivz.model.Dataset;

public interface DatasetRepository extends CrudRepository<Dataset, Integer> {
	
	public Dataset findByName(String name);

}
