package com.citi.aqua.derivz.services.service;

import java.util.List;

import com.citi.aqua.derivz.dto.BatchStatusResponseDTO;

public interface BatchStatusService {

	public List<BatchStatusResponseDTO> getStatusReport(String cobDate);

}
