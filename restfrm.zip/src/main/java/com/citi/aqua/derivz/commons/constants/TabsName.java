package com.citi.aqua.derivz.commons.constants;

public final class TabsName {
  
  private TabsName () {}
  
  public static final String BOX = "Box";
  public static final String CAPACITY = "Capacity";
  public static final String POSTING = "Current Postings";
  public static final String FMTM = "Forward MTM";
  public static final String FRTB = "FRTB";
  public static final String GSST = "GSST";
  public static final String LISTED = "Listed";
  public static final String MTM = "MTM";
  
}
