package com.citi.aqua.derivz.utils;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@ToString
public class ErrorDetails {
	
	private String errorMessage;
	private String errorCause;
	
}
