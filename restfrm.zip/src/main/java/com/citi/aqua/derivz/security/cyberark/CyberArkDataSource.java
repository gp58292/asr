package com.citi.aqua.derivz.security.cyberark;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

public class CyberArkDataSource extends SQLServerDataSource {

    private static final Logger LOGGER = LoggerFactory.getLogger(CyberArkFactory.class);

    private String appId = null;
    private String safe = null;
    private String object = null;
    private transient CyberArkFactory passwordFactory;

    @Override
    public Connection getConnection() {
        Connection conn = null;
        try {
            conn = super.getConnection();
        } catch (Exception e) {
            LOGGER.info("CyberArk -> Retry connect by refreshing password.");
            try {
                conn = createConnectionWithRetry(3);
            } catch (SQLException sqlExc) {
                LOGGER.error("CyberArk -> Retry: Error while connecting to DB with property : ", sqlExc);
            }
        }
        return conn;

    }

    private Connection createConnectionWithRetry(int retry) throws SQLException {
        try {
            String password = passwordFactory.getPassword(appId, safe, object, "Refresh DataSource Password.");
            this.setPassword(password);
            return super.getConnection();
        } catch (Exception e) {
            LOGGER.warn((new StringBuilder()).append("CyberArk -> Retry:").append(retry)
                    .append(". Error while connecting to DB with property : ").toString());
            if (--retry < 0)
                throw new SQLException("CyberArk -> Error while connecting to DB with property : ", e.getCause());
            else
                return createConnectionWithRetry(retry);
        }
    }

    public CyberArkFactory getPasswordFactory() {
        return passwordFactory;
    }

    public void setPasswordFactory(CyberArkFactory passwordFactory) {
        this.passwordFactory = passwordFactory;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getSafe() {
        return safe;
    }

    public void setSafe(String safe) {
        this.safe = safe;
    }

    public String getObject() {
        return object;
    }

    public void setObject(String object) {
        this.object = object;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CyberArkDataSource that = (CyberArkDataSource) o;
        return Objects.equals(appId, that.appId) &&
                Objects.equals(safe, that.safe) &&
                Objects.equals(object, that.object);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appId, safe, object);
    }
}