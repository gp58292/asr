package com.citi.aqua.derivz.services.factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzException;

@Service
public class SearchResultSourceFactory {
	
	@Autowired
	ListedSearchResultSource listedSearchResultSource;
	
	@Autowired
	PostingSearchResultSource postingSearchResultSource;
	
	@Autowired
	BoxSearchResultSource boxSearchResultSource;
	
	@Autowired
	CapacitySearchResultSource capacitySearchResultSource;
	
	public SearchResultSource getSearchResultSource(String source) {
		SearchResultSource searchResultSource = null;
		if (DerivzCommonConstants.LISTED.equals(source)) {
			searchResultSource = listedSearchResultSource;
		} else if (DerivzCommonConstants.CURRENT_POSTINGS.equals(source)) {
			searchResultSource = postingSearchResultSource;
		} else if (DerivzCommonConstants.BOX.equals(source)) {
			searchResultSource = boxSearchResultSource;
		} else if (DerivzCommonConstants.CAPACITY.equals(source)) {
			searchResultSource = capacitySearchResultSource;
		} else {
			throw new DerivzException("Source does not exist");
		}
		return searchResultSource;
	}

}
