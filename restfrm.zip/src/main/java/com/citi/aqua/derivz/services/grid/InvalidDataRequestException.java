package com.citi.aqua.derivz.services.grid;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/18/2019
 */
public class InvalidDataRequestException extends CeftFrmGridException {
    private static final long serialVersionUID = -8114945954446329995L;

    public InvalidDataRequestException(String message) {
        super("Invalid request: "+message);
    }
}
