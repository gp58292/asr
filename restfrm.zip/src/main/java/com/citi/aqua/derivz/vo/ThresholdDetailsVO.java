package com.citi.aqua.derivz.vo;

import java.math.BigDecimal;
import java.util.Date;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ThresholdDetailsVO {
	private String type;
	private String basis;
	private String currency;
	private BigDecimal amount;
	private String agency; 
	private String rating;
	private Date ratingDate;
	private Date startDate;
	private Date endDate;
	
}
