package com.citi.aqua.derivz.vo;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonInclude(Include.NON_NULL)
public class FRTBDataVO {

	private int agreementID;
	private String shelf;
	private String mnemonic;
	private String extension;
	private String csaDescription;
	private String riskFactor;
	private String currency;
	private String yieldcurve;
	private String domicile;
	private String subyieldcurve;
	private BigDecimal amount;
	private String partyLegalEntity;
	private String interCompanyAgreement;
	private String counterPartyName;
	private String consentToSubstitution;
	private String rightofReuse;
	private String masterAgreement;
	private String pledgor;
	private String exchangeclearedAgreement;
	private String csaStatus;
	private String counterpartyCustodianRequired;
	private String partyCustodianRequired;
	private String governingLaw;
	private String mandatoryMarkFrequency;
	private String incorporatedCountry;
	private String masterAgreementStatus;
	private String cpMarginType;
	private String customerName;
	private String triggerEvent;
	private String saTriggerEvent;
	private String clearingAgreement;
	private String firmAccountMnemonic;
	private String segmentLevelDescription;
	private String riskSensitivityType;
	private String businessDate;
}
