package com.citi.aqua.derivz.services.grid.impl;

import com.citi.aqua.derivz.services.grid.*;
import com.citi.aqua.derivz.services.grid.model.DataRequest;
import com.citi.aqua.derivz.services.grid.model.DistinctValueDataRequest;
import com.citi.aqua.derivz.services.grid.model.SearchQueryResult;
import com.citi.aqua.derivz.services.grid.postprocessing.SearchQueryPostprocessor;
import com.citi.aqua.derivz.utils.LogUtils;
import com.citi.aqua.derivz.vo.aggrid.filter.ColumnFilter;
import com.citi.aqua.derivz.vo.aggrid.filter.NumberColumnFilter;
import com.citi.aqua.derivz.vo.aggrid.filter.SetColumnFilter;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;
import com.citi.aqua.derivz.vo.aggrid.request.SortModel;
import com.citi.aqua.frm.framework.grid.User;
import com.citi.aqua.frm.framework.grid.data.DataSetId;
import com.citi.aqua.frm.framework.grid.exception.DataSetNotFoundException;
import com.citi.aqua.frm.framework.grid.exception.DataSetNotLoadedException;
import com.citi.aqua.frm.framework.grid.exception.FrmDataGridException;
import com.citi.aqua.frm.framework.grid.query.QueryResult;
import com.citi.aqua.frm.framework.grid.tools.FrmGrid;
import com.citi.aqua.frm.framework.query.FrmQuery;
import com.citi.aqua.frm.framework.query.model.*;
import com.google.common.base.Stopwatch;
import com.google.common.collect.Iterables;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import java.util.*;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;
import static java.util.Objects.isNull;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
@Slf4j
public class CeftFrmQueryServiceImpl implements CeftFrmQueryService {

    private final FrmGrid grid;
    private final SearchQueryPostprocessor postprocessor;
    private final CeftFrmGroupingPivotQueryServiceImpl pivotQueryServiceDelegate;

    public CeftFrmQueryServiceImpl(FrmGrid grid,
            SearchQueryPostprocessor postprocessor, int maxPivotColumns) {
        this.grid = grid;
        this.postprocessor = postprocessor;
        this.pivotQueryServiceDelegate = new CeftFrmGroupingPivotQueryServiceImpl(grid, postprocessor, this,
                maxPivotColumns);
    }

    /**
     * Count query using old request format.
     * @param request request to be processed
     * @deprecated User version which takes filter list instead
     * @return size of the
     */
    @Deprecated
    public long countQuery(DataRequest request) {
        log.info("Querying set {} for size, query={}", request.getDataSet(), request);
        return executeCountQuery(buildCoreQuery(request), request.getDataSet().getSoeId());
    }


    @Override
    public long countQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet)
            throws DataSetNotLoadedException, DataSetNotFoundException, FrmDataGridException {
        log.info("GridService::countQuery: querying set {} for size, query={}", dataSet, request);
        if (request.isPivotMode() || (Objects.nonNull(request.getRowGroupCols()) && !request.getRowGroupCols()
                .isEmpty())) {
            log.debug("GridService::countQuery: querying set {} for size as pivot/grouping query", dataSet);
            return pivotQueryServiceDelegate.countGroupingPivotQuery(request, dataSet);
        } else {
            log.debug("GridService::countQuery: querying set {} for size as plain query.", dataSet);
            return executeCountQuery(buildCoreQuery(request, dataSet), dataSet.getSoeId());
        }
    }

    protected long executeCountQuery(FrmQuery query, String soeId) {
        query.setQueryType(FrmQuery.QueryType.COUNT);
        QueryResult result = executeQuery(query, soeId);
        log.debug("CountQuery: got result: {}", result);
        Map row = result.getResult().get(0);
        Long size = (Long) Iterables.getFirst(row.values(), null);

        return Optional.ofNullable(size).orElse(-1L);
    }

    protected QueryResult executeQuery(FrmQuery query, String soeId) {
        return grid.connectQueryService().queryDataSet(query, new User(soeId, false));
    }

    @Override
    public SearchQueryResult searchQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet)
            throws FrmDataGridException {
        try {
            log.info("GridService::searchQuery: querying set {} for rows, query={}", dataSet, request);
            if (request.isPivotMode() || (Objects.nonNull(request.getRowGroupCols()) && !request.getRowGroupCols()
                    .isEmpty())) {
                log.debug("GridService::searchQuery: querying set {} for rows as pivot/grouping query", dataSet);
                return pivotQueryServiceDelegate.searchGroupingPivotQuery(request, dataSet);

            } else {
                log.debug("GridService::searchQuery: querying set {} for rows as plain query.", dataSet);
                return executePlainSearchQuery(request, dataSet);
            }
        } catch (FrmDataGridException | InvalidDataRequestException e) {
            throw e;
        } catch (RuntimeException re) {
            throw new FrmDataGridException("Failed to execute query", re);
        }
    }

    protected SearchQueryResult executePlainSearchQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet) {
        FrmQuery frmQuery = buildCoreQuery(request, dataSet);
        List<Pair<String, String>> columns = request.getValueCols()
                .stream()
                .map(col -> new ImmutablePair<>(Optional.ofNullable(col.getField()).orElse(col.getId()), col.getId()))
                .collect(Collectors.toList());

        List<ColumnSortCriteria> sortCriteria = Optional.ofNullable(request.getSortModel()).orElse(emptyList())
                .stream()
                .map(model -> new ColumnSortCriteria(model.getColId(),
                        SortModel.DESCENDING.equals(model.getSort()) ? SortOrder.DESCENDING : SortOrder.ASCENDING))
                .collect(Collectors.toList());

        return executeSearchQuery(frmQuery, columns, sortCriteria, dataSet.getSoeId(), request.getLimit(),
                request.getStartRow());
    }

    protected SearchQueryResult executeSearchQuery(FrmQuery frmQuery, List<Pair<String, String>> columns,
            List<ColumnSortCriteria> sortCriteria, String soeId, int limit, int offset) {
        if (columns != null && !columns.isEmpty()) {
            frmQuery.setSelectDefinitions(columns.stream()
                    .map(p -> new SelectDefinition(p.getLeft(), p.getRight()))
                    .collect(Collectors.toList()));
        }

        if (sortCriteria != null && !sortCriteria.isEmpty()) {
            frmQuery.setOrderDefinitions(
                    sortCriteria
                            .stream()
                            .map(order -> new OrderDefinition(order.getColumn(),
                                    OrderDefinition.Ordering.NATURAL, order.getOrder().isReversed()))
                            .collect(Collectors.toList()));
        }
        frmQuery.setPagination(new Pagination(limit, offset));
        QueryResult result = executeQuery(frmQuery, soeId);
        log.debug("SearchQuery: query completed, got {} result rows in {}", result.getResult().size(),
                result.getExecutionTime());
        SearchQueryResult res = new SearchQueryResult((List) result.getResult(), null, limit, offset, false);
        if (postprocessor != null) {
            res = postprocessor.processQueryResult(res);
            log.debug("Applying postprocessing to query result, after postprocessing got {} rows.",
                    res.getValues().size());
        }
        return res;
    }

    public List<Object> distinctValuesQuery(DistinctValueDataRequest request) {
        Stopwatch stopwatch = Stopwatch.createStarted();
        CeftDataSet dataSet = request.getDataSet();
        log.debug("DistinctValuesQuery: Querying data set for distinct column values. "
                        + "Data set: {}; Column: {}; query: {}", dataSet, request.getColumn(), request);
        FrmQuery query = buildCoreQuery(request);
        String soeId = dataSet.getSoeId();
        List<Object> res = executeDistinctQuery(request.getColumn(), dataSet, query, soeId);
        log.info("DistinctValuesQuery: Completed query for distinct column values. "
                + "Data set: {}; Column: {}; Execution time: {}; Result: {}",
                dataSet, request.getColumn(), stopwatch.elapsed(), LogUtils.listForLogging(res));
        return res;
    }


    @Override
    public List<Object> distinctValuesQuery(CeftDataSet dataSet, Map<String, ColumnFilter> filters, String column)
            throws DataSetNotLoadedException, DataSetNotFoundException, FrmDataGridException {
        Stopwatch stopwatch = Stopwatch.createStarted();
        log.debug("DistinctValuesQuery: Querying data set for distinct column values. "
                + "Data set: {}; Column: {}; filters: {}",
                dataSet, column, LogUtils.mapForLogging(filters));

        FrmQuery query = buildCoreQuery(dataSet.toDataSetId(), filters);
        List<Object> res = executeDistinctQuery(column, dataSet, query, dataSet.getSoeId());
        log.info("DistinctValuesQuery: Completed query for distinct column values. "
                        + "Data set: {}; Column: {}; Execution time: {}; Result: {}",
                dataSet, column, stopwatch.elapsed(), LogUtils.listForLogging(res));

        return res;
    }

    protected List<Object> executeDistinctQuery(String column, CeftDataSet dataSet, FrmQuery query, String soeId) {
        query.setSelectDefinitions(Collections.singletonList(new SelectDefinition(column)));
        query.setOrderDefinitions(Collections.singletonList(new OrderDefinition(column)));
        query.setDistinct(true);
        QueryResult result = executeQuery(query, soeId);

        List<Object> list = result.getResult()
                .stream()
                .map(row -> Iterables.getFirst(row.values(), null))
                .collect(Collectors.toList());
        List<Object> logList = list.size() > 5 ? list.subList(0, 5) : list;
        log.info("DistinctValuesQuery: Querying set {} for distinct column {} values, got result: {}{}.",
                dataSet, column, logList, list.size() > logList.size() ? "... " : "");
        return list;
    }

    protected FrmQuery buildCoreQuery(DataSetId frmSetId, Map<String, ColumnFilter> filterMap) {
        FrmQuery query = new FrmQuery();
        query.setQueryType(FrmQuery.QueryType.SELECT);
        query.setDataSetId(frmSetId);
        List<ConditionAware> filterConditions =
                Optional.ofNullable(filterMap).orElse(Collections.emptyMap())
                        .entrySet()
                        .stream()
                        .map(e -> buildColumnFilter(e.getKey(), e.getValue()))
                        .collect(Collectors.toList());
        if (!filterConditions.isEmpty()) {
            query.setWhereConditions(Collections.singletonList(CompoundCondition.and(filterConditions)));
        }
        return query;
    }


    protected FrmQuery buildCoreQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet) {
        return buildCoreQuery(dataSet.toDataSetId(), request.getFilterModel());
    }

    protected FrmQuery buildCoreQuery(DataRequest request) {
        return buildCoreQuery(request.getDataSet().toDataSetId(), request.getFilters());
    }


    protected static ConditionAware buildColumnFilter(String column, ColumnFilter filter) {
        if (isNull(filter)) {
            throw new IllegalArgumentException("ColumnFilter should not be null.");
        }
        if (isNull(column) || column.isEmpty()) {
            throw new IllegalArgumentException("Column may not be empty.");
        }

        if (filter instanceof SetColumnFilter) {
            SetColumnFilter columnFilter = (SetColumnFilter) filter;
            if (isNull(columnFilter.getValues())) {
                throw new IllegalArgumentException("ColumnFilter should not be empty.");

            }
            List<ConditionAware> conditions = columnFilter.getValues().stream()
                    .map(val -> new FilterDefinition(column, val, FilterDefinition.FilterType.EQUAL))
                    .collect(Collectors.toList());

            if (columnFilter.getValues().contains("")) {
                conditions.add(new FilterDefinition(column, null, FilterDefinition.FilterType.IS_NULL));
            }
            return conditions.size() == 1 ? conditions.get(0) : CompoundCondition.or(conditions);
        } else if (filter instanceof NumberColumnFilter) {
            //todo: add creation of the numeric filter.
            throw new UnsupportedOperationException("No number filtering implemented yet.");
        } else {
            throw new IllegalArgumentException("Unknown filter type: " + filter.getClass());
        }
    }

}
