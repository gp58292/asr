package com.citi.aqua.derivz.config;

import com.citi.aqua.derivz.services.grid.CeftFrmQueryService;
import com.citi.aqua.derivz.services.grid.LoadingProgressTracker;
import com.citi.aqua.derivz.services.grid.LoadingStatusService;
import com.citi.aqua.derivz.services.grid.impl.CeftFrmQueryServiceImpl;
import com.citi.aqua.derivz.services.grid.impl.LoadingStatusServiceImpl;
import com.citi.aqua.derivz.services.grid.postprocessing.ColumnNamePostprocessor;
import com.citi.aqua.derivz.services.grid.postprocessing.RemoveNullValuesRowPostprocessor;
import com.citi.aqua.derivz.services.grid.postprocessing.RowPostprocessor;
import com.citi.aqua.derivz.services.grid.postprocessing.SearchQueryPostprocessor;
import com.citi.aqua.frm.framework.client.FrmGridClientNodeConfig;
import com.citi.aqua.frm.framework.grid.tools.FrmGrid;
import com.citi.aqua.frm.framework.messaging.config.MessagingConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import java.util.List;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 1/11/2019
 */
@Configuration
@Import({FrmGridClientNodeConfig.class, MessagingConfig.class})
public class FrmGridConfiguration {

    @Bean
    LoadingProgressTracker loadingProgressTracker() {
        return new LoadingProgressTracker();
    }

    @Bean
    LoadingStatusService igniteLoadingStatusService(FrmGrid grid,
            LoadingProgressTracker progressTracker) {
        return new LoadingStatusServiceImpl(grid, progressTracker);
    }


    @Bean
    RowPostprocessor lowercaseColumnNamePostprocessor() {
        return new ColumnNamePostprocessor(String::toLowerCase);
    }

    @Bean
    RowPostprocessor removeNullValuesRowPostprocessor() {
        return new RemoveNullValuesRowPostprocessor();
    }

    @Bean
    SearchQueryPostprocessor postprocessor(List<RowPostprocessor> rowPostprocessors) {
        return new SearchQueryPostprocessor(rowPostprocessors);
    }

    @Bean
    CeftFrmQueryService igniteQueryService(FrmGrid grid, SearchQueryPostprocessor postprocessor,
            @Value("${ceft.frm.maxPivotColumns:100}")int maxPivotColumns) {
        return new CeftFrmQueryServiceImpl(grid, postprocessor, maxPivotColumns);
    }

}
