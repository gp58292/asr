package com.citi.aqua.derivz.web.utils;

import java.util.List;

import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CEFTDataSetRequest {

	private Long bookmarkId;
	private String type;
	private EnterpriseGetRowsRequest gridRequest;
	List<String> agreementKeys;
}
