package com.citi.aqua.derivz.services.grid;

import com.citi.aqua.derivz.services.grid.model.DataRequest;
import com.citi.aqua.derivz.services.grid.model.DistinctValueDataRequest;
import com.citi.aqua.derivz.services.grid.model.SearchQueryResult;
import com.citi.aqua.derivz.vo.aggrid.filter.ColumnFilter;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;
import com.citi.aqua.frm.framework.grid.exception.DataSetNotFoundException;
import com.citi.aqua.frm.framework.grid.exception.DataSetNotLoadedException;
import com.citi.aqua.frm.framework.grid.exception.FrmDataGridException;

import java.util.List;
import java.util.Map;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
public interface CeftFrmQueryService {

    /**
     * Count the results of the query, ignores limit/offset.
     *
     * @param request request to be processed
     * @return number of rows which would be returned by given query.
     * @deprecated Please, use version with 'EnterpriseGetRowsRequest' argument instead.
     */
    @Deprecated
    long countQuery(DataRequest request);

    /**
     * Select all possible values for the given query.
     *
     * @param request query to analyse
     * @return list of all possible values which appear in selected column for given query
     * @deprecated Please, use version with 'EnterpriseGetRowsRequest' argument instead.
     */
    @Deprecated
    List<Object> distinctValuesQuery(DistinctValueDataRequest request);

    long countQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet)
            throws DataSetNotLoadedException, DataSetNotFoundException, FrmDataGridException;

    SearchQueryResult searchQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet)
            throws DataSetNotLoadedException, DataSetNotFoundException, FrmDataGridException;

    List<Object> distinctValuesQuery(CeftDataSet dataSet, Map<String, ColumnFilter> filters, String column)
            throws DataSetNotLoadedException, DataSetNotFoundException, FrmDataGridException;
}
