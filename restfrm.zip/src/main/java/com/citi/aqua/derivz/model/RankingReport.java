package com.citi.aqua.derivz.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@Entity
@Table(name = DBConstants.TBL_RANKING_STATIC_REPORT_DATA, schema=DerivzDBConstants.SCHEMA_DZ)
public class RankingReport extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "collateral_type")
	private String collateralType;

	@Column(name = "discount_curve")
	private String discountCurve;

	@Column(name = "ccy")
	private String ccy;

	@Column(name = "hqla")
	private String hqla;

	@Column(name = "country")
	private String country;

	@Column(name = "esph")
	private String esph;
	
	@Column(name = "group_disagg")
	private String groupDisagg;

	@Column(name = "group_agg")
	private String groupAgg;

	@Column(name = "funding_ranking")
	private Float fundingRanking;

	@Column(name = "posting_ranking")
	private Float postingRanking;

}