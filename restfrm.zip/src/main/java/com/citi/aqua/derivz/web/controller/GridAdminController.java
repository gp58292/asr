package com.citi.aqua.derivz.web.controller;

import com.citi.aqua.derivz.services.ApiKeyService;
import com.citi.aqua.derivz.services.grid.LoadingStatusService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.security.AccessControlException;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 8/23/2019
 */
@RequestMapping("/adm")
@RestController
@Slf4j
public class GridAdminController {

    @Autowired
    ApiKeyService keyService;

    @Autowired
    LoadingStatusService loadingStatusService;


    @ExceptionHandler(Exception.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR, reason = "Unexpected server error")
    public void handleGenericError(Exception ex) {
        log.warn("Unexpected exception while processing request.", ex);
    }


    @ExceptionHandler(AccessControlException.class)
    @ResponseStatus(value = HttpStatus.UNAUTHORIZED, reason = "Invalid token")
    public void handleAccessError(AccessControlException ex) {
        log.warn("Returning access denied.");
    }

    @RequestMapping(value = "reset")
    public String resetCaches(String token) {
        //validate token...
        log.info("GridAdminController:: Requested to force cache reset.");
        if(!keyService.isKeyValid(token)) {
            log.warn("Failed to authorize, passed token is not valid.");
            throw new AccessControlException("Wrong token");
        }
        log.info("GridAdminController:: user is authorized, performing grid cleanup operation.");
        loadingStatusService.forceGridCleanup();
        return "Success";
    }
}
