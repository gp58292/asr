package com.citi.aqua.derivz.web.quartz.config;
  
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.web.quartz.job.ReferenceDataRefreshCacheJob;
  
@Configuration 
public class QuartzConfiguration {
	
	@Value("${spring.quartz.cron.expression}")
	private String cronExpression;
	
	@Value("${spring.quartz.cron.start.delay}")
	private String startDelay;
	
	@Autowired
	CacheService cachingService;
	
	@Bean
	public JobDetailFactoryBean jobDetailFactoryBean() {
		JobDetailFactoryBean stFactory = new JobDetailFactoryBean();
		stFactory.setJobClass(ReferenceDataRefreshCacheJob.class);
		stFactory.setGroup("ReferenceDataGroup");
		stFactory.setName("ReferenceData");

		Map<String, Object> map = new HashMap<>();
		map.put("name", "CacheRefresh");
		map.put(ReferenceDataRefreshCacheJob.COUNT, 1);
		map.put(ReferenceDataRefreshCacheJob.LOCAL_CACHE_UPDATED_TIME, new Timestamp(new Date().getTime()));
		map.put("cachingService", cachingService);
		
		stFactory.setJobDataAsMap(map);
		return stFactory;
	}
	
	@Bean
	public CronTriggerFactoryBean cronTriggerFactoryBean() {
		CronTriggerFactoryBean stFactory = new CronTriggerFactoryBean();
		stFactory.setJobDetail(jobDetailFactoryBean().getObject());
		stFactory.setName("ReferenceDataTrigger");
		stFactory.setGroup("ReferenceDataGroup");
		int delay = Integer.parseInt(startDelay);
		stFactory.setStartDelay(delay);
		stFactory.setCronExpression(cronExpression);
		return stFactory;
	}
	
	@Bean
	public SchedulerFactoryBean schedulerFactoryBean() {
		SchedulerFactoryBean scheduler = new SchedulerFactoryBean();
		scheduler.setTriggers(cronTriggerFactoryBean().getObject());
		return scheduler;
	}
}  
