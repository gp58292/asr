package com.citi.aqua.derivz.data.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.citi.aqua.derivz.model.SelectionFilters;

@Repository
public interface SelectionFiltersRepository extends CrudRepository<SelectionFilters, Long> {

	// This method is used to find all the available filters without any
	// restrictions applied to them
	public List<SelectionFilters> findAllByOrderByLogicalGroupAsc();

	public List<SelectionFilters> findAllByOrderByDisplayNameAsc();

	// @Cacheable(value="TreeViewFilterListCache",keyGenerator="customKeyGenerator")
	// This method is used to find only those filters with the params listed keys
	public List<SelectionFilters> findByFilterKeyIn(final List<Long> keys);

	// This method is used to find individual filter with the parameter key
	public SelectionFilters findByFilterKey(final Long attributeKey);

	public List<SelectionFilters> findByComponentTypeIn(final List<String> componentTypes);

	// This method is used to define the predefined results only
	public List<SelectionFilters> findTop20ByNodeName(final String nodeName);

	// This method is used to load all data
	public List<SelectionFilters> findAll();

	public List<SelectionFilters> findByIsDisplayed(final int value);

	public List<SelectionFilters> findByCollateralLookup(final int value);

}
