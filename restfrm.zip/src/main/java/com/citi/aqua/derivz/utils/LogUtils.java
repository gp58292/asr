package com.citi.aqua.derivz.utils;


import org.apache.commons.lang3.StringUtils;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.util.Objects.isNull;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 8/8/2019
 */
public class LogUtils {
    private static final int MAX_LOGGED_LIST_ENTRIES = 5;
    private static final int MAX_LOGGED_RESULT_ROWS = 3;
    protected static final int MAX_STRING_ENTRY_LENGTH = 80;
    private static final int MAX_ROW_ITEM_COUNT = 20;
    protected static final int MAX_LOGGED_MAP_ENTRIES = 10;

    public static String listForLogging(List<?> entries) {
        return Optional.ofNullable(entries).map(e ->
                "[" + e.stream()
                        .limit(MAX_LOGGED_LIST_ENTRIES)
                        .map(value -> mapValue(value, MAX_STRING_ENTRY_LENGTH))
                        .collect(Collectors.joining(", "))
                        + overflowEllipsis(e.size() - MAX_LOGGED_LIST_ENTRIES, "items")
                        + "]"
        ).orElse("[[NULL LIST]]");
    }

    public static String mapForLogging(Map<String, ?> map) {
        return mapForLogging(map, MAX_STRING_ENTRY_LENGTH);
    }


    public static String mapForLogging(Map<String, ?> map, int entryLength) {
        if (isNull(map)) {
            return "{{NULL MAP}}";
        }
        return "{" + map.entrySet().stream()
                .sorted(Comparator.comparing(Map.Entry::getKey))
                .limit(MAX_LOGGED_MAP_ENTRIES)
                .map(e -> e.getKey() + "=" + mapValue(e.getValue(), entryLength))
                .collect(Collectors.joining(", "))
                + overflowEllipsis(map.size() - MAX_LOGGED_MAP_ENTRIES, "entries") + "}";
    }


    protected static String overflowEllipsis(int overflow, String type) {
        return overflow > 0 ? String.format(", ...(%d %smore)", overflow,
                Optional.ofNullable(type).map(s -> s + " ").orElse("")) : "";
    }

    public static String queryResultMapToString(List<Map<String, Object>> queryResult) {
        return Optional.ofNullable(queryResult).map(qres -> {
            String rowView = IntStream.range(0, MAX_LOGGED_RESULT_ROWS)
                    .limit(qres.size())
                    .mapToObj(i -> {
                        Map<String, Object> rowMap = qres.get(i);
                        String rowString = mapResultRow(rowMap);
                        return String.format("row %d: [%s%s]", i + 1, rowString,
                                overflowEllipsis(rowMap.size() - MAX_ROW_ITEM_COUNT, "entries"));
                    }).collect(Collectors.joining(", "));
            return String.format("[[Total %d rows: { %s%s}]]", qres.size(), rowView,
                    overflowEllipsis(qres.size() - MAX_LOGGED_RESULT_ROWS, "rows"));
        }).orElse("NULL RESULT");
    }

    protected static String mapResultRow(Map<String, Object> row) {
        return row.entrySet()
                .stream()
                .sorted(Comparator.comparing(Map.Entry::getKey))
                .limit(MAX_ROW_ITEM_COUNT)
                .map(e -> e.getKey() + "=" + mapValue(e.getValue(), MAX_STRING_ENTRY_LENGTH))
                .collect(Collectors.joining(", "));
    }

    protected static String mapValue(Object value, int maxWidth) {
        String res = StringUtils.abbreviate("" + value, maxWidth);
        if (value instanceof String) {
            res = String.format("\"%s\"", res);
        }
        return res;
    }


}
