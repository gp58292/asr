package com.citi.aqua.derivz.web.utils;

import java.util.List;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.derivz.vo.AgreementOptimalRankVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DerivzNonListSearchRestRequest<T> {

	private String tabName;
	
	private List<Long> agreementKeys;
	
	private List<AgreementOptimalRankVO> agreementOptimalRanks;
	
	private List<String> collateralTypes;

	private Boolean isFilterd;
	
	private List<SearchFieldVO<?>> criteria;
	
	private List<SearchResultColumns> smsColumns;
	
}