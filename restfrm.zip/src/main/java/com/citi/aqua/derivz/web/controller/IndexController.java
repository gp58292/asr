package com.citi.aqua.derivz.web.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class IndexController {

    private static final Logger LOGGER = LoggerFactory.getLogger(IndexController.class);

    @RequestMapping(value = "/{[path:^(?!api)(?!login)(?!assets)[^.]*}")
    public String redirect(HttpServletResponse response) throws IOException {
    	LOGGER.debug("Redirecting..");
        return "forward:/index.html";
    }
}
