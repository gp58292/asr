package com.citi.aqua.derivz.web.utils;

import org.apache.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.citi.aqua.derivz.web.exception.DerivzRestAPIError;

@Component
public final class ResponseBuilder {

	private ResponseBuilder() {}

	public static <T> DerivzRestResponse<T> build(T payload, int statusCode) {
		DerivzRestResponse<T> 	response = new DerivzRestResponse<>();
								response.setResponseData(payload);
								response.setResponseStatus(statusCode);
		return response;
	}
	public static <T> DerivzRestResponse<T> build(String message, int statusCode) {
		DerivzRestResponse<T> 	response = new DerivzRestResponse<>();
								response.setResponseData((T)message);
								response.setMessage(message);
								response.setResponseStatus(statusCode);
		return response;
	}
	
	public static <T> DerivzRestResponse<T> build(T payload, int statusCode, String errorMessage, String errorCode) {
		DerivzRestResponse<T> 	response = new DerivzRestResponse<>();
								response.setResponseData(payload);
								response.setResponseStatus(statusCode);
								response.setRestError(new DerivzRestAPIError(errorMessage, errorCode));
		return response;
	}
	public static <T> DerivzRestResponse<T> build(T payload, int statusCode, String errorMessage, String errorCode,String errorDetails) {
		DerivzRestResponse<T> 	response = new DerivzRestResponse<>();
								response.setResponseData(payload);
								response.setResponseStatus(statusCode);
								response.setRestError(new DerivzRestAPIError(errorMessage, errorCode,errorDetails));
		return response;
	}
	@SuppressWarnings("unchecked")
	public static <T> DerivzRestResponse<T> buildExceptionResponse() {
		DerivzRestResponse<T> 	response = new DerivzRestResponse<>();
								String message = "Exception Occured";
								response.setResponseData((T) message);
								response.setResponseStatus(HttpStatus.SC_NOT_MODIFIED);
								response.setRestError(new DerivzRestAPIError("GENERIC_MESSAGE_FOR_FAILURE", "GM001"));
		return response;
	}

}
