package com.citi.aqua.derivz.services.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citi.aqua.derivz.data.repository.RankingReportRepository;
import com.citi.aqua.derivz.model.RankingReport;
import com.citi.aqua.derivz.services.service.RankingReportService;

@Service
public class RankingReportServiceImpl implements RankingReportService {

	
	@Autowired
	RankingReportRepository rankingReportRepository;

	@Override
	public List<RankingReport> getRankingReportDetails() {
		return rankingReportRepository.findAll();
	}

}
