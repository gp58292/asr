package com.citi.aqua.derivz.web.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.model.RatingRankings;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.services.service.ReferenceDataProviderService;
import com.citi.aqua.derivz.vo.ReferenceDataVO;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import com.citi.aqua.derivz.web.utils.ResponseBuilder;

@RestController
@RequestMapping(DerivzAPIUriConstants.REFERENCE_API_URI)
public class ReferenceDataController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReferenceDataController.class);

	@Autowired
	ReferenceDataProviderService referenceDataProviderService;

	@Autowired
	CacheService cachingService;

	@SuppressWarnings("rawtypes")
	@RequestMapping(value = DerivzAPIUriConstants.GET_DROPDOWN_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<List<ReferenceDataVO>> getReferenceDataForDropDown(@PathVariable("key") final Long attributeKey) {
		LOGGER.debug("ReferenceDataController::getReferenceDataForDropDown() ");
		List<ReferenceDataVO> referenceResponseData = null;
		try {
			Map<Long, List<ReferenceDataVO>> referenceDataElementsList = cachingService.getReferenceData();
			referenceResponseData = referenceDataElementsList.get(attributeKey);
			return ResponseBuilder.build(referenceResponseData, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("ReferenceDataController::getReferenceDataForDropDown() :: Error " + de, de);
			return ResponseBuilder.build(referenceResponseData, HttpStatus.SC_NOT_FOUND, "Failed to retrieve reference data", "DS012");
		}
	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(value = DerivzAPIUriConstants.GET_TYPEAHEAD_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<List<ReferenceDataVO>> getTypeAheadList(@PathVariable("key") final Long attributeKey, @PathVariable("valueLike") final String referenceValueLike) {
		LOGGER.debug("ReferenceDataController::getReferenceData() ");
		List<ReferenceDataVO> referenceResponseData = null;
		try {
			if(referenceValueLike!=null && referenceValueLike.length() >0)
				referenceResponseData = referenceDataProviderService.findTypeAheadReferenceList(attributeKey, referenceValueLike);
			else 
				referenceResponseData=new ArrayList<>();
			return ResponseBuilder.build(referenceResponseData, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("ReferenceDataController::getTypeAheadList() :: Error " + de, de);
			return ResponseBuilder.build(referenceResponseData, HttpStatus.SC_NOT_FOUND, "Failed to get type ahead list data", "DS013");
		} 
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = DerivzAPIUriConstants.GET_TYPEAHEAD_BY_PASTED_VALUES_URI, method = RequestMethod.POST)
	public @ResponseBody DerivzRestResponse<Map<String,List<ReferenceDataVO>>> getTypeAheadListByPastedValues(HttpServletRequest request,@PathVariable("key") final Long attributeKey, @RequestBody String[] referenceValueLike) {
		String[] referenceValue = null;
		LOGGER.debug("ReferenceDataController::getReferenceData() ");
		if(referenceValueLike == null || referenceValueLike.length == 0) {
			referenceValue = request.getParameterValues("valueLike");
		} else {
			referenceValue = referenceValueLike;
		}
		Map<String,List<ReferenceDataVO>> referenceResponseData = null;
		try {
			referenceResponseData = referenceDataProviderService.findTypeAheadReferenceListByPastedValues(attributeKey, referenceValue);
			return ResponseBuilder.build(referenceResponseData, HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("ReferenceDataController::getTypeAheadListByPastedValues() :: Error " + de, de);
			return ResponseBuilder.build(referenceResponseData, HttpStatus.SC_NOT_FOUND, "Failed to get type ahead reference list data", "DS014");
		} 
	}

	
	
    @RequestMapping(value = DerivzAPIUriConstants.RATING_RANKING_API_URI, method = RequestMethod.GET)
    public @ResponseBody DerivzRestResponse<Set<RatingRankings>> getRatingRankings(HttpServletRequest request) {
        LOGGER.debug("getRatingRankings::getReferenceData() ");
        Set<RatingRankings> referenceResponseData = null;
        try {
            referenceResponseData = referenceDataProviderService.getRatingRankings();
            return ResponseBuilder.build(referenceResponseData, HttpStatus.SC_OK);
        } catch (DerivzApplicationException de) {
            LOGGER.error("getRatingRankings::getTypeAheadListByPastedValues() :: Error " + de, de);
            return ResponseBuilder.build(referenceResponseData, HttpStatus.SC_NOT_FOUND, "Failed to get rating rankings data", "DS015");
        } 
    }
    
    @RequestMapping(value = DerivzAPIUriConstants.DATASET_TYPE_API_URI, method = RequestMethod.GET)
    public @ResponseBody DerivzRestResponse<List<String>> getDatasetTypes(HttpServletRequest request) {
        LOGGER.debug("getDatasetTypes() ");
        List<String> referenceResponseData = null;
        try {
            referenceResponseData = referenceDataProviderService.getAllDatasetTypes();
            return ResponseBuilder.build(referenceResponseData, HttpStatus.SC_OK);
        } catch (DerivzApplicationException de) {
            LOGGER.error("getDatasetTypes() :: Error " + de, de);
            return ResponseBuilder.build(referenceResponseData, HttpStatus.SC_NOT_FOUND, "Failed to get rating rankings data", "DS015");
        } 
    }
    
    @GetMapping(value = DerivzAPIUriConstants.GET_COB_DATE_URI)
	public @ResponseBody DerivzRestResponse<String> getCobDate() {
		LOGGER.debug("ReferenceDataController::getCobDate() ");
		String cobDate = "";
		try {
			cobDate = referenceDataProviderService.getCobDateFromDB();
			if (!cobDate.isEmpty()) {
				return ResponseBuilder.build(cobDate, HttpStatus.SC_OK);
			} else {
				return ResponseBuilder.build(cobDate, HttpStatus.SC_NOT_FOUND, "No Cob Date found in database", "DS007");
			}
		} catch (DerivzApplicationException de) {
			LOGGER.error("BookmarkController::getCobDate() :: Error " + de, de);
			return ResponseBuilder.build(cobDate, HttpStatus.SC_NOT_FOUND, "No Cob Date found in database", "DS008");
		}
	}
}
