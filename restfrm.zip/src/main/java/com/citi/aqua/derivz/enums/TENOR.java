package com.citi.aqua.derivz.enums;

import java.util.function.Function;

public enum TENOR {

	YEARS("Years"),
	MONTHS("Months"),
	DAYS("Days");
	
	private final String name;
	private TENOR(String name) {this.name=name;}
	public String getName() {return this.name;}
	
	private static final Function<String, TENOR> func =EnumUtils.lookupMap(TENOR.class, e -> e.getName());
	public static TENOR valueOfByName(String name) {return func.apply(name);}
}
