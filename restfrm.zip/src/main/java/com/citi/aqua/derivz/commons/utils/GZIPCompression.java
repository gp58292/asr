package com.citi.aqua.derivz.commons.utils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GZIPCompression {

	private static final String UTF8 = "UTF-8";
	private static final Logger LOGGER = LoggerFactory.getLogger(GZIPCompression.class);
	
	public static byte[] compress(final String stringToCompress) {
        if (!ObjectUtils.anyNotNull(stringToCompress) || stringToCompress.length() == 0) {
            return null;
        }

        try (final ByteArrayOutputStream baos = new ByteArrayOutputStream();
            final GZIPOutputStream gzipOutput = new GZIPOutputStream(baos)) {
            gzipOutput.write(stringToCompress.getBytes(UTF8));
            gzipOutput.finish();
            return baos.toByteArray();
        } catch (IOException e) {
        	LOGGER.error("GZIPCompression::compress()  :: Error :" + e, e);
        }catch (Exception e) {
        	LOGGER.error("GZIPCompression::compress()  :: Error :" + e, e);
         }
        return stringToCompress.getBytes();
    }

    public static String decompress(final byte[] compressed) {
        if (!ObjectUtils.anyNotNull(compressed)|| compressed.length == 0) {
            return null;
        }
        final StringBuilder outStr = new StringBuilder();
        if(isCompressed(compressed)) {
            String line;
            try {
            	final GZIPInputStream gis = new GZIPInputStream(new ByteArrayInputStream(compressed));
                final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(gis, "UTF-8"));
				while ((line = bufferedReader.readLine()) != null) {
				  outStr.append(line);
				}
			} catch (IOException e) {
				LOGGER.error("GZIPCompression::decompress()  :: Error :" + e, e);
			}
	    }else {
	        outStr.append(compressed);
	    }
        
        return outStr.toString();
    }
    
    public static boolean isCompressed(final byte[] compressed) {
        return (compressed[0] == (byte) (GZIPInputStream.GZIP_MAGIC)) && (compressed[1] == (byte) (GZIPInputStream.GZIP_MAGIC >> 8));
    }
}
