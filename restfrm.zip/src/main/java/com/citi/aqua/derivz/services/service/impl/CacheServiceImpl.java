package com.citi.aqua.derivz.services.service.impl;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import com.citi.aqua.derivz.commons.constants.DerivzBeanConstants;
import com.citi.aqua.derivz.commons.constants.DerivzCacheConstants;
import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.exceptions.DerivzDAOLayerException;
import com.citi.aqua.derivz.data.cache.eh.ReferenceCacheKeys;
import com.citi.aqua.derivz.data.cache.eh.StaticCacheKeys;
import com.citi.aqua.derivz.data.cache.repository.SearchColumnsRepository;
import com.citi.aqua.derivz.data.repository.BatchProcessAuditRepository;
import com.citi.aqua.derivz.data.repository.DistinctValuesRepository;
import com.citi.aqua.derivz.data.repository.RatingRankingRepository;
import com.citi.aqua.derivz.data.repository.SelectionFiltersRepository;
import com.citi.aqua.derivz.enums.ComponentType;
import com.citi.aqua.derivz.model.BatchProcessAudit;
import com.citi.aqua.derivz.model.DistinctValues;
import com.citi.aqua.derivz.model.RatingRankings;
import com.citi.aqua.derivz.model.SelectionFilters;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.services.service.CombinedColumns;
import com.citi.aqua.derivz.vo.ReferenceDataVO;

@Service(DerivzBeanConstants.CACHE_SERVICE_BEAN)
public class CacheServiceImpl implements CacheService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReferenceDataProviderServiceImpl.class);

	@Autowired
	DistinctValuesRepository distinctValuesRepository;

	@Autowired
	SelectionFiltersRepository selectionFiltersRepository;

	@Autowired
	private BatchProcessAuditRepository batchProcessAuditRepository;
	
	@Autowired
	private RatingRankingRepository ratingRankingRepository;
	
	@Autowired
	private CombinedColumns combinedColumns;

	@SuppressWarnings("rawtypes")
	private Map<Long, List<ReferenceDataVO>> referenceMapCache;
	
	@Autowired
	private SearchColumnsRepository searchColumnsRepository;

	@SuppressWarnings("rawtypes")
	@Cacheable(cacheNames = DerivzCacheConstants.REFERENCE_DATA_CACHE)
	public Map<Long, List<ReferenceDataVO>> loadReferenceData() {
		try {
			final List<String> filterKeyList = Arrays.asList(ComponentType.DROPDOWN.getName(),ComponentType.EVENT_RATING.getName(),ComponentType.INCLUDE_EXCLUDE.getName(),ComponentType.MULTI_INCLUDE_EXCLUDE.getName());
			final List<SelectionFilters> selectionFilterList =combinedColumns.findByComponentTypeIn(filterKeyList); 
			final List<Long> compositeKeysLongList = selectionFilterList.stream()
					.map(selectionFilters -> selectionFilters.getFilterKey()).collect(Collectors.toList());
			final List<DistinctValues> distinctDataList = distinctValuesRepository.findByCompositeKeyIn(compositeKeysLongList);
			referenceMapCache = createCacheReferenceMap(distinctDataList);
			
		} catch (Exception e) {
			LOGGER.error("CachingServiceImpl::provideReferenceCache() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_REFERENCE_GET_DATA);
		}
		LOGGER.debug("CachingServiceImpl::loadReferenceData()::ends");
		return referenceMapCache;
	}
	
	@SuppressWarnings({ "rawtypes" })
	private Map<Long, List<ReferenceDataVO>> createCacheReferenceMap(final List<DistinctValues> distinctDataList) {
		LOGGER.debug("CachingServiceImpl::createCacheReferenceMap() ");
		Map<Long, List<ReferenceDataVO>> referenceMap = new HashMap<>();
		try {
			distinctDataList
				.stream()
				.forEach(distinct -> {
					Long compKey=distinct.getCompositeKey();
				if (referenceMap.containsKey(compKey)) {
					final List<ReferenceDataVO> referenceDataElementsList = referenceMap.get(compKey);
					final ReferenceDataVO referenceDataElements = new ReferenceDataVO(distinct.getKey(),distinct.getValue());
					referenceDataElementsList.add(referenceDataElements);
				} else {
					final List<ReferenceDataVO> referenceDataElementsList = new LinkedList<>();
					final ReferenceDataVO referenceDataElements = new ReferenceDataVO(distinct.getKey(),distinct.getValue());
					referenceDataElementsList.add(referenceDataElements);
					referenceMap.put(compKey, referenceDataElementsList);
				}
			});

		} catch (Exception e) {
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_REFERENCE_GET_DATA);
		}
		return referenceMap;
	}
	
	@Cacheable(cacheNames = DerivzCacheConstants.REFERENCE_DATA_CACHE,key="#key")
	public List<DistinctValues> loadAllReferenceData(ReferenceCacheKeys key) {
		 long start = System.currentTimeMillis();
		 LOGGER.debug("CachingServiceImpl::loadReferenceData()::Loading All reference records from DB ");
		 List<DistinctValues> allList= distinctValuesRepository.findAll();
		 long end = System.currentTimeMillis();
		 LOGGER.debug("CachingServiceImpl::loadReferenceData()::Time for Fecthing All reference records:: {} ms", (end-start));
		 return allList;
	}
	
	@SuppressWarnings({ "rawtypes" })
	@Cacheable(cacheNames = DerivzCacheConstants.REFERENCE_DATA_CACHE,key="#key")
	public  Map<Long, List<ReferenceDataVO>> createReferenceData(final List<DistinctValues> distinctDataList, ReferenceCacheKeys key) {
		try {
			return distinctDataList.parallelStream().collect(Collectors.groupingBy(DistinctValues::getCompositeKey,
									 Collectors.mapping(dv -> new ReferenceDataVO<String>(dv.getKey(),dv.getValue()),Collectors.toList())
									));
		} catch (Exception e) {
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_REFERENCE_GET_DATA);
		} 
	}
	
	@SuppressWarnings({ "rawtypes"})
	@Cacheable(cacheNames = DerivzCacheConstants.REFERENCE_DATA_CACHE,key="#key?.toString()+#referenceKey?.toString()")
	public   List<ReferenceDataVO> getReferenceDataByKey(final Long referenceKey, ReferenceCacheKeys key) {
		LOGGER.debug("CachingServiceImpl::createReferenceData() ");
		try {
			 long start = System.currentTimeMillis();
			 LOGGER.debug("CachingServiceImpl::getReferenceDataByKey()::Loading [{}] reference records from DB ", referenceKey);
			 List<DistinctValues> distinctList= distinctValuesRepository.findDistinctValueByKey(referenceKey);
			 long end = System.currentTimeMillis();
			 LOGGER.debug("CachingServiceImpl::getReferenceDataByKey()::Time for fecthing reference records:: {} ms", end-start);
			return distinctList.parallelStream().map(dv->new ReferenceDataVO<String>(dv.getKey(),dv.getValue())).collect(Collectors.toList());
		} catch (Exception e) {
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_REFERENCE_GET_DATA);
		}
	}

	@Transactional
	@CacheEvict(value = DerivzCacheConstants.REFERENCE_DATA_CACHE, allEntries = true)
	public void evictReferenceDataCache() {
		LOGGER.debug("Evicting all entries from REFERENCE_DATA_CACHE.");
	}

	@Transactional
	@CacheEvict(value = DerivzCacheConstants.STATIC_DATA_CACHE, allEntries = true)
	public void evictStaticDataCache() {
		LOGGER.debug("Evicting all entries from STATIC_COMPONENT_DATA_CACHE.");
	}

	@Override
	public BatchProcessAudit getBatchProcessAuditByModule(String module) {
		return batchProcessAuditRepository.findByModule(module);
	}

	@Override
	public List<BatchProcessAudit> getBatchProcessAudit() {
		return (List<BatchProcessAudit>) batchProcessAuditRepository.findAll();
	}

	@Override
	public int updateCacheUpdatedTimeForModule(Timestamp cacheUpdatedTime, String module) {
		return batchProcessAuditRepository.updateCacheUpdatedTimeForModule(cacheUpdatedTime, module);
	}

	@Cacheable(cacheNames = DerivzCacheConstants.STATIC_DATA_CACHE)
	public Map<Long, SelectionFilters> findStaticComponentData(StaticCacheKeys key) {
		LOGGER.debug("Start: Inside CachingServiceImpl::findStaticComponentData()");
		try {
			final List<SelectionFilters> selectionFiltersList = selectionFiltersRepository.findAll();
			// populate the value into map
			return selectionFiltersList
							.stream()
							.collect(Collectors.toMap(selectionFilters -> selectionFilters.getFilterKey(),selectionFilters -> selectionFilters));
		} catch (Exception e) {
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_REFERENCE_GET_DATA);
		}
	}

	public SelectionFilters findElementWithFilterKey(final Long key) {
		try {
			final Map<Long, SelectionFilters> staticComponentMap = findStaticComponentData(StaticCacheKeys.STATIC_COMPONENT_DATA);
			return staticComponentMap.get(key);
		} catch (Exception e) {
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_REFERENCE_GET_DATA);
		}
	}

	@SuppressWarnings("rawtypes")
	public Map<Long, List<ReferenceDataVO>> getReferenceData() {
		return referenceMapCache;
	}
	
    @Cacheable(cacheNames = DerivzCacheConstants.REFERENCE_DATA_CACHE,key="#key?.toString()")
    public  Set<RatingRankings> getRatingRankings(ReferenceCacheKeys key) {
        LOGGER.debug("CachingServiceImpl::createReferenceData() ");
        try {
             long start = System.currentTimeMillis();
             LOGGER.debug("CachingServiceImpl::getRatingRankings()::Loading [{}] reference records from DB ", key);
             List<RatingRankings> rankingsList=ratingRankingRepository.findAll();
             long end = System.currentTimeMillis();
             LOGGER.debug("CachingServiceImpl::getRatingRankings()::Time for fecthing reference records:: {} ms", end-start);
            return rankingsList!=null ? rankingsList.stream().collect(Collectors.toSet()):  null;
        } catch (Exception e) {
            throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_REFERENCE_GET_DATA);
        }
    }

	// Pull required columns to show in grid results in UI while loading app in browser
	@Cacheable(cacheNames = DerivzCacheConstants.STATIC_DATA_CACHE ,key="#key")
	public List<SearchResultColumns> getAllSearchResultColumns(StaticCacheKeys key) {
		try {
			return this.searchColumnsRepository
			      //.findAllByOrderByTabOrderAscFieldOrderAsc()
			      .findByIsEnabledTrueOrderByTabOrderAscFieldOrderAsc()
			      .parallelStream().map(mp-> { mp.setFieldName(mp.getFieldName().trim());mp.setDisplayName(mp.getDisplayName().trim()); mp.setTabName(mp.getTabName().trim());return mp; })
			      .collect(Collectors.toList());
		} catch (Exception e) {
			LOGGER.error("CachingServiceImpl::getAllSearchResultColumns() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_REFERENCE_GET_DATA);
		}
	}
	
	
	// Pull required columns to show in grid results in UI while loading app in browser
	@Cacheable(cacheNames = DerivzCacheConstants.STATIC_DATA_CACHE ,key="#key+#tabName")
	public List<SearchResultColumns> getAllSearchResultColumnsByTabName(StaticCacheKeys key,String tabName) {
		LOGGER.debug("Start: Inside CachingServiceImpl::getAllSearchResultColumns()");
		try {
			return this.getAllSearchResultColumns(StaticCacheKeys.RESULT_COLUMNS).stream().filter(p -> p.getTabName() == tabName).collect(Collectors.toList());
		} catch (Exception e) {
			LOGGER.error("CachingServiceImpl::getAllSearchResultColumns() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_REFERENCE_GET_DATA);
		}
	}

}
