package com.citi.aqua.derivz.dto;

import com.citi.aqua.derivz.model.Bookmark;
import com.citi.aqua.derivz.web.utils.BookmarkStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class BookmarkResponseDTO {

	private Bookmark bookmark;

	private BookmarkStatus bookmarkStatus;
	
}
