package com.citi.aqua.derivz.websocket;

import com.citi.aqua.derivz.services.grid.CeftDataSet;
import com.citi.aqua.derivz.services.grid.CeftDataSetStatus;
import com.citi.aqua.derivz.services.grid.LoadingProgressTracker;
import com.citi.aqua.frm.framework.grid.data.DataSetStatusCode;
import com.citi.aqua.frm.framework.grid.data.DefaultTopicNameConstants;
import com.citi.aqua.frm.framework.grid.data.ProcessLoadingMsg;
import com.citi.aqua.frm.framework.grid.utils.JSONUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteException;
import org.apache.ignite.events.EventType;
import org.apache.ignite.lang.IgniteBiPredicate;
import org.apache.ignite.lifecycle.LifecycleBean;
import org.apache.ignite.lifecycle.LifecycleEventType;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.atmosphere.config.service.Disconnect;
import org.atmosphere.config.service.ManagedService;
import org.atmosphere.config.service.Ready;
import org.atmosphere.cpr.AtmosphereResource;
import org.atmosphere.cpr.AtmosphereResourceEvent;
import org.atmosphere.cpr.AtmosphereResourceFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;
import reactor.core.scheduler.Schedulers;

import java.util.Date;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

@Slf4j
@Component
@ManagedService(path = "/websocket/dataservice")
@Profile("ignite")
public class WebsocketDataLoadingService implements LifecycleBean {

    private static final String WEBSOCKET_SCHEDULER_NAME = "WebsocketScheduler";
    @IgniteInstanceResource
    private Ignite ignite;
    private final AtmosphereResourceFactory atmosphereResourceFactory;
    private LoadingProgressTracker loadingProgressTracker;
    private FluxSink<ProcessLoadingMsg> fluxSink;

    @Autowired
    public WebsocketDataLoadingService(AtmosphereResourceFactory atmosphereResourceFactory,
            Optional<LoadingProgressTracker> loadingProgressTracker) {
        this.atmosphereResourceFactory = atmosphereResourceFactory;
        loadingProgressTracker.ifPresent(progressTracker -> {
            this.loadingProgressTracker = progressTracker;
        });

        Flux.<ProcessLoadingMsg>create(sink -> this.fluxSink = sink)
                .subscribeOn(Schedulers.newSingle(WEBSOCKET_SCHEDULER_NAME))
                .subscribe(m -> executeProgressMessage(m));
    }


    @Ready
    public void onReady(final AtmosphereResource resource) {
        log.debug("WebsocketDataLoadingService::onReady; uuid: {}", resource.uuid());
    }

    @Disconnect
    public void onDisconnect(AtmosphereResourceEvent event) {
        String uuid = event.getResource().uuid();
        if (event.isCancelled()) {
            log.debug("WebsocketDataLoadingService::onDisconnect Browser {} unexpectedly disconnected",
                    uuid);
        } else if (event.isClosedByClient()) {
            log.debug("WebsocketDataLoadingService::onDisconnect Browser {} closed the connection",
                    uuid);
        }
        atmosphereResourceFactory.remove(uuid);
        loadingProgressTracker.deregisterWebSocketUUID(uuid);
    }


    public void bindMessaging() {
        IgniteBiPredicate<UUID, Object> processingBiPredicate = (uuid, message) -> {
            try {
                if (ProcessLoadingMsg.class.isInstance(message)) {
                    fluxSink.next((ProcessLoadingMsg) message);
                } else {
                    log.warn("WebsocketDataLoadingService::Unexpected message with class {}, message: {}, skipping.",
                            message.getClass(), message);
                }
            } catch (Exception exc) {
                //we want not to stop because of single exception
                log.warn("WebsocketDataLoadingService:: Exception on ignite messaging, resuming.", exc);
            }
            return true;
        };
        ignite.message().localListen(DefaultTopicNameConstants.DEFAULT_LOADING_PROGRESS_TOPIC, processingBiPredicate);
    }


    private void sendMessage(Object msg, String uuid) {
        //we should at least filter user according to msg.dataSet.soeId here
        //we can do it when integration on frontend will do.\
        log.debug("WebsocketDataLoadingService::sendMessage Sending message over atmosphere resource {}, message: {}",
                uuid, msg);
        AtmosphereResource socket = atmosphereResourceFactory.find(uuid);
        if (socket != null) {
            String textMessage = JSONUtils.stringify(msg);
            socket.write(textMessage);
        } else {
            log.debug("WebsocketDataLoadingService::sendMessage No socket with id {} found, not sending message.",
                    uuid);
        }
    }


    private void executeProgressMessage(ProcessLoadingMsg message) {
        Set<String> uuids = loadingProgressTracker.findUUID(message.getDataSetId());
        //we are not sending original user back and forth, it is easier to get it back from request maping
        CeftDataSet dataSet = loadingProgressTracker.findDataSet(message.getDataSetId());


        if (uuids.isEmpty() || dataSet == null) {
            //this is the case we did not initialize request via "requestDataSet" api method.
            return;
        }

        DataSetStatusCode code;
        switch (message.getStatus()) {
            case SUCCESS:
                code = DataSetStatusCode.READY;
                break;
            case RUNNING:
                code = DataSetStatusCode.LOADING;
                break;
            default:
                code = DataSetStatusCode.NOT_LOADED;
        }

        long processedItemCount = message.getProcessedItemCount();
        long totalItems = Optional.ofNullable(message.getTotalCount())
                .orElse(code == DataSetStatusCode.READY ? processedItemCount : -1L);

        uuids.forEach(uuid -> sendMessage(
                new CeftDataSetStatus(dataSet, new Date(message.getDataSetVersion()), code, processedItemCount,
                        totalItems, uuid), uuid));
    }


    @Override
    public void onLifecycleEvent(LifecycleEventType event) throws IgniteException {
        if (event == LifecycleEventType.AFTER_NODE_START) {
            log.info("Initiating messaging.");
            bindMessaging();
            ignite.events().localListen(evt -> {
                if (EventType.EVT_CLIENT_NODE_RECONNECTED == evt.type()) {
                    bindMessaging();
                } else {
                    log.info(
                            "Unable to restore remote Ignite message listener for dataset updates. Quite likely that node is disconnected");
                }
                return true;
            }, EventType.EVT_CLIENT_NODE_RECONNECTED, EventType.EVT_CLIENT_NODE_DISCONNECTED);
        }
    }
}
