package com.citi.aqua.derivz.services.service.impl;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.citi.aqua.derivz.commons.constants.DerivzBeanConstants;
import com.citi.aqua.derivz.services.factory.SearchResultSource;
import com.citi.aqua.derivz.services.factory.SearchResultSourceFactory;
import com.citi.aqua.derivz.services.service.ExportService;
import com.citi.aqua.derivz.vo.SearchFieldVO;

@Service(DerivzBeanConstants.EXPORT_SERVICE_BEAN)
public class ExportServiceImpl implements ExportService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ExportServiceImpl.class);
	
	@Autowired
	SearchResultSourceFactory searchResultSourceFactory;

	@SuppressWarnings("rawtypes")
	@Override
	public void exportToExcel(HttpServletResponse response, String source, List<SearchFieldVO> searchCriteria, List<Long> agreementKeyList) throws IOException {
		LOGGER.debug("ExportServiceImpl :: exportToExcel method initiated");
		int rowNum = 0;
		SearchResultSource searchResultSource = searchResultSourceFactory.getSearchResultSource(source);
		HSSFWorkbook workbook = new HSSFWorkbook();
		workbook.createSheet(source);
		List<String> headerColumns = searchResultSource.getHeaders();
		rowNum = searchResultSource.addHeaderRow(workbook, source, headerColumns, rowNum);
		searchResultSource.addDataRow(workbook, source, searchCriteria, agreementKeyList, rowNum);
		searchResultSource.generateExcel(response, workbook, source);
	}
	
}
