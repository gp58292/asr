package com.citi.aqua.derivz.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import com.citi.aqua.derivz.model.TableMetaData.TableMetadataKey;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
/**
 * @name TableMetaData
 * @description Entity to get the meta data information about any table
 *
 */
@Getter
@Setter
@ToString
@Entity
@IdClass(TableMetadataKey.class)
@Table(name = DerivzDBConstants.TBL_META_DATA)
public class TableMetaData extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "Table_Name")
	String tableName;

	@Id
	@Column(name = "Column_Name")
	String columnName;

	
	@Column(name = "Data_Type")
	String dataType;
	
	 public static class TableMetadataKey implements Serializable {
		private static final long serialVersionUID = 1L;
		String columnName;
	    String tableName;
	  }

}