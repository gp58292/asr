package com.citi.aqua.derivz.services.service.impl;

import com.citi.aqua.derivz.commons.exceptions.CEFTException;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.exceptions.DerivzDAOLayerException;
import com.citi.aqua.derivz.data.jdbc.SearchResultDAO;
import com.citi.aqua.derivz.dto.RetrievedDataResponseDTO;
import com.citi.aqua.derivz.model.DerivzDBConstants;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.derivz.services.grid.CeftDataSet;
import com.citi.aqua.derivz.services.grid.CeftFrmQueryService;
import com.citi.aqua.derivz.services.grid.InvalidDataRequestException;
import com.citi.aqua.derivz.services.grid.model.SearchQueryResult;
import com.citi.aqua.derivz.utils.LogUtils;
import com.citi.aqua.derivz.vo.AgreementOptimalRankVO;
import com.citi.aqua.derivz.vo.RatingFieldVO;
import com.citi.aqua.derivz.vo.aggrid.filter.ColumnFilter;
import com.citi.aqua.derivz.vo.aggrid.filter.SetColumnFilter;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;
import com.citi.aqua.frm.ceft.CeftDataSetType;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;

@Slf4j
public class SearchResultServiceImpl implements SearchResultDAO {
	
    private CeftFrmQueryService queryService;
    
    private JdbcTemplate jdbcTemplate;
    
	public SearchResultServiceImpl(CeftFrmQueryService queryService,JdbcTemplate jdbcTemplate) {
		this.queryService=queryService;
		this.jdbcTemplate=jdbcTemplate;
	}

	@SuppressWarnings("rawtypes")
	@Override @Deprecated
	public RetrievedDataResponseDTO retriveResultsFromDB(String tabName, List<SearchResultColumns> searchResultColumnsList,
			Boolean isFilterd, List<Long> agreementKeyList, List<AgreementOptimalRankVO> agreementOptimalRanks,
			List<String[]> rowList, String collatralTypeNamesCSV, List<RatingFieldVO> listOfRangeField,
			List<SearchResultColumns> smsColumns, List<String[]> listOfTenorRange) throws CEFTException {
		return null;
	}

	@Override
	public RetrievedDataResponseDTO retriveDatasetResultsUsingBookmarkId(String datasetType,
			List<SearchResultColumns> searchResultColumnsList, String userId, Long bookmarkId, EnterpriseGetRowsRequest gridRequest,List<String> agreementKeys) throws CEFTException {
		CeftDataSet ceftDataset=new CeftDataSet(userId, bookmarkId, CeftDataSetType.findByCode(datasetType.toLowerCase()));
		log.debug("Request to ignite cache, Data set: {}", ceftDataset);

		if(agreementKeys!=null && !agreementKeys.isEmpty() && CeftDataSetType.LISTED!=CeftDataSetType.findByCode(datasetType.toLowerCase()) ) {
            Pair<String, ColumnFilter> agreementKeysFilter = filterDataOnAgreementKeys(agreementKeys, ceftDataset);
            log.debug("AgreementKeyFilter::{}",agreementKeysFilter);
            Map<String, ColumnFilter> filterMap = new HashMap<>(Optional.ofNullable(gridRequest.getFilterModel()).orElse(emptyMap()));
            filterMap.put(agreementKeysFilter.getKey(), agreementKeysFilter.getValue());
            gridRequest.setFilterModel(filterMap);
        }
        try {
			RetrievedDataResponseDTO dto = new RetrievedDataResponseDTO();
			log.info("Search Query request: {}", gridRequest);

			SearchQueryResult queryResult = queryService.searchQuery(gridRequest, ceftDataset);
			if (queryResult.getValues() != null) {
				log.debug("Query result: {}", LogUtils.queryResultMapToString(queryResult.getValues()));
			}
			dto.setListOfRecords(queryResult.getValues());
			dto.setSecondaryColDefs(queryResult.getPivotColumns());
			if (queryResult.isPivotColumnOverflow()) {
				dto.setListOfRecords(emptyList());
				dto.setCount(0L);
				dto.setPivotColumnOverflow(true);
			} else {
			long size = queryService.countQuery(gridRequest, ceftDataset);
			dto.setCount(size);
			}
			return dto;
		} catch (InvalidDataRequestException invalidRequestException) {
        	RetrievedDataResponseDTO emptyRes = new RetrievedDataResponseDTO();
        	emptyRes.setListOfRecords(emptyList());
        	emptyRes.setSecondaryColDefs(emptyList());
        	emptyRes.setCount(0L);
        	return emptyRes;
		}
	}

	private Pair<String, ColumnFilter> filterDataOnAgreementKeys(List<String> agreementKeys, CeftDataSet dataSet) {
		if(!CeftDataSetType.BOX.equals(dataSet.getType())){
		    return new ImmutablePair<>(DerivzDBConstants.AGREEMENT_KEY,new SetColumnFilter(agreementKeys));
		} else {
			List<String> securityKeys= new ArrayList<>();
			StringBuilder sqlBuilder = new StringBuilder(DerivzDBConstants.CALL_PROC);
			sqlBuilder.append(DerivzDBConstants.SCHEMA_CEFT + ".")
			.append(DerivzDBConstants.SP_GET_SEC_KEY_BOX)
			.append(DerivzDBConstants.PROC_ONE_ARG);
			try (Connection conn = jdbcTemplate.getDataSource().getConnection() ;SQLServerCallableStatement cs = conn.prepareCall(sqlBuilder.toString()).unwrap(SQLServerCallableStatement.class)) {
				
				SQLServerDataTable sourceDataTable = new SQLServerDataTable();
				sourceDataTable.addColumnMetadata(DerivzDBConstants.AGREEMENT_KEY, java.sql.Types.VARCHAR);
				agreementKeys.stream().forEach(key -> {
					try {
						sourceDataTable.addRow(key.toString());
					} catch (SQLServerException e) {
						throw new DerivzApplicationException(e,
								DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
					}
				});
				cs.setStructured(1,
						DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.POSTINGS_INPUT,
						sourceDataTable);
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					ResultSet rs = cs.getResultSet();
					while(rs.next()){
						String secKey=rs.getString(1);
						securityKeys.add(secKey);
					}
				}
				
			}catch (SQLException e) {
				log.error("SearchResultServiceImpl::filterDataOnAgreementKeys() ::Error");
				throw new DerivzApplicationException(e,
						DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
			}
			return new ImmutablePair<>(DerivzDBConstants.SECURITY_KEYS,new SetColumnFilter(securityKeys));
		}
	}
}
