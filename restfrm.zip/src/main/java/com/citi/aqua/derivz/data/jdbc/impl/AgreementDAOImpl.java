package com.citi.aqua.derivz.data.jdbc.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.dbutils.DbUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.exceptions.DerivzDAOLayerException;
import com.citi.aqua.derivz.data.jdbc.AgreementDAO;
import com.citi.aqua.derivz.dto.AgreementResponseDTO;
import com.citi.aqua.derivz.dto.CSAResponseDTO;
import com.citi.aqua.derivz.model.DBConstants;
import com.citi.aqua.derivz.vo.CollateralCashDetailsVO;
import com.citi.aqua.derivz.vo.CollateralHaircutDetailsVO;
import com.citi.aqua.derivz.vo.PartyDetailsVO;
import com.citi.aqua.derivz.vo.ProductDetailsVO;
import com.citi.aqua.derivz.vo.ThresholdDetailsVO;
import com.microsoft.sqlserver.jdbc.SQLServerCallableStatement;

@Repository
public class AgreementDAOImpl implements AgreementDAO {

	private static final String YEARS = " YEARS";
	private static final String MONTHS = " MONTHS";
	private static final String DAYS = " DAYS";

	private static final Logger log = LoggerFactory.getLogger(AgreementDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public AgreementResponseDTO callAgreementDetailsProc(Long agreementKey) {
		log.debug("AgreementDAOImpl :: callAgreementDetailsProc");
		AgreementResponseDTO agreementResponseDTO = new AgreementResponseDTO();
		ResultSet rs = null;
		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			StringBuilder sqlBuilder = new StringBuilder(DBConstants.CALL_PROC);
			sqlBuilder.append(DBConstants.SCHEMA_CEFT).append(".")
					.append(DBConstants.SP_GET_AGREEMENT_DETAIL_DATA).append(DBConstants.PROC_ONE_ARG);
			try (SQLServerCallableStatement cs = conn.prepareCall(sqlBuilder.toString()).unwrap(SQLServerCallableStatement.class)) {
				cs.setLong(1, agreementKey);
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					rs = cs.getResultSet();
					while (rs.next()) {

						agreementResponseDTO.setAgreementId(rs.getLong(DBConstants.AGREEMENT_ID_1));
						agreementResponseDTO.setAgreementKey(rs.getLong(DBConstants.AGREEMENT_KEY));
						agreementResponseDTO.setClearingAgreement(rs.getString("clearing_agreement"));
						agreementResponseDTO.setCloseoutNettingEnforcabilityFlag(rs.getString("closeout_netting_enforcability_flag"));
						agreementResponseDTO.setEntity(rs.getString("entity"));
						agreementResponseDTO.setExchangeClearedAgreement(rs.getString("exchangecleared_agreement"));
						agreementResponseDTO.setMasterAgreement(rs.getString("master_agreement"));
						agreementResponseDTO.setMasterAgreementStatus(rs.getString("master_agreement_status"));
						agreementResponseDTO.setSendToCredit(rs.getString("send_to_credit"));
						agreementResponseDTO.setSme(rs.getString("s_m_e"));
						agreementResponseDTO.setGoverningLaw(rs.getString("governing_law"));
						agreementResponseDTO.setPartyLegalEntity(rs.getString("party_legal_entity"));
						agreementResponseDTO.setCounterParty(rs.getString("counter_party"));
						agreementResponseDTO.setParty(rs.getString("party"));
						agreementResponseDTO.setIncorporatedCountry(rs.getString("incorporated_country"));
						agreementResponseDTO.setPartyGfcId(rs.getString(DBConstants.PARTY_GFCID));
						agreementResponseDTO.setCounterPartyGfcId(rs.getString(DBConstants.COUNTER_PARTY_GFCID));

						this.setPartyDetails(agreementResponseDTO, rs);
						this.setCounterPartyDetails(agreementResponseDTO, rs);
						this.setCoveredProducts(agreementResponseDTO, rs);

					}
					resultSetReturned = cs.getMoreResults();
					if (resultSetReturned) {
						rs = cs.getResultSet();
						List<Map<String,String>> csaTypeList=new ArrayList<>();
						
						while (rs.next()) {
							Map<String,String> csaTypeStatusMap = new HashMap<>();
							csaTypeStatusMap.put(DBConstants.CSA_DESCRIPTION_1,rs.getString(DBConstants.CSA_DESCRIPTION_1));
							csaTypeStatusMap.put(DBConstants.CSA_STATUS_1,rs.getString(DBConstants.CSA_STATUS_1));
							csaTypeList.add(csaTypeStatusMap);
						}
						agreementResponseDTO.setCsaTypeDescList(csaTypeList);
					}
				}
			}
		} catch (SQLException e) {
			log.error("AgreementDAOImpl::callAgreementDetailsProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(rs);
		}
		return agreementResponseDTO;
	}

	private void setPartyDetails(AgreementResponseDTO agreementResponseDTO, ResultSet rs) throws SQLException {
		Set<PartyDetailsVO> partyDetailsList = agreementResponseDTO.getPartyDetails();
		if (partyDetailsList == null) {
			partyDetailsList = new HashSet<>();
		}
		if (rs.getString("party_location") != null || rs.getString(DBConstants.PARTY_GFCID) != null
				|| rs.getString("party_branch_name") != null || rs.getString("funding_index") != null) {
			PartyDetailsVO partyDetails = new PartyDetailsVO();
			partyDetails.setFundingIndex(rs.getInt("funding_index"));
			partyDetails.setPartyBranchName(rs.getString("party_branch_name"));
			partyDetails.setPartyGfcId(rs.getString(DBConstants.PARTY_GFCID));
			partyDetails.setPartyLocation(rs.getString("party_location"));
			partyDetailsList.add(partyDetails);
			agreementResponseDTO.setPartyDetails(partyDetailsList);
		}
	}

	private void setCounterPartyDetails(AgreementResponseDTO agreementResponseDTO, ResultSet rs) throws SQLException {
		Set<PartyDetailsVO> cpDetailsList = agreementResponseDTO.getCounterPartyDetails();
		if (cpDetailsList == null) {
			cpDetailsList = new HashSet<>();
		}
		if (rs.getString("counter_party_branch_name") != null || rs.getString("counter_party_gfcid") != null
				|| rs.getString("counter_party_location") != null) {
			PartyDetailsVO cpDetails = new PartyDetailsVO();
			cpDetails.setPartyBranchName(rs.getString("counter_party_branch_name"));
			cpDetails.setPartyGfcId(rs.getString(DBConstants.COUNTER_PARTY_GFCID));
			cpDetails.setPartyLocation(rs.getString("counter_party_location"));
			cpDetailsList.add(cpDetails);
			agreementResponseDTO.setCounterPartyDetails(cpDetailsList);
		}
	}

	private void setCoveredProducts(AgreementResponseDTO agreementResponseDTO, ResultSet rs) throws SQLException {
		List<ProductDetailsVO> coveredProductList = agreementResponseDTO.getCoveredProducts();
		if (coveredProductList == null) {
			coveredProductList = new ArrayList<>();
		}
		if (rs.getString("include_exclude") != null || rs.getString("instrument_name") != null) {
			ProductDetailsVO coveredProducts = new ProductDetailsVO();
			coveredProducts.setIncludeExclude(rs.getString("include_exclude"));
			coveredProducts.setInstrumentCode(rs.getInt("instrument_code"));
			coveredProducts.setInstrumentName(rs.getString("instrument_name"));
			coveredProducts.setCovProdType(rs.getString("cov_prod_type"));
			coveredProducts.setParentInstrCode(rs.getInt(DBConstants.COV_PROD_PARENT_INSTR_CODE));
			coveredProductList.add(coveredProducts);
			agreementResponseDTO.setCoveredProducts(coveredProductList);
		}
	}

	@Override
	public CSAResponseDTO callCsaTypeDetailsProc(Long agreementId, String csaType) {
		CSAResponseDTO csaTypeResponseDTO;
		log.debug("AgreementDAOImpl :: callCsaDetailsProc");
		try {
			csaTypeResponseDTO = callCsaTypeDetailsProcHeader(agreementId, csaType);
			callCSAThresholdProc(csaTypeResponseDTO, agreementId, csaType);
			callCSACreditThresholdProc(csaTypeResponseDTO, agreementId, csaType);
			callCSAPublicRatingProc(csaTypeResponseDTO, agreementId, csaType);
			callCSAHaircutScheduleProc(csaTypeResponseDTO, agreementId, csaType);
			callCSAScheduledThresholdProc(csaTypeResponseDTO, agreementId, csaType);
			callCSACollateralCashProc(csaTypeResponseDTO, agreementId, csaType);
			callCSACoveredProductsProc(csaTypeResponseDTO, agreementId, csaType);

		} catch (Exception e) {
			log.error("AgreementDAOImpl::callCsaDetailsProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		}
		return csaTypeResponseDTO;

	}

	private void callCSAScheduledThresholdProc(CSAResponseDTO csaTypeResponseDTO, Long agreementId, String csaType) throws SQLException {
		log.debug("AgreementDAOImpl :: callCSAScheduledThresholdProc");
		ResultSet rs = null;
		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			StringBuilder sqlBuilder = new StringBuilder(DBConstants.CALL_PROC);
			sqlBuilder.append(DBConstants.SCHEMA_CEFT).append(".")
					.append(DBConstants.SP_GET_CSA_TYPE_DATA_SCHEDULE_THRESHOLD)
					.append(DBConstants.PROC_TWO_ARG);
			try (SQLServerCallableStatement cs = conn.prepareCall(sqlBuilder.toString()).unwrap(SQLServerCallableStatement.class)) {
				cs.setLong(1, agreementId);
				cs.setString(2, csaType);
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					rs = cs.getResultSet();
					while (rs.next()) {
						Set<ThresholdDetailsVO> partyScheduledThresholdList = csaTypeResponseDTO.getPartyScheduledThreshold();
						if (partyScheduledThresholdList == null) {
							partyScheduledThresholdList = new HashSet<>();
						}
						if (rs.getString("party_type_of_threshold") != null
								|| rs.getString("party_Basis") != null
								|| rs.getString("party_currency") != null
								|| rs.getString("party_amount") != null) {
							ThresholdDetailsVO threshold = new ThresholdDetailsVO();
							threshold.setType(rs.getString("party_type_of_threshold"));
							threshold.setBasis(rs.getString("party_Basis"));
							threshold.setCurrency(rs.getString("party_currency"));
							threshold.setAmount(BigDecimal.valueOf(rs.getDouble("party_amount")));
							threshold.setStartDate(rs.getDate("party_start_date"));
							threshold.setEndDate(rs.getDate("party_end_date"));
							partyScheduledThresholdList.add(threshold);
							csaTypeResponseDTO.setPartyScheduledThreshold(partyScheduledThresholdList);
						}
						Set<ThresholdDetailsVO> cpScheduledThresholdList = csaTypeResponseDTO.getCpScheduledThreshold();
						if (cpScheduledThresholdList == null) {
							cpScheduledThresholdList = new HashSet<>();
						}
						if (rs.getString("cp_type_of_threshold") != null || rs.getString("cp_basis") != null
								|| rs.getString("cp_currency") != null
								|| rs.getString("cp_amount") != null) {
							ThresholdDetailsVO threshold = new ThresholdDetailsVO();
							threshold.setType(rs.getString("cp_type_of_threshold"));
							threshold.setBasis(rs.getString("cp_basis"));
							threshold.setCurrency(rs.getString("cp_currency"));
							threshold.setAmount(BigDecimal.valueOf(rs.getDouble("cp_amount")));
							threshold.setStartDate(rs.getDate("cp_start_date"));
							threshold.setEndDate(rs.getDate("cp_end_date"));
							cpScheduledThresholdList.add(threshold);
							csaTypeResponseDTO.setCpScheduledThreshold(cpScheduledThresholdList);
						}

					}

				}
			} catch (SQLException e) {
				log.error("AgreementDAOImpl::callCSAScheduledThresholdProc() ::Error" + e, e);
				throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
			} finally {
				DbUtils.closeQuietly(rs);
			}

		}
		
	}

	private CSAResponseDTO callCsaTypeDetailsProcHeader(Long agreementId, String csaType) {
		log.debug("AgreementDAOImpl :: callCsaTypeDetailsProcHeader");
		CSAResponseDTO csaTypeResponseDTO = new CSAResponseDTO();
		ResultSet rs = null;
		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			StringBuilder sqlBuilder = new StringBuilder(DBConstants.CALL_PROC);
			sqlBuilder.append(DBConstants.SCHEMA_CEFT).append(".")
					.append(DBConstants.SP_GET_CSA_TYPE_DATA_HEADER)
					.append(DBConstants.PROC_TWO_ARG);
			try (SQLServerCallableStatement cs = conn.prepareCall(sqlBuilder.toString()).unwrap(SQLServerCallableStatement.class)) {
				cs.setLong(1, agreementId);
				cs.setString(2, csaType);
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					rs = cs.getResultSet();
					while (rs.next()) {
						csaTypeResponseDTO.setCsaDescription(rs.getString("csa_description"));
						csaTypeResponseDTO.setMarginEffectiveDate(rs.getDate("margin_effective_date"));
						csaTypeResponseDTO.setPartyPseMarginReduction(rs.getString("party_pse_margin_reduction"));
						csaTypeResponseDTO.setNetting(rs.getString("netting"));
						csaTypeResponseDTO.setCsaStatus(rs.getString("csa_status"));
						csaTypeResponseDTO.setSecurityAgreementDate(rs.getDate("security_agreementdate"));
						csaTypeResponseDTO.setCustodianRequired(rs.getString("custodian_required"));
						csaTypeResponseDTO.setPledgor(rs.getString("pledgor"));
						csaTypeResponseDTO.setCurrency(rs.getString("currency"));
						csaTypeResponseDTO.setCallFrequency(rs.getString("call_frequency"));
						csaTypeResponseDTO.setThirdPartyCustFlag(rs.getString("third_party_cust_flag"));
						csaTypeResponseDTO.setPartyName(rs.getString("party_name"));
						csaTypeResponseDTO.setPartyGfcid(rs.getString(DBConstants.PARTY_GFCID));
						csaTypeResponseDTO.setConsentToSubstitution(rs.getString("consent_to_substitution"));
						csaTypeResponseDTO.setCpName(rs.getString("cp_name"));
						csaTypeResponseDTO.setCpGfcid(rs.getString("cp_gfcid"));
						csaTypeResponseDTO.setCollateralReuse(rs.getString("collateral_reuse"));
						csaTypeResponseDTO.setCpCollateralReuse(rs.getString("cp_coll_reuse"));
						csaTypeResponseDTO.setCpConsentToSubstitutionRequired(
								rs.getString("cp_consent_to_substitution_required"));
						csaTypeResponseDTO.setPartyCustodianRequired(rs.getString("party_custodian_required"));
						csaTypeResponseDTO.setCpCustodianRequired(rs.getString("cp_custodian_required"));
						

					}
				}
			}
		} catch (Exception e) {
			log.error("AgreementDAOImpl::callCsaDetailsProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(rs);
		}
		return csaTypeResponseDTO;
	}

	private void sortCollateralHairCutList(Set<CollateralHaircutDetailsVO> collateralHaircutSet) {
		List<CollateralHaircutDetailsVO> sortedList = new ArrayList<>(collateralHaircutSet);
		Collections.sort(sortedList, new Comparator<CollateralHaircutDetailsVO>() {

			@Override
			public int compare(CollateralHaircutDetailsVO o1, CollateralHaircutDetailsVO o2) {
				int minTermO1 = 0;
				int minTermO2 = 0;
				int result = 0;
				minTermO1 = convertToDays(o1.getAchMinTerm());
				minTermO2 = convertToDays(o2.getAchMinTerm());
				result = minTermO1 - minTermO2;
				if (result == 0) {
					int maxTermO1 = 0;
					int maxTermO2 = 0;
					maxTermO1 = convertToDays(o1.getAchMaxTerm());
					maxTermO2 = convertToDays(o2.getAchMaxTerm());
					result = maxTermO1 - maxTermO2;
					if (result == 0) {
						result = o1.getAchType().compareTo(o2.getAchType());
						if(result==0) {
							result = o1.getAchHaicutPercentage().compareTo(o2.getAchHaicutPercentage());
						}
					}
				}
				return result;
			}

			private int convertToDays(String str) {
				int days = 0;
				if (str != null) {
					if (str.contains(DAYS)) {
						days = Integer.parseInt(str.replace(DAYS, ""));
					}
					if (str.contains(MONTHS)) {
						days = 30 * Integer.parseInt(str.replace(MONTHS, ""));
					}
					if (str.contains(YEARS)) {
						days = 365 * Integer.parseInt(str.replace(YEARS, ""));
					}
				}
				return days;
			}

		});
		collateralHaircutSet.clear();
		collateralHaircutSet.addAll(sortedList);

	}

	private void callCSAThresholdProc(CSAResponseDTO csaTypeResponseDTO, Long agreementId, String csaType)
			throws SQLException {
		log.debug("AgreementDAOImpl :: callCSAThresholdProc");
		ResultSet rs = null;
		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			StringBuilder sqlBuilder = new StringBuilder(DBConstants.CALL_PROC);
			sqlBuilder.append(DBConstants.SCHEMA_CEFT).append(".")
					.append(DBConstants.SP_GET_CSA_TYPE_DATA_THRESHOLD).append(DBConstants.PROC_TWO_ARG);
			try (SQLServerCallableStatement cs = conn.prepareCall(sqlBuilder.toString()).unwrap(SQLServerCallableStatement.class)) {
				cs.setLong(1, agreementId);
				cs.setString(2, csaType);
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					rs = cs.getResultSet();
					while (rs.next()) {
						Set<ThresholdDetailsVO> partyThresholdList = csaTypeResponseDTO.getPartyThresholdList();
						if (partyThresholdList == null) {
							partyThresholdList = new HashSet<>();
						}
						if (rs.getString("party_threshold_type") != null
								|| rs.getString("party_threshold_basis") != null
								|| rs.getString("party_threshold_currency") != null
								|| rs.getString("party_threshold_amount") != null) {
							ThresholdDetailsVO threshold = new ThresholdDetailsVO();
							threshold.setType(rs.getString("party_threshold_type"));
							threshold.setBasis(rs.getString("party_threshold_basis"));
							threshold.setCurrency(rs.getString("party_threshold_currency"));
							threshold.setAmount(BigDecimal.valueOf(rs.getDouble("party_threshold_amount")));
							partyThresholdList.add(threshold);
							csaTypeResponseDTO.setPartyThresholdList(partyThresholdList);
						}
						Set<ThresholdDetailsVO> cpThresholdList = csaTypeResponseDTO.getCpThresholdList();
						if (cpThresholdList == null) {
							cpThresholdList = new HashSet<>();
						}
						if (rs.getString("cp_threhold_type") != null || rs.getString("cp_threshold_basis") != null
								|| rs.getString("cp_threshold_currency") != null
								|| rs.getString("cp_threshold_amount") != null) {
							ThresholdDetailsVO threshold = new ThresholdDetailsVO();
							threshold.setType(rs.getString("cp_threhold_type"));
							threshold.setBasis(rs.getString("cp_threshold_basis"));
							threshold.setCurrency(rs.getString("cp_threshold_currency"));
							threshold.setAmount(BigDecimal.valueOf(rs.getDouble("cp_threshold_amount")));
							cpThresholdList.add(threshold);
							csaTypeResponseDTO.setCpThresholdList(cpThresholdList);
						}

					}

				}
			} catch (SQLException e) {
				log.error("AgreementDAOImpl::callCSAThresholdProc() ::Error" + e, e);
				throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
			} finally {
				DbUtils.closeQuietly(rs);
			}

		}
	}

	private void callCSACreditThresholdProc(CSAResponseDTO csaTypeResponseDTO, Long agreementId, String csaType) {
		log.debug("AgreementDAOImpl :: callCSACreditThresholdProc");
		ResultSet rs = null;
		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			StringBuilder sql = new StringBuilder(DBConstants.CALL_PROC);
			sql.append(DBConstants.SCHEMA_CEFT).append(".")
					.append(DBConstants.SP_GET_CSA_TYPE_DATA_CREDIT_THRESHOLD).append(DBConstants.PROC_TWO_ARG);
			try (SQLServerCallableStatement cs = conn.prepareCall(sql.toString()).unwrap(SQLServerCallableStatement.class)) {
				cs.setLong(1, agreementId);
				cs.setString(2, csaType);
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					rs = cs.getResultSet();
					while (rs.next()) {
						Set<ThresholdDetailsVO> partyCreditThresholdList = csaTypeResponseDTO
								.getPartyCreditThresholdList();
						if (partyCreditThresholdList == null) {
							partyCreditThresholdList = new LinkedHashSet<>();
						}
						if (rs.getString("party_credit_threshold_type") != null
								|| rs.getString("party_credit_threshold_agency") != null
								|| rs.getString("party_credit_threshold_rating") != null
								|| rs.getString("party_credit_threshold_amount") != null) {
							ThresholdDetailsVO threshold = new ThresholdDetailsVO();
							threshold.setType(rs.getString("party_credit_threshold_type"));
							threshold.setAgency(rs.getString("party_credit_threshold_agency"));
							threshold.setRating(rs.getString("party_credit_threshold_rating"));
							threshold.setAmount(BigDecimal.valueOf(rs.getDouble("party_credit_threshold_amount")));
							partyCreditThresholdList.add(threshold);
							csaTypeResponseDTO.setPartyCreditThresholdList(partyCreditThresholdList);
						}
						Set<ThresholdDetailsVO> cpCreditThresholdList = csaTypeResponseDTO.getCpCreditThresholdList();
						if (cpCreditThresholdList == null) {
							cpCreditThresholdList = new HashSet<>();
						}
						if (rs.getString("cp_credit_threshold_type") != null
								|| rs.getString("cp_credit_threshold_agency") != null
								|| rs.getString("cp_credit_threshold_rating") != null
								|| rs.getString("cp_credit_threshold_amount") != null) {
							ThresholdDetailsVO threshold = new ThresholdDetailsVO();
							threshold.setType(rs.getString("cp_credit_threshold_type"));
							threshold.setAgency(rs.getString("cp_credit_threshold_agency"));
							threshold.setRating(rs.getString("cp_credit_threshold_rating"));
							threshold.setAmount(BigDecimal.valueOf(rs.getDouble("cp_credit_threshold_amount")));
							cpCreditThresholdList.add(threshold);
							csaTypeResponseDTO.setCpCreditThresholdList(cpCreditThresholdList);
						}
					}

				}
			}
		} catch (SQLException e) {
			log.error("AgreementDAOImpl::callCSACreditThresholdProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(rs);
		}
	}

	private void callCSAPublicRatingProc(CSAResponseDTO csaTypeResponseDTO, Long agreementId, String csaType) {
		log.debug("AgreementDAOImpl :: callCSAPublicRatingProc");
		ResultSet rs = null;
		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			StringBuilder sql = new StringBuilder(DBConstants.CALL_PROC);
			sql.append(DBConstants.SCHEMA_CEFT).append(".")
					.append(DBConstants.SP_GET_CSA_TYPE_DATA_PUBLIC_RATING).append(DBConstants.PROC_TWO_ARG);
			try (SQLServerCallableStatement cs = conn.prepareCall(sql.toString()).unwrap(SQLServerCallableStatement.class)) {
				cs.setLong(1, agreementId);
				cs.setString(2, csaType);
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					rs = cs.getResultSet();
					while (rs.next()) {
						Set<ThresholdDetailsVO> partyPublicRatingList = csaTypeResponseDTO.getPartyPublicRatingList();
						if (partyPublicRatingList == null) {
							partyPublicRatingList = new HashSet<>();
						}
						if (rs.getString("party_public_rating_agency") != null
								|| rs.getString("party_public_rating_rating") != null) {
							ThresholdDetailsVO threshold = new ThresholdDetailsVO();
							threshold.setRatingDate(rs.getDate("party_public_rating_date"));
							threshold.setAgency(rs.getString("party_public_rating_agency"));
							threshold.setRating(rs.getString("party_public_rating_rating"));
							partyPublicRatingList.add(threshold);
							csaTypeResponseDTO.setPartyPublicRatingList(partyPublicRatingList);
						}
						Set<ThresholdDetailsVO> cpPublicRatingList = csaTypeResponseDTO.getCpPublicRatingList();
						if (cpPublicRatingList == null) {
							cpPublicRatingList = new HashSet<>();
						}
						if (rs.getString("cp_public_rating_agency") != null
								|| rs.getString("cp_public_rating_rating") != null) {
							ThresholdDetailsVO threshold = new ThresholdDetailsVO();
							threshold.setRatingDate(rs.getDate("cp_public_rating_date"));
							threshold.setAgency(rs.getString("cp_public_rating_agency"));
							threshold.setRating(rs.getString("cp_public_rating_rating"));
							cpPublicRatingList.add(threshold);
							csaTypeResponseDTO.setCpPublicRatingList(cpPublicRatingList);
						}
					}

				}
			}
		} catch (SQLException e) {
			log.error("AgreementDAOImpl::callCSAPublicRatingProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(rs);
		}

	}

	private void callCSAHaircutScheduleProc(CSAResponseDTO csaTypeResponseDTO, Long agreementId, String csaType) {
		log.debug("AgreementDAOImpl :: callCSAHaircutScheduleProc");
		ResultSet rs = null;
		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			StringBuilder sql = new StringBuilder(DBConstants.CALL_PROC);
			sql.append(DBConstants.SCHEMA_CEFT).append(".")
					.append(DBConstants.SP_GET_CSA_TYPE_DATA_HAIRCUT_SCHEDULE).append(DBConstants.PROC_TWO_ARG);
			try (SQLServerCallableStatement cs = conn.prepareCall(sql.toString()).unwrap(SQLServerCallableStatement.class)) {
				cs.setLong(1, agreementId);
				cs.setString(2, csaType);
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					rs = cs.getResultSet();
					while (rs.next()) {
						Set<CollateralHaircutDetailsVO> collateralHaircutSet = csaTypeResponseDTO
								.getCollateralHaircutScheduleList();
						if (collateralHaircutSet == null) {
							collateralHaircutSet = new LinkedHashSet<>();
						}
						if (rs.getString("ach_type") != null || rs.getString("ach_min_term") != null
								|| rs.getString("ach_max_term") != null || rs.getString("ach_haicut_percentage") != null
								|| rs.getString("ach_issuer_rating") != null || rs.getString("ach_rating") != null) {
							CollateralHaircutDetailsVO collHaircutSchedule = new CollateralHaircutDetailsVO();
							collHaircutSchedule.setAchType(rs.getString("ach_type"));
							collHaircutSchedule.setAchMinTerm(rs.getString("ach_min_term"));
							collHaircutSchedule.setAchMaxTerm(rs.getString("ach_max_term"));
							collHaircutSchedule.setAchHaicutPercentage(rs.getDouble("ach_haicut_percentage"));
							collHaircutSchedule.setAchIssuerRating(rs.getString("ach_issuer_rating"));
							collHaircutSchedule.setAchRating(rs.getString("ach_rating"));
							collHaircutSchedule.setAchCollateralApplied(rs.getString("ach_collateral_applied"));
							collHaircutSchedule.setCollateralParty(rs.getString("collateral_party"));
							collHaircutSchedule.setAchRanking(rs.getString("ach_ranking"));
							collateralHaircutSet.add(collHaircutSchedule);
							sortCollateralHairCutList(collateralHaircutSet);
							csaTypeResponseDTO.setCollateralHaircutScheduleList(collateralHaircutSet);
						}
					}

				}
			}
		} catch (SQLException e) {
			log.error("AgreementDAOImpl::callCSAHaircutScheduleProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(rs);
		}

	}

	private void callCSACollateralCashProc(CSAResponseDTO csaTypeResponseDTO, Long agreementId, String csaType) {
		log.debug("AgreementDAOImpl :: callCSACollateralCashProc");
		ResultSet rs = null;
		Set<CollateralCashDetailsVO> accCashDetailsList = new HashSet<>();

		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			StringBuilder sql = new StringBuilder(DBConstants.CALL_PROC);
			sql.append(DBConstants.SCHEMA_CEFT).append(".")
					.append(DBConstants.SP_GET_CSA_TYPE_DATA_COLL_CASH).append(DBConstants.PROC_TWO_ARG);
			try (SQLServerCallableStatement cs = conn.prepareCall(sql.toString()).unwrap(SQLServerCallableStatement.class)) {
				cs.setLong(1, agreementId);
				cs.setString(2, csaType);
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					rs = cs.getResultSet();
					while (rs.next()) {

						if (rs.getString("acc_currency") != null || rs.getString("acc_interest_matrix") != null
								|| rs.getString("acc_interest_spread") != null
								|| rs.getString("acc_compounding") != null) {
							CollateralCashDetailsVO collateralCash = new CollateralCashDetailsVO();
							collateralCash.setAccCurrency(rs.getString("acc_currency"));
							collateralCash.setAccInterestMatrix(rs.getString("acc_interest_matrix"));
							collateralCash.setAccInterestSpread(rs.getString("acc_interest_spread"));
							collateralCash.setAccCompounding(rs.getString("acc_compounding"));
							collateralCash.setAccPaymentFrequency(rs.getString("acc_payment_frequency"));
							collateralCash.setAccResetFrequency(rs.getString("acc_reset_frequency"));
							collateralCash.setAccRanking(rs.getString("acc_ranking"));
							accCashDetailsList.add(collateralCash);

						}
					}
					csaTypeResponseDTO.setAcceptableCollateralCashList(accCashDetailsList);
				}
			}
		} catch (SQLException e) {
			log.error("AgreementDAOImpl::callCSACollateralCashProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(rs);
		}

	}

	private void callCSACoveredProductsProc(CSAResponseDTO csaTypeResponseDTO, Long agreementId, String csaType) {
		log.debug("AgreementDAOImpl :: callCSACoveredProductsProc");
		ResultSet rs = null;
		Set<ProductDetailsVO> coveredProductList = new HashSet<>();

		try (Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			StringBuilder sql = new StringBuilder(DBConstants.CALL_PROC);
			sql.append(DBConstants.SCHEMA_CEFT).append(".")
					.append(DBConstants.SP_GET_CSA_TYPE_DATA_COV_PROD).append(DBConstants.PROC_TWO_ARG);
			try (SQLServerCallableStatement cs = conn.prepareCall(sql.toString()).unwrap(SQLServerCallableStatement.class)) {
				cs.setLong(1, agreementId);
				cs.setString(2, csaType);
				boolean resultSetReturned = cs.execute();
				if (resultSetReturned) {
					rs = cs.getResultSet();
					while (rs.next()) {
						if (rs.getString(DBConstants.COV_PROD_PARENT_INSTR_CODE) != null
								|| rs.getString("cov_prod_include_exclude") != null
								|| rs.getString("cov_prod_type") != null || rs.getString("cov_prod_name") != null) {
							ProductDetailsVO product = new ProductDetailsVO();
							product.setIncludeExclude(rs.getString("cov_prod_include_exclude"));
							product.setInstrumentCode(rs.getInt("cov_prod_code"));
							product.setParentInstrCode(rs.getInt(DBConstants.COV_PROD_PARENT_INSTR_CODE));
							product.setCovProdType(rs.getString("cov_prod_type"));
							product.setInstrumentName(rs.getString("cov_prod_name"));
							coveredProductList.add(product);

						}
					}
					csaTypeResponseDTO.setCoveredProducts(coveredProductList);
				}
			}
		} catch (SQLException e) {
			log.error("AgreementDAOImpl::callCSACoveredProductsProc() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(rs);
		}

	}
}
