package com.citi.aqua.derivz.services.grid;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/18/2019
 */
public class CeftFrmGridException extends RuntimeException {
    private static final long serialVersionUID = -5166226825525135602L;

    public CeftFrmGridException(String message) {
        super(message);
    }

}
