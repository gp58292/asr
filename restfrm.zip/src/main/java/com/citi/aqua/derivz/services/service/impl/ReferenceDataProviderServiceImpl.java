package com.citi.aqua.derivz.services.service.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.citi.aqua.derivz.commons.constants.DerivzBeanConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.exceptions.DerivzDAOLayerException;
import com.citi.aqua.derivz.data.cache.eh.ReferenceCacheKeys;
import com.citi.aqua.derivz.data.repository.BaseRepository;
import com.citi.aqua.derivz.data.repository.BookmarkRepository;
import com.citi.aqua.derivz.data.repository.DistinctValuesRepository;
import com.citi.aqua.derivz.model.DBConstants;
import com.citi.aqua.derivz.model.DistinctValues;
import com.citi.aqua.derivz.model.RatingRankings;
import com.citi.aqua.derivz.model.ui.UIComponentConfig;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.services.service.ReferenceDataProviderService;
import com.citi.aqua.derivz.utils.ReferenceUtils;
import com.citi.aqua.derivz.vo.ReferenceDataVO;

@Service(DerivzBeanConstants.REFERENCE_DATA_PROVIDER_SERVICE_BEAN)
public class ReferenceDataProviderServiceImpl implements ReferenceDataProviderService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReferenceDataProviderServiceImpl.class);

	@Autowired
	BaseRepository baseRepository;

	@Autowired
	DistinctValuesRepository distinctValuesRepository;

	@Autowired
	CacheService cachingService;

	@Autowired
	UIComponentConfig uiComponentConfig;
	
	@Autowired
	ReferenceUtils referenceUtils;

	@Autowired
	BookmarkRepository bookmarkRepository;
	
	/**
	 * @name findDistinctReferenceData
	 * @description Method is used to get distinct drop down list reference data
	 * @param Long
	 * @return List
	 */
	@SuppressWarnings("rawtypes")
	public List<ReferenceDataVO> findDistinctReferenceData(final Long attributeKey) {
		LOGGER.debug("ReferenceDataProviderServiceImpl::findDistinctReferenceData() ");
		final List<ReferenceDataVO> referenceResponseData = new LinkedList<>();
		List<DistinctValues> distinctValueList = new LinkedList<>();
		try {
			// Repository call to they the distinct data values for drop down list from the
			// database
			distinctValueList = distinctValuesRepository.findDistinctValueByKey(attributeKey);
			// Iterating through the values to format the value in the API expected format
			for (DistinctValues distinctValue : distinctValueList) {
				ReferenceDataVO referenceDataElements = new ReferenceDataVO();
				referenceDataElements.setKey(distinctValue.getKey());
				referenceDataElements.setValue(distinctValue.getValue());
				referenceResponseData.add(referenceDataElements);
			}
		} catch (Exception e) {
			LOGGER.error("ReferenceDataProviderServiceImpl::findDistinctReferenceData() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_REFERENCE_GET_DATA);
		}
		return referenceResponseData;
	}

	/**
	 * @name findTypeAheadReferenceList
	 * @description Method is used to get distinct type ahead value for the
	 *              reference data
	 * @param Long
	 * @param String referenceValueLike
	 * @return List
	 */
	@SuppressWarnings("rawtypes")
	public List<ReferenceDataVO> findTypeAheadReferenceList(final Long attributeKey, final String referenceValueLike) {
		LOGGER.debug("ReferenceDataProviderServiceImpl::findTypeAheadReferenceList() ");
		List<ReferenceDataVO> distinctValueList = new LinkedList<>();
		try {
			distinctValueList = cachingService.getReferenceDataByKey(attributeKey, ReferenceCacheKeys.ALL_REFRENCE);

		} catch (Exception e) {
			LOGGER.error("ReferenceDataProviderServiceImpl::findTypeAheadReferenceList() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_REFERENCE_GET_DATA);
		}
				
		final List<ReferenceDataVO> searchList = referenceUtils.findSearchedList(distinctValueList, referenceValueLike);
		return searchList
					.parallelStream()
					.limit(uiComponentConfig.getTypeahead().getLimit().orElse(5L)).collect(Collectors.toList());

	}

	@SuppressWarnings("rawtypes")
	public Map<String, List<ReferenceDataVO>> findTypeAheadReferenceListByPastedValues(final Long attributeKey,
			final String[] referenceValueLike) {
		LOGGER.debug("ReferenceDataProviderServiceImpl::findTypeAheadReferenceListByPastedValues() ");
		List<ReferenceDataVO> distinctValueList = new LinkedList<>();
		Map<String, List<ReferenceDataVO>> mpResult = new HashMap<>();
		try {
			distinctValueList = cachingService.getReferenceDataByKey(attributeKey, ReferenceCacheKeys.ALL_REFRENCE);

		} catch (Exception e) {
			LOGGER.error("ReferenceDataProviderServiceImpl::findTypeAheadReferenceList() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_REFERENCE_GET_DATA);
		}
		List<String> valuesToMatch = Arrays.asList(referenceValueLike).parallelStream().map(mp -> mp.trim())
				.filter(p -> p != null && p.length() > 0) // Filter empty row from pasted values
				.collect(Collectors.toList());

		List<ReferenceDataVO> referenceDataList = distinctValueList.parallelStream()
				.filter(p -> valuesToMatch.parallelStream()
						.anyMatch(searchStr -> searchStr.equalsIgnoreCase(p.getValue().toString())))
				.collect(Collectors.toList());

		List<ReferenceDataVO> notMatchingReferenceDataList = valuesToMatch.parallelStream()
				.filter(searchStr -> referenceDataList.parallelStream()
						.noneMatch(p -> searchStr.equalsIgnoreCase(p.getValue().toString())))
				.map(str -> new ReferenceDataVO(-1L, str)).collect(Collectors.toList());
		mpResult.put("FOUND", referenceDataList);
		mpResult.put("NOT_FOUND", notMatchingReferenceDataList);
		return mpResult;
	}

	@Override
	public Set<RatingRankings> getRatingRankings() {
		return cachingService.getRatingRankings(ReferenceCacheKeys.RATING_RANKINGS);
	}

	@Override
	public List<String> getAllDatasetTypes() {
		return bookmarkRepository.getAllDatasetType();
	}
	
	//@Override
	public String getCobDateFromDB() {
		String cobDate = null;
		try {
			cobDate = distinctValuesRepository.getCobDateFromDB();
			
		} catch (Exception se) {
			LOGGER.error("distinctValuesRepository::getCobDateFromDB() ::Error" + se.getMessage());
		}
		return cobDate;
	}
}
