package com.citi.aqua.derivz.services.grid.model;

import com.citi.aqua.derivz.services.grid.CeftDataSet;
import com.citi.aqua.derivz.vo.aggrid.filter.ColumnFilter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public abstract class DataRequest {
    CeftDataSet dataSet;
    Map<String, ColumnFilter> filters=new HashMap<>();
}
