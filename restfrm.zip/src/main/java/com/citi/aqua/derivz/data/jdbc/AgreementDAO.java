package com.citi.aqua.derivz.data.jdbc;

import com.citi.aqua.derivz.dto.AgreementResponseDTO;
import com.citi.aqua.derivz.dto.CSAResponseDTO;

public interface AgreementDAO {
	
	public AgreementResponseDTO callAgreementDetailsProc(final Long agreementKey);

	public CSAResponseDTO callCsaTypeDetailsProc(final Long agreementId, final String csaType);

}
