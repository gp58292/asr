package com.citi.aqua.derivz.vo.aggrid.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ColumnVO implements Serializable {
	private static final long serialVersionUID = 1L;
	private String id;
    private String displayName;
    private String field;
    private String aggFunc;

    public ColumnVO(String id) {
        this.id = id;
    }
}