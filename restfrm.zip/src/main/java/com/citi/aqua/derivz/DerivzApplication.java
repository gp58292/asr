package com.citi.aqua.derivz;

import com.citi.aqua.derivz.data.cache.eh.StaticCacheKeys;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.frm.framework.messaging.websocket.config.EnableAtmosphereFramework;
import com.citi.aqua.frm.framework.utils.VersionLoggerConfig;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableCaching
@EnableJpaRepositories(basePackages = {"com.citi.aqua.derivz.data.repository", "com.citi.aqua.derivz.data.cache.repository"})
@EntityScan(basePackages = "com.citi.aqua.derivz.model")
@EnableTransactionManagement
@EnableConfigurationProperties
@EnableEncryptableProperties
@EnableAtmosphereFramework({"com.citi.aqua.derivz.websocket"})
@Import(VersionLoggerConfig.class)
public class DerivzApplication {

    public static final Logger LOGGER = LoggerFactory.getLogger(DerivzApplication.class);

    private final CacheService cacheService;

    @Autowired
    public DerivzApplication(CacheService cacheService) {
        this.cacheService = cacheService;
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(DerivzApplication.class);
        app.run(args);
    }

    @Bean
    CommandLineRunner runner() {
        return args -> {
            LOGGER.debug("CommandLineRunner running in the UnsplashApplication class...");

            LOGGER.info("########################## Start: Inside Spring Boot CommandLineRunner: ###########################");
            cacheService.findStaticComponentData(StaticCacheKeys.STATIC_COMPONENT_DATA);
            cacheService.getAllSearchResultColumns(StaticCacheKeys.RESULT_COLUMNS);
            LOGGER.info("####### Successfully Cached Static Data: Inside Spring Boot CommandLineRunner: #####");

            cacheService.loadReferenceData();
            LOGGER.info("###### Successfully Cached Reference Data: Inside Spring Boot CommandLineRunner: #####");
            //cacheService.loadAllReferenceData(ReferenceCacheKeys.ALL_REFRENCE);
            LOGGER.info("########################## End: Inside Spring Boot CommandLineRunner: ###########################");
        };
    }

}
