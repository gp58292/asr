package com.citi.aqua.derivz.comparator;

import java.util.Comparator;

import com.citi.aqua.derivz.vo.GroupVO;

public class GroupComparator implements Comparator<GroupVO> {

	@Override
	public int compare(GroupVO o1, GroupVO o2) {

		return o1.getName().compareTo(o2.getName());
	}

}
