package com.citi.aqua.derivz.vo.aggrid.filter;

import com.citi.aqua.derivz.utils.LogUtils;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SetColumnFilter extends ColumnFilter {
    private List<String> values= Collections.emptyList();

    public String toString() {
        return String.format("SetColumnFilter(filterType=%s, values=%s)", filterType, LogUtils.listForLogging(values));
    }
}
