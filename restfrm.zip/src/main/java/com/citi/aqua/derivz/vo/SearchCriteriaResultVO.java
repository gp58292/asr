package com.citi.aqua.derivz.vo;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SearchCriteriaResultVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private long agreementKey;

	private String address;

	private String agreementCcy;

	private int agreementId;

	private String alco;

	private String autoEarlyTerminationFlag;

	private String bankruptcy;

	private String basis;

	private String sME;

	private String calculationAgent;

	private String callFrequency;

	private int callMonth;

	private String callday1Eom;

	private int callday1Ofmonth;

	private String callday2Eom;

	private int callday2Ofmonth;

	private String capfloorAddendum;

	private int cashCollDeliveryDeadline;

	private int cashCollateralIndexTime;

	private int cashDeliveryBankingDays;

	private String chain;

	private String citiThreshold;

	private String clearedActivity;

	private String clearedHouseActivity;

	private String clearingAgreement;

	private String clientClearingActivity;

	private String closeoutAmountProtocol;

	private String closeoutNettingEnforcabilityFlag;

	private String collateralCalculationAgent;

	private String collateralCallDeadline;

	private String collateralNotificationRegion;

	private String collateralSecuritiesTerm;

	private String collateralValuationFrequency;

	private String commonCustodian;

	private String consentToSubstitution;

	private String contact;

	private long counterPartyKey;

	private long counterPartyReportingKey;

	private String counterpartyMultibranch;

	private String counterpartyName;

	private String countryName;

	private double cpBorrowingThreshold;

	private String cpCreditBasedThresholdAmount;

	private String cpCustodianRequired;

	private String cpMarginType;

	private double cpMinimumCallThresholdAmount;

	private double cpMinimumReturnThresholdAmount;

	private String cpRating;

	private String cpRatingAgency;

	private String cpSpecifiedEntities;

	private String cpSpecifiedIndebtedness;

	private String cpSpecifiedTransactions;

	private String cpTerminationCurrency;

	private double cpThreshold;

	private String cpThresholdBasis;

	private double cpThresholdThresholdAmount;

	private double cpTransactionThreshold;

	private String cpTypeOfBorrowingThreshold;

	private double cpincrementalMovementAmount;

	private int csaCode;

	private String csaDescription;

	private String csaMarginType;

	private String csaStatus;

	private String currency;

	private String custodianRequired;

	private String custodyBankName;

	private String customerName;

	private int deletedFlag;

	private String derivsProvision;

	private String disputeMechanism;

	private String endDateSysAq;

	private String entity;

	private String entryDate;

	private String exchangeclearedAgreement;

	private String extension;

	private String fatca;

	private String fax;

	private String fileNumber;

	private String firmAddress;

	private String firmContact;

	private String firmCustodyBankName;

	private String firmFax;

	private String firmTelephone;

	private String fxProvision;

	private String fxoProvision;

	private String governingLaw;

	private BigDecimal iaThreshold;

	private double imFloor;

	private BigDecimal imcap;

	private String incorporatedCountry;

	private double incrementalMovementAmount;

	private String interCompanyAgreement;

	private String intercompanyType;

	private short isKeyOnly;

	private String lastModified;

	private String linkMrnccdOutofscopeTrades;

	private String maDate;

	private String mandatoryMarkFrequency;

	private String marginEffectiveDate;

	private String marktomarketAgent;

	private String masterAgreement;

	private String masterAgreementStatus;

	private String masterAgreementVersion;

	private String masterRole;

	private double miniTransferAmt;

	private int mirrorAgreementid;

	private String mnemonic;

	private String mrnccdCompliance;

	private String mtmCurrency;

	private String multiBranchMargining;

	private String multiCurrencyMargining;

	private String negotiationStartDate;

	private String netting;

	private String parentChild;

	private String partyAssociate;

	private double partyBorrowingThreshold;

	private String partyCreditbasedThresholdAmount;

	private String partyCustodianRequired;

	private long partyKey;

	private String partyLegalEntity;

	private String partyMarginType;

	private double partyMinimumCallThresholdAmount;

	private double partyMinimumReturnThresholdAmount;

	private String partyMultibranch;

	private String partyPseMarginReduction;

	private String partyRating;

	private String partyRatingAgency;

	private long partyReportingKey;

	private String partySpecifiedEntities;

	private String partySpecifiedIndebtedness;

	private String partySpecifiedTransactions;

	private String partyTerminationCurrency;

	private String partyThresholdBasis;

	private double partyThresholdThresholdAmount;

	private double partyTransactionThreshold;

	private String partyTypeOfBorrowingThreshold;

	private String pbgIndicator;

	private String pledgor;

	private String pseMarginLastModified;

	private String pseMarginReduction;

	private String pseMarginReductionFlag;

	private String restrictionsOnCollateral;

	private String saTriggerEvent;

	private int securitiesDeliveryBankingDays;

	private String securityAgreementdate;

	private String securityCallDayOfWeek;

	private String securityCounterpartyName;

	private String securityGoverningLaw;

	private String securityTypeOfAccount;

	private String serviceRepresentative;

	private String sftBaselNetting;

	private String shelf;

	private String sixCApplies;

	private String sixcApplied;

	private String sourceSystem;

	private String startDateSysAq;

	private String telephone;

	private String tendApplies;

	private String terminationDate;

	private String terminationTiming;

	private String terminationType;

	private String thirdPartyCustFlag;

	private double thresholdAmount;

	private String thresholdBasis;

	private String thresholdCurrency;

	private String triggerEvent;

	private String triparty;

	private String trueSegregation;

	private String useBillingfeeAsCollateral;

	private String useCouponAsCollateral;

	private String useExcessVmAsImCollateral;

	private String useFeeAsCollateral;

	private String usePaiAsCollateral;

	private String usenscnewRules;

	private String varEligible;

	private String vmCollateralInCashOnly;

}