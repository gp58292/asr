package com.citi.aqua.derivz.commons.utils;

import com.fasterxml.jackson.databind.JsonNode;

public class JsonUtil {

	public static Object isNullThenNull(JsonNode node) {
		return null;
	}
}
