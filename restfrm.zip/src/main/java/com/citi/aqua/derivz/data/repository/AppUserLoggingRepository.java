package com.citi.aqua.derivz.data.repository;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.citi.aqua.derivz.model.AppUserLogging;


@Repository
@Transactional
public interface AppUserLoggingRepository extends CrudRepository<AppUserLogging, Long> {

}
