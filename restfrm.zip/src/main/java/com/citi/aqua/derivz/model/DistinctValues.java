package com.citi.aqua.derivz.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = DerivzDBConstants.TBL_DISTINCT_DATA, schema=DerivzDBConstants.SCHEMA_CEFT)
public class DistinctValues extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "uniq_key")
	private Long key;

	@Column(name = "value")
	private String value;

	@Column(name = "composite_key")
	private Long compositeKey;

}