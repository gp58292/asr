package com.citi.aqua.derivz.web.utils;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CEFTBookmarkPlusSearchRequest {

	private BookmarkRequest bookmarkRequest;

	private SearchRequest searchRequest;

	private String atmosphereResourceUuid;

}
