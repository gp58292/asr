package com.citi.aqua.derivz.vo;

import java.io.IOException;
import com.citi.aqua.derivz.model.DerivzJsonConstants;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.type.TypeFactory;

public class RatingRangeListDeserializer<T> extends StdDeserializer<RatingRangeList<T>> {

  private static final long serialVersionUID = 1L;

  static ObjectMapper objectMapper = new ObjectMapper();
  static TypeFactory typeFactory = objectMapper.getTypeFactory();

  public RatingRangeListDeserializer() {
    this(null);
  }

  protected RatingRangeListDeserializer(Class<?> vc) {
    super(vc);
  }



  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  public RatingRangeList<T> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
    JsonNode node = p.getCodec().readTree(p);
    RatingRangeList.RatingRangeListBuilder scvb = RatingRangeList.builder();

    if (node.get(DerivzJsonConstants.VALUE_LIST) != null) {
      scvb.valueList(objectMapper.readValue(node.get(DerivzJsonConstants.VALUE_LIST).toString(), typeFactory.constructArrayType(RatingRange.class)));
    }
    return (RatingRangeList<T>)scvb.build();
  }

}
