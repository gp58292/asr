package com.citi.aqua.derivz.model;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class VoyagerNavigationData implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private int datasetId;

	private int bookmarkId;
	
	private int displayFlag;
	
	private String displayName;
	
	private String shortName;
	
	private String navigationUrl;
    
}
