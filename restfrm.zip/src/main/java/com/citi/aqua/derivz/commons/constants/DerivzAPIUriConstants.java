package com.citi.aqua.derivz.commons.constants;

public final class DerivzAPIUriConstants {

	public static final String HOME_PAGE = "/index.html";
	public static final String API_CALL = "/api/";

	// Settings API
	public static final String SETTINGS_API_URI = "/api/settings";
	public static final String SETTINGS_TREE_VIEW_URI = "/columns-tree";
	public static final String SETTINGS_FLAT_VIEW_URI = "/columns-list";
	public static final String SETTINGS_UPDATE_COLUMNS_URI = "/columns";
	public static final String SETTINGS_GET_COLUMNS_URI = "/columns/{userId}";

	// Search Result Display API
	public static final String SEARCH_API_URI = "/api/search";
	public static final String SEARCH_COLLATERAL_URI = "/collateral";
	public static final String SEARCH_VOYAGER_DATASET="voyagerdata";
	public static final String SEARCH_RESULT_LISTED_COLUMNS_URI = "/result/listed-columns";
	public static final String SEARCH_RESULT_EXPORT_URI = "/result/export";
	public static final String SEARCH_RESULT_EXPORT_CSV_URI = "/result/export-csv";
    public static final String SEARCH_COLLATERAL_TYPE_LOOKUP = "/collateral-type-lookup";
    
    public static final String AGREEMENT_API_URI = "/api/agreement";
	public static final String SEARCH_AGREEMENT_DETAILS_URI = "/getAgreementDetails/{agreementKey}";
	public static final String SEARCH_CSA_TYPE_DETAILS_URI = "/getCsaTypeDetails/{agreementId}/{csaType}";
	public static final String BATCHSTATUS_API_URI = "/api/batchstatus";
	public static final String BATCH_STATUS_REPORT_URI = "/getReport/{cobDate}";
	// Book mark API
	public static final String BOOKMARK_API_URI = "/api/bookmark";
	public static final String BOOKMARK_WITH_ID_URI = "/{bookmarkId}";
	public static final String PUT_TEMP_BOOKMARK_WITH_ORIGINAL_URI = "/replace";
	public static final String SHARE_BOOKMARK_DATA_URI = "/share";
	public static final String DELETE_ALL_TEMP_BOOKMARK_URI = "/deletetemp";
	public static final String RESTORE_TEMP_BOOKMARK_URI = "/restore";

	// Reference Data API
	public static final String REFERENCE_API_URI = "/api/reference";
	public static final String RATING_RANKING_API_URI = "/ratingRanking";
	public static final String GET_DROPDOWN_URI = "/dropdown/{key}";
	public static final String GET_TYPEAHEAD_URI = "/typeahead/{key}/{valueLike}";
	public static final String GET_TYPEAHEAD_BY_PASTED_VALUES_URI = "/typeahead/pasted/{key}";	

	// Cache API URI
	public static final String CACHE_API_URI = "/api/cache";
	public static final String CYBERARK_API_URI = "/api/cyberarc";
	public static final String LOAD_REFERENCE_DATA_URI = "/loadReferenceData";
	public static final String EVICT_REFERENCE_DATA_URI = "/evictReferenceData";
	public static final String LOAD_STATIC_DATA_URI = "/loadStaticData";
	public static final String EVICT_STATIC_DATA_URI = "/evictStaticData";
	public static final String CACHE_STATUS_URI = "/status";
	public static final String REFRESH_CACHE_URI = "/refresh";
	public static final String REFRESH_REFERENCE_DATA_URI = "/refreshStaticData";
	public static final String REFRESH_STATIC_DATA_URI = "/refreshReferenceData";
	public static final String LOAD_STATIC_SEARCH_RESULT_COLUMNS_URI = "/getResultColumns";

	public static final String LOAD_BOX_DATA_URI = "/box";
	public static final String LOAD_POSTING_DATA_URI = "/postings";
	public static final String LOAD_CAPACITY_DATA_URI = "/capacity";
	public static final String LOAD_FWD_MTM_DATA_URI = "/forward-mtm";
	public static final String LOAD_MTM_DATA_URI = "/mtm";
	public static final String LOAD_GSST_DATA_URI = "/gsst";
	public static final String LOAD_FRTB_DATA_URI = "/frtb";
	
	public static final String LOAD_TABS_DATA_URI = "/tabs";

	public static final String GET_DATASET_ID_FOR_VOYAGER_LINK= "/get/datasetId";
	public static final String GET_USER_DATASET_FOR_VOYAGER_LINK= "/getUserDataset/{bookmarkId}";
	public static final String REQUEST_DATASET_URI = "/requestDataset";
	public static final String RETRIEVE_DATASET_URI = "/retrieveDataSet";
	public static final String DATASET_TYPE_API_URI = "/getDatasetTypes";
	public static final String GET_COB_DATE_URI = "/getCobDate";
	public static final String REPORTS_API_URI="/api/reports";
	public static final String SEARCH_REPORT_DETAILS_URI = "/geRankingStaticDetails/{reportType}";
	
	
	
	private DerivzAPIUriConstants() {
		throw new AssertionError();
	}

}
