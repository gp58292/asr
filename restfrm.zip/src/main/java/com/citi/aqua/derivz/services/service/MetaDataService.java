package com.citi.aqua.derivz.services.service;

import java.util.List;
import com.citi.aqua.derivz.model.TableMetaData;

/**
 * @name MetaDataService
 * @Description Service defined to get information for the Tables metadata
 */
public interface MetaDataService extends BaseService {
	
	public List<TableMetaData> findMetadataByTableName(final String tableName);
	
	 

}
