package com.citi.aqua.derivz.vo;

import java.io.IOException;

import com.citi.aqua.derivz.enums.OPERATION;
import com.citi.aqua.derivz.model.DerivzJsonConstants;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.type.TypeFactory;

public class RatingRangeListWrapperDeserializer<T> extends StdDeserializer<RatingRangeListWrapper<T>> {

  private static final long serialVersionUID = 1L;

  static ObjectMapper objectMapper = new ObjectMapper();
  static TypeFactory typeFactory = objectMapper.getTypeFactory();

  public RatingRangeListWrapperDeserializer() {
    this(null);
  }

  protected RatingRangeListWrapperDeserializer(Class<?> vc) {
    super(vc);
  }



  @SuppressWarnings({"unchecked", "rawtypes"})
  @Override
  public RatingRangeListWrapper<T> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
    JsonNode node = p.getCodec().readTree(p);
    RatingRangeListWrapper.RatingRangeListWrapperBuilder scvb = RatingRangeListWrapper.builder();
    JavaType stringType = typeFactory.constructType(String.class);
    
    if (node.get(DerivzJsonConstants.IN_VALUE_LIST) != null) {
        scvb.inValueList(objectMapper.readValue(node.get(DerivzJsonConstants.IN_VALUE_LIST).toString(),typeFactory.constructParametricType(RatingRangeList.class,stringType)));
   }
    if (node.get(DerivzJsonConstants.NOT_IN_VALUE_LIST) != null) {
        scvb.notInValueList(objectMapper.readValue(node.get(DerivzJsonConstants.NOT_IN_VALUE_LIST).toString(),typeFactory.constructParametricType(RatingRangeList.class,stringType)));
   }
    RatingRangeListWrapper<T> wrapper=(RatingRangeListWrapper<T>)scvb.build();
    if (node.get(DerivzJsonConstants.NOT_IN_VALUE_LIST) != null && wrapper.getNotInValueList().getValueList()!=null && wrapper.getNotInValueList().getValueList().length>0) {
    	for(RatingRange range:wrapper.getNotInValueList().getValueList()) {
    		range.setOperation(OPERATION.OR_N);
    	}
    }
    return wrapper;
  }

}
