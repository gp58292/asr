package com.citi.aqua.derivz.services.grid.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 8/22/2019
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SecondaryColumnEntry {
    private String groupId;
    private List<SecondaryColumnEntry> children;
    private String headerName;
    private String colId;
    private String field;
}
