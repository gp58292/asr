package com.citi.aqua.derivz.vo;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.type.TypeFactory;

public class TenorRangeListDeserializer<T,E> extends StdDeserializer<TenorRangeList<T,E>> {

  private static final long serialVersionUID = 1L;

  static ObjectMapper objectMapper = new ObjectMapper();
  static TypeFactory typeFactory = objectMapper.getTypeFactory();

  public TenorRangeListDeserializer() {
    this(null);
  }

  protected TenorRangeListDeserializer(Class<?> vc) {
    super(vc);
  }



  @Override
  public TenorRangeList<T,E> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
    JsonNode node = p.getCodec().readTree(p);
    TenorRangeList.TenorRangeListBuilder<T, E> scvb=TenorRangeList.builder();

    if (node.get("inValue") != null) {
      JavaType tenorRange = typeFactory.constructType(TenorRange.class);
      scvb.inValue(objectMapper.readValue(node.get("inValue").toString(), typeFactory.constructType(tenorRange)));
    }

    if (node.get("notInValue") != null) {
    	 JavaType tenorRange = typeFactory.constructType(TenorRange.class);
         scvb.notInValue(objectMapper.readValue(node.get("notInValue").toString(), typeFactory.constructType(tenorRange)));
    }

    return scvb.build();
  }

}
