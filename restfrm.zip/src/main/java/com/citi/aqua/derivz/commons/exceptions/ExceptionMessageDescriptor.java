package com.citi.aqua.derivz.commons.exceptions;

public interface ExceptionMessageDescriptor {

	String getMessageCode();
	String getMessageDescription();
}
