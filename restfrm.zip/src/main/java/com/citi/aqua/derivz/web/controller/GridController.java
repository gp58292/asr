package com.citi.aqua.derivz.web.controller;

import com.citi.aqua.derivz.services.grid.CeftDataSet;
import com.citi.aqua.derivz.services.grid.CeftDataSetStatus;
import com.citi.aqua.derivz.services.grid.CeftFrmQueryService;
import com.citi.aqua.derivz.services.grid.LoadingStatusService;
import com.citi.aqua.derivz.services.grid.model.DistinctValueDataRequest;
import com.citi.aqua.derivz.services.grid.model.SearchQueryResult;
import com.citi.aqua.derivz.utils.LogUtils;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;
import com.citi.aqua.frm.ceft.CeftDataSetType;
import com.citi.aqua.frm.framework.grid.exception.DataSetNotLoadedException;
import com.google.common.base.Stopwatch;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @Modified Viraj
 * @since 6/19/2019
 */
@Slf4j
@RestController
@RequestMapping("/api/grid")
public class GridController {

    @Autowired
    LoadingStatusService loadingStatusService;

    @Autowired
    CeftFrmQueryService queryService;

    @ExceptionHandler(DataSetNotLoadedException.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR, reason = "Data set not loaded.")
    public void handleNotLoaded(DataSetNotLoadedException ex) {
        log.warn("Unexpected exception while processing request.", ex);
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR, reason = "Unexpected server error")
    public void handleGenericError(Exception ex) {
        log.warn("Unexpected exception while processing request.", ex);
    }

    @GetMapping(value = "set/{bookmark}/{dataSet}/loaded")
    public boolean isLoaded(@PathVariable long bookmark, @PathVariable String dataSet, String soeid) {
        return loadingStatusService.isDataSetReady(
                new CeftDataSet(soeid, bookmark, CeftDataSetType.findByCode(dataSet)));
    }

    @RequestMapping(value = "set/{bookmark}/{dataSet}/requestDataSet", method = RequestMethod.GET)
    public CeftDataSetStatus requestDataSet(@PathVariable long bookmark, @PathVariable String dataSet,
            String soeid, @RequestParam(name = "socket", required = false) String atmosphereResource) {
        CeftDataSet set = new CeftDataSet(soeid, bookmark, CeftDataSetType.findByCode(dataSet));
        log.info("Requesting data set {}", set);
        CeftDataSetStatus result = loadingStatusService.requestDataSet(set, atmosphereResource);
        log.info("Got result: {}", result);
        return result;
    }

    @GetMapping(value = "set/{bookmark}/{dataSet}/status")
    public CeftDataSetStatus loadingStatus(@PathVariable long bookmark, @PathVariable String dataSet, String soeid) {
        CeftDataSetType type = CeftDataSetType.findByCode(dataSet);
        return loadingStatusService.dataSetStatus(new CeftDataSet(soeid, bookmark, type));
    }

    @GetMapping(value = "set/{bookmark}/status")
    public CeftDataSetStatus[] loadingStatus(@PathVariable long bookmark, String soeid) {
        return loadingStatusService.dataSetStatusForBookmark(soeid, bookmark);
    }


    @PostMapping(value = "distinct")
    public List<Object> distinctValuesQuery(@RequestBody DistinctValueDataRequest request) {
        Stopwatch stopwatch = Stopwatch.createStarted();
        log.info("GridController::distinctValuesQuery: Request to get distinct values for query. "
                        + "DataSet: {}; column: {}; request: {}", request.getDataSet(), request.getColumn(), request);
        List<Object> result = queryService.distinctValuesQuery(request);
        log.info("GridController::distinctValuesQuery: Query executed successfully. "
                + "DataSet: {} Execution time: {}; Query: {}; Result size: {}; Result: {}",
                request.getDataSet(), stopwatch.elapsed(), request, result.size(), LogUtils.listForLogging(result));
        return result;
    }

    @RequestMapping(value = "query-search-er", method = RequestMethod.POST)
    public SearchQueryResult unifiedSearchQuery(@RequestBody EnterpriseGetRowsRequest request, long bookmark,
            String tab, String soeid) {
        CeftDataSetType type = CeftDataSetType.findByCode(tab);
        CeftDataSet dataSet = new CeftDataSet(soeid, bookmark, type);
        log.info("SearchQuery data set: {}, request: {}", dataSet, request);
        Stopwatch started = Stopwatch.createStarted();
        //validate request
        SearchQueryResult result;
            result = queryService.searchQuery(request, dataSet);
        log.debug("SearchQuery executed in {}, got {} rows", started.elapsed(), result.getValues().size());
        return result;
    }

    @RequestMapping(value = "query-count-er", method = RequestMethod.POST)
    public long unifiedCountQuery(@RequestBody EnterpriseGetRowsRequest request, long bookmark,
            String tab, String soeid) {
        CeftDataSetType type = CeftDataSetType.findByCode(tab);
        CeftDataSet dataSet = new CeftDataSet(soeid, bookmark, type);
        Stopwatch stopwatch = Stopwatch.createStarted();
        log.info("CountQuery: request to count, Data set: {}, request: {}", dataSet, request);
        long res;
            res = queryService.countQuery(request, dataSet);
        log.info("CountQuery: request to count completed in {}, Data set: {}, res: {},", stopwatch.elapsed(),
                dataSet, res);
        return res;
    }

    @RequestMapping(value = "query-distinct", method = RequestMethod.POST)
    public List<Object> unifiedDistinctValuesQuery(@RequestBody DistinctValueDataRequest request) {
        Stopwatch stopwatch = Stopwatch.createStarted();
        log.info("DistinctQuery: Request to get distinct values for query, Data set: {}, column: {} request: {}",
                request.getDataSet(),
                request.getColumn(), request);
        List<Object> result = queryService.distinctValuesQuery(request);
        log.info("DistinctQuery: completed in {}, got {} results, result : {}(...)", stopwatch.elapsed(), result.size(),
                result.stream().limit(5).collect(Collectors.toList()));
        return result;
    }
    @RequestMapping(value = "query-distinct-er", method = RequestMethod.POST)
    public List<Object> unifiedDistinctValuesQuery(@RequestBody EnterpriseGetRowsRequest request, long bookmark,
            String tab, String soeid, String column) {

        CeftDataSetType type = CeftDataSetType.findByCode(tab);
        CeftDataSet dataSet = new CeftDataSet(soeid, bookmark, type);
        Stopwatch stopwatch = Stopwatch.createStarted();
        log.info("DistinctQuery: Request to get distinct values for query, Data set: {}, column: {} request: {}",
                dataSet,column, request);
        List<Object> result = queryService.distinctValuesQuery(dataSet, request.getFilterModel(), column);
        log.info("DistinctQuery: completed in {}, got {} results, result : {}(...)", stopwatch.elapsed(), result.size(),
                result.stream().limit(5).collect(Collectors.toList()));
        return result;
    }



}
