package com.citi.aqua.derivz.vo;

import java.io.IOException;
import com.citi.aqua.derivz.enums.OPERATION;
import com.citi.aqua.derivz.model.DerivzJsonConstants;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.type.TypeFactory;

public class RatingRangeDeserializer<T> extends StdDeserializer<RatingRange<T>> {

  private static final long serialVersionUID = 1L;

  static ObjectMapper objectMapper = new ObjectMapper();
  static TypeFactory typeFactory = objectMapper.getTypeFactory();

  public RatingRangeDeserializer() {
    this(null);
  }

  protected RatingRangeDeserializer(Class<?> vc) {
    super(vc);
  }



  @SuppressWarnings({"rawtypes", "unchecked"})
  @Override
  public RatingRange<T> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
    JsonNode node = p.getCodec().readTree(p);
    RatingRange.RatingRangeBuilder<T> scvb = RatingRange.builder();

    if (node.get(DerivzJsonConstants.AGENCY_NAME) != null) {
      scvb.agencyName(node.get(DerivzJsonConstants.AGENCY_NAME).asText());
    }
    if (node.get(DerivzJsonConstants.PERIOD) != null) {
      scvb.period(node.get(DerivzJsonConstants.PERIOD).asText());
    }
    if (node.get(DerivzJsonConstants.NUM_INDEX) != null) {
        scvb.numIndex(node.get(DerivzJsonConstants.NUM_INDEX).asInt());
      }
    if (node.get(DerivzJsonConstants.VALUE) != null) {
      JavaType stringType = typeFactory.constructType(String.class);
      JavaType refernceDataType = typeFactory.constructType(ReferenceDataVO.class,stringType);
      RangeVO returnValue = objectMapper.readValue(node.get("value").toString(),typeFactory.constructParametricType(RangeVO.class, refernceDataType));
      
      scvb.value(returnValue);
    }

    if (node.get(DerivzJsonConstants.OPERATION) != null) {
      String nameOfOperation = node.get(DerivzJsonConstants.OPERATION).asText();
      OPERATION operationType = OPERATION.valueOfByName(nameOfOperation);
      scvb.operation(operationType);
      return (RatingRange<T>) scvb.build();
    }

    return null;
  }

}
