package com.citi.aqua.derivz.web.controller;

import java.util.List;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.model.RankingReport;
import com.citi.aqua.derivz.services.service.RankingReportService;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import com.citi.aqua.derivz.web.utils.ResponseBuilder;


@RestController
@RequestMapping(DerivzAPIUriConstants.REPORTS_API_URI)
public class ReportController {

	private static final Logger LOGGER = LoggerFactory.getLogger(ReportController.class);

	@Autowired
	RankingReportService reportService;

	@RequestMapping(value = DerivzAPIUriConstants.SEARCH_REPORT_DETAILS_URI, method = RequestMethod.GET)
	public @ResponseBody DerivzRestResponse<List<RankingReport>> getReportDetails(@PathVariable("reportType") final String reportType) {
		try {
			return ResponseBuilder.build(reportService.getRankingReportDetails(), HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("ReportsController::getReportsDetails() :: Error " + de, de);
			return ResponseBuilder.build(null, HttpStatus.SC_NOT_FOUND,	"Failed to fetch static data" + reportType+"report details. "+".", "DS100");
		} 
	}
	
}
