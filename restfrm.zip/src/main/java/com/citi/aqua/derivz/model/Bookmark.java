package com.citi.aqua.derivz.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@Entity
@Table(name = DerivzDBConstants.TBL_USER_SEARCH_SAVED_LIST, schema=DerivzDBConstants.SCHEMA_CEFT)
public class Bookmark extends BaseEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "uniq_key")
	private long key;

	@Column(name = "last_selected")
	private int lastSelected;

	@Column(name = "list_name")
	private String name;

	@Column(name = "user_id")
	private String userId;

	@Column(name = "list_type")
	private String type;

	@Column(name = "saved_list")
	private String criteria;

	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss", shape = JsonFormat.Shape.STRING)
    @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_time")
	private Date updatedTime;
	
	@Column(name = "parent_id")
	private Long parentId;
	
	@Column(name = "description")
	private String description;
	
	@Column(name="chart_flag",columnDefinition="int default 0")
	private Integer chartFlag;
	
	@Column(name="delete_flag",columnDefinition="int default 0")
	private int deleteFlag;
	
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss", shape = JsonFormat.Shape.STRING)
    @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_access_time")
	private Date lastAccessTime;

}