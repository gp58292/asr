package com.citi.aqua.derivz.vo;

import java.io.IOException;
import java.io.Serializable;

import com.citi.aqua.derivz.enums.OPERATION;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Getter
@Setter
@JsonDeserialize(using = IncludeExcludeVODeserializer.class)
public class IncludeExcludeVO<T> implements Serializable {

	private static final long serialVersionUID = 1L;
	private OPERATION operation;
	private T value;
	private T butNotValue;
	
    private void writeObject(java.io.ObjectOutputStream stream) throws IOException {
        stream.writeObject(value);
        stream.writeObject(butNotValue);
    }

    @SuppressWarnings("unchecked")
	private void readObject(java.io.ObjectInputStream stream)  throws IOException, ClassNotFoundException {
    	value = (T) stream.readObject();
    	butNotValue = (T) stream.readObject();
    }

}
