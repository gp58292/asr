package com.citi.aqua.derivz.web.utils;

import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.frm.framework.export.DisplayableColumnDescription;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.apache.commons.text.StringEscapeUtils;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
public class ExportColumnDescription implements DisplayableColumnDescription {
    private String name;
    private String displayName;
    private String type;
    private Integer fieldOrder;

    public static List<ExportColumnDescription> MakeExportColumnDescriptions(List<SearchResultColumns> staticResultColumns, String requestType) {
        if (staticResultColumns == null) {
            throw new IllegalArgumentException("ExportColumnDescription::MakeExportColumnDescriptions - input parameters should not be null");
        }

        return staticResultColumns.stream()
                .filter(column -> column.getTabId().equals(requestType) && column.getIsEnabled() && column.getIsDefaultDisplay())
                .map(column -> {
                    Integer columnFieldOrder = column.getFieldOrder();
                    String columnType = column.getFieldType().toString();
                    String columnDisplayName = column.getDisplayName();
                    return new ExportColumnDescription(column.getFieldName(), columnDisplayName, columnType, columnFieldOrder);
                })
                .sorted(Comparator.comparingInt(ExportColumnDescription::getFieldOrder))
                .collect(Collectors.toList());
    }

    public static String encodeTextAsCsvNoLeadingZero(Object input) {
        return StringEscapeUtils.escapeCsv(input.toString());
    }

}
