package com.citi.aqua.derivz.model;

public class PropertyConstants {
	public static final String CEFT_AUTHENTICATION_DISABLE="ceft.authentication.disable";
	
	private PropertyConstants() {}
}
