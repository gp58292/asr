package com.citi.aqua.derivz.data.jdbc;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.citi.aqua.derivz.model.CEFTUser;


public interface UserSearchDAO {
	
	public List<CEFTUser> getUserListEntitlement(final String soeid) throws SQLException;

}
