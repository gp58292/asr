package com.citi.aqua.derivz.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonInclude(Include.NON_NULL)
public class CapacityDataVO {

	private int agreementId;
	private String clearingAgreement;
	private String collSourceSystem;
	private String collateralApplied;
	private String collateralCcy;
	private String collateralType;
	private String consentToSubstitution;
	private String counterPartyName;
	private String cpMarginType;
	private String csaDescription;
	private String csaMarginType;
	private String csaStatus;
	private String custodianRequired;
	private String customerName;
	private String exchangeClearedAgreement;
	private String gfcid;
	private String gfcidType;
	private String gfcidTypeDescription;
	private String governingLaw;
	private String imVm;
	private String incorporatedCountry;
	private String liquidityType;
	private String mandatoryMarkFrequency;
	private String masterAgreement;
	private String masterAgreementStatus;
	private String partyLegalEntity;
	private String pledgor;
	private String postedReceivedcode;
	private String sixCApplies;
	private String triggerEvent;
	private String saTriggerEvent;
	private String sme;
	private String segNonseg;
	private String typeOfCollateral;
	private String industrySector;
	private String mgdSegLevel5Desc;
	private String interCompanyAgreement;
	private String collateralParty;
	
	private long mtm;
	private long currentPosting;
	private long maxCapacity;
	private long maxCapacityConc;
	private long incrementalCapacity;
	private long incrementalCapacityConc;
	private long currentCollateralReceived;
	private long maxExposure;
	private long maxExposureConc;
	private long incrementalExposure;
	private long incrementalExposureConc;
	
	private String partyCustodianRequired;
	private String counterPartyCustodianRequired;
	
}