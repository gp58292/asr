package com.citi.aqua.derivz.services.grid.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import static java.util.Objects.nonNull;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/9/2019
 */
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class ComplexSearchRequest extends SearchDataRequest {
    /** List of columns used to values in rows. */
    List<String> columnGrouping = new ArrayList<>();
    /** Values of the grouping columns for this query. If there are less values than columnGrouping items, then this
     * is aggregation query, and if equals - we query for all values
     */
    List<String> groupValues = new ArrayList<>();
    /** Aggregations within query (function+column) */
    List<ColumnAggregation> aggregations = new ArrayList<>();
    /** List of columns, which values will be used as pivot query columns */
    List<String> pivotColumns = new ArrayList<>();


    public boolean isPivotRequest() {
        return nonNull(getPivotColumns())&&!pivotColumns.isEmpty();
    }

}
