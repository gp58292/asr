package com.citi.aqua.derivz.vo;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserDatasetVO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int datasetId;
	
	private int displayFlag;

	private int bookmarkId;
	
	private String displayName;
	
	private String shortName;
}
