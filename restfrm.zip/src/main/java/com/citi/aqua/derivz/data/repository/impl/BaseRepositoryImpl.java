package com.citi.aqua.derivz.data.repository.impl;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import com.citi.aqua.derivz.data.repository.BaseRepository;
import com.citi.aqua.derivz.model.BaseEntity;

@Repository("BaseRepository")
public class BaseRepositoryImpl implements BaseRepository {

	private static final Logger LOGGER = LoggerFactory.getLogger(BaseRepositoryImpl.class);

	@PersistenceContext
	EntityManager entityManager;

	@SuppressWarnings("unchecked")
	@Override
	public List<? extends BaseEntity> getDataset(final String entity, final String filterQuery, final int maxResults) {
		List<? extends BaseEntity> baseEntities = new ArrayList<>();
		try {
			Class<? extends BaseEntity> entityClass = (Class<? extends BaseEntity>) Class.forName(entity);
			baseEntities = (List<BaseEntity>) entityManager.createNativeQuery(filterQuery, entityClass)
					.setFirstResult(0).setMaxResults(maxResults).getResultList();
		} catch (ClassNotFoundException e) {
			LOGGER.debug("BaseRepositoryImpl::getDataset() :: Error :", e);
		}
		return baseEntities;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<? extends BaseEntity> findResultSet(final String entity, final String filterQuery) {
		List<? extends BaseEntity> baseEntities = new ArrayList<>();
		try {
			Class<? extends BaseEntity> entityClass = (Class<? extends BaseEntity>) Class.forName(entity);
			baseEntities = (List<BaseEntity>) entityManager.createNativeQuery(filterQuery, entityClass).setFirstResult(0).setMaxResults(100).getResultList();
		} catch (ClassNotFoundException e) {
			LOGGER.debug("BaseRepositoryImpl::findResultSet() :: Error :", e);
		}
		return baseEntities;
	}

}
