package com.citi.aqua.derivz.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.citi.aqua.derivz.model.RankingReport;

public interface RankingReportRepository extends JpaRepository<RankingReport, Integer> {

}
