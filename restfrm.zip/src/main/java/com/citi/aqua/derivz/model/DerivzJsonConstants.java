package com.citi.aqua.derivz.model;

public final class DerivzJsonConstants {
  
    private  DerivzJsonConstants () {}
    
    public static final String VALUE = "value";
    public static final String BUT_NOT_VALUE = "butNotValue";
    public static final String OPERATION = "operation";
	public static final String IN_VALUE_LIST = "inValueList";
	public static final String NOT_IN_VALUE_LIST = "notInValueList";
	public static final String VALUE_LIST = "valueList";

	public static final String AGENCY_NAME = "agencyName";
	public static final String PERIOD = "period";
	public static final String NUM_INDEX = "numIndex";
	

}