package com.citi.aqua.derivz.services.service.impl;

import java.util.List;
import java.util.stream.Collectors;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.citi.aqua.derivz.commons.constants.DerivzBeanConstants;
import com.citi.aqua.derivz.data.repository.CustomFieldRepository;
import com.citi.aqua.derivz.data.repository.SelectionFiltersRepository;
import com.citi.aqua.derivz.model.CustomAttributes;
import com.citi.aqua.derivz.model.SelectionFilters;
import com.citi.aqua.derivz.services.service.CombinedColumns;

@Service(DerivzBeanConstants.COMBINED_COLUMN_BEAN)
public class CombinedColumnsImpl implements CombinedColumns {

  @Autowired
  SelectionFiltersRepository selectionFiltersRepo;
  
  @Autowired
  CustomFieldRepository customFieldRepository;
  
  @Override
  public List<SelectionFilters> findAll(boolean isLogicalGroupBy) {
    
    List<SelectionFilters> filterSelectionList=selectionFiltersRepo.findAll();
    List<CustomAttributes> customAtrributeList=customFieldRepository.findAll();
    
      DozerBeanMapper apiBeanMapper = new DozerBeanMapper();
                customAtrributeList.stream().forEach(customAtrribute -> {
          final SelectionFilters searchCriteriaResultVO = apiBeanMapper.map(customAtrribute,SelectionFilters.class);
          filterSelectionList.add(searchCriteriaResultVO);
      });
                
      return  filterSelectionList.parallelStream()
                                 .sorted(isLogicalGroupBy?CombinedColumns.orderByLogicalGroupName():CombinedColumns.orderByDisplayName())
                                 .collect(Collectors.toList());
  }

  @Override
  public List<SelectionFilters> findByFilterKeyIn(final List<Long> keys){
    
    List<SelectionFilters> filterSelectionList=selectionFiltersRepo.findByFilterKeyIn(keys);
    List<CustomAttributes> customAtrributeList=customFieldRepository.findByFilterKeyIn(keys);
    
      DozerBeanMapper apiBeanMapper = new DozerBeanMapper();
                customAtrributeList.stream().forEach(customAtrribute -> {
          final SelectionFilters searchCriteriaResultVO = apiBeanMapper.map(customAtrribute,SelectionFilters.class);
          filterSelectionList.add(searchCriteriaResultVO);
      });
                
      return  filterSelectionList.parallelStream()
                                 .collect(Collectors.toList());
  }

	@Override
	public List<SelectionFilters> findByComponentTypeIn(List<String> componentTypes) {
		List<SelectionFilters> filterSelectionList=selectionFiltersRepo.findByComponentTypeIn(componentTypes);
	    List<CustomAttributes> customAtrributeList=customFieldRepository.findByComponentTypeIn(componentTypes);
	    
	      DozerBeanMapper apiBeanMapper = new DozerBeanMapper();
	                customAtrributeList.stream().forEach(customAtrribute -> {
	          final SelectionFilters searchCriteriaResultVO = apiBeanMapper.map(customAtrribute,SelectionFilters.class);
	          filterSelectionList.add(searchCriteriaResultVO);
	      });
	                
	      return  filterSelectionList.parallelStream()
	                                 .collect(Collectors.toList());
	}
}
