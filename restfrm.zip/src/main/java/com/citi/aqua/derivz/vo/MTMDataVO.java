package com.citi.aqua.derivz.vo;

import java.math.BigDecimal;
import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonInclude(Include.NON_NULL)
public class MTMDataVO {
	
	private Date businessDate;
	private Long agreementId;
	private String partyLegalEntity;
	private String buckets;
	private String counterParty;
	private String counterPartyGFCId;
	private String csaDescription;
	private String csaType;
	private String extension;
	private String interCompanyAgreementCP;
	private String mnemonic;
	private String shelf;
	private String mgdSegLevel5Desc;
	private String mgdSegLevel6Desc;
	private String mgdSegLevel7Desc;
	private BigDecimal mtmUsd;
	
}