package com.citi.aqua.derivz.vo;

import java.io.IOException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.type.TypeFactory;

public class TenorRangeDeserializer<T,E> extends StdDeserializer<TenorRange<T,E>> {

  private static final long serialVersionUID = 1L;

  static ObjectMapper objectMapper = new ObjectMapper();
  static TypeFactory typeFactory = objectMapper.getTypeFactory();

  public TenorRangeDeserializer() {
    this(null);
  }

  protected TenorRangeDeserializer(Class<?> vc) {
    super(vc);
  }



  @Override
  public TenorRange<T,E> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
    JsonNode node = p.getCodec().readTree(p);
    TenorRange.TenorRangeBuilder<T, E> scvb=TenorRange.builder();

    if (node.get("period") != null) {
      JavaType stringType = typeFactory.constructType(String.class);
      JavaType refernceDataType = typeFactory.constructParametricType(ReferenceDataVO.class, stringType);
      scvb.period(objectMapper.readValue(node.get("period").toString(), typeFactory.constructType(refernceDataType)));
    }

    if (node.get("rangeValue") != null) {
      JavaType longType = typeFactory.constructType(Long.class);
      JavaType refernceDataType = typeFactory.constructParametricType(RangeVO.class, longType);
      scvb.rangeValue(objectMapper.readValue(node.get("rangeValue").toString(),typeFactory.constructType(refernceDataType)));
      return scvb.build();
    }

    return null;
  }

}
