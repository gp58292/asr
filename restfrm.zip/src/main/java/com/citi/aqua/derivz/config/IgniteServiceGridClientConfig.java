package com.citi.aqua.derivz.config;

import org.apache.ignite.IgniteSpringBean;
import org.apache.ignite.configuration.DataRegionConfiguration;
import org.apache.ignite.configuration.DataStorageConfiguration;
import org.apache.ignite.configuration.DeploymentMode;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.spi.discovery.DiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.ipfinder.kubernetes.TcpDiscoveryKubernetesIpFinder;
import org.apache.ignite.spi.discovery.tcp.ipfinder.vm.TcpDiscoveryVmIpFinder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

@Configuration
@Profile("frm-framework-service-grid")
public class IgniteServiceGridClientConfig {

    @Autowired
    private Environment environment;

    @Value("${frm-service-ip-finder.addresses:127.0.0.1:47601..47610}")
    private Collection<String> addresses;

    @Bean
    @Profile({"!kubernetes"})
    TcpDiscoveryVmIpFinder ipFinderService() {
        TcpDiscoveryVmIpFinder ipFinder = new TcpDiscoveryVmIpFinder();
        ipFinder.setAddresses(addresses);
        return ipFinder;
    }

    @Bean
    @Profile({"kubernetes"})
    @ConfigurationProperties(
            prefix = "frm-service-tcp-discovery-kubernetes-ip-finder"
    )
    TcpDiscoveryKubernetesIpFinder tcpDiscoveryKubernetesIpFinderService() {
        return new TcpDiscoveryKubernetesIpFinder();
    }

    @Bean
    @ConfigurationProperties(
            prefix = "frm-service-tcp-discovery-spi"
    )
    DiscoverySpi discoverySpiService() {
        TcpDiscoverySpi spi = new TcpDiscoverySpi();
        List<String> profiles = Arrays.asList(this.environment.getActiveProfiles());
        if(profiles.contains("kubernetes")) {
            spi.setIpFinder(tcpDiscoveryKubernetesIpFinderService());
        } else {
            spi.setIpFinder(ipFinderService());
        }
        return spi;
    }

    @Bean
    DataStorageConfiguration dataStorageConfigurationService(DataRegionConfiguration dataRegionConfigurationService) {
        DataStorageConfiguration dataStorageConfiguration = new DataStorageConfiguration();
        dataStorageConfiguration.setDefaultDataRegionConfiguration(dataRegionConfigurationService);
        return dataStorageConfiguration;
    }

    @Bean
    @ConfigurationProperties(
            prefix = "frm-service-data-region-configuration"
    )
    DataRegionConfiguration dataRegionConfigurationService() {
        return new DataRegionConfiguration();
    }

    @Bean
    @ConfigurationProperties(
            prefix = "frm-service-ignite-configuration"
    )
    IgniteConfiguration igniteConfigurationService(@Qualifier("discoverySpiService") DiscoverySpi discoverySpiService, DataStorageConfiguration dataStorageConfigurationService) {
        IgniteConfiguration igniteConfiguration = new IgniteConfiguration();
        igniteConfiguration.setDiscoverySpi(discoverySpiService);
        igniteConfiguration.setPeerClassLoadingEnabled(false);
        igniteConfiguration.setDeploymentMode(DeploymentMode.ISOLATED);
        igniteConfiguration.setDataStorageConfiguration(dataStorageConfigurationService);
        igniteConfiguration.setClientMode(true);
        return igniteConfiguration;
    }

    @Bean(destroyMethod = "close")
    public IgniteSpringBean frmServiceGridBean(IgniteConfiguration igniteConfigurationService) {
        IgniteSpringBean bean = new IgniteSpringBean();
        bean.setConfiguration(igniteConfigurationService);
        return bean;
    }
}
