package com.citi.aqua.derivz.web.utils;

import com.citi.aqua.derivz.commons.exceptions.CEFTException;
import com.citi.aqua.derivz.dto.RetrievedDataResponseDTO;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static java.lang.Integer.min;

@Slf4j
public class CEFTRequestIterator implements Iterator<Map<String,Object>> {
    private CEFTDataSetRequest ceftDataSetRequest;

    private UserSearchCriteriaService userSearchCriteriaService;

    private int currentRow = -1;
    private int currentStartRow;
    private int currentEndRow;
    private int startRow;
    private int endRow;

    @Setter
    private int windowSize = 3000;

    private Iterator<Map<String,Object>> currentResultsIterator;
    private RetrievedDataResponseDTO currentResponseDTO;

    private String userId;

    private void CEFTDataSetRequest(){}

    public CEFTRequestIterator(CEFTDataSetRequest ceftDataSetRequest, String userId,
                               UserSearchCriteriaService userSearchCriteriaService){
        this.ceftDataSetRequest = ceftDataSetRequest;
        this.userId = userId;
        this.userSearchCriteriaService = userSearchCriteriaService;

        this.startRow = ceftDataSetRequest.getGridRequest().getStartRow();
        this.endRow = ceftDataSetRequest.getGridRequest().getEndRow();
    }


    public static CEFTRequestIterator getCETRequestIterator(CEFTDataSetRequest ceftDataSetRequest,
                       String userId, UserSearchCriteriaService userSearchCriteriaService) {
        return new CEFTRequestIterator(ceftDataSetRequest, userId, userSearchCriteriaService);
    }

    public Map<String, Object> peakFirstCurrent() {
        if (this.hasNext() && this.currentResponseDTO != null) {
            List<Map<String,Object>> currentResultList = this.currentResponseDTO.getListOfRecords();
            if (currentResultList != null && currentResultList.size() > 0) {
                return currentResultList.get(0);
            }
            else {
                return null;
            }
        }
        else {
            return null;
        }
    }

    private boolean slideTheWindow() throws CEFTException {
        if (currentEndRow < endRow) {
            if (currentRow < 0) {
                currentRow = startRow;
                currentStartRow = startRow;
            }
            else {
                currentStartRow = currentRow;
            }
            currentEndRow = min(endRow, currentStartRow + windowSize);
            log.debug("CEFTRequestIterator::slideTheWindow: currentRow={}, currentStartRow={}, currentEndRow={}",
                    currentRow, currentStartRow, currentEndRow);
            EnterpriseGetRowsRequest currentGetRowsRequest = ceftDataSetRequest.getGridRequest();
            currentGetRowsRequest.setStartRow(currentStartRow);
            currentGetRowsRequest.setEndRow(currentEndRow);
            currentResponseDTO = userSearchCriteriaService.searchDatasetResults(ceftDataSetRequest.getType(), userId,
                    ceftDataSetRequest.getBookmarkId(),
                    currentGetRowsRequest,
                    ceftDataSetRequest.getAgreementKeys());

            // If we reached the end of data set, we should adjust endRow
            int numberOfRowsReturned = currentResponseDTO.getListOfRecords().size();
            int numberOfRowsRequested = currentEndRow - currentStartRow;
            if (numberOfRowsReturned < numberOfRowsRequested) {
                endRow = currentRow + numberOfRowsReturned;
            }

            currentResultsIterator = currentResponseDTO.getListOfRecords().iterator();

            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public boolean hasNext() {
        if ( currentRow < 0 || (currentRow == currentEndRow && currentRow < endRow) ) {
            if (endRow < 0) {
                endRow = Integer.MAX_VALUE;
            }
            if (startRow < 0) {
                startRow = 0;
            }
            try {
                return slideTheWindow();
            } catch (CEFTException e) {
                log.error("CEFTRequestIterator: error querying data set: ", e);
                return false;
            }
        }

        if (currentResultsIterator != null && currentRow < endRow) {
            return currentResultsIterator.hasNext();
        }
        else {
            return false;
        }

    }

    @Override
    public Map<String, Object> next() {
        if (currentResultsIterator != null) {
            currentRow++;
            return currentResultsIterator.next();
        }
        else {
            return null;
        }
    }
}
