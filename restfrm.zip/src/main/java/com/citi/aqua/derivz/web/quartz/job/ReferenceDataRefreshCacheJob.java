package com.citi.aqua.derivz.web.quartz.job;
import java.sql.Timestamp;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.JobKey;
import org.quartz.PersistJobDataAfterExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.citi.aqua.derivz.commons.constants.DerivzCommonConstants;
import com.citi.aqua.derivz.model.BatchProcessAudit;
import com.citi.aqua.derivz.services.service.CacheService;

@PersistJobDataAfterExecution
@DisallowConcurrentExecution
@Component
public class ReferenceDataRefreshCacheJob extends QuartzJobBean {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ReferenceDataRefreshCacheJob.class);
	public static final String COUNT = "count";
	public static final String LOCAL_CACHE_UPDATED_TIME = "LOCAL_CACHE_UPDATED_TIME";
	
    protected void executeInternal(JobExecutionContext ctx) throws JobExecutionException {
    	LOGGER.debug("ReferenceDataRefreshCacheJob::executeInternal()");
    	JobDataMap dataMap = ctx.getJobDetail().getJobDataMap();
    	JobKey jobKey = ctx.getJobDetail().getKey();
    	LOGGER.debug("JReferenceDataRefreshCacheJob:: Job Key : {} ", jobKey);
    	int cnt = dataMap.getInt(COUNT);
		cnt++;
		dataMap.put(COUNT, cnt);
		CacheService cachingService = (CacheService) dataMap.get("cachingService");
		BatchProcessAudit batchProcessAudit = cachingService.getBatchProcessAuditByModule(DerivzCommonConstants.MAC_MODULE);
		Timestamp localCacheUpdatedTime = (Timestamp) dataMap.get(LOCAL_CACHE_UPDATED_TIME);
		Timestamp dbCacheUpdatedTime = batchProcessAudit.getCacheUpdatedTime();
		Timestamp dbBatchUpdatedTime = batchProcessAudit.getBatchUpdatedTime();
		LOGGER.debug("Local cache updated Time : {} ", localCacheUpdatedTime);
		LOGGER.debug("Database cache updated Time {}: ", dbCacheUpdatedTime);
		LOGGER.debug("Database batch updated Time {}: ", dbBatchUpdatedTime);
		
		if(dbCacheUpdatedTime != null) {
			localCacheUpdatedTime = dbCacheUpdatedTime;
		} else {
			localCacheUpdatedTime = (Timestamp) dataMap.get(LOCAL_CACHE_UPDATED_TIME);
		}
	    if( batchProcessAudit.getFlag() == 1 && !localCacheUpdatedTime.equals(dbBatchUpdatedTime)) {
	    	LOGGER.debug("Cache is not updated. Evict Cache and LoadReferenceData from database and cache it again!!");
	    	cachingService.evictReferenceDataCache();
	    	cachingService.loadReferenceData();
	    	int cacheUpdatedStatus = cachingService.updateCacheUpdatedTimeForModule(dbBatchUpdatedTime, DerivzCommonConstants.MAC_MODULE);
	    	if (cacheUpdatedStatus == 1) {
	    		LOGGER.debug("Database cache time updated with batch updated Time : {}", dbBatchUpdatedTime);
	    		dataMap.put(LOCAL_CACHE_UPDATED_TIME, dbBatchUpdatedTime);
			} else {
				LOGGER.debug("Database cache time not updated with batch updated Time : {} ", dbBatchUpdatedTime);
				dataMap.put(LOCAL_CACHE_UPDATED_TIME, localCacheUpdatedTime);
			}
	    }
    }
    
}
