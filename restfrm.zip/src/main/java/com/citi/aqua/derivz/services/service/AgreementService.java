package com.citi.aqua.derivz.services.service;

import com.citi.aqua.derivz.dto.AgreementResponseDTO;
import com.citi.aqua.derivz.dto.CSAResponseDTO;

public interface AgreementService {
	
	public AgreementResponseDTO getAgreementDetails(final Long agreementKey);
	
	public CSAResponseDTO getCsaTypeDetails(final Long agreementId, final String csaType);

}
