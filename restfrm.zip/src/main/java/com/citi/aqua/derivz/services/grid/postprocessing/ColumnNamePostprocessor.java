package com.citi.aqua.derivz.services.grid.postprocessing;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * A postprocessor which applies given function to each column name. Typically used to correct case of column name.
 *
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/5/2019
 */
public class ColumnNamePostprocessor implements RowPostprocessor {

    private final Function<String, String> columnNameMapper;

    public ColumnNamePostprocessor(Function<String, String> columnNameMapper) {
        this.columnNameMapper = columnNameMapper;
    }

    @Override
    public Map<String, Object> processRow(Map<String, Object> input) {
        return input.entrySet()
                .stream()
                .collect(HashMap::new,
                        (m, e) -> m.put(columnNameMapper.apply(e.getKey()), e.getValue()),
                        HashMap::putAll);
    }
}
