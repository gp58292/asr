package com.citi.aqua.derivz.services.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.citi.aqua.derivz.vo.SearchFieldVO;

public interface ExportService {
	
	@SuppressWarnings("rawtypes")
	public void exportToExcel(HttpServletResponse response, String source, List<SearchFieldVO> searchCriteria, List<Long> agreementKeyList) throws IOException;

}
