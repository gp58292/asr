package com.citi.aqua.derivz.vo;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
public class CollateralHaircutDetailsVO {

	private String achType;
	private String achMinTerm;
	private String achMaxTerm;
	private Double achHaicutPercentage;

	private String achRating;
	private String achCollateralApplied;
	private String achIssuerRating;
	private String achRanking;
	private String collateralParty;


}
