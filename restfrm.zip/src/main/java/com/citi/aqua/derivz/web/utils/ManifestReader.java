package com.citi.aqua.derivz.web.utils;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.security.CodeSource;
import java.util.Map;
import java.util.TreeMap;
import java.util.jar.Manifest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @name ManifestReader
 *
 */
public class ManifestReader {

    public static final Logger LOGGER = LoggerFactory.getLogger(ManifestReader.class);

    private URL resolve(URI uri) throws MalformedURLException {
        File f = new File(uri.getPath());
        if (f.isDirectory()) {
            // check if we are debugging in IDE
            int pathIdx = f.getPath().indexOf("build");
            if (pathIdx > 0) { //We are in local build environment
                return uri.resolve("../../tmp/jar/MANIFEST.MF").toURL();
            }
            return uri.resolve("META-INF/MANIFEST.MF").toURL();
        }
        return new URL("jar:" + uri.toASCIIString() + "!/META-INF/MANIFEST.MF");
    }

    public Map<String, String> readAll() {
        Map<String, String> result = new TreeMap<>();
        try {
            CodeSource cs = getClass().getProtectionDomain().getCodeSource();
            URL url = resolve(cs.getLocation().toURI());
            Manifest mf = new Manifest(url.openStream());
            for( Map.Entry<Object, Object> entry : mf.getMainAttributes().entrySet())
                result.put(entry.getKey().toString(), entry.getValue().toString());
        } catch (Exception e) {
            LOGGER.debug("Could not read MANIFEST:", e);
        }
        return result;
    }

}
