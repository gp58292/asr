package com.citi.aqua.derivz.vo.aggrid.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class SortModel implements Serializable {
	public static final String ASCENDING="asc";
	public static final String DESCENDING="desc";
	private static final long serialVersionUID = 1L;
	private String colId;
    private String sort;
}