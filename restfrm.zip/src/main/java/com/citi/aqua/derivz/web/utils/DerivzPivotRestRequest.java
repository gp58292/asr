package com.citi.aqua.derivz.web.utils;

import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.citi.aqua.derivz.vo.aggrid.filter.ColumnFilter;
import com.citi.aqua.derivz.vo.aggrid.request.ColumnVO;
import com.citi.aqua.derivz.vo.aggrid.request.SortModel;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DerivzPivotRestRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private int startRow;
    
    private int endRow;

    // row group columns
    private List<ColumnVO> rowGroupCols;

    // value columns
    private List<ColumnVO> valueCols;

    // pivot columns
    private List<ColumnVO> pivotCols;

    // true if pivot mode is one, otherwise false
    private boolean pivotMode;

    // what groups the user is viewing
    private List<String> groupKeys;

    // if filtering, what the filter model is
    private Map<String, ColumnFilter> filterModelVO;

    // if sorting, what the sort model is
    private List<SortModel> sortModelVO;

    public DerivzPivotRestRequest() {
        this.rowGroupCols = emptyList();
        this.valueCols = emptyList();
        this.pivotCols = emptyList();
        this.groupKeys = emptyList();
        this.filterModelVO = emptyMap();
        this.sortModelVO = emptyList();
    }
 
}