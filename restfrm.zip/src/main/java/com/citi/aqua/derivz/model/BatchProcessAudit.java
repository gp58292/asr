package com.citi.aqua.derivz.model;

import java.io.Serializable;
import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = DerivzDBConstants.TBL_BATCH_PROCESS_AUDIT, schema = DerivzDBConstants.SCHEMA_CEFT)
public class BatchProcessAudit implements Serializable { 

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "id")
	private Long id;
	
	@Column(name = "batch_update_time")
	private Timestamp batchUpdatedTime;
	
	@Column(name = "module")
	private String module;
	
	@Column(name = "flag")
	private int flag;
	
	@Column(name = "cache_update_time")
	private Timestamp cacheUpdatedTime;
	
}