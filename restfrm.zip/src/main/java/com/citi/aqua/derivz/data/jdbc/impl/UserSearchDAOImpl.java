package com.citi.aqua.derivz.data.jdbc.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.dbutils.DbUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.exceptions.DerivzDAOLayerException;
import com.citi.aqua.derivz.data.jdbc.UserSearchDAO;
import com.citi.aqua.derivz.model.CEFTUser;
import com.citi.aqua.derivz.model.DerivzDBConstants;

@Repository(value = "UserSearchDAO")
public class UserSearchDAOImpl implements UserSearchDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserSearchDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<CEFTUser> getUserListEntitlement(final String soeid) throws SQLException {
		List<CEFTUser> user = new LinkedList<>();
		CallableStatement cs = null;
		ResultSet rs = null;
		try(Connection conn = jdbcTemplate.getDataSource().getConnection()) {
			StringBuilder sql = new StringBuilder("{CALL ");
			sql.append( DerivzDBConstants.SCHEMA_CEFT ).append( "." ).append( DerivzDBConstants.USP_GET_USER_AUTHENTICATION ).append( " (?,?) }");
			cs = conn.prepareCall(sql.toString());
			cs.setString(1, soeid);
			cs.setString(2,DerivzDBConstants.DASHBOARD_TYPE_CEFT);
			boolean resultSetReturned = cs.execute();
			if (resultSetReturned) {
				rs = cs.getResultSet();
				while (rs.next()) {
					CEFTUser cEFTUser = new CEFTUser();
					cEFTUser.setSoeid(rs.getString("soeId"));
					cEFTUser.setFriendlyName(rs.getString("displayName"));
					cEFTUser.setUserRole(rs.getString("role"));
					cEFTUser.setStatus(rs.getString("status"));
					cEFTUser.setEmail(rs.getString("email"));
					cEFTUser.setCeftAccess(rs.getString("access"));
					cEFTUser.setVoyagerAccess(rs.getString("access"));
					user.add(cEFTUser);
				}
			}
			return user;
		} catch (Exception e) {
			LOGGER.error("UserEntitlementDAOImpl::getUserListEntitlement() ::Error" + e, e);
			throw new DerivzApplicationException(e, DerivzDAOLayerException.FAILED_SEARCH_PROCEDURE);
		} finally {
			DbUtils.closeQuietly(cs);
			DbUtils.closeQuietly(rs);
		}

	}

}
