package com.citi.aqua.derivz.services.grid;

import lombok.NoArgsConstructor;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Support for routing of the websocket messages.
 *
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/28/2019
 */
@Slf4j
@NoArgsConstructor
public class LoadingProgressTracker {

    private final Map<String, CeftDataSetEntry> requestMap = new HashMap<>();

    public void registerWebSocketUUID(CeftDataSet dataSet, String requestUuid) {
        requestMap.computeIfAbsent(dataSet.toDataSetId().getSetId(), k -> new CeftDataSetEntry(dataSet))
                .addUuid(requestUuid);
    }

    public void deregisterWebSocketUUID(String uuid) {
        requestMap.forEach((k, v)->v.remove(uuid));
        Set<String> emptyItems = requestMap.entrySet()
                .stream()
                .filter(e -> e.getValue().isEmpty())
                .map(e -> e.getKey())
                .collect(Collectors.toSet());
        emptyItems.forEach(requestMap::remove);
    }

    public Set<String> findUUID(String frmSetId) {
        return Optional
                .ofNullable(requestMap.get(frmSetId))
                .map(e -> Collections.unmodifiableSet(e.getUuids()))
                .orElse(Collections.emptySet());
    }

    public CeftDataSet findDataSet(String frmSetId) {
        return Optional.ofNullable(requestMap.get(frmSetId)).map(e -> e.getDataSet()).orElse(null);
    }

    @Value
    protected class CeftDataSetEntry {
        CeftDataSet dataSet;
        Set<String> uuids = Collections.newSetFromMap(new ConcurrentHashMap<>());

        public void addUuid(String uuid) {
            uuids.add(uuid);
        }

        public void remove(String uuid) {
            uuids.remove(uuid);
        }

        public boolean isEmpty() {
            return uuids.isEmpty();
        }
    }
}
