package com.citi.aqua.derivz.services.grid.impl;

import com.citi.aqua.derivz.services.grid.CeftDataSet;
import com.citi.aqua.derivz.services.grid.CeftFrmQueryService;
import com.citi.aqua.derivz.services.grid.InvalidDataRequestException;
import com.citi.aqua.derivz.services.grid.model.SearchQueryResult;
import com.citi.aqua.derivz.services.grid.model.SecondaryColumnEntry;
import com.citi.aqua.derivz.services.grid.postprocessing.SearchQueryPostprocessor;
import com.citi.aqua.derivz.vo.aggrid.filter.ColumnFilter;
import com.citi.aqua.derivz.vo.aggrid.filter.SetColumnFilter;
import com.citi.aqua.derivz.vo.aggrid.request.ColumnVO;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;
import com.citi.aqua.frm.framework.grid.exception.FrmDataGridException;
import com.citi.aqua.frm.framework.grid.query.DirectSqlQuery;
import com.citi.aqua.frm.framework.grid.query.QueryResult;
import com.citi.aqua.frm.framework.grid.tools.FrmGrid;
import com.google.common.collect.Iterables;
import com.google.common.collect.Streams;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Collections.emptyList;
import static java.util.Objects.nonNull;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/9/2019
 */
@Slf4j
public class CeftFrmGroupingPivotQueryServiceImpl {

    public static final String CHILD_COUNT_COLUMN_NAME = "__child_count";
    private final int maxPivotColumns;
    private final FrmGrid grid;
    private final SearchQueryPostprocessor postprocessor;
    private final CeftFrmQueryService queryService;

    public CeftFrmGroupingPivotQueryServiceImpl(FrmGrid grid,
            SearchQueryPostprocessor postprocessor, CeftFrmQueryService queryService, int maxPivotColumns) {
        this.grid = grid;
        this.postprocessor = postprocessor;
        this.queryService = queryService;
        this.maxPivotColumns = maxPivotColumns;
    }

    public long countGroupingPivotQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet)
            throws FrmDataGridException {
        String sqlQuery;
        if (request.isPivotMode()) {
            sqlQuery = buildCountAggregateQuery(request, dataSet);
        } else {
            if (isAggregate(request.getRowGroupCols(), request.getGroupKeys())) {
                sqlQuery = buildCountAggregateQuery(request, dataSet);
            } else {
                //all groups expanded
                sqlQuery = buildCountPlainQuery(request, dataSet);
            }
        }
        return executeCountQuery(sqlQuery, dataSet);
    }

    public SearchQueryResult searchGroupingPivotQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet)
            throws FrmDataGridException {
        //check if this is pivot or grouping query:
        if (request.isPivotMode()) {
            //validate the request
            if (request.getRowGroupCols() == null || request.getRowGroupCols().isEmpty() ||
                    request.getPivotCols() == null || request.getPivotCols().isEmpty()) {
                log.debug("The request is not valid, missing grouping and/or pivot cols.");
                throw new InvalidDataRequestException("Invalid request.");
            }
            // do pivot
            return processPivotSearchQuery(request, dataSet);
        } else {
            String sqlQuery;
            //not all groups expanded:
            if (isAggregate(request.getRowGroupCols(), request.getGroupKeys())) {
                sqlQuery = buildAggregateQuery(request, dataSet);
            } else {
                //all groups expanded
                sqlQuery = buildPlainQuery(request, dataSet);
            }
            return executeSearchQuery(sqlQuery, dataSet, request.getLimit(), request.getStartRow());
        }
    }

    private SearchQueryResult processPivotSearchQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet) {
        List<PivotColumnEntry> pivotColumns = buildPivotColumns(request, dataSet);
        boolean pivotColumnsOverflow = pivotColumns.size() > maxPivotColumns;
        if (pivotColumnsOverflow) {
            log.warn("GridQueryService:: pivot request resulted with {}, "
                            + "while maximum allowed is {}. Truncating column list.",
                    pivotColumns.size(), maxPivotColumns);
            pivotColumns = pivotColumns.subList(1, maxPivotColumns);
        }
        String pivotSqlQuery = buildPivotQuery(request, dataSet, pivotColumns);
        SearchQueryResult searchQueryResult =
                executeSearchQuery(pivotSqlQuery, dataSet, request.getLimit(), request.getStartRow());
        searchQueryResult.setPivotColumnOverflow(pivotColumnsOverflow);
        searchQueryResult.setPivotColumns(buildSecondaryPivotColumnHierarchy(pivotColumns));
        return searchQueryResult;
    }

    protected static List<SecondaryColumnEntry> buildSecondaryPivotColumnHierarchy(
            List<PivotColumnEntry> pivotColumns) {

        class GroupPrototype {
            String displayName;
            String id;
            final Map<Object, GroupPrototype> children = new HashMap<>();
            final List<PivotColumnEntry> columns = new ArrayList<>();

            GroupPrototype(String displayName, String id) {
                this.displayName = displayName;
                this.id = id;
            }

            SecondaryColumnEntry toColumnEntry() {
                SecondaryColumnEntry res = new SecondaryColumnEntry();
                res.setGroupId(id);
                res.setHeaderName(displayName);
                res.setChildren(Stream.concat(children.values().stream().map(GroupPrototype::toColumnEntry),
                        columns.stream().map(PivotColumnEntry::toSecondaryColumnEntry))
                        .sorted(Comparator.comparing(SecondaryColumnEntry::getHeaderName))
                        .collect(Collectors.toList()));
                return res;
            }
        }

        Map<Object, GroupPrototype> groups = new HashMap<>();
        GroupPrototype prototype = null;
        for (PivotColumnEntry columnEntry : pivotColumns) {
            Map<Object, GroupPrototype> map = groups;
            for (int i = 0; i < columnEntry.getValues().size(); i++) {
                Object val = columnEntry.getValues().get(i);
                final int finI = i;
                prototype = map.computeIfAbsent(val, kv ->
                        new GroupPrototype(
                                (kv != null ? kv.toString() : ""),
                                columnEntry.getValues()
                                        .subList(0, finI + 1)
                                        .stream()
                                        .map(Object::toString)
                                        .collect(Collectors.joining("|"))));
                map = prototype.children;
            }
            if (prototype != null) {
                prototype.columns.add(columnEntry);
            }
        }
        return groups.values()
                .stream()
                .map(GroupPrototype::toColumnEntry)
                .sorted(Comparator.comparing(SecondaryColumnEntry::getHeaderName))
                .collect(Collectors.toList());


    }


    private SearchQueryResult executeSearchQuery(String sqlQuery, CeftDataSet dataSet, int limit, int offset) {
        try {
            List<Map<String, Object>> queryResult = executePlainQuery(sqlQuery, dataSet).stream()
                    .map(m -> (Map<String, Object>) m)
                    .collect(Collectors.toList());
            SearchQueryResult result = new SearchQueryResult(queryResult, null, limit, offset, false);
            if (nonNull(postprocessor)) {
                result = postprocessor.processQueryResult(result);
            }
            return result;
        } catch (RuntimeException re) {
            throw new FrmDataGridException("Failed to execute query.", re);
        }
    }


    private long executeCountQuery(String sqlQuery, CeftDataSet dataSet) {
        List<Map<String, ?>> res = executePlainQuery(sqlQuery, dataSet);
        Object first = Iterables.getFirst(res.get(0).values(), null);
        return ((Number) Objects.requireNonNull(first)).longValue();
    }

    private List<List<Object>> extractPivotValues(EnterpriseGetRowsRequest request, CeftDataSet dataSet) {
        return request.getPivotCols()
                .stream()
                .map(col -> columnPivotValues(col, request, dataSet))
                .collect(Collectors.toList());
    }

    private List<Object> columnPivotValues(ColumnVO col, EnterpriseGetRowsRequest groupingRequest,
            CeftDataSet dataSet) {
        return queryService.distinctValuesQuery(dataSet, groupingRequest.getFilterModel(), col.getField());
    }

    private List<PivotColumnEntry> buildPivotColumns(EnterpriseGetRowsRequest request, CeftDataSet dataSet) {
        List<List<Object>> pivotValues = extractPivotValues(request, dataSet);
        List<List<Object>> pivotCombinations = cartesian(pivotValues);

        return pivotCombinations.stream()
                .flatMap(combination -> request.getValueCols().stream()
                        .map(aggregationColumn -> createPivotColumn(request, combination, aggregationColumn)))
                .collect(Collectors.toList());
    }


    private PivotColumnEntry createPivotColumn(EnterpriseGetRowsRequest request, List<Object> values,
            ColumnVO aggregation) {
        String colName = String.format("PIVOT|%s|%s(%s)",
                values.stream()
                        .map(v -> ("" + v).replace('|', '_'))
                        .collect(Collectors.joining("|")),
                aggregation.getAggFunc(),
                aggregation.getField());
        return new PivotColumnEntry(request.getPivotCols(), values, aggregation, colName);
    }


    private String buildPivotQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet,
            List<PivotColumnEntry> pivotColumns) {
        return buildPivotQueryCore(request, dataSet, pivotColumns) + buildLimitClause(request.getLimit(),
                request.getStartRow());
    }

    private String buildPivotQueryCore(EnterpriseGetRowsRequest request, CeftDataSet dataSet,
            List<PivotColumnEntry> pivotColumns) {
        List<String> pivotColumnStatements =
                pivotColumns.stream().map(PivotColumnEntry::pivotColumnSelectClause).collect(
                        Collectors.toList());

        List<ColumnVO> groupingColumnStatement = buildGroupingColumnList(request.getRowGroupCols(),
                request.getGroupKeys());

        String selectClause = buildSelectClause(groupingColumnStatement);
        if (!pivotColumnStatements.isEmpty()) {
            selectClause += ", " + String.join(", ", pivotColumnStatements);
        }
        selectClause+= ", " + childCountSelectClause(request) + " ";

        return selectClause
                + buildFromClause(dataSet)
                + buildWhereClause(request.getFilterModel(), request.getRowGroupCols(), request.getGroupKeys())
                + buildGroupClause(groupingColumnStatement);
    }

    protected static List<List<Object>> cartesian(List<List<Object>> lists) {
        if (lists.isEmpty()) {
            return emptyList();
        } else if (lists.size() == 1) {
            return lists.get(0).stream().map(Collections::singletonList).collect(Collectors.toList());
        }
        List<List<Object>> restCartesian = cartesian(lists.subList(1, lists.size()));
        return lists.get(0)
                .stream()
                .flatMap(o -> restCartesian.stream().map(l -> ListUtils.union(Collections.singletonList(o), l)))
                .collect(Collectors.toList());
    }


    private List<Map<String, ?>> executePlainQuery(String sqlQuery, CeftDataSet dataSet) {
        QueryResult queryResult = grid.connectQueryService()
                .queryDatasetDirect(new DirectSqlQuery(dataSet.toDataSetId(), sqlQuery), dataSet.toUser());
        return queryResult.getResult();
    }

    private String buildPlainQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet) {
        List<ColumnVO> nonAggregationColumns = request.getValueCols()
                .stream()
                .filter(col -> col.getAggFunc() == null)
                .collect(Collectors.toList());
        List<ColumnVO> aggregations = requestToAggregations(request);
        String coreSqlClause = buildPlainQueryCore(dataSet, request.getRowGroupCols(), request.getGroupKeys(),
                request.getFilterModel());

        List<ColumnVO> selectGroupingValues =
                buildGroupingColumnList(request.getRowGroupCols(), request.getGroupKeys());

        List<ColumnVO> aggregationColumnAsValues = Optional.ofNullable(aggregations).orElse(emptyList())
                .stream()
                .map(agCol -> new ColumnVO(agCol.getId(), agCol.getDisplayName(), agCol.getField(), null))
                .collect(Collectors.toList());

        String selectClause = buildSelectClause(nonAggregationColumns.isEmpty(),
                selectGroupingValues, aggregationColumnAsValues, nonAggregationColumns);

        return selectClause + coreSqlClause + buildLimitClause(request.getLimit(), request.getStartRow());
    }

    private String buildCountPlainQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet) {
        List<ColumnVO> columns = request.getValueCols()
                .stream()
                .filter(col -> col.getAggFunc() == null)
                .collect(Collectors.toList());
        String coreSqlClause =
                "SELECT 1 " + buildPlainQueryCore(dataSet, request.getRowGroupCols(), request.getGroupKeys(),
                        request.getFilterModel());
        return countQuery(coreSqlClause);
    }

    private String countQuery(String coreSqlClause) {
        return String.format("SELECT COUNT(*) FROM (%s)", coreSqlClause);
    }

    private String buildPlainQueryCore(CeftDataSet dataSet, List<ColumnVO> columnGrouping,
            List<String> groupValues,
            Map<String, ColumnFilter> filters) {
        return buildFromClause(dataSet) + buildWhereClause(filters, columnGrouping, groupValues);
    }

    protected String buildAggregateQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet) {
        List<ColumnVO> rowGroupCols = request.getRowGroupCols();
        List<ColumnVO> columnVOS = requestToAggregations(request);
        String queryCore = buildAggregateQueryCore(dataSet, rowGroupCols,
                request.getGroupKeys(), request.getFilterModel());

        String limitClause = buildLimitClause(request.getLimit(), request.getStartRow());
        String selectClause =
                buildSelectClause(buildGroupingColumnList(rowGroupCols, request.getGroupKeys()), columnVOS);

        return selectClause + ", " + childCountSelectClause(request) + " " + queryCore + limitClause;
    }


    private static String childCountSelectClause(EnterpriseGetRowsRequest request) {
        String countCol = "*";

        if (request.getRowGroupCols().size() > request.getGroupKeys().size()+1) {
            countCol = "DISTINCT " + request.getRowGroupCols().get(request.getGroupKeys().size()+1).getField();
        }
        return "COUNT(" + countCol + ") AS " + CHILD_COUNT_COLUMN_NAME;
    }

    private List<ColumnVO> requestToAggregations(EnterpriseGetRowsRequest request) {
        return Optional.ofNullable(request.getValueCols()).orElse(emptyList())
                .stream()
                .filter(col -> nonNull(col.getAggFunc()))
                .collect(Collectors.toList());
    }

    private String buildCountAggregateQuery(EnterpriseGetRowsRequest request, CeftDataSet dataSet) {
        String queryCore = buildAggregateQueryCore(dataSet, request.getRowGroupCols(),
                request.getGroupKeys(), request.getFilterModel());
        String query = "SELECT 1 " + queryCore;
        return countQuery(query);
    }


    private String buildAggregateQueryCore(CeftDataSet dataSet, List<ColumnVO> columnGrouping, List<String> groupValues,
            Map<String, ColumnFilter> filters) {
        List<ColumnVO> groupingColumns = buildGroupingColumnList(columnGrouping, groupValues);

        String fromClause = buildFromClause(dataSet);
        String whereClause = buildWhereClause(filters, columnGrouping, groupValues);
        String groupClause = buildGroupClause(groupingColumns);

        return fromClause + whereClause + groupClause;
    }

    private String buildGroupClause(List<ColumnVO> selectGroupingValues) {
        return " GROUP BY " + selectGroupingValues.stream().map(ColumnVO::getField).collect(Collectors.joining(", "));
    }


    private List<ColumnVO> buildGroupingColumnList(List<ColumnVO> columnGrouping, List<String> groupValues) {
        if (isAggregate(columnGrouping, groupValues)) {
            return columnGrouping
                    .stream()
                    .limit(groupValues.size() + 1L)
                    .collect(Collectors.toList());
        } else {
            return new ArrayList<>(columnGrouping);
        }
    }


    private String buildLimitClause(int limit, int offset) {
        return String.format(" LIMIT %s OFFSET %s", limit, offset);
    }

    private String buildWhereClause(Map<String, ColumnFilter> filters, List<ColumnVO> columnGrouping,
            List<String> groupValues) {
        List<String> groupInducedConditions = buildGroupValueConditions(columnGrouping, groupValues);
        List<String> filterConditions = buildFilterConditions(filters);

        String conditions = Stream.concat(groupInducedConditions.stream(), filterConditions.stream())
                .collect(Collectors.joining(" AND "));
        return conditions.isEmpty() ? " " : " WHERE " + conditions;
    }

    private List<String> buildGroupValueConditions(List<ColumnVO> columnGrouping, List<String> groupValues) {
        return Streams.zip(groupValues.stream(), columnGrouping.stream(),
                (v, c) -> buildEqCondition(c.getField(), v)).collect(Collectors.toList());
    }

    @SafeVarargs
    private static String buildSelectClause(List<ColumnVO>... columnClauses) {
        return buildSelectClause(false, columnClauses);
    }

    @SafeVarargs
    protected static String buildSelectClause(boolean withWildcard, List<ColumnVO>... columnClauses) {
        List<ColumnVO> columnVOStream = Arrays.stream(columnClauses)
                .filter(Objects::nonNull)
                .flatMap(List::stream)
                .collect(Collectors.toList());
        List<ColumnVO> filteredList = new ArrayList<>();
        Map<String, ColumnVO> aliasMap = new HashMap<>();
        for (ColumnVO columnVO : columnVOStream) {
            String alias = columnVO.getId();
            if (!aliasMap.containsKey(alias)) {
                filteredList.add(columnVO);
                aliasMap.put(alias, columnVO);
            } else {
                ColumnVO previous = aliasMap.get(alias);
                if (!StringUtils.equalsIgnoreCase(previous.getId(), columnVO.getId())
                        || !StringUtils.equalsIgnoreCase(previous.getField(), columnVO.getField())
                        || !StringUtils.equalsIgnoreCase(previous.getAggFunc(), columnVO.getAggFunc())
                ) {
                    throw new IllegalArgumentException(
                            "Unexpected query to be built, two different columns requested with alias " + alias
                                    + ": " + previous + " and " + columnVO);
                }
            }
        }
        String columns = filteredList
                .stream()
                .map(CeftFrmGroupingPivotQueryServiceImpl::buildColumnSelectClause)
                .collect(Collectors.joining(", "));
        if (columns.isEmpty()) {
            columns = "*";
        } else if (withWildcard) {
            columns += ", *";
        }
        return "SELECT " + columns;
    }


    @SuppressWarnings("ConstantConditions")
    private List<String> buildFilterConditions(Map<String, ColumnFilter> filters) {
        return Optional.ofNullable(filters)
                .orElse(Collections.emptyMap())
                .keySet()
                .stream()
                .sorted()
                .map(column -> buildFilterClause(column, filters.get(column)))
                .collect(Collectors.toList());
    }

    private String buildFilterClause(String key, ColumnFilter rawFilter) {
        if (rawFilter instanceof SetColumnFilter) {
            SetColumnFilter filter = (SetColumnFilter) rawFilter;
            String combined = filter.getValues()
                    .stream()
                    .map(val -> buildEqCondition(key, val))
                    .collect(Collectors.joining(" OR "));
            if (filter.getValues().size() > 1) {
                return "(" + combined + ")";
            } else {
                return combined;
            }
        } else {
            throw new UnsupportedOperationException(
                    "Filter type " + rawFilter.getClass().getName() + " not yet supported.");
        }

    }

    protected static String buildEqCondition(String column, Object value) {
        if (value == null || (value instanceof String && ((String) value).isEmpty())) {
            return String.format("(%1$s='' OR %1$s IS NULL)", column);
        } else if (value instanceof Number) {
            return String.format("%s=%s", column, "" + value);
        } else {
            return String.format("%s='%s'", column, value);
        }
    }

    protected String buildFromClause(CeftDataSet ceftDataSet) {
        String sqlNamespace = grid.connectQueryService().getDataSetSQLNamespace(ceftDataSet.toDataSetId(), ceftDataSet
                .toUser());
        String sqlTableName = grid.connectQueryService().getDataSetSQLTableName(ceftDataSet.toDataSetId(), ceftDataSet
                .toUser());
        return String.format(" FROM %s.%s", sqlNamespace, sqlTableName);
    }

    private static String buildColumnSelectClause(ColumnVO columnVO) {
        String sClause;
        if (nonNull(columnVO.getAggFunc())) {
            sClause = String.format("%s(%s)", columnVO.getAggFunc().toUpperCase(), columnVO.getField());
        } else {
            sClause = columnVO.getField();
        }
        if (nonNull(columnVO.getId())) {
            return String.format("%s AS %s", sClause, columnVO.getId());
        } else {
            return sClause;
        }
    }

    protected boolean isAggregate(EnterpriseGetRowsRequest request) {
        return isAggregate(request.getRowGroupCols(), request.getGroupKeys());
    }

    private boolean isAggregate(List<ColumnVO> columnGrouping, List<String> groupValues) {
        return Optional.ofNullable(groupValues).map(List::size).orElse(0) < columnGrouping.size();
    }

    @Value
    protected static class PivotColumnEntry {
        List<ColumnVO> columns;
        List<Object> values;
        ColumnVO aggregation;
        String columnName;

        protected String pivotColumnSelectClause() {
            String valCond = Streams.zip(columns.stream(), values.stream(),
                    (col, val) -> buildEqCondition(col.getField(), val))
                    .collect(Collectors.joining(" AND "));
            return String.format("%s(CASE WHEN (%s) THEN %s END) AS \"%s\"",
                    aggregation.getAggFunc(), valCond, aggregation.getField(),
                    columnName);
        }

        private SecondaryColumnEntry toSecondaryColumnEntry() {
            SecondaryColumnEntry res = new SecondaryColumnEntry();
            res.setColId(columnName.toLowerCase());
            res.setField(columnName.toLowerCase());

            String fieldName = Optional.ofNullable(aggregation.getDisplayName()).orElse(aggregation.getField().toLowerCase());
            res.setHeaderName(String.format("%s(%s)", aggregation.getAggFunc().toLowerCase(), fieldName));
            return res;
        }
    }
}
