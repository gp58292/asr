package com.citi.aqua.derivz.config;

import com.citi.aqua.frm.framework.messaging.websocket.config.EnableAtmosphereFramework;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Profile("frm-framework-service-grid")
@Configuration
@EnableAtmosphereFramework({"com.citi.aqua.derivz.websocket", "com.citi.aqua.frm.framework.messaging.websocket"})
public class WebsocketConfiguration {
}
