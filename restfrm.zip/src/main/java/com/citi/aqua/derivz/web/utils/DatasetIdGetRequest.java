package com.citi.aqua.derivz.web.utils;

public class DatasetIdGetRequest {

    String soeid;
    String datasetTypeName;

    public String getSoeid() {
        return soeid;
    }

    public void setSoeid(String soeid) {
        this.soeid = soeid;
    }

    public String getDatasetTypeName() {
        return datasetTypeName;
    }

    public void setDatasetTypeName(String datasetTypeName) {
        this.datasetTypeName = datasetTypeName;
    }

    @Override
    public String toString() {
        return "DatasetIdGetRequest{" +
                "soeid='" + soeid + '\'' +
                ", datasetTypeName='" + datasetTypeName + '\'' +
                '}';
    }
}
