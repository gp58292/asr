package com.citi.aqua.derivz.services.grid.model;

import com.citi.aqua.derivz.services.grid.ColumnSortCriteria;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class SearchDataRequest extends DataRequest {
    /** Columns to be queried. If empty, then '*' (all columns) is used. */
    private List<String> columns;

    private List<ColumnSortCriteria> sortCriteria;
    private int offset;
    private int limit;
}
