package com.citi.aqua.derivz.commons.constants;

public class QueryConstants {

	public static final String AGRREMENT_KEY_DISTINCT_QUERY = "select distinct(agreement_key) from dz.vw_dim_agreement_ceft where agreement_key  is not null";

}
