package com.citi.aqua.derivz.vo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class CollateralCashDetailsVO {
	private String accCurrency;
	private String accInterestMatrix;
	private String accInterestSpread;
	private String accCompounding;
	private String accPaymentFrequency;
	private String accResetFrequency;
	private String accRanking;
}
