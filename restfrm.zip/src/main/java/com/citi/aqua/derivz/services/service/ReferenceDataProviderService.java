package com.citi.aqua.derivz.services.service;

import java.util.List;
import java.util.Map;
import java.util.Set;
import com.citi.aqua.derivz.model.RatingRankings;
import com.citi.aqua.derivz.vo.ReferenceDataVO;
@SuppressWarnings("rawtypes")
public interface ReferenceDataProviderService {

	public List<ReferenceDataVO> findDistinctReferenceData(final Long attributeKey);

	public List<ReferenceDataVO> findTypeAheadReferenceList(final Long attributeKey,final String referenceValueLike);
	
    public Map<String, List<ReferenceDataVO>> findTypeAheadReferenceListByPastedValues(final Long attributeKey,final String[] referenceValueLike);
    
    public Set<RatingRankings> getRatingRankings();

	public List<String> getAllDatasetTypes();
	
	public String getCobDateFromDB();

}
