package com.citi.aqua.derivz.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)	
public class CollateralResponseDTO {

	private String collateralTypeName;
	private String countryCode;
	private String currencyCode;
	private String guarantor;
	private String includeExclude;
	private String inclusionIndicator;
	private String indexExcluded;
	private String indexName;
	private String industryClass;
	private String industryCode;
	private String isinCode;
	private String marketSectorCode;
	private String sectypeLevel1Code;
	private String sectypeLevel2Code;
	private String sectypeLevel3Code;
	private String smci;
	private String smcp;
	private String stateCode;
	private String typeOfCollateral;

}