package com.citi.aqua.derivz.services.grid.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
public class DistinctValueDataRequest extends DataRequest {
    private String column;


}
