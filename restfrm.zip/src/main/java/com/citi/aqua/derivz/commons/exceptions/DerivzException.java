package com.citi.aqua.derivz.commons.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @name DerivzException
 * @description This is the Generic Exception to handler both Application
 *              Exception and Validation Exception
 *
 */
@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR, reason = "Failed to process the given request")
public class DerivzException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public DerivzException() {
	}

	public DerivzException(String message) {
		super(message);
	}

	public DerivzException(Throwable cause) {
		super(cause);
	}

	public DerivzException(String message, Throwable throwable) {
		super(message, throwable);
	}

}
