package com.citi.aqua.derivz.data.cache.eh;

public enum ReferenceCacheKeys {
    DROP_DOWN, ALL_REFRENCE, RATING_RANKINGS
}
