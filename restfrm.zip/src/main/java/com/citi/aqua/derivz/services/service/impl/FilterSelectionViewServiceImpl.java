package com.citi.aqua.derivz.services.service.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import com.citi.aqua.derivz.commons.constants.DerivzBeanConstants;
import com.citi.aqua.derivz.commons.constants.DerivzCacheConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.exceptions.RestExceptionMessage;
import com.citi.aqua.derivz.comparator.GroupComparator;
import com.citi.aqua.derivz.comparator.SearchCriteriaComparator;
import com.citi.aqua.derivz.comparator.TableNodeComparator;
import com.citi.aqua.derivz.enums.ComponentType;
import com.citi.aqua.derivz.model.SelectionFilters;
import com.citi.aqua.derivz.services.service.CombinedColumns;
import com.citi.aqua.derivz.services.service.FilterSelectionViewService;
import com.citi.aqua.derivz.vo.GroupVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import com.citi.aqua.derivz.vo.TableNodeVO;

@Service(DerivzBeanConstants.SETTINGS_PAGE_VIEW_SERVICE_BEAN)
public class FilterSelectionViewServiceImpl implements FilterSelectionViewService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FilterSelectionViewServiceImpl.class);

	
	@Autowired
	CombinedColumns combinedColumns;

    @Cacheable(value = DerivzCacheConstants.TREE_VIEW_FILTER_LIST_CACHE, keyGenerator = "customKeyGenerator")
	public List<GroupVO> findTreeViewFilterList() {
		LOGGER.debug("FilterSelectionViewServiceImpl::findTreeViewFilterList() ");
		final Map<String, Map<String, List<SearchFieldVO>>> filtersAvailable = new LinkedHashMap<>();
		// Repository call to find the list of all the filters available in the
		// application
		final List<SelectionFilters> filterSelectionList = this.combinedColumns.findAll(true); 
		List<SearchFieldVO> existingColumnList = new LinkedList<>();
		try {
			for (final SelectionFilters filter : filterSelectionList) {
				Map<String, List<SearchFieldVO>> nodeAttributesMap = new LinkedHashMap<>();
				final SearchFieldVO searchCriteriaVO = new SearchFieldVO();
				final List<SearchFieldVO> modifiedColumnList = new LinkedList<>();
				if (filtersAvailable.containsKey(filter.getLogicalGroup())) {
					// The logical group is already present
					nodeAttributesMap = filtersAvailable.get(filter.getLogicalGroup());
					searchCriteriaVO.setFieldName(filter.getFieldName());
					searchCriteriaVO.setName(filter.getDisplayName());
					searchCriteriaVO.setSchemaName(filter.getSchemaName());
					searchCriteriaVO.setComponentType(ComponentType.valueOfByName(filter.getComponentType()));
					searchCriteriaVO.setNodeName(filter.getNodeName());
					searchCriteriaVO.setLogicalGroupName(filter.getLogicalGroup());
					searchCriteriaVO.setKey(filter.getFilterKey());
					searchCriteriaVO.setDataType(filter.getAttributeDatatype());
					searchCriteriaVO.setKey(filter.getFilterKey());
					searchCriteriaVO.setNodeDisplayName(filter.getNodeDisplayName());
					searchCriteriaVO.setDistinctRequired(filter.getDistinctRequired());
					searchCriteriaVO.setWhoHasFlag(filter.getWhoHasFlag());
					searchCriteriaVO.setFilterOnlyFlag(filter.getFilterOnlyFlag());
					// if , the same node is present already in the logical group
					if (nodeAttributesMap.containsKey(filter.getNodeDisplayName())) {
                        existingColumnList = nodeAttributesMap.get(filter.getNodeDisplayName());
						existingColumnList.add(searchCriteriaVO);
						Collections.sort(existingColumnList, new SearchCriteriaComparator());
					}
					// if new node is available for the logical group
					else {
						modifiedColumnList.add(searchCriteriaVO);
						Collections.sort(modifiedColumnList, new SearchCriteriaComparator());
						nodeAttributesMap.put(filter.getNodeDisplayName(), modifiedColumnList);
						filtersAvailable.put(filter.getLogicalGroup(), nodeAttributesMap);
					}

				}
				// If the logical group is not present in the filters map
				else {
					searchCriteriaVO.setFieldName(filter.getFieldName());
					searchCriteriaVO.setComponentType(ComponentType.valueOfByName(filter.getComponentType()));
					searchCriteriaVO.setName(filter.getDisplayName());
					searchCriteriaVO.setSchemaName(filter.getSchemaName());
					searchCriteriaVO.setNodeName(filter.getNodeName());
					searchCriteriaVO.setLogicalGroupName(filter.getLogicalGroup());
					searchCriteriaVO.setDataType(filter.getAttributeDatatype());
					searchCriteriaVO.setKey(filter.getFilterKey());
					searchCriteriaVO.setNodeDisplayName(filter.getNodeDisplayName());
					searchCriteriaVO.setDistinctRequired(filter.getDistinctRequired());
					searchCriteriaVO.setWhoHasFlag(filter.getWhoHasFlag());
					searchCriteriaVO.setFilterOnlyFlag(filter.getFilterOnlyFlag());
					
					final List<SearchFieldVO> newColumnList = new LinkedList<>();
					newColumnList.add(searchCriteriaVO);
					nodeAttributesMap = new HashMap<>();
					nodeAttributesMap.put(filter.getNodeDisplayName(), newColumnList);
					Collections.sort(newColumnList, new SearchCriteriaComparator());
					filtersAvailable.put(filter.getLogicalGroup(), nodeAttributesMap);
				}
			}
		} catch (Exception e) {
			throw new DerivzApplicationException(e, RestExceptionMessage.FAILED_TREE_VIEW_LOAD);
		}
		return formGroupStructure(filtersAvailable);
	}

	@SuppressWarnings("rawtypes")
	private List<GroupVO> formGroupStructure(final Map<String, Map<String, List<SearchFieldVO>>> treeViewMap) {
		LOGGER.debug("FilterSelectionViewServiceImpl::formGroupStructure() ");
		List<GroupVO> groupList = new LinkedList<>();
		try {
			final Set<String> groupSet = treeViewMap.keySet();
			for (String groups : groupSet) {
				final GroupVO groupVO = new GroupVO();
				groupVO.setName(groups);
				final Map<String, List<SearchFieldVO>> nodeAttributeMap = treeViewMap.get(groups);
				final List<TableNodeVO> tableNodesList = new LinkedList<>();

				final Set<String> nodesSet = nodeAttributeMap.keySet();
				for (final String nodes : nodesSet) {
					final TableNodeVO nodeVO = new TableNodeVO();
					nodeVO.setName(nodes);
					nodeVO.setChildren(nodeAttributeMap.get(nodes));
					tableNodesList.add(nodeVO);
				}
				Collections.sort(tableNodesList, new TableNodeComparator());
				groupVO.setChildren(tableNodesList);
				groupList.add(groupVO);
			}

			Collections.sort(groupList, new GroupComparator());

		} catch (Exception e) {
			LOGGER.error("FilterSelectionViewServiceImpl::formGroupStructure() :: Error " + e, e);
			throw new DerivzApplicationException(e, RestExceptionMessage.FAILED_TREE_VIEW_LOAD);
		}

		return groupList;
	}

	@Cacheable(cacheNames = DerivzCacheConstants.FLAT_VIEW_FILTER_LIST_CACHE)
	public List<TableNodeVO> findFlatViewFilterList() {
		List<TableNodeVO> flatList = new LinkedList<>();
		try {
			final Map<String, List<SearchFieldVO>> flatViewMap = new HashMap<>();
			List<SearchFieldVO> existingColumnList = new LinkedList<>();

			// Repository call to find the list of all the available filters in the
			// application
			final List<SelectionFilters> filterSelectionList = this.combinedColumns.findAll(false);
			for (final SelectionFilters filter : filterSelectionList) {
				final SearchFieldVO searchCriteriaVO = new SearchFieldVO();
				if (flatViewMap.containsKey(filter.getLogicalGroup())) {
					searchCriteriaVO.setFieldName(filter.getFieldName());
					searchCriteriaVO.setName(filter.getDisplayName());
					searchCriteriaVO.setSchemaName(filter.getSchemaName());
					searchCriteriaVO.setComponentType(ComponentType.valueOfByName(filter.getComponentType()));
					searchCriteriaVO.setNodeName(filter.getNodeName());
					searchCriteriaVO.setLogicalGroupName(filter.getLogicalGroup());
					searchCriteriaVO.setKey(filter.getFilterKey());
					searchCriteriaVO.setDataType(filter.getAttributeDatatype());
					searchCriteriaVO.setKey(filter.getFilterKey());
					searchCriteriaVO.setNodeDisplayName(filter.getNodeDisplayName());
					searchCriteriaVO.setDistinctRequired(filter.getDistinctRequired());
					searchCriteriaVO.setWhoHasFlag(filter.getWhoHasFlag());
					searchCriteriaVO.setFilterOnlyFlag(filter.getFilterOnlyFlag());
					
					existingColumnList = flatViewMap.get(filter.getLogicalGroup());
					existingColumnList.add(searchCriteriaVO);
				} else {
					searchCriteriaVO.setFieldName(filter.getFieldName());
					searchCriteriaVO.setComponentType(ComponentType.valueOfByName(filter.getComponentType()));
					searchCriteriaVO.setName(filter.getDisplayName());
					searchCriteriaVO.setSchemaName(filter.getSchemaName());
					searchCriteriaVO.setNodeName(filter.getNodeName());
					searchCriteriaVO.setLogicalGroupName(filter.getLogicalGroup());
					searchCriteriaVO.setDataType(filter.getAttributeDatatype());
					searchCriteriaVO.setKey(filter.getFilterKey());
					searchCriteriaVO.setNodeDisplayName(filter.getNodeDisplayName());
					searchCriteriaVO.setDistinctRequired(filter.getDistinctRequired());
					searchCriteriaVO.setWhoHasFlag(filter.getWhoHasFlag());
					searchCriteriaVO.setFilterOnlyFlag(filter.getFilterOnlyFlag());
					
					final List<SearchFieldVO> newColumnList = new LinkedList<>();
					newColumnList.add(searchCriteriaVO);
					flatViewMap.put(filter.getLogicalGroup(), newColumnList);
				}
			}
			flatList = formFlatStructure(flatViewMap);
		} catch (Exception e) {
			throw new DerivzApplicationException(e, RestExceptionMessage.FAILED_FLAT_VIEW_LOAD);
		}
		return flatList;
	}

	@SuppressWarnings("rawtypes")
  private List<TableNodeVO> formFlatStructure(final Map<String, List<SearchFieldVO>> flatViewMap) {
		LOGGER.debug("FilterSelectionViewServiceImpl::formFlatStructure() ");
		try {
			final Map<String, List<SearchFieldVO>> sortedMap = flatViewMap.entrySet().stream()
					.sorted(Map.Entry.comparingByKey()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
							(oldValue, newValue) -> oldValue, LinkedHashMap::new));
			return sortedMap.keySet().stream().map(group -> new TableNodeVO(group, sortedMap.get(group))).collect(Collectors.toList());
		} catch (Exception e) {
			throw new DerivzApplicationException(e, RestExceptionMessage.FAILED_FLAT_VIEW_LOAD);
		}
	}
	
	

}