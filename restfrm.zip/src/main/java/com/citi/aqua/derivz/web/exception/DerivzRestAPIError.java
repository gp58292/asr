package com.citi.aqua.derivz.web.exception;

import java.io.Serializable;

public class DerivzRestAPIError implements Serializable {

	private static final long serialVersionUID = 1L;

	private String errorMessage;

	private String errorCode;
	
	private String errorDetails;

	
	public DerivzRestAPIError(final String errorMessage, final String errorCode) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public DerivzRestAPIError(String errorMessage, String errorCode, String errorDetails) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.errorDetails=errorDetails;
	}

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage
	 *            the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode
	 *            the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDetails() {
		return errorDetails;
	}

	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

}
