package com.citi.aqua.derivz.vo;

import java.io.IOException;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder
@Getter
@Setter
@JsonDeserialize(using = TenorRangeListDeserializer.class)
public class TenorRangeList<T,E> implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private TenorRange<T,E> inValue;
	private TenorRange<T,E> notInValue;
	
    private void writeObject(java.io.ObjectOutputStream stream) throws IOException {
        stream.writeObject(inValue);
        stream.writeObject(notInValue);
    }

	@SuppressWarnings("unchecked")
    private void readObject(java.io.ObjectInputStream stream)  throws IOException, ClassNotFoundException {
		inValue = (TenorRange<T,E>) stream.readObject();
		notInValue=(TenorRange<T,E>) stream.readObject();
    }
}
