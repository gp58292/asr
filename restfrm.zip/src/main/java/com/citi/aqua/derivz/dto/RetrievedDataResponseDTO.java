package com.citi.aqua.derivz.dto;

import com.citi.aqua.derivz.model.DimAgreement;
import com.citi.aqua.derivz.services.grid.model.SecondaryColumnEntry;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@Getter
@Setter
@ToString
public class RetrievedDataResponseDTO {

	@Deprecated
	private List<DimAgreement> dimAgreementList;
    
    private List<Map<String,Object>> listOfRecords;
	private String cobDate;
	private Long count;
	private List<SecondaryColumnEntry> secondaryColDefs;
	private Boolean pivotColumnOverflow;
}