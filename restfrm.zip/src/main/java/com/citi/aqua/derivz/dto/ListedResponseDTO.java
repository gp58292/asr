package com.citi.aqua.derivz.dto;

import java.util.List;

import com.citi.aqua.derivz.vo.SearchCriteriaResultVO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ListedResponseDTO {

	private List<SearchCriteriaResultVO> searchCriteriaResultList;

	private String cobDate;

	private Long count;

}