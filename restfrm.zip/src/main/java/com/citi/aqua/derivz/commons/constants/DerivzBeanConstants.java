package com.citi.aqua.derivz.commons.constants;

public final class DerivzBeanConstants {

	// Beans name
	public static final String CACHE_SERVICE_BEAN = "CacheService";
	public static final String SETTINGS_PAGE_VIEW_SERVICE_BEAN = "FilterSelectionViewService";
	public static final String SEARCH_CRITERIA_SERVICE_BEAN = "UserSearchCriteriaService";
	public static final String BOOKMARK_SERVICE_BEAN = "BookmarkService";
	public static final String DATA_SET_SERVICE_BEAN ="DatasetService";
	public static final String REFERENCE_DATA_PROVIDER_SERVICE_BEAN ="ReferenceDataProviderService";
	public static final String EXPORT_SERVICE_BEAN = "ExportService";
	
	public static final String COMBINED_COLUMN_BEAN = "Combined_Column";
	
	
	public static final String LOGIN_ACTIVITY ="LOGIN";
	public static final String LOGOUT_ACTIVITY ="LOGOUT";
	
	private DerivzBeanConstants() {
	    throw new AssertionError();
	}

}
