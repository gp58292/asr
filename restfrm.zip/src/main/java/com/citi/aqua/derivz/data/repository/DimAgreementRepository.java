package com.citi.aqua.derivz.data.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.citi.aqua.derivz.model.DimAgreement;
import com.citi.aqua.derivz.model.InputParameters;

@Repository
@Transactional
public interface DimAgreementRepository extends CrudRepository<DimAgreement, Long> {

	/*
	 * @Modifying
	 * 
	 * @Query(value = ":query", nativeQuery = true) public int
	 * findSearchResult(@Param("query") String query); // public List<DimAgreement>
	 * findSearchResult(@Param("query") String query);
	 * 
	 * @Modifying
	 * 
	 * @Query(value = "{call dz.TESTPROC()}", nativeQuery = true)
	 * 
	 * public int findSearchResult1(@Param("query") String query);
	 */

	@Procedure(name = "in_only_test")
	void inOnlyTest(@Param("inParam1") List<InputParameters> inParam1);

}
