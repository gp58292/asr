package com.citi.aqua.derivz.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity
@Table(name="Dataset", schema="dbo")
@NamedQuery(name="Dataset.findAll", query="SELECT f FROM Dataset f")
public class Dataset extends BaseEntity {

	private static final long serialVersionUID = 1L;
			
	@Id
	@Column(name="id")
	private Long id;

	@Column(name="name")
	private String name;

	@Column(name="query")
	private String query;
	
	@Column(name="entity")
	private String entity;

}