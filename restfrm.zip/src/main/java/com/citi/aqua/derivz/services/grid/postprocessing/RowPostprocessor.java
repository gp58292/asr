package com.citi.aqua.derivz.services.grid.postprocessing;

import java.util.Map;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 7/5/2019
 */
public interface RowPostprocessor {

    /**
     * Applies required postprocessing to the result row. If row should be removed, then null should be returned.
     *
     * @param input row to be processed
     * @return an updated version of the row, or null if row is to be removed.
     */
    Map<String, Object> processRow(Map<String, Object> input);
}
