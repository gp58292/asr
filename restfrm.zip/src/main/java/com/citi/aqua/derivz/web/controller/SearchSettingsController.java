package com.citi.aqua.derivz.web.controller;

import java.util.Arrays;
import java.util.List;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.commons.exceptions.RestExceptionMessage;
import com.citi.aqua.derivz.model.Bookmark;
import com.citi.aqua.derivz.services.service.BookmarkService;
import com.citi.aqua.derivz.services.service.FilterSelectionViewService;
import com.citi.aqua.derivz.vo.GroupVO;
import com.citi.aqua.derivz.vo.TableNodeVO;
import com.citi.aqua.derivz.web.utils.DerivzRestResponse;
import com.citi.aqua.derivz.web.utils.DerivzSettingsRestRequest;
import com.citi.aqua.derivz.web.utils.ResponseBuilder;

@RestController
@RequestMapping(DerivzAPIUriConstants.SETTINGS_API_URI)
public class SearchSettingsController extends BaseController {

	private static final Logger LOGGER = LoggerFactory.getLogger(SearchSettingsController.class);

	@Autowired
	BookmarkService bookmarkService;

	@Autowired
	FilterSelectionViewService filterSelectionViewService;

	@RequestMapping(value = DerivzAPIUriConstants.SETTINGS_TREE_VIEW_URI, method = RequestMethod.GET)
	public @ResponseBody  DerivzRestResponse<List<GroupVO>> getColumnsTreeView() {
		LOGGER.debug("SearchSettingsController::getColumnsTreeView() ");
		try {
			return ResponseBuilder.build(filterSelectionViewService.findTreeViewFilterList(), HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("SearchSettingsController::getColumnsTreeView() :: Error " + de, de);
			throw new DerivzApplicationException(de, RestExceptionMessage.FAILED_TREE_VIEW_LOAD);
		} catch (Exception e) {
			LOGGER.error("SearchSettingsController::getColumnsTreeView() :: Error " + e, e);
			throw new DerivzApplicationException(e, RestExceptionMessage.GENERIC_MESSAGE_FOR_FAILURE);
		}
	}

	@RequestMapping(value = DerivzAPIUriConstants.SETTINGS_FLAT_VIEW_URI, method = RequestMethod.GET)
	public @ResponseBody  DerivzRestResponse<List<TableNodeVO>> getColumnsFlatView() {
		LOGGER.debug("SearchSettingsController::getColumnsFlatView() ");
		try {
			// Service call to get the settings column in
			return ResponseBuilder.build(filterSelectionViewService.findFlatViewFilterList(), HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("SearchSettingsController::getColumnsFlatView() :: Error " + de, de);
			throw new DerivzApplicationException(de, RestExceptionMessage.FAILED_FLAT_VIEW_LOAD);
		} catch (Exception e) {
			LOGGER.error("SearchSettingsController::getColumnsFlatView() :: Error " + e, e);
			throw new DerivzApplicationException(e, RestExceptionMessage.GENERIC_MESSAGE_FOR_FAILURE);
		}
	}

	@SuppressWarnings("rawtypes")
	@RequestMapping(value = DerivzAPIUriConstants.SETTINGS_UPDATE_COLUMNS_URI, method = RequestMethod.PUT)
	public @ResponseBody DerivzRestResponse saveUserColumns(@RequestBody final DerivzSettingsRestRequest settingsSaveRequest) {
		LOGGER.debug("SearchSettingsController::saveUserColumns() ");
		try {
			String fieldKeysCSV = Arrays.toString(settingsSaveRequest.getSelectedFieldsKeys());
			// Service call to save the settings list by user preference to persist data into database
			// find if the list already exists or not
			final Bookmark userSearchList = bookmarkService.findUserSettingsColumns(settingsSaveRequest.getUserId());
			if (null != userSearchList) {
				bookmarkService.updateSettingsColumnList(userSearchList.getKey(), fieldKeysCSV);
			} else {
				bookmarkService.saveUserSettingColumns(settingsSaveRequest.getUserId(), fieldKeysCSV, settingsSaveRequest.getColumnSettingName());
			}
			return ResponseBuilder.build("Search list saved", HttpStatus.SC_OK);
		} catch (DerivzApplicationException de) {
			LOGGER.error("SearchSettingsController::saveUserColumns() :: Error " + de, de);
			return ResponseBuilder.build("Search list not saved", HttpStatus.SC_NOT_FOUND, "Failed to save user's settings list", "DS004");
		} catch (Exception e) {
			LOGGER.error("SearchSettingsController::saveUserColumns() :: Error " + e, e);
			return ResponseBuilder.buildExceptionResponse();
		}
	}

}
