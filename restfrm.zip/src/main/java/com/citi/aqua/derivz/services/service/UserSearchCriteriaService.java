package com.citi.aqua.derivz.services.service;

import java.util.List;

import com.citi.aqua.derivz.commons.exceptions.CEFTException;
import com.citi.aqua.derivz.dto.CollateralResponseDTO;
import com.citi.aqua.derivz.dto.ListedResponseDTO;
import com.citi.aqua.derivz.dto.RetrievedDataResponseDTO;
import com.citi.aqua.derivz.model.VoyagerNavigationData;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.derivz.vo.AgreementOptimalRankVO;
import com.citi.aqua.derivz.vo.RatingFieldVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import com.citi.aqua.derivz.vo.aggrid.request.EnterpriseGetRowsRequest;

@SuppressWarnings("rawtypes")
public interface UserSearchCriteriaService {

	public ListedResponseDTO findUserFilterSearch(final List<SearchFieldVO> selectionFilterVOList);

	public List<SearchFieldVO> findPredefinedResultSet();

	public List<String[]> formatCriteriaObjectForRows(List<SearchFieldVO> serachCriteriaVoList);
	
	public List<RatingFieldVO> formatRatingInRows(List<SearchFieldVO> serachCriteriaVoListData);

	public List<String[]> formatTenorCriteriaForRows(List<SearchFieldVO> serachCriteriaVoList);
	
	public List<SearchFieldVO> getCollateralLookupColumns();

	public List<CollateralResponseDTO> findCollateralFilterSearch(final List<SearchFieldVO> selectionFilterVOList);

	public List<VoyagerNavigationData> loadUserDatasetIds(final String user, final String bookmarkId);
	
	@Deprecated
	public RetrievedDataResponseDTO loadTabsData(final String tabName,final List<Long> agreementKeyList, final List<AgreementOptimalRankVO> agreementOptimalRanks, final Boolean isFilterd,final List<SearchFieldVO> criteria,final List<SearchResultColumns> smsColumns) throws CEFTException;

	public RetrievedDataResponseDTO searchDatasetResults(String datasetType, String userId, Long bookmarkId, EnterpriseGetRowsRequest gridRequest,List<String> agreementKeys) throws CEFTException;
}
