package com.citi.aqua.derivz.web.utils;

public enum BookmarkStatus {
	
	SAVED, UPDATED;
}
