package com.citi.aqua.derivz.services.grid;

import lombok.Getter;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/21/2019
 */
public enum SortOrder {
    ASCENDING(false), DESCENDING(true);

    @Getter
    private final boolean reversed;

    SortOrder(boolean reversed) {
        this.reversed = reversed;
    }
}
