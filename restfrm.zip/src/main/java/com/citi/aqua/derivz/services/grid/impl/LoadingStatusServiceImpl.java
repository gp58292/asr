package com.citi.aqua.derivz.services.grid.impl;

import com.citi.aqua.derivz.services.grid.*;
import com.citi.aqua.frm.ceft.CeftDataSetType;
import com.citi.aqua.frm.framework.grid.DataLoadingService;
import com.citi.aqua.frm.framework.grid.User;
import com.citi.aqua.frm.framework.grid.data.DataSetStatus;
import com.citi.aqua.frm.framework.grid.data.DataSetStatusCode;
import com.citi.aqua.frm.framework.grid.exception.FrmDataGridException;
import com.citi.aqua.frm.framework.grid.tools.FrmGrid;
import com.google.common.base.Stopwatch;
import lombok.extern.slf4j.Slf4j;

import java.util.Arrays;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 6/19/2019
 */
@Slf4j
public class LoadingStatusServiceImpl implements LoadingStatusService {
    private final FrmGrid grid;
    private final LoadingProgressTracker progressTracker;

    public LoadingStatusServiceImpl(FrmGrid grid, LoadingProgressTracker progressTracker) {
        this.grid = grid;
        this.progressTracker = progressTracker;
    }


    @Override
    public void loadData(CeftDataSet dataSet) {
        Stopwatch stopwatch = Stopwatch.createStarted();
        log.info("LoadingStatusServiceImpl::loadData() Starting data set loading. data set: {}", dataSet);
        DataLoadingService loadingService = grid.connectLoadingService();
        loadingService.loadDataSet(dataSet.toDataSetId(), dataSet.toUser());
        log.info("LoadingStatusServiceImpl::loadData() Started data set loading. Data set: {}; Execution time: {}",
                dataSet, stopwatch.elapsed());
    }

    @Override
    public CeftDataSetStatus requestDataSet(CeftDataSet dataSet, String atmosphereResourceUUID) throws FrmDataGridException {
        try {
            grid.connectLoadingService()
                    .validateDataSetVersion(dataSet.toDataSetId(), new User(dataSet.getSoeId(), false));
            Thread.sleep(250); //we need a bit of time to finish async activities in the grid
            CeftDataSetStatus currentStatus = dataSetStatus(dataSet);
            if (currentStatus.getStatus() == DataSetStatusCode.NOT_LOADED) {
                loadData(dataSet);
                Thread.sleep(250); //we need a bit of time to finish async activities in the grid
                currentStatus = dataSetStatus(dataSet);
                if (currentStatus.getStatus() == DataSetStatusCode.NOT_LOADED) {
                    throw new FrmDataGridException("Unable to initiate loading data set " + dataSet);
                }
            }
            if (atmosphereResourceUUID != null) {
                progressTracker.registerWebSocketUUID(dataSet, atmosphereResourceUUID);
            }
            return currentStatus;
        } catch (InterruptedException e) {
            log.warn("Unexpected interruption while waiting for async complete.", e);
            Thread.currentThread().interrupt();
            throw new FrmDataGridException("Unable to initiate loading data set " + dataSet);
        }
    }

    @Override
    public boolean isDataSetReady(CeftDataSet dataSet) {
        log.info("LoadingStatusServiceImpl::isDataSetReady Checking if set is ready. Data set: {}", dataSet);
        DataLoadingService loadingService = grid.connectLoadingService();
        return loadingService.isDataSetReady(dataSet.toDataSetId(), dataSet.toUser());
    }

    @Override
    public CeftDataSetStatus dataSetStatus(CeftDataSet dataSet) {
        log.info("LoadingStatusServiceImpl::dataSetStatus Checking data set status. Data set: {}", dataSet);
        DataLoadingService loadingService = grid.connectLoadingService();
        DataSetStatus frmStatus = loadingService.getDataSetStatus(dataSet.toDataSetId(), dataSet.toUser());
        return new CeftDataSetStatus(frmStatus, dataSet.getSoeId());
    }

    @Override
    public CeftDataSetStatus[] dataSetStatusForBookmark(String soeId, long bookmarkId) {
        return  Arrays.stream(CeftDataSetType.values())
                .map(type -> new CeftDataSet(soeId, bookmarkId, type))
                .map(this::dataSetStatus)
                .toArray(CeftDataSetStatus[]::new);
    }

    @Override
    public void forceGridCleanup() {
        log.info("GridService:: forced to clear all caches.");
        grid.connectLoadingService().clearAllCaches();
    }
}
