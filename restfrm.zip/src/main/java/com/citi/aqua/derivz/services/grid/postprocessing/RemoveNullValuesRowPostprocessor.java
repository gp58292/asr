package com.citi.aqua.derivz.services.grid.postprocessing;

import java.util.HashMap;
import java.util.Map;

import static java.util.Objects.nonNull;

/**
 * @author Aleksander Nowinski, aleksander.nowinski@citi.com
 * @since 9/27/2019
 */
public class RemoveNullValuesRowPostprocessor implements RowPostprocessor {
    @Override
    public Map<String, Object> processRow(Map<String, Object> input) {
        return input.entrySet()
                .stream()
                .filter(entry -> nonNull(entry.getValue()))
                .collect(HashMap::new,
                        (m, e) -> m.put(e.getKey(), e.getValue()),
                        HashMap::putAll);
    }
}
