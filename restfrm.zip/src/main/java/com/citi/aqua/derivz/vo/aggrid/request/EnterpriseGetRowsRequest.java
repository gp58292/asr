package com.citi.aqua.derivz.vo.aggrid.request;


import com.citi.aqua.derivz.utils.LogUtils;
import com.citi.aqua.derivz.vo.aggrid.filter.ColumnFilter;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;

@Data
public class EnterpriseGetRowsRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private int startRow;
    private int endRow;

    // row group columns
    private List<ColumnVO> rowGroupCols;

    // value columns
    private List<ColumnVO> valueCols;

    // pivot columns
    private List<ColumnVO> pivotCols;

    // true if pivot mode is one, otherwise false
    private boolean pivotMode;

    // what groups the user is viewing
    private List<String> groupKeys;

    // if filtering, what the filter model is
    private Map<String, ColumnFilter> filterModel;

    // if sorting, what the sort model is
    private List<SortModel> sortModel;

    public EnterpriseGetRowsRequest() {
        this.rowGroupCols = emptyList();
        this.valueCols = emptyList();
        this.pivotCols = emptyList();
        this.groupKeys = emptyList();
        this.filterModel = emptyMap();
        this.sortModel = emptyList();
    }
    
    public int getLimit() {
        return this.endRow - this.startRow;
    }


    public String toString() {
        return String.format("EnterpriseGetRowsRequest("
                + "startRow=%d, endRow=%d, pivotMode=%s, valueCols=%s, rowGroupCols=%s, groupKeys=%s, pivotCols=%s, "
                + "filterModel=%s, sortModel=%s)",
                startRow, endRow, pivotMode, LogUtils.listForLogging(valueCols), LogUtils.listForLogging(rowGroupCols),
                LogUtils.listForLogging(groupKeys), LogUtils.listForLogging(pivotCols),
                LogUtils.mapForLogging(filterModel, 150), LogUtils.listForLogging(sortModel));
    }
}