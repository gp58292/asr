package com.citi.aqua.derivz.model.columns.mapping;

public enum FieldDataType {

	INTEGER,DATE,STRING,DOUBLE
}
