package com.citi.aqua.derivz.web.utils;

/**
 * @name ErrorMessage
 * @description Class is used as a utility class for ErrorMessage
 *
 */
public class ErrorMessage {

	private String message;

	public ErrorMessage(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}