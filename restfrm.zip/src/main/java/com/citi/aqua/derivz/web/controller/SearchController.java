package com.citi.aqua.derivz.web.controller;

import com.citi.aqua.derivz.commons.constants.DerivzAPIUriConstants;
import com.citi.aqua.derivz.commons.exceptions.CEFTException;
import com.citi.aqua.derivz.commons.exceptions.DerivzApplicationException;
import com.citi.aqua.derivz.data.cache.eh.StaticCacheKeys;
import com.citi.aqua.derivz.dto.BookmarkResponseDTO;
import com.citi.aqua.derivz.dto.CollateralResponseDTO;
import com.citi.aqua.derivz.dto.ListedResponseDTO;
import com.citi.aqua.derivz.dto.RetrievedDataResponseDTO;
import com.citi.aqua.derivz.model.VoyagerLinkResponse;
import com.citi.aqua.derivz.model.VoyagerNavigationData;
import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;
import com.citi.aqua.derivz.services.grid.CeftDataSet;
import com.citi.aqua.derivz.services.grid.CeftDataSetStatus;
import com.citi.aqua.derivz.services.grid.LoadingStatusService;
import com.citi.aqua.derivz.services.service.BookmarkService;
import com.citi.aqua.derivz.services.service.CacheService;
import com.citi.aqua.derivz.services.service.ExportService;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.vo.SearchFieldVO;
import com.citi.aqua.derivz.web.utils.*;
import com.citi.aqua.frm.ceft.CeftDataSetType;
import com.citi.aqua.frm.framework.export.CsvExporter;
import com.citi.aqua.frm.framework.grid.exception.DataSetNotFoundException;
import com.citi.aqua.frm.framework.grid.exception.DataSetNotLoadedException;
import com.citi.aqua.frm.framework.grid.exception.FrmDataGridException;
import com.google.common.base.Stopwatch;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;

@RestController
@RequestMapping(DerivzAPIUriConstants.SEARCH_API_URI)
@Slf4j
public class SearchController {

    @Autowired
    UserSearchCriteriaService userSearchCriteriaService;

    @Autowired
    BookmarkService bookmarkService;

    @Autowired
    CacheService cacheService;
    
    @Autowired
    LoadingStatusService loadingStatusService;

    @Autowired
    ExportService exportService;

    @Autowired
    CsvExporter csvExporter;

    @Value("${ceft.export.windowSize:5000}")
    private int exportWindowSize;

    @PostMapping(value = DerivzAPIUriConstants.SEARCH_COLLATERAL_URI)
    public @ResponseBody
    DerivzRestResponse<ListedResponseDTO> searchCollateralByCriteria(
            @RequestBody final DerivzListSearchRestRequest searchSaveCriteriaRequest) {
        log.debug("SearchController::searchCollateralByCriteria() ");
        ListedResponseDTO macListingsResponseDTO = null;
        try {
            macListingsResponseDTO = userSearchCriteriaService
                    .findUserFilterSearch(searchSaveCriteriaRequest.getCriteria());
            return ResponseBuilder.build(macListingsResponseDTO, HttpStatus.SC_OK);
        } catch (DerivzApplicationException de) {
            log.error("SearchController::searchCollateralByCriteria() :: Error " + de, de);
            return ResponseBuilder.build(macListingsResponseDTO, HttpStatus.SC_NOT_FOUND, "Failed to retrieve search from list procedure", "DS119");
        }
    }

    @SuppressWarnings({"rawtypes"})
    @PostMapping(value = DerivzAPIUriConstants.SEARCH_RESULT_LISTED_COLUMNS_URI)
    public @ResponseBody
    DerivzRestResponse<List> findPredefinedColumns() {
        log.debug("SearchController::findPredefinedColumns()");
        List<SearchFieldVO> searchCriteriaVOList = null;
        try {
            searchCriteriaVOList = userSearchCriteriaService.findPredefinedResultSet();
            return ResponseBuilder.build(searchCriteriaVOList, HttpStatus.SC_OK);
        } catch (DerivzApplicationException de) {
            log.error("SearchController::findPredefinedColumns() :: Error " + de, de);
            return ResponseBuilder.build(searchCriteriaVOList, HttpStatus.SC_NOT_FOUND, "Exception Occured in findPredefinedColumns", "DS114");
        }
    }


    @PostMapping(value = DerivzAPIUriConstants.SEARCH_RESULT_EXPORT_URI)
    public @ResponseBody
    void exportToExcel(final HttpServletRequest request, final HttpServletResponse response,
                       @RequestBody final DerivzExportResultRestRequest derivzExportResultRestRequest) {
        try {
            exportService.exportToExcel(response, derivzExportResultRestRequest.getSource(),
                    derivzExportResultRestRequest.getCriteria(), derivzExportResultRestRequest.getAgreementKeys());
        } catch (DerivzApplicationException | IOException de) {
            log.error("SearchController::exportToExcel() :: Error " + de, de);
        }
    }

    @SuppressWarnings({"rawtypes"})
    @GetMapping(value = DerivzAPIUriConstants.SEARCH_COLLATERAL_TYPE_LOOKUP)
    public @ResponseBody
    DerivzRestResponse<List> getCollateralLookupColumns() {
        List<SearchFieldVO> searchCriteriaVOList = null;
        try {
            searchCriteriaVOList = userSearchCriteriaService.getCollateralLookupColumns();
            return ResponseBuilder.build(searchCriteriaVOList, HttpStatus.SC_OK);
        } catch (DerivzApplicationException de) {
            log.error("SearchController::getCollateralLookupColumns() :: Error " + de, de);
            return ResponseBuilder.build(searchCriteriaVOList, HttpStatus.SC_NOT_FOUND, "Exception Occured in getCollateralLookupColumns", "DS004");
        }
    }

    @PostMapping(value = DerivzAPIUriConstants.SEARCH_COLLATERAL_TYPE_LOOKUP)
    public @ResponseBody
    DerivzRestResponse<List<CollateralResponseDTO>> searchCollateralLookup(
            @RequestBody final DerivzListSearchRestRequest searchSaveCriteriaRequest) {
        List<CollateralResponseDTO> collateralResponseDTO = null;
        try {
            collateralResponseDTO = userSearchCriteriaService
                    .findCollateralFilterSearch(searchSaveCriteriaRequest.getCriteria());
            return ResponseBuilder.build(collateralResponseDTO, HttpStatus.SC_OK);
        } catch (DerivzApplicationException de) {
            log.error("SearchController::searchCollateralLookup() :: Error " + de, de);
            return ResponseBuilder.build(collateralResponseDTO, HttpStatus.SC_NOT_FOUND, "Failed to retrieve search from list procedure", "DS111");
        }
    }

    @SuppressWarnings({"rawtypes"})
    @PostMapping(value = DerivzAPIUriConstants.GET_DATASET_ID_FOR_VOYAGER_LINK)
    public @ResponseBody
    DerivzRestResponse searchDatasetIdLookup(final HttpServletRequest request,
                                             @RequestBody final DatasetIdGetRequest searchGetDatasetRequest) {
        VoyagerLinkResponse voyagerLinkResponse = new VoyagerLinkResponse("", 0, "", -1);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String userId = authentication.getName();
        try {
            voyagerLinkResponse = bookmarkService.getDatasetId(userId, searchGetDatasetRequest.getDatasetTypeName());
            return ResponseBuilder.build(voyagerLinkResponse, HttpStatus.SC_OK);
        } catch (DerivzApplicationException de) {
            log.error("SearchController::searchDatasetIdLookup() :: Error " + de, de);
            return ResponseBuilder.build(voyagerLinkResponse, HttpStatus.SC_NOT_FOUND, "Failed to get datasetId for dataset type.", "DS110");
        }
    }

    @GetMapping(value = DerivzAPIUriConstants.GET_USER_DATASET_FOR_VOYAGER_LINK)
    public @ResponseBody
    DerivzRestResponse<List<VoyagerNavigationData>> getUserDatasetIds(final HttpServletRequest request, @PathVariable("bookmarkId") final Integer bookmarkID) {
        log.debug("SearchController::getUserDatasetIds()");
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String userId = authentication.getName();
        Objects.requireNonNull(bookmarkID);
        String bookmarkId = String.valueOf(bookmarkID);
        try {
            List<VoyagerNavigationData> response = userSearchCriteriaService.loadUserDatasetIds(userId, bookmarkId);
            return ResponseBuilder.build(response, HttpStatus.SC_OK);
        } catch (DerivzApplicationException de) {
            log.error("SearchController::getUserDatasetIds() :: Error " + de, de);
            return ResponseBuilder.build(null, HttpStatus.SC_NOT_FOUND, "Failed to get dataset for user.", "DS009");
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @PostMapping(value = DerivzAPIUriConstants.LOAD_TABS_DATA_URI)
    @Deprecated
    public @ResponseBody
    DerivzRestResponse<RetrievedDataResponseDTO> loadTabsData(
            @RequestBody final DerivzNonListSearchRestRequest searchSaveCriteriaRequest) {
        RetrievedDataResponseDTO tabDataList = null;
        try {
            tabDataList = userSearchCriteriaService.loadTabsData(
                    searchSaveCriteriaRequest.getTabName(),
                    searchSaveCriteriaRequest.getAgreementKeys(),
                    searchSaveCriteriaRequest.getAgreementOptimalRanks(),
                    searchSaveCriteriaRequest.getIsFilterd(),
                    searchSaveCriteriaRequest.getCriteria(),
                    searchSaveCriteriaRequest.getSmsColumns());

            return ResponseBuilder.build(tabDataList, HttpStatus.SC_OK);
        } catch (CEFTException de) {
            log.error("SearchController::loadingData() :: Error " + de, de);
            return ResponseBuilder.build(tabDataList, HttpStatus.SC_NOT_FOUND, "Exception Occured while loading " + searchSaveCriteriaRequest.getTabName() + " data", "DS024");
        }
    }
    
    
    @PostMapping(value = DerivzAPIUriConstants.REQUEST_DATASET_URI)
    public @ResponseBody
    DerivzRestResponse<DerivzSearchDataRestResponse> requestDataset(
            @RequestBody final CEFTBookmarkPlusSearchRequest bookmarkPlusSearchRequest) throws CEFTException {
        Stopwatch stopwatch = Stopwatch.createStarted();
        DerivzSearchDataRestResponse response = new DerivzSearchDataRestResponse();
        BookmarkResponseDTO bookmarkWithStatus= new BookmarkResponseDTO();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String userId = authentication.getName();
        try {
            if(bookmarkPlusSearchRequest.getBookmarkRequest().getBookmarkData() !=null) {
                bookmarkWithStatus = bookmarkService.saveOrUpdateBookmark(userId,
                        bookmarkPlusSearchRequest.getBookmarkRequest().getBookmarkId(),
                        bookmarkPlusSearchRequest.getBookmarkRequest().getBookmarkData(),
                        bookmarkPlusSearchRequest.getSearchRequest().getSearchCriteria(),
                        bookmarkPlusSearchRequest.getBookmarkRequest().getParentBookmarkId());
            }
        }catch (DerivzApplicationException ce) {
			log.error("SearchController::requestDataset() :: Error " + ce, ce);
            return ResponseBuilder.build(response, HttpStatus.SC_NOT_FOUND, "Exception Occured while retrieving Bookmark data", "DS024",ce.getMessage());
		}catch (CEFTException e) {
			log.error("SearchController::requestDataset() :: Error " + e, e);
            return ResponseBuilder.build(response, HttpStatus.SC_NOT_FOUND, e.getMessage(), "DS024");
		}
        CeftDataSet set = new CeftDataSet(userId, bookmarkWithStatus.getBookmark().getKey(), CeftDataSetType.findByCode(bookmarkPlusSearchRequest.getSearchRequest().getDatasetType()));
		log.info("Requesting data set {}", set);
		try {
            CeftDataSetStatus dataSetStatus = loadingStatusService.requestDataSet(set, bookmarkPlusSearchRequest.getAtmosphereResourceUuid());
            response.setDataSetStatus(dataSetStatus);
            response.setBookmarkWithStatus(bookmarkWithStatus);
            log.info("SearchController::requestDataset() Completed request. User: {}; Bookmark: {}; Tab: {};"
                            + " Execution time: {}; Result data set status: {}",
                    userId, bookmarkPlusSearchRequest.getBookmarkRequest().getBookmarkId(),
                    bookmarkPlusSearchRequest.getSearchRequest().getDatasetType(), stopwatch.elapsed(),
                    response.getDataSetStatus());
            return ResponseBuilder.build(response, HttpStatus.SC_OK);
		}catch (FrmDataGridException fdge) {
			log.error("SearchController::requestDataset() :: Error " + fdge, fdge);
            return ResponseBuilder.build(response, HttpStatus.SC_NOT_FOUND, "Exception Occured while requesting from Grid " + set.getType().getDisplayName() + " data", "DS024",fdge.getMessage());
		}
		
    }


	@PostMapping(value = DerivzAPIUriConstants.RETRIEVE_DATASET_URI)
    public @ResponseBody
    DerivzRestResponse<RetrievedDataResponseDTO> searchDatasetResults(
            @RequestBody final CEFTDataSetRequest ceftDataSetRequest) {
        Stopwatch stopwatch = Stopwatch.createStarted();
        RetrievedDataResponseDTO response = new RetrievedDataResponseDTO();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String userId = authentication.getName();
        try {
        	response = userSearchCriteriaService.searchDatasetResults(ceftDataSetRequest.getType(), userId, 
        			ceftDataSetRequest.getBookmarkId(), ceftDataSetRequest.getGridRequest(),ceftDataSetRequest.getAgreementKeys());
            log.info("SearchController::searchDatasetResults Completed request. User: {}; Bookmark: {}; Tab: {};"
                            + " Execution time: {}; Result rows: {}", userId, ceftDataSetRequest.getBookmarkId(),
                    ceftDataSetRequest.getType(), stopwatch.elapsed(), response.getListOfRecords().size());
            return ResponseBuilder.build(response, HttpStatus.SC_OK);
        } catch (CEFTException de) {
            log.error("SearchController::searchDatasetResults() :: Error ", de);
            return ResponseBuilder.build(response, HttpStatus.SC_NOT_FOUND,
                    "Exception Occurred while loading " + ceftDataSetRequest.getType() + " data", "DS024",de.getMessage());
        }catch (DataSetNotLoadedException | DataSetNotFoundException dle) {
            log.error("SearchController::searchDatasetResults() :: Error " + dle, dle);
            return ResponseBuilder.build(response, HttpStatus.SC_NOT_FOUND,
            		dle.getMessage() +" for " + ceftDataSetRequest.getType(), "DS024",dle.getMessage());
        }catch (FrmDataGridException ce) {
            log.error("SearchController::searchDatasetResults() :: Error " + ce, ce);
            return ResponseBuilder.build(response, HttpStatus.SC_NOT_FOUND,
                    "Exception Occured while retriving from Grid ", "DS024",ce.getMessage());
        }
    }

    @PostMapping(path = DerivzAPIUriConstants.SEARCH_RESULT_EXPORT_CSV_URI + "/{fileName}", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    ResponseEntity<Flux<String>> exportToCsv(@RequestBody final CEFTDataSetRequest ceftDataSetRequest,
                                             @PathVariable String fileName) {

        log.debug("SearchController::exportToCsv() :: ceftDataSetRequest " + ceftDataSetRequest);

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String userId = authentication.getName();

        CEFTRequestIterator ceftRequestIterator = CEFTRequestIterator.getCETRequestIterator(ceftDataSetRequest, userId,
                userSearchCriteriaService);
        ceftRequestIterator.setWindowSize(exportWindowSize);

        Map<String, Object> firstRow = ceftRequestIterator.peakFirstCurrent();
        Supplier<Iterator<Map<String, Object>>> resultIterator = () -> ceftRequestIterator;

        List<SearchResultColumns> staticResultColumns = null;
        staticResultColumns = cacheService.getAllSearchResultColumns(StaticCacheKeys.RESULT_COLUMNS);

        if (firstRow != null && staticResultColumns != null) {
            List<ExportColumnDescription> columnDescriptions = ExportColumnDescription.MakeExportColumnDescriptions(staticResultColumns, ceftDataSetRequest.getType());

            Flux<String> csvStream = csvExporter.streamCsv(resultIterator, columnDescriptions)
                    .subscribeOn(Schedulers.elastic());

            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
                    .body(csvStream);
        } else {
            return ResponseEntity.noContent().build();
        }
    }

}
