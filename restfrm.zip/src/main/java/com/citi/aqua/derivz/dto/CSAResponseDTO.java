package com.citi.aqua.derivz.dto;

import java.util.Date;
import java.util.Set;

import com.citi.aqua.derivz.vo.CollateralCashDetailsVO;
import com.citi.aqua.derivz.vo.CollateralHaircutDetailsVO;
import com.citi.aqua.derivz.vo.ProductDetailsVO;
import com.citi.aqua.derivz.vo.ThresholdDetailsVO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
@Getter
@Setter
@ToString
public class CSAResponseDTO {
	
	private String csaDescription;
	private Date marginEffectiveDate ;
	private String partyPseMarginReduction;
	private String netting ;
	private String csaStatus ;
	private Date securityAgreementDate ;
	private String custodianRequired;
	private String pledgor ;
	private String currency;
	private String callFrequency;
	private String thirdPartyCustFlag; 
	
	private String partyName;
	private String partyGfcid;
	private Set<ThresholdDetailsVO> partyThresholdList;
	private Set<ThresholdDetailsVO> partyCreditThresholdList;
	private Set<ThresholdDetailsVO> partyPublicRatingList;
	private Set<ThresholdDetailsVO>partyScheduledThreshold;
	private String collateralReuse ;
	
	private String consentToSubstitution;
	private String partyCustodianRequired;
	private String cpCustodianRequired;
	private String cpName;
	private String cpGfcid;
	private Set<ThresholdDetailsVO> cpThresholdList;
	private Set<ThresholdDetailsVO> cpCreditThresholdList;
	private Set<ThresholdDetailsVO> cpPublicRatingList;
	private Set<ThresholdDetailsVO>cpScheduledThreshold;
	private String cpCollateralReuse;
	private String cpConsentToSubstitutionRequired;
	private Set<ProductDetailsVO> coveredProducts;
	private Set<CollateralCashDetailsVO> acceptableCollateralCashList;
	private Set<CollateralHaircutDetailsVO> collateralHaircutScheduleList;
	
}