package com.citi.aqua.derivz.data.repository;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import com.citi.aqua.derivz.model.CEFTUser;
import com.citi.aqua.derivz.model.DerivzDBConstants;

public interface UserRepository extends CrudRepository<CEFTUser, Long> {

	@Query(value = "SELECT friendly_name FROM " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER
			+ " t where t.soeid = :soeid", nativeQuery = true)
	public String findFriendlyNameBySoeid(@Param("soeid") final String soeid);

	@Query(value = "SELECT group_name FROM " + DerivzDBConstants.SCHEMA_CEFT + "." + DerivzDBConstants.TBL_USER
			+ " t where t.soeid = :soeid", nativeQuery = true)
	public String findGroupNameBySoeid(@Param("soeid") final String soeid);

}
