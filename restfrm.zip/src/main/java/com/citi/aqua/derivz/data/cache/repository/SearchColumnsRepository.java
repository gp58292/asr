package com.citi.aqua.derivz.data.cache.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.citi.aqua.derivz.model.columns.mapping.SearchResultColumns;

@Repository
public interface SearchColumnsRepository extends CrudRepository<SearchResultColumns, Long> {

	// This method is used to load all data
	@Transactional(readOnly=true)
	public List<SearchResultColumns> findAllByOrderByTabOrderAscFieldOrderAsc();
	
	//@Transactional(readOnly=true)
    //public List<SearchResultColumns> findByIsEnabledByOrderByTabOrderAscFieldOrderAsc(boolean isEnabled);
	
	@Transactional(readOnly=true)
    public List<SearchResultColumns> findByIsEnabledTrueOrderByTabOrderAscFieldOrderAsc();
		
	// Pull all columns for specific tab
	@Transactional(readOnly=true)
	public List<SearchResultColumns> findByTabName(final Long tabName);

}
