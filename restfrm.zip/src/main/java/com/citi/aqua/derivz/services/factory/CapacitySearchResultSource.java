package com.citi.aqua.derivz.services.factory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.citi.aqua.derivz.services.service.UserSearchCriteriaService;
import com.citi.aqua.derivz.vo.CapacityDataVO;
import com.citi.aqua.derivz.vo.SearchFieldVO;

@Component
public class CapacitySearchResultSource extends SearchResultSource {

	@Autowired
	UserSearchCriteriaService userSearchCriteriaService;

	@Override
	public List<String> getHeaders() {
		return Arrays.asList("Agreement Id", "CSA Description", "Collateral Type ", "MTM", "Max Capacity",
				"Current Posting", "Incremental Capacity", "Max Exposure", "Current Collateral Received",
				"Incremental Exposure");
	}

	@Override
	public int addDataRow(HSSFWorkbook workbook, String sheetName, List<SearchFieldVO> searchCriteria, List<Long> agreementKeyList, int rowNum) {
		Sheet sheet = workbook.getSheet(sheetName);
		DataFormat dataFormat=workbook.createDataFormat();

		int tmpRowNum = rowNum;

		CellStyle cellStyle = workbook.createCellStyle();
		HSSFFont font = workbook.createFont();
		font.setFontName("Calibri");
		font.setFontHeight((short) 220);
		cellStyle.setFont(font);
		sheet.createFreezePane(0, 1);

		List<CapacityDataVO> capacityDataVOList =  new ArrayList(); 
				//userSearchCriteriaService.loadCapacityData(agreementKeyList);
		for (CapacityDataVO data : capacityDataVOList) {
			int index = -1;
			Row row = sheet.createRow(tmpRowNum++);
			addXLSXCell(row, ++index, Integer.toString(data.getAgreementId()), cellStyle);
			addXLSXCell(row, ++index, data.getCsaDescription(), cellStyle);
			addXLSXCell(row, ++index, data.getCollateralType(), cellStyle);
			addXLSXCellNumeric(row, ++index, data.getMtm(), cellStyle,dataFormat);
			addXLSXCellNumeric(row, ++index, data.getMaxCapacity(), cellStyle,dataFormat);
			addXLSXCellNumeric(row, ++index, data.getCurrentPosting(), cellStyle,dataFormat);
			addXLSXCellNumeric(row, ++index, data.getIncrementalCapacity(), cellStyle,dataFormat);
			addXLSXCellNumeric(row, ++index, data.getMaxExposure(), cellStyle,dataFormat);
			addXLSXCellNumeric(row, ++index, data.getCurrentCollateralReceived(), cellStyle,dataFormat);
			addXLSXCellNumeric(row, ++index, data.getIncrementalExposure(), cellStyle,dataFormat);
		}
		return tmpRowNum;
	}
}
