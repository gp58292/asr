package com.citi.aqua.derivz.config;

import com.citi.aqua.frm.framework.web.security.MethodSecurityConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationEventPublisher;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerEndpointsConfiguration;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.endpoint.FrameworkEndpointHandlerMapping;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.security.web.util.matcher.RequestMatcher;

import javax.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.List;

@Configuration
@EnableOAuth2Sso
@Import({MethodSecurityConfig.class})
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired(required = false)
    private AuthenticationEventPublisher eventPublisher;

    private List<ResourceServerConfigurer> configurers = Collections.emptyList();

    @Autowired(required = false)
    private AuthorizationServerEndpointsConfiguration endpoints;

    @Override
    public void configure(HttpSecurity http) throws Exception {
        http.headers().frameOptions().disable()
                .and().csrf().disable()
                .authorizeRequests()
                .antMatchers("/login**")
                .permitAll()
                .antMatchers("/api/utils/environmentDetails")
                .permitAll()
                .antMatchers("/assets/**")
                .permitAll()
                .antMatchers("/adm/**") //there is separate authorisation for these methods
                .permitAll()
                .antMatchers("/api/cyberarc/getPasswordUsingNickname")
                .permitAll()
                .antMatchers("/api/cyberarc/getPasswordUsingNickname/**")
                .permitAll()
                .antMatchers("/*")
                .hasAnyAuthority("ROLE_CEFT-VIEW", "ROLE_Main_Application")
                .anyRequest()
                .authenticated()
                .and()
                .exceptionHandling().accessDeniedPage("/access-denied.html");

        ResourceServerSecurityConfigurer resources = new ResourceServerSecurityConfigurer().stateless(false);
        ResourceServerTokenServices services = tokenServices();
        if (services != null) {
            resources.tokenServices(services);
        } else {
            if (tokenStore() != null) {
                resources.tokenStore(tokenStore());
            } else if (endpoints != null) {
                resources.tokenStore(endpoints.getEndpointsConfigurer().getTokenStore());
            }
        }
        if (eventPublisher != null) {
            resources.eventPublisher(eventPublisher);
        }
        for (ResourceServerConfigurer configurer : configurers) {
            configurer.configure(resources);
        }
//
//        // @formatter:on
        http.apply(resources);
        if (endpoints != null) {
            // Assume we are in an Authorization Server
            http.requestMatcher(new WebSecurityConfig.NotOAuthRequestMatcher(endpoints.oauth2EndpointHandlerMapping()));
        }
        for (ResourceServerConfigurer configurer : configurers) {
            configurer.configure(http);
        }
    }


    @Bean
    @Primary
    public TokenStore tokenStore() {
        return new JwtTokenStore(accessTokenConverter());
    }

    @Bean
    @Primary
    public JwtAccessTokenConverter accessTokenConverter() {
        final JwtAccessTokenConverter converter = new JwtAccessTokenConverter();
        converter.setSigningKey("AQUA_GROUP");
        return converter;
    }

    @Bean
    @Primary
    public DefaultTokenServices tokenServices() {
        final DefaultTokenServices defaultTokenServices = new DefaultTokenServices();
        defaultTokenServices.setTokenStore(tokenStore());
        return defaultTokenServices;
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring()
                .antMatchers(
                        "/swagger-resources/configuration/ui",
                        "/swagger-resources/configuration/security",
                        "/swagger-ui.html",
                        "/swagger-resources",
                        "/webjars/**"
                )
                // OPTIONS
                .and()
                .ignoring()
                .antMatchers(HttpMethod.OPTIONS, "/**")
                // RESOURCES
                .and()
                .ignoring()
                .antMatchers(HttpMethod.GET, "/*.html", "/favicon.ico", "/**/*.html", "/**/*.css", "/**/*.js",
                        "/**/*.js.map", "/**/*.png", "/**/*.jpg", "/**/*.woff", "/**/*.ttf", "/**/*.woff2",
                        "/data/**/*.json", "/data/**/*.csv", "/assets/**")
                // REST API
                .and()
                .ignoring()
                .antMatchers("/websocket/**");

    }


    /**
     * @param configurers the configurers to set
     */
    @Autowired(required = false)
    public void setConfigurers(List<ResourceServerConfigurer> configurers) {
        this.configurers = configurers;
    }

    private static class NotOAuthRequestMatcher implements RequestMatcher {

        private FrameworkEndpointHandlerMapping mapping;

        public NotOAuthRequestMatcher(FrameworkEndpointHandlerMapping mapping) {
            this.mapping = mapping;
        }

        @Override
        public boolean matches(HttpServletRequest request) {
            String requestPath = getRequestPath(request);
            for (String path : mapping.getPaths()) {
                if (requestPath.startsWith(mapping.getPath(path))) {
                    return false;
                }
            }
            return true;
        }

        private String getRequestPath(HttpServletRequest request) {
            String url = request.getServletPath();

            if (request.getPathInfo() != null) {
                url += request.getPathInfo();
            }

            return url;
        }
    }

}
