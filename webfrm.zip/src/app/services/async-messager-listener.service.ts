import { Injectable } from '@angular/core';
import { CeftDataSetStatus } from '@aqua/models';
import { BehaviorSubject } from 'rxjs';
import { filter } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class AsyncMessagerListner {
  public get currentSocketListner$() {
    return this._currentSocketListner$.asObservable();
  }

  private _currentSocketListner$ = new BehaviorSubject<any>(undefined);

  constructor() {
    this.listenMessagesAndIfReadyClearAfterSomeTime();
  }

  public setMessage(data: any) {
    this._currentSocketListner$.next(data);
  }

  private listenMessagesAndIfReadyClearAfterSomeTime(): void {
    // This will reset currentSocketlistener as once we receive ready, we need to clear last values
    this._currentSocketListner$.pipe(filter((data: any) => !!data && data.ready)).subscribe((data: CeftDataSetStatus) => {
      setTimeout(() => this._currentSocketListner$.next(undefined), 1000);
    });
  }
}
