import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class CacheService {
  private _dropDownCache: Map<number | string, any> = new Map<number | string, any>();

  public put(key: number | string, data: any) {
    this._dropDownCache.set(key, data);
  }

  public get(key: number | string): any {
    return this._dropDownCache.get(key);
  }
  public clearCache(): void {
    this._dropDownCache.clear();
  }
}
