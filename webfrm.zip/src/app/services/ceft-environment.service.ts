import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CeftEnvironmentDetails } from '@aqua/models';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, shareReplay, tap } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
/**
 * Simple service to fetch environment details.
 */
export class CeftEnvironmentService {
  private readonly envDetails$: Observable<CeftEnvironmentDetails>;
  private envDetailsStored$: BehaviorSubject<CeftEnvironmentDetails> = new BehaviorSubject<CeftEnvironmentDetails>(null);

  get envDetailsValue() {
    return this.envDetailsStored$.value;
  }
  constructor(private httpClient: HttpClient) {
    this.envDetails$ = this.fetchEnvDetails().pipe(
      map((response: CeftEnvironmentDetails) => response),
      tap(envDetails => this.envDetailsStored$.next(envDetails)),
      shareReplay()
    );
    this.envDetails$.subscribe();
  }

  public fetchEnvDetails() {
    return this.httpClient.get('/api/utils/ceftEnvironmentDetails');
  }

  public subscribeEnvDetails() {
    return this.envDetails$;
  }
}
