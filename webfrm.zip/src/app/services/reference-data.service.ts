import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { cloneDeep } from 'lodash';
import { Observable, of } from 'rxjs';
import { publishReplay, refCount, share, tap } from 'rxjs/operators';

import { AppUrlsConfig } from './app-urls.config';
import { CacheService } from './cache.service';

@Injectable({ providedIn: 'root' })
export class ReferenceDataService {
  private refDataCallCount: number = 0;

  constructor(private http: HttpClient, private urlConfig: AppUrlsConfig, private cacheService: CacheService) {
    console.debug('SearchService::constructor:: Loading Search Service ..................................');
  }

  public getReferenceData(fieldKey: number): Observable<any> {
    const requestUrl: string = this.urlConfig.EP_GET_REFERENCE_DATA + fieldKey;
    console.debug('ReferenceDataService::getReferenceData' + requestUrl);
    const dropDownData: any = this.cacheService.get(fieldKey);
    if (dropDownData) {
      return of(cloneDeep(dropDownData));
    } else {
      console.debug('ReferenceDataService::getReferenceData ' + this.refDataCallCount++);
      return this.http.get(requestUrl).pipe(
        publishReplay(1),
        refCount(),
        share(),
        tap((data: any) => this.cacheService.put(fieldKey, cloneDeep(data)))
      );
    }
  }

  public getTypeAheadData(fieldKey: number, valueLike: string): Observable<any> {
    const requestUrl: string = this.urlConfig.EP_GET_TYPEAHEAD_DATA + fieldKey + '/' + valueLike;
    console.debug('ReferenceDataService::getTypeAheadData' + requestUrl);
    if (valueLike) {
      return this.http.get(requestUrl).pipe(
        publishReplay(1),
        refCount()
      );
    }
    return of([]);
  }

  public getTypeAheadDataByPastedValue(fieldKey: number, valueLike: string[]): Observable<any> {
    const requestUrl: string = this.urlConfig.EP_GET_TYPEAHEAD_DATA_BY_PASTED_VALUES + fieldKey;
    console.debug('ReferenceDataService::getTypeAheadDataByPastedValue::' + requestUrl);
    if (valueLike && valueLike.length > 0) {
      return this.http.post(requestUrl, valueLike);
    }
  }
}
