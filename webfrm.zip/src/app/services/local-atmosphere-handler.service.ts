import { Injectable, OnDestroy } from '@angular/core';
import { CeftDataSetStatus } from '@aqua/models';
import { VizNotificationService } from '@service/viz-notification.service';
import * as Atmosphere from 'atmosphere.js';
import { Observable, Subject } from 'rxjs';
import { tap } from 'rxjs/operators';

import { AsyncMessagerListner } from './async-messager-listener.service';

// @todo: Socket infrastructure are similar for all endpoints. Providable service wrapper will be moved under FRM Commons package.
@Injectable()
export class LocalAtmosphereHandlerService implements OnDestroy {
  public static generateGuid() {
    let result: string;
    let i: string;
    let j: number = 0;

    result = '';
    for (j = 0; j < 32; j++) {
      if (j === 8 || j === 12 || j === 16 || j === 20) {
        result = result + '4';
      }
      i = Math.floor(Math.random() * 16)
        .toString(16)
        .toUpperCase();
      result = result + i;
    }
    return result;
  }
  private subSocket: any;
  private request = new Atmosphere.AtmosphereRequest();
  private messageObserver = new Subject<any>();
  private requestMap = new Map();
  private currentRequestSubject = new Subject<string>();

  /**
   * ID of the socket connection.
   */
  private connectionUuid: string;

  constructor(private userNotification: VizNotificationService, private asyncMessagerListner: AsyncMessagerListner) {
    console.debug('DataServiceRequestsStatusService::constructor');
    this.configure();
    this.connect();
  }

  public ngOnDestroy() {
    console.debug('DataServiceRequestsStatusService::ngOnDestroy');
    this.subSocket.close();
  }

  public getConnectionUuid() {
    return encodeURIComponent(this.connectionUuid);
  }

  public reset() {
    this.subSocket.close();
    this.connect();
  }

  public registerDataRequest(uuid: string) {
    const removeRequestFunction = this.removeRequest.bind(this);
    const observableLocal = this.messageObserver;
    const observable = new Observable(observer => {
      observableLocal.asObservable().subscribe(
        (data: CeftDataSetStatus) => {
          console.debug('AtmosphereRequestsService::::WebSocket::observableLocal::', data);
          if (data.webSocketUuid === uuid) {
            observer.next(data);
            // observer.complete();
            // removeRequestFunction();
          }
        },
        error => {
          console.error('AtmosphereRequestsService::::WebSocket::Error occurred during wait for dataset request readiness', error);
          observer.complete();
          removeRequestFunction();
        }
      );
    }).pipe(tap((data: any) => this.asyncMessagerListner.setMessage(data)));
    this.requestMap.set(uuid, observable);
    this.currentRequestSubject.next(uuid);
    return observable;
  }

  public getCurrentRequest(): Observable<any> {
    return this.currentRequestSubject.asObservable();
  }

  public getMessageObservable(uuid) {
    return this.requestMap.get(uuid);
  }

  public stopMessageObservable(uuid) {
    const removeRequestFunction = this.removeRequest.bind(this);
    const observable = this.requestMap.get(uuid);
    removeRequestFunction();
  }

  public removeRequest(uuid) {
    this.requestMap.delete(uuid);
  }

  public removeAllRequest() {
    this.requestMap.forEach((observable: any, uuid: string) => {
      this.stopMessageObservable(uuid);
      this.removeRequest(uuid);
    });
  }

  private connect() {
    try {
      this.subSocket = Atmosphere.subscribe(this.request);
    } catch (e) {
      this.userNotification.showError(
        'Unable to initialize application properly. Please try again later. If problem persists please contact SL3 support.'
      );
      console.error('Unable to subscribe to Websocket Data Service', e);
    }
  }

  private configure() {
    console.debug('DataServiceRequestsStatusService::configure');
    this.request.url = '/websocket/dataservice';
    this.request.contentType = 'application/json';
    this.request.transport = 'websocket';
    this.request.timeout = 60000;
    this.request.maxReconnectOnClose = 7;
    this.request.onOpen = this.onRequestOpen;
    this.request.onMessage = this.onRequestMessage;
    this.request.onReconnect = this.onReConnect;
    this.request.onReopen = this.onReOpen;
    this.request.onClose = this.onRequestClose;
    this.request.onError = this.onRequestError;
    this.request.onClientTimeout = this.onClientTimeout;
    this.request.onTransportFailure = this.onFailureToReconnect;
    this.request.onFailureToReconnect = this.onFailureToReconnect;
    this.request.onMessagePublished = this.onMessagePublished;
  }

  private onRequestMessage = resp => {
    console.debug('DataServiceRequestsStatusService::onRequestMessage', resp);
    try {
      if (resp && resp.responseBody) {
        this.messageObserver.next(JSON.parse(resp.responseBody));
      }
    } catch (error) {
      console.warn('unable to parse websocket message from server', error);
    }
  };

  private onReConnect = (request, resp) => {
    console.debug('DataServiceRequestsStatusService::onReconnect', request, resp);
    this.connectionUuid = resp && resp.request ? resp.request.uuid : undefined;
    this.userNotification.showWarning('Trying to reconnect...');
  };

  private onReOpen = (request, resp) => {
    console.debug('DataServiceRequestsStatusService::onReOpen', request, resp);
    this.connectionUuid = resp.request.uuid;
  };

  private onRequestOpen = resp => {
    console.debug('DataServiceRequestsStatusService::onRequestOpen', resp);
    this.connectionUuid = resp.request.uuid;
  };

  private onRequestClose = resp => {
    console.debug('DataServiceRequestsStatusService::onRequestClose', resp);
    this.connectionUuid = null;
  };

  private onRequestError = resp => {
    console.error('Unable to subscribe to Websocket Data Service', resp);
    this.userNotification.showError(
      'Unable to initialize application properly. Please try again later. If problem persists please contact SL3 support.'
    );
  };

  private onMessagePublished = resp => {
    console.debug('DataServiceRequestsStatusService::onMessagePublished', resp);
  };

  private onClientTimeout = request => {
    console.error('DataServiceRequestsStatusService::onFailureToReconnect', request);
    this.userNotification.showError('Session has expired. If problem persists please contact SL3 support.', 'Dismiss', 10000);
  };

  private onFailureToReconnect = (request, resp) => {
    console.error('DataServiceRequestsStatusService::onFailureToReconnect', request, resp);
    this.userNotification.showError('Session has expired. If problem persists please contact SL3 support.', 'Dismiss', 10000);
  };
}
