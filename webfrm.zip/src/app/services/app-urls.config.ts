import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AppUrlsConfig {
  // Base settings
  public API: string = '/api';

  // Controller End Points

  public EP_REFERENCE: string = '/reference';
  public EP_CACHE: string = '/cache';
  public EP_COLLATERAL_TYPE_LOOKUP: string = '/collateral-type-lookup';

  // ReferenceDataController
  public EP_GET_REFERENCE_DATA: string = this.API + this.EP_REFERENCE + '/dropdown/';
  public EP_GET_TYPEAHEAD_DATA: string = this.API + this.EP_REFERENCE + '/typeahead/';
  public EP_GET_TYPEAHEAD_DATA_BY_PASTED_VALUES: string = this.API + this.EP_REFERENCE + '/typeahead/pasted/';
  public EP_GET_COB_DATE: string = this.API + this.EP_REFERENCE + '/getCobDate';
}
