import { Injectable } from "@angular/core";

@Injectable()
export class UrlConfig {
	// Base settings
	public API: string = "/api";

	// Controller End Points for Admin
	public EMPC_LOGIN: string = "/lg";
	public EMPC_SSO: string = "/sso";

	// Direct end point
	public EP_CITI_SEARCH_PEOPLE_BY_SOEID: string =
		"http://search.citi.net/api/search/people?q.fields=soeid";
	public EP_CITI_REMOTE_USER_PIC: string =
		"http://globaldirectory.citigroup.net/ExzWR3359/{#geid}.jpg";

	// Get Envoirements
	public EP_GET_ENVOIREMENT: string = this.API + "/getEnviromentDetails";
	public EP_ERRORS_TO_BACKEND: string = this.API + "/logClientErrors";

	// Reference data service
	public EP_LOGIN_GETUSER: string = this.API + this.EMPC_LOGIN + "/getUser";

	// SSO service
	public EP_SSO_AUTHENTICATE: string =
		this.API + this.EMPC_SSO + "/authenticate";
	public EP_SSO_CHANGE_PASSWORD: string =
		this.API + this.EMPC_SSO + "/changePassword";
	public EP_SSO_LOGOUT: string = this.API + this.EMPC_SSO + "/logout";

	public EP_SSO_GET_TOKEN: string = this.API + this.EMPC_SSO + "/getUserToken";
	public EP_SSO_VALIDATE_TOKEN: string =
		this.API + this.EMPC_SSO + "/validateUserToken";
}
