import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { filter, shareReplay } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class ComponentInstanceService {
  private _component$: BehaviorSubject<any> = new BehaviorSubject<any>(undefined);

  public getComponent() {
    return this._component$.value;
  }
  public get component$() {
    return this._component$.pipe(
      filter(data => !!data),
      shareReplay(1)
    );
  }
  public set component(component: any) {
    this._component$.next(component);
  }
}
