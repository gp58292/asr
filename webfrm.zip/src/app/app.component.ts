import { Component } from "@angular/core";
import { FRMAuth } from '@citi-icg-163206/frm-framework-npm-commons';
import { BehaviorSubject } from 'rxjs';

@Component({
	selector: "ceft-root",
	templateUrl: "./app.component.html",
	styleUrls: ["./app.component.scss"]
})
@FRMAuth()
export class AppComponent {
  public isAuth$: BehaviorSubject<boolean>;
}
