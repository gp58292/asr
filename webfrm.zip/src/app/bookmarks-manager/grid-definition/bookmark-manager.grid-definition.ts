import { DeleteRenderer, UsedInChartRenderer } from '@aqua/aqua-component/aqua-grid/inline-cell-renderer';
import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { SearchResultColumns, GridColumnsDefBuilder } from '@aqua/filters/models';

export const BOOKMARK_MANAGER_GRID_DEFINATION: SearchResultColumns[] = [
  new GridColumnsDefBuilder('ID', 'key')
    .isHyperLink(true)
    .width(10)
    .build(),
  new GridColumnsDefBuilder('Bookmark Name', 'name')
    .isHyperLink(true)
    .width(30)
    .build(),
  new GridColumnsDefBuilder('Description', 'type').width(20).build(),
  new GridColumnsDefBuilder('Created/Last Updated On', 'updatedTime')
    .fieldType(FieldType.DATE)
    .width(30)
    .build(),
  new GridColumnsDefBuilder('Last Accessed On', 'lastAccessTime')
    .fieldType(FieldType.DATE)
    .width(30)
    .build(),
  new GridColumnsDefBuilder('Used in Charts', 'chartFlag')
    .rendererFramework(UsedInChartRenderer)
    .width(5)
    .build(),
  new GridColumnsDefBuilder('Delete', '')
    .rendererFramework(DeleteRenderer)
    .width(5)
    .build()
];
