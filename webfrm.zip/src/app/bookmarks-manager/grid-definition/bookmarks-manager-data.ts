export class BookmarksManagerData {
  public data: any[] = [
    {
      displayName: 'ID',
      fieldName: 'key',
      fieldOrder: 1,
      fieldType: 'INTEGER',
      isDefaultDisplay: true,
      isEnabled: true,
      isSearchable: false,
      key: 1
    },
    {
      displayName: 'Bookmark Name',
      fieldName: 'name',
      fieldOrder: 2,
      fieldType: 'STRING',
      isDefaultDisplay: true,
      isEnabled: true,
      isSearchable: false,
      key: 1
    },
    {
      displayName: 'Description',
      fieldName: 'description',
      fieldOrder: 3,
      fieldType: 'STRING',
      isDefaultDisplay: true,
      isEnabled: true,
      isSearchable: false,
      key: 1
    },
    {
      displayName: 'Creted/Last Updated On',
      fieldName: 'updatedTime',
      fieldOrder: 4,
      fieldType: 'DATE',
      isDefaultDisplay: true,
      isEnabled: true,
      isSearchable: false,
      key: 1
    },
    {
      displayName: 'Last Accessed On',
      fieldName: 'lastAccessTime',
      fieldOrder: 4,
      fieldType: 'DATE',
      isDefaultDisplay: true,
      isEnabled: true,
      isSearchable: false,
      key: 1
    },
    {
      displayName: 'Change History',
      fieldName: 'name',
      fieldOrder: 5,
      fieldType: 'INTEGER',
      isDefaultDisplay: true,
      isEnabled: true,
      isSearchable: false,
      key: 1
    },
    {
      displayName: 'Used in Charts',
      fieldName: 'chartFlag',
      fieldOrder: 6,
      fieldType: 'INTEGER',
      isDefaultDisplay: true,
      isEnabled: true,
      isSearchable: false,
      key: 1
    },
    {
      displayName: 'Delete',
      fieldName: 'delete',
      fieldOrder: 7,
      fieldType: 'INTEGER',
      isDefaultDisplay: true,
      isEnabled: true,
      isSearchable: false,
      key: 1
    }
  ];
}
