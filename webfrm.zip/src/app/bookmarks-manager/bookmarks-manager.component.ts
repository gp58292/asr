import { Component } from '@angular/core';
import { GridUtils } from '@aqua/aqua-component/aqua-grid/utils';
import { BOOKMARK_MANAGER_GRID_DEFINATION } from '@aqua/bookmarks-manager/grid-definition/bookmark-manager.grid-definition';
import { BookmarkService } from '@aqua/filters/data-finder/bookmark';
import { GridOptions } from 'ag-grid-community';

@Component({
  selector: 'bookmarks-manager',
  templateUrl: './bookmarks-manager.component.html',
  styleUrls: ['./bookmarks-manager.component.scss']
})
export class BookmarksManagerComponent {
  public bookmarkList$ = this.bookmarkService.bookmarkList$;

  public bookmarkColDef = GridUtils.buildColumns(BOOKMARK_MANAGER_GRID_DEFINATION);

  public gridOptions: GridOptions = {
    sideBar: null,
    rowHeight: 30,
    defaultColDef: {
      resizable: true,
      sortable: false,
      filter: false
    }
  };

  constructor(public bookmarkService: BookmarkService) {
    console.debug('BookmarksManagerComponent::constructor:: ', this.bookmarkColDef, BOOKMARK_MANAGER_GRID_DEFINATION);
  }

  public onSelectedBookmark($event) {
    if ($event.colDef.headerName === 'Delete') {
      console.debug('BookmarksManagerComponent::onSelectedBookmark:: Delete the bookmark with ID as ', $event.data.key);
      this.bookmarkService.deleteBookmark($event.data.key, () => this.bookmarkService.loadAllBookmarks());
    } else if ($event.colDef.headerName === 'ID') {
      console.debug('BookmarksManagerComponent::onSelectedBookmark::Move to specific bookmark with ID ', $event.data.key);
    }
  }
}
