import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { Response } from "@angular/http";
import { Router } from "@angular/router";
import { throwError } from "rxjs";
import { UrlConfig } from "./../services/url-config.service";
import { VizNotificationService } from "./../services/viz-notification.service";

@Injectable()
export class ErrorHandlerService {
	constructor(
		private router: Router,
		private vizNotification: VizNotificationService,
		private urlConfig: UrlConfig,
		private http: HttpClient
	) {
		console.debug("ErrorHandlerService::constructor::");
	}

	public handle(error: Response | any, isApplicationCodeError: boolean = true) {
		console.error(
			"ErrorHandlerService::handle::",
			error,
			isApplicationCodeError
		);
		const errMsg = (error as any).message
			? (error as any).message
			: error.status
			? `${error.status} - ${error.statusText}`
			: "Server error";
		if (error instanceof HttpErrorResponse) {
			console.debug("ErrorHandlerService::handle::", error.status);
			// SC_UNAUTHORIZED && SC_FORBIDDEN
			if (error.status === 401 || error.status === 403) {
				this.vizNotification.showError(
					"Please Sign In, Your session has timed out."
				);
				this.router.navigate(["login"]);
			} else if (error.status >= 500 && error.status <= 599) {
				// server error
				// console.debug("ErrorHandlerServiceService::handle::Application currently unavailable, please contact AQUA Support team");
				this.vizNotification.showError(
					"Application currently unavailable, please contact AQUA Support team"
				);
			}
		}

		this.sendToConsole(error, errMsg);
		if (isApplicationCodeError) {
			this.sendToServer(error);
		}

		return throwError(errMsg);
	}

	// send the error the browser console (safely, if it exists) and taster message shown if env is not prod and uat.
	private sendToConsole(error: any, errMsg: string): string {
		if (console && console.group && console.error) {
			console.group("Error Log Service");
			console.error(errMsg);
			console.groupEnd();

			if (
				localStorage.getItem("envName") &&
				localStorage.getItem("envName").indexOf("prod") === -1 &&
				localStorage.getItem("envName").indexOf("uat") === -1
			) {
				if (error.rejection && error.rejection.message) {
					this.vizNotification.showWarning(
						error.rejection.message + " Please contact AQUA support team",
						"Warning!! UI ERROR"
					);
				} else {
					this.vizNotification.showWarning(
						error + " Please contact AQUA support team",
						"Warning!! UI ERROR"
					);
				}
			}
		}
		return errMsg;
	}

	// send the error to the server-side error tracking end-point.
	private sendToServer(error: any): void {
		const lastLog = new Date();
		const sentData: any = {};
		sentData.message = error.message;
		sentData.url = window.location.href;
		sentData.timestamp = lastLog.toISOString();
		sentData.userAgent = window.navigator.userAgent;

		if (localStorage && localStorage.getItem("userParams_name")) {
			sentData.username = localStorage.getItem("userParams_name");
		}

		sentData.level = "ERROR";
		sentData.stack = error.stack;

		let errorMessage = "";

		Object.entries(sentData).forEach(
			([index, label]) => (errorMessage += index + " : " + label + "\n")
		);

		// for (const { label, index } of sentData) {
		// 	errorMessage += index + " : " + label + "\n";
		// }
		this.http
			.put(this.urlConfig.EP_ERRORS_TO_BACKEND, errorMessage)
			.subscribe(
				(): void => {
					console.debug("error logged successfullly on server");
				},
				(httpError: any): void => {
					console.debug("Error while loging error to backend:", httpError);
				}
			);
	}
}
