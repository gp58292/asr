import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()
export class HttpDataRequestInterceptor implements HttpInterceptor {
  private headersCEFT = {
    'Cache-Control': 'no-cache, no-store, max-age=0, must-revalidate',
    Expires: '0',
    Pragma: 'no-cache',
    'Content-Type': 'application/json',
  };

  public intercept (req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    // Seems CEFT require some custom headers. To protect CORS'es from it, we check request.url to have same origin as the application.
    if ((new URL(req.url, window.location.origin)).origin === window.location.origin) {
      return next.handle(req.clone({ setHeaders: this.headersCEFT }));
    }

    return next.handle(req);
  }
}
