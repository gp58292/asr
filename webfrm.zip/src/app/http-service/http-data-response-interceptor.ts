import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppHttpResponse, isAppHttpResponse } from '@aqua/models';
import { EMPTY, Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import { UrlConfig, VizNotificationService } from '../services';
import { ErrorHandlerService } from './error-handler.service';

@Injectable()
export class HttpDataResponseInterceptor implements HttpInterceptor {
  constructor (private urlConfig: UrlConfig, private errorHandle: ErrorHandlerService, private vizNotification: VizNotificationService) {
  }

  public intercept (req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    console.debug('HttpDataResponseInterceptor::intercept:: ', req.url);

    // Till local services wrapped with AppHttpResponse meta we need to isolate handling of this. Better to remove this wrapper!
    if ((new URL(req.url, window.location.origin)).origin === window.location.origin) {
      return next.handle(req).pipe(
        map((response) => {
          if (response instanceof HttpResponse && isAppHttpResponse(response.body)) {
            const appHttpBody: AppHttpResponse<any> = response.body;

            if (appHttpBody.responseStatus !== 200 && appHttpBody.restError) {
              // We don't need to throw the error if this error served within restError. Service is still in charge for responseData.
              this.vizNotification.showError(appHttpBody.restError.errorMessage);
            }

            return new HttpResponse({
              headers: response.headers,
              status: response.status,
              statusText: response.statusText,
              url: response.url,
              body: appHttpBody.responseData
            });
          }

          return response;
        }),
        catchError(err => {
          if (req.url !== this.urlConfig.EP_ERRORS_TO_BACKEND) {
            if (err instanceof HttpErrorResponse) {
              this.errorHandle.handle(err, false);
            }

            return throwError(err);
          }

          return EMPTY;
        }),
      );
    }

    return next.handle(req);
  }
}
