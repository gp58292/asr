import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppContainerLayoutComponent } from '@aqua/app-container-layout/app-container-layout.component';
import { DataFinderComponent } from '@aqua/filters/data-finder/data-finder.component';

const appContainerRoutes: Routes = [
  {
    path: '',
    component: AppContainerLayoutComponent,
    children: [
      {
        path: 'datafinder',
        component: DataFinderComponent,
        children: [],
      },
      {
        // What was the point to redirect from the root to the only one possible route - /datafinder?
        // @todo Need to find a way to make redirectTo to keep original query params.
        path: '',
        component: DataFinderComponent,
        children: [],
        pathMatch: 'full'
      }
    ]
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(appContainerRoutes),
  ],
  exports: [
    RouterModule,
  ],
})
export class AppContainerRoutingModule {
}
