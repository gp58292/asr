import { Component } from '@angular/core';
import { MatDialog } from '@angular/material';
import { BookmarkService } from '@aqua/filters/data-finder/bookmark/bookmark.service';
import { RankingStaticReportComponent } from '@aqua/filters/ranking-static-reports/ranking-static-report.component';
import { RankingStaticReportsUrlConfigService } from '@aqua/filters/ranking-static-reports/services/ranking-static-reports-url-config-service';

@Component({
  selector: 'app-container-layout',
  templateUrl: './app-container-layout.component.html',
  styleUrls: ['./app-container-layout.component.scss']
})
/**
 * Main Application container with the AQUA brand footer and header.
 */
export class AppContainerLayoutComponent {
  public activeBookmark$ = this.bookmarkService.activeBookmark$();

  constructor(
    private bookmarkService: BookmarkService,
    private rankingStaticReportUrlConfig: RankingStaticReportsUrlConfigService,
    private dialog: MatDialog
  ) {}

  public showRankingStaticData() {
    this.dialog.open(RankingStaticReportComponent);
  }

  public openDMTServerURL() {
    window.open(this.rankingStaticReportUrlConfig.DMT_SERVER_URL, '_blank');
  }
}
