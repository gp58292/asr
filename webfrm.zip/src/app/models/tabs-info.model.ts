import { DataSetRequest } from './dataset-request.model';

export class TabsInfo {
  public static comparator(a: TabsInfo, b: TabsInfo): number {
    return a.tabOrder > b.tabOrder ? 1 : 0;
  }
  // public tabId: string;
  // public tabName: string;
  // public tabOrder: number;
  public dataSetRequest:DataSetRequest;
  public tabRecordCount: number = 0;
  constructor(public tabId: string, public tabName: string, public tabOrder: number) {}

  public equals(obj: TabsInfo) {
    // tslint:disable-next-line:triple-equals
    console.debug('TabsInfo::equals::', this, obj, this.tabId == obj.tabId, this.tabId, obj.tabId);
    // tslint:disable-next-line:triple-equals
    if (this.tabId == obj.tabId) {
      return true;
    }
    if (obj == null || !obj) {
      return false;
    }

    return false;
  }
  public getDataSetType(isFiltered: boolean = false) {
    return isFiltered ? this.tabId + '_filtered' : this.tabId;
  }

  public getTabName(isFiltered: boolean = false) {
    return isFiltered ? this.tabName + ' Filtered' : this.tabName;
  }
}
