export class CeftEnvironmentDetails {
  public asrAppHostname: string;
  public asrAppPort: string;
  get asrHostname() {
    return this.asrAppHostname;
  }
}
