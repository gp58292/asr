import { DataSet } from './dataset.model';

export class ColumnValueRequest {
  public column: string;
  public dataSet: DataSet;
  public filters?: { column: string; values: string[] }[];
}
