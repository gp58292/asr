import { IServerSideGetRowsRequest } from 'ag-grid-community';

export class DataSetRequest {
  public soeid: string;
  public bookmarkId: number;
  public type: string;
  public gridRequest: IServerSideGetRowsRequest;
  public agreementKeys: number[];
}
