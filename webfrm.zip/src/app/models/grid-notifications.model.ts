import { AquaGrid } from '@aqua/aqua-component/aqua-grid';
import { IServerSideGetRowsRequest } from 'ag-grid-community';

export class GridNotificationModel {
  public serverSideGetRowsRequest: IServerSideGetRowsRequest;
  public aquaGrid: AquaGrid;
}
