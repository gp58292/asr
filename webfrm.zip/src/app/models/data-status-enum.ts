export enum DataStatus {
  COMPLETED = 'COMPLETED',
  LOADING = 'LOADING',
  READY = 'READY',
  NOT_LOADED = 'NOT_LOADED'
}
