import { Component } from '@angular/core';
import { MatDialog } from '@angular/material';
import { BookmarkService } from '@aqua/filters/data-finder/bookmark/bookmark.service';

import recorder from './recorder/js/recorder.js';
import { AquaASRCriteriaService, AquaAsrService, AquaAsrSpeechService, RecorderService } from './service';

@Component({
  selector: 'aqua-asr',
  templateUrl: './aqua-asr.component.html',
  styleUrls: ['./aqua-asr.component.scss'],
  providers: [RecorderService, AquaAsrSpeechService, AquaASRCriteriaService, AquaAsrService]
})
export class AquaASR {
  public activeBookmark$ = this.bookmarkService.activeBookmark$();

  constructor(public dialog: MatDialog, private bookmarkService: BookmarkService, public auaAsrSpeechService: AquaAsrSpeechService) {
    // this.loadScript('/app/aqua-asr/recorder/js/command.js');
    console.debug('AQUA-ASR::constructor::', recorder);
  }

  public ngOnInit() {
    this.auaAsrSpeechService.listenSpeechRecognition();
    this.auaAsrSpeechService.startSpeechRecognition();
  }
  public ngOnDestroy() {
    this.auaAsrSpeechService.stopSpeechRecognition();
  }

  public start() {
    this.auaAsrSpeechService.startByCommand();
  }

  public stop() {
    this.auaAsrSpeechService.isStartDisable = false;
    this.auaAsrSpeechService.isStopDisable = true;
    this.auaAsrSpeechService.timeLeft = 0;
    // this.auaAsrSpeechService.stopTimer();
  }

  // private loadScript(url: string) {
  //   const body: HTMLDivElement = document.body as HTMLDivElement;
  //   const script = document.createElement('script');
  //   script.innerHTML = '';
  //   script.src = url;
  //   script.async = true;
  //   script.defer = true;
  //   body.appendChild(script);
  // }
}
