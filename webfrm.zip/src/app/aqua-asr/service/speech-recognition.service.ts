import { Injectable, NgZone } from '@angular/core';
import { Observable, Observer } from 'rxjs';
import { shareReplay } from 'rxjs/operators';

// tslint:disable-next-line:interface-name
interface IWindow extends Window {
  webkitSpeechRecognition: any;
  SpeechRecognition: any;
}

@Injectable({ providedIn: 'root' })
export class SpeechRecognitionService {
  private speechRecognition: any;

  constructor(private zone: NgZone) {
    console.debug('AQUA-ASR::SpeechRecognitionService:initiated');
  }

  public speechToText(): Observable<string> {
    return Observable.create((observer: Observer<any>) => {
      // tslint:disable-next-line: no-angle-bracket-type-assertion
      const { webkitSpeechRecognition }: IWindow = <IWindow>(<unknown>window);
      this.speechRecognition = new webkitSpeechRecognition();
      this.speechRecognition.continuous = true;
      this.speechRecognition.interimResults = false;
      this.speechRecognition.lang = 'en-us';
      this.speechRecognition.maxAlternatives = 1;
      this.speechRecognition.isStarted = false;

      this.speechRecognition.onresult = speech => {
        let text: string = '';
        console.debug('AQUA-ASR::SpeechRecognitionService:onresult::', speech);
        if (speech.results) {
          const result = speech.results[speech.resultIndex];
          const transcript = result[0].transcript;
          if (result.isFinal) {
            if (result[0].confidence < 0.3) {
              console.debug('AQUA-ASR::SpeechRecognitionService::Unrecognized result - Please try again');
            } else {
              text = transcript.trim();
              console.debug('AQUA-ASR::SpeechRecognitionService::Did you said? -> ' + text + ' , If not then say something else...');
            }
          }
        }
        this.zone.run(() => {
          observer.next(text);
          // observer.complete();
        });
      };

      this.speechRecognition.onerror = error => {
        console.debug('AQUA-ASR::SpeechRecognitionService::on error::', error, observer, observer.closed);
        // this.speechRecognition.isStarted = false;
        observer.error(error);
      };

      this.speechRecognition.onend = () => {
        console.debug('AQUA-ASR::SpeechRecognitionService::on end::', observer, observer.closed);
        // this.speechRecognition.isStarted = false;
        observer.complete();
      };
      this.speechRecognition.isStarted = true;
      this.speechRecognition.start();
    }).pipe(shareReplay(1));
  }

  public start() {
    console.debug('AQUA-ASR::SpeechRecognitionService::start::', this.speechRecognition);
    if (this.speechRecognition && !this.speechRecognition.isStarted) {
      this.speechRecognition.isStarted = true;
      this.speechRecognition.start();
    }
  }

  public stop() {
    console.debug('AQUA-ASR::SpeechRecognitionService::stop::', this.speechRecognition);
    if (this.speechRecognition) {
      this.speechRecognition.isStarted = false;
      this.speechRecognition.stop();
    }
  }

  public abort() {
    console.debug('AQUA-ASR::SpeechRecognitionService::abort::', this.speechRecognition);
    if (this.speechRecognition) {
      this.speechRecognition.isStarted = false;
      this.speechRecognition.abort();
    }
  }
}
