import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SearchField } from '@aqua/filters/models';
import { CeftEnvironmentService, VizNotificationService } from '@aqua/services';
import { AuthenticationService, User } from '@citi-icg-163206/frm-framework-npm-commons';

import { SpeechStatus } from '../model';
import { AquaAsrService } from './aqua-asr.service';

import Recorder from '../recorder/js/recorder.js';

// declare function Recorder(media: MediaStreamAudioSourceNode, config: any): void;
@Injectable()
export class RecorderService {
  private inputStream: MediaStream;
  private soeId: string;
  private rec: any;
  constructor(
    private vizNotification: VizNotificationService,
    private ceftEnvironmentService: CeftEnvironmentService,
    private authenticationService: AuthenticationService,
    private http: HttpClient,
    private aquaAsrService: AquaAsrService
  ) {
    this.authenticationService.subscribeUserDetails().subscribe((user: User) => {
      this.soeId = user.soeid;
    });
  }

  public startRecording() {
    console.debug('AQUA-ASR::RecorderService::RECORDER:Start RecordButton clicked..!!');

    const constraints = {
      audio: true,
      video: false
    };

    navigator.mediaDevices
      .getUserMedia(constraints)
      .then((stream: MediaStream) => {
        console.debug('AQUA-ASR::RecorderService::getUserMedia() success, stream created, initializing Recorder...');
        this.inputStream = stream;
        // create an audio context after getUserMedia is called, sampleRate might change after getUserMedia is called
        const audioContext = new AudioContext();

        /* use the stream */
        const input = audioContext.createMediaStreamSource(stream);

        /*
          Create the Recorder object and configure to record mono sound (1 channel)
          Recording 2 channels  will double the file size
        */
        this.rec = new Recorder(input, {
          numChannels: 1
        });

        // start the recording process
        this.rec.record();
        console.debug('AQUA-ASR::RecorderService::Recording started..!!');
      })
      .catch(err => {
        console.error(err);
      });
  }

  public stopRecording() {
    console.debug('AQUA-ASR::RECORDER:Stop RecordButton clicked..!!');

    // tell the recorder to stop the recording

    this.rec.stop();
    console.debug('AQUA-ASR::RECORDER::Recording Stopped..!!');

    // stop microphone access
    this.inputStream.getAudioTracks()[0].stop();

    this.vizNotification.showMessage('SpeechToText conversion is in progress...', '', 12000);
    const me = this;
    this.rec.exportWAV((blob: Blob) => {
      console.debug('AQUA-ASR::RECORDER::Export WAV Blob..!!', blob, me.ceftEnvironmentService.envDetailsValue);
      const formData = new FormData();
      formData.append('audioBlob', blob, me.soeId);

      const url = me.ceftEnvironmentService.envDetailsValue.asrAppHostname;
      me.http.post(url + '/python/collateral', formData).subscribe(
        (data: SearchField[]) => {
          console.debug('AQUA-ASR::RecorderService::Deep Speech json result::', data);
          this.aquaAsrService.updateAsrValue(data);
        },
        error => {
          console.error('AQUA-ASR::RecorderService::SpeechToText conversion is failed::', error);
          me.vizNotification.showMessage('SpeechToText conversion is failed.', '', 2000);
          this.aquaAsrService.updateAsrSpeechStatus(SpeechStatus.SPEECH_CONVERSION_FAILED);
        }
      );
    });
  }
}
