import { Injectable } from '@angular/core';
import { SearchComponent } from '@aqua/filters/data-finder/search/search.component';
import { SearchField } from '@aqua/filters/models';
import { BehaviorSubject } from 'rxjs';
import { filter, shareReplay } from 'rxjs/operators';
import { SpeechStatus } from '../model';

@Injectable()
export class AquaAsrService {
  private _aquaAsrResult$: BehaviorSubject<SearchField[]> = new BehaviorSubject<SearchField[]>(undefined);
  private _aquaAsrSpeechStatus$: BehaviorSubject<SpeechStatus> = new BehaviorSubject<SpeechStatus>(undefined);

  public getAsrValue() {
    return this._aquaAsrResult$.value;
  }
  public updateAsrValue(result: SearchField[]) {
    this._aquaAsrResult$.next(result);
  }
  public get aquaAsrListener$() {
    return this._aquaAsrResult$.pipe(
      filter(data => !!data),
      shareReplay(1)
    );
  }
  public getAsrSpeechStatus() {
    return this._aquaAsrSpeechStatus$.value;
  }
  public updateAsrSpeechStatus(result: SpeechStatus) {
    this._aquaAsrSpeechStatus$.next(result);
  }
  public get aquaAsrSpeechStatusListener$() {
    return this._aquaAsrSpeechStatus$.pipe(
      filter(data => !!data),
      shareReplay(1)
    );
  }
}
