import { Injectable } from '@angular/core';
import { BookmarkService } from '@aqua/filters/data-finder/bookmark';
import { FilterPanelComponent } from '@aqua/filters/data-finder/filter-panel/filter-panel.component';
import { SearchField } from '@aqua/filters/models';
import { DataTreeStorageService } from '@aqua/filters/services';
import { ComponentInstanceService } from '@aqua/services';
import { keyBy, merge, values } from 'lodash';

@Injectable()
export class AquaASRCriteriaService {
  private fieldsData: SearchField[];
  constructor(
    private bookmarkService: BookmarkService,
    private dataStorageTreeService: DataTreeStorageService,
    private componentInstanceService: ComponentInstanceService
  ) {
    this.dataStorageTreeService.listenState().subscribe(state => {
      this.fieldsData = state;
    });
  }

  public clearBookmark() {
    this.bookmarkService.setActiveBookmarkByKey(-1);
    this.dataStorageTreeService.clearAllFilters();
    // TODO: Need to work on clear functionality of bookmark
    // this.searchService.clearSearchResult();
    this.bookmarkService.loadBookmark(-1);
  }
  public searchBookmark() {
    const component = this.componentInstanceService.getComponent();
    console.debug('AQUA-ASR::AquaASRCriteriaService::searchBookmark:: ', component);
    if (component && component instanceof FilterPanelComponent) {
      component.onClickSearch();
    }
  }
  public resetBookmark() {
    const component = this.componentInstanceService.getComponent();
    console.debug('AQUA-ASR::AquaASRCriteriaService::resetBookmark:: ', component);
    if (component && component instanceof FilterPanelComponent) {
      component.onChangeBookmark();
      component.onClickReset();
    }
  }

  public buildFields(data: SearchField[]): void {
    console.debug('AQUA-ASR::AquaASRCriteriaService::buildFields started ');
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < data.length; i++) {
      const field = this.findFields(this.fieldsData, data[i].fieldName);
      if (field) {
        if (field.filtered) {
          field.value = merge({}, field.value, data[i].value);
          // values(merge(keyBy(field.value), keyBy(data[i].value)));
          field.filtered = false;
          console.debug('AQUA-ASR::AquaASRCriteriaService::buildFields::Merging:: ', field, field.filtered, field.value);
          this.dataStorageTreeService.updateNode(field, 'filter');
          this.dataStorageTreeService.updateNode(field, 'filter');
        } else {
          field.value = data[i].value;
          field.whoHasFlag = data[i].whoHasFlag;
          console.debug('AQUA-ASR::AquaASRCriteriaService::buildFields::Adding:: ', field, field.filtered);
          this.dataStorageTreeService.updateNode(field, 'filter');
        }
      }
    }
    console.debug('AQUA-ASR::AquaASRCriteriaService::buildFields completed ');
  }

  private findFields(listOfField: any[], fName: string): SearchField {
    console.debug('AQUA-ASR::AquaASRCriteriaService::findFields started');
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < listOfField.length; i++) {
      const arrayOfFields = listOfField[i].children as SearchField[];
      const finalFiled: SearchField[] = arrayOfFields.filter(f => f.fieldName === fName);
      // console.debug('AQUA-ASR::AquaASRCriteriaService::findFields:: ', finalFiled, arrayOfFields);
      if (finalFiled && finalFiled.length > 0) {
        return finalFiled[0];
      }
    }
    console.debug('AQUA-ASR::AquaASRCriteriaService::findFields::');
    return undefined;
  }

  /**
   * Deep merge two objects.
   * @param target
   * @param ...sources
   */
  private mergeDeep(target, ...sources) {
    if (!sources.length) {
      return target;
    }
    const source = sources.shift();

    if (this.isObject(target) && this.isObject(source)) {
      for (const key in source) {
        if (this.isObject(source[key])) {
          if (!target[key]) {
            Object.assign(target, { [key]: {} });
          }
          this.mergeDeep(target[key], source[key]);
        } else {
          Object.assign(target, { [key]: source[key] });
        }
      }
    }

    return this.mergeDeep(target, ...sources);
  }
  /**
   * Simple object check.
   * @param item
   * @returns {boolean}
   */
  private isObject(item) {
    return item && typeof item === 'object' && !Array.isArray(item);
  }
}
