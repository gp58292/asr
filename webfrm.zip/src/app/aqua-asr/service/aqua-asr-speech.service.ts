import { Injectable } from '@angular/core';
import { SearchField } from '@aqua/filters/models';
import { VizNotificationService } from '@aqua/services';
import { interval, Observable } from 'rxjs';

import { SpeechStatus } from '../model';
import { AquaASRCriteriaService } from './aqua-asr-criteria.service';
import { AquaAsrService } from './aqua-asr.service';
import { RecorderService } from './recorder.service';
import { SpeechRecognitionService } from './speech-recognition.service';

@Injectable()
export class AquaAsrSpeechService {
  public timer$: Observable<number>;
  public isStartDisable: boolean = false;
  public isStopDisable: boolean = true;
  public duration: number = 10;
  public timeLeft: number = this.duration;
  private interval: any;

  private aquaAudio: HTMLAudioElement;
  private clearAudio: HTMLAudioElement;
  private resetAudio: HTMLAudioElement;
  private searchAudio: HTMLAudioElement;

  private startCommands: string[] = ['hello', 'hi', 'hey', 'aqua', 'helloaqua', 'hiaqua', 'heyaqua', 'hello  aqua', 'hi aqua'];
  private searchCommands: string[] = ['aquasearch', 'helloaquasearch', 'hiaquasearch', 'heyaquasearch', 'search', 'aqua search'];
  private clearCommands: string[] = [
    'aquaclear',
    'helloaquaclear',
    'hiaquaclear',
    'heyaquaclear',
    'clear',
    'aqua clear',
    'aquagear',
    'aquacare'
  ];
  private resetCommands: string[] = ['aquareset', 'helloaquareset', 'hiaquareset', 'heyaquareset', 'reset', 'aqua reset'];
  private commandBackup: string;
  constructor(
    private speechRecognitionService: SpeechRecognitionService,
    private vizNotification: VizNotificationService,
    private aquaASRCriteriaService: AquaASRCriteriaService,
    private recorderService: RecorderService,
    private aquaAsrService: AquaAsrService
  ) {
    this.aquaAudio = new Audio('/app/aqua-asr/recorder/media/aqua.wav');
    this.clearAudio = new Audio('/app/aqua-asr/recorder/media/clear.wav');
    this.resetAudio = new Audio('/app/aqua-asr/recorder/media/reset.wav');
    this.searchAudio = new Audio('/app/aqua-asr/recorder/media/search.wav');
    this.listenAsrResult();
    this.listenAsrSpeechStatus();
  }
  public stopTimer() {
    this.destroyStopTimer();
  }

  public startByCommand() {
    console.debug('AQUA-ASR::HeaderComponent::start');
    // this.vizNotification.showMessage("I am listening");
    this.stopSpeechRecognition();
    this.recorderService.startRecording();
    this.isStartDisable = true;
    this.isStopDisable = false;
    this.initStopTimer();
  }
  public stopSpeechRecognition(): void {
    this.speechRecognitionService.stop();
  }
  public startSpeechRecognition(): void {
    this.speechRecognitionService.start();
  }

  public listenSpeechRecognition(): void {
    this.speechRecognitionService.speechToText().subscribe(
      text => {
        try {
          text = text.toLowerCase();
          const command = text.replace(/\s/g, '');
          this.commandBackup = command.toLocaleLowerCase();
          switch (true) {
            case this.startCommands.includes(command):
              this.doAsyncTask(
                () => {
                  this.startByCommand();
                },
                this.aquaAudio,
                'I am listening.'
              );
              break;
            case this.searchCommands.includes(command):
              this.doAsyncTask(
                () => {
                  this.startSearch();
                },
                this.searchAudio,
                'I am searching.'
              );
              break;
            case this.clearCommands.includes(command):
              this.doAsyncTask(
                () => {
                  this.aquaASRCriteriaService.clearBookmark();
                },
                this.clearAudio,
                'I am clearing bookmark.'
              );
              break;
            case this.resetCommands.includes(command):
              this.doAsyncTask(
                () => {
                  this.reset();
                },
                this.resetAudio,
                'I am resetting field values.'
              );
              break;
            default:
              this.vizNotification.showError('Command is not recognized - Please try again', '', 2000);
              console.debug('AQUA-ASR::AquaAsrSpeechService::{' + command + '} Command is not recognized - Please try again');
          }
        } catch (error) {
          console.debug('AQUA-ASR::AquaAsrSpeechService::error', error);
        }
      },
      err => {
        console.debug('AQUA-ASR::ERROR::', err);
        if (err.error === 'no-speech') {
          this.listenSpeechRecognition();
        }
        // if (err.error === 'aborted') {
        //   this.startSpeechRecognition();
        // }
      },
      () => {
        console.debug('AQUA-ASR::complete.......');
        if (this.startCommands.includes(this.commandBackup)) {
          console.debug('AQUA-ASR::command already running');
        } else {
          this.startSpeechRecognition();
        }
      }
    );
  }

  private listenAsrResult() {
    this.aquaAsrService.aquaAsrListener$.subscribe((records: SearchField[]) => {
      console.debug('AQUA-ASR::listenAsrResult::records', records);
      this.aquaASRCriteriaService.buildFields(records);
      this.listenSpeechRecognition();
      // this.commandBackup = '';
    });
  }

  private listenAsrSpeechStatus() {
    this.aquaAsrService.aquaAsrSpeechStatusListener$.subscribe((records: SpeechStatus) => {
      console.debug('AQUA-ASR::listenAsrSpeechStatus::records', records);
      if (SpeechStatus.SPEECH_CONVERSION_FAILED === records) {
        this.speechRecognitionService.start();
        this.isStartDisable = true;
        this.isStopDisable = false;
      }
    });
  }

  private startSearch() {
    console.debug('AQUA-ASR::AquaAsrSpeechService::search');
    this.aquaASRCriteriaService.searchBookmark();
  }
  private reset() {
    console.debug('AQUA-ASR::AquaAsrSpeechService::reset bookmark');
    this.aquaASRCriteriaService.resetBookmark();
  }

  private initStopTimer() {
    this.interval = setInterval(() => {
      if (this.timeLeft > 0) {
        this.timeLeft--;
      } else {
        console.debug('AQUA-ASR::AquaAsrSpeechService::initStopTimer::', this.timeLeft);
        this.timeLeft = this.duration;
        this.recorderService.stopRecording();
        this.isStartDisable = false;
        this.isStopDisable = true;
        this.destroyStopTimer();
      }
    }, 1000);
  }

  private destroyStopTimer() {
    console.debug('AQUA-ASR::AquaAsrSpeechService::destroyStopTimer::', this.interval);
    if (this.interval) {
      clearInterval(this.interval);
    }
  }

  private doAsyncTask(cb: any, audio: HTMLAudioElement, message: string) {
    console.debug('AQUA-ASR::AquaAsrSpeechService::doAsyncTask::', cb, audio, message);
    this.vizNotification.showMessage(message, '', 2000);
    try {
      audio && audio.play();
    } catch (exe) {
      console.debug('AQUA-ASR::AquaAsrSpeechService::doAsyncTask::Play Audio::', exe);
    }
    console.debug('AQUA-ASR::AquaAsrSpeechService::doAsyncTask::Play Audio::', audio.error);
    setTimeout(() => {
      console.debug('AQUA-ASR::AquaAsrSpeechService::doAsyncTask::Call Back::', cb, audio, message);
      cb();
    }, 2000);
  }
}
