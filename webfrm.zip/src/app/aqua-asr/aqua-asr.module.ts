import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AquaASR } from './aqua-asr.component';

@NgModule({
  declarations: [AquaASR],
  imports: [CommonModule, HttpClientModule, ReactiveFormsModule, BrowserAnimationsModule],
  exports: [AquaASR]
})
export class AquaAsrModule {}
