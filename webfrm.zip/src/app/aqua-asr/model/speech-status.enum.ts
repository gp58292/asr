export enum SpeechStatus {
  STOP,
  START,
  SPEECH_CONVERSION_FAILED
}
