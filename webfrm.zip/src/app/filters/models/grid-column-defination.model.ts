import { FieldType } from '@aqua/aqua-component/aqua-grid/model/field-type.enum';
import { SearchResultColumns } from './search-result-columns.model';

export class GridColumnsDef extends SearchResultColumns {
  public isHyperLink?: boolean;
  public width?: number;
  public minWidth?: number;
  public rendererFramework?: any;
  public enablePivot?: boolean;
  public enableValue?: boolean;
  public enableRowGroup?: boolean;
  public enableFilter?: boolean;
}

// tslint:disable-next-line:max-classes-per-file
export class GridColumnsDefBuilder {
  private _key: number;
  public key(_key: number) {
    this._key = _key;
    return this;
  }
  // tslint:disable-next-line: member-ordering
  private _fieldType: FieldType = FieldType.STRING;
  public fieldType(_fieldType: FieldType) {
    this._fieldType = _fieldType;
    return this;
  }
  // tslint:disable-next-line: member-ordering
  private _fieldOrder?: number;
  public fieldOrder(_fieldOrder: number) {
    this._fieldOrder = _fieldOrder;
    return this;
  }

  // tslint:disable-next-line: member-ordering
  private _tabId?: string;
  public tabId(_tabId: string) {
    this._tabId = _tabId;
    return this;
  }
  // tslint:disable-next-line: member-ordering
  private _tabName?: string;
  public tabName(_tabName: string) {
    this._tabName = _tabName;
    return this;
  }
  // tslint:disable-next-line: member-ordering
  private _tabOrder?: number;
  public tabOrder(_tabOrder: number) {
    this._tabOrder = _tabOrder;
    return this;
  }
  // tslint:disable-next-line: member-ordering
  private _isSearchable?: boolean;
  public isSearchable(_isSearchable: boolean) {
    this._isSearchable = _isSearchable;
    return this;
  }
  // tslint:disable-next-line: member-ordering
  private _isDefaultDisplay?: boolean = true;
  public isDefaultDisplay(_isDefaultDisplay: boolean) {
    this._isDefaultDisplay = _isDefaultDisplay;
    return this;
  }
  // tslint:disable-next-line: member-ordering
  private _tabVoyagerId?: string;
  public tabVoyagerId(_tabVoyagerId: string) {
    this._tabVoyagerId = _tabVoyagerId;
    return this;
  }

  // tslint:disable-next-line: member-ordering
  private _isHyperLink?: boolean;
  public isHyperLink(_isHyperLink: boolean) {
    this._isHyperLink = _isHyperLink;
    return this;
  }
  // tslint:disable-next-line: member-ordering
  private _width?: number;
  public width(_width: number) {
    this._width = _width;
    return this;
  }
  // tslint:disable-next-line: member-ordering
  private _minWidth?: number;
  public minWidth(_minWidth: number) {
    this._minWidth = _minWidth;
    return this;
  }
  // tslint:disable-next-line: member-ordering
  private _rendererFramework?: any;
  public rendererFramework(_rendererFramework: any) {
    this._rendererFramework = _rendererFramework;
    return this;
  }

  // tslint:disable-next-line: member-ordering
  private _enablePivot?: boolean;
  public enablePivot(_enablePivot: boolean = true) {
    this._enablePivot = _enablePivot;
    return this;
  }

  // tslint:disable-next-line: member-ordering
  private _enableValue?: boolean;
  public enableValue(_enableValue: boolean = true) {
    this._enableValue = _enableValue;
    return this;
  }

  // tslint:disable-next-line: member-ordering
  private _enableRowGroup?: boolean;
  public enableRowGroup(_enableRowGroup: boolean = true) {
    this._enableRowGroup = _enableRowGroup;
    return this;
  }

  // tslint:disable-next-line: member-ordering
  private _enableFilter?: boolean;
  public enableFilter(_enableFilter: boolean = true) {
    this._enableFilter = _enableFilter;
    return this;
  }
  // tslint:disable-next-line:member-ordering
  constructor(private _displayName: string, private _fieldName: string) {}

  public build(): GridColumnsDef {
    const columnDef: GridColumnsDef = new GridColumnsDef();
    columnDef.key = this._key;
    columnDef.displayName = this._displayName;
    columnDef.fieldName = this._fieldName;
    columnDef.fieldOrder = this._fieldOrder;
    columnDef.fieldType = this._fieldType;
    columnDef.isDefaultDisplay = this._isDefaultDisplay;
    columnDef.isHyperLink = this._isHyperLink;
    columnDef.isSearchable = this._isSearchable;
    columnDef.minWidth = this._minWidth;
    columnDef.rendererFramework = this._rendererFramework;
    columnDef.tabId = this._tabId;
    columnDef.tabName = this._tabName;
    columnDef.enablePivot = this._enablePivot;
    columnDef.enableRowGroup = this._enableRowGroup;
    columnDef.enableValue = this._enableValue;
    columnDef.enableFilter = this._enableFilter;
    return columnDef;
  }
}
