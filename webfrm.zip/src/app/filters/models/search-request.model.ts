import { CommonUtils } from '@aqua/util';

import { SearchField } from './search-field.model';

export class SearchRequest {
  public set searchCriteria(_searchCriteria: SearchField[]) {
    this._searchCriteria = CommonUtils.deepClone(_searchCriteria);
  }
  public get searchCriteria() {
    return this._searchCriteria;
  }
  public datasetType: string;
  private _searchCriteria: SearchField[];

  public toJSON() {
    return {
      datasetType: this.datasetType,
      searchCriteria: this.searchCriteria
    };
  }
}
