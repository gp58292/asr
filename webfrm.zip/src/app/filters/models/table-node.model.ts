import { SearchField } from "@aqua/filters/models/search-field.model";

export interface TableNode {
	name: string;
	children: SearchField[];
}
