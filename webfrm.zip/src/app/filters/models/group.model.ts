import { TableNode } from "@aqua/filters/models/table-node.model";

export interface Group {
	name: string;
	children: TableNode[];
}
