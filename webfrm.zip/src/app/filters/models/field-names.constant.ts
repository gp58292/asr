export enum FieldNames {
  AGREEMENT_ID = 'agreement_id',
  AGREEMENT_KEY = 'agreement_key'
}
