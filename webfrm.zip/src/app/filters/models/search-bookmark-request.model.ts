import { BookmarkRequest } from '../data-finder/bookmark/bookmark-request.model';
import { SearchRequest } from './search-request.model';

export class SearchBookmarkRequest {
  public atmosphereResourceUuid: string;
  public bookmarkRequest: BookmarkRequest;
  public searchRequest: SearchRequest;
}
