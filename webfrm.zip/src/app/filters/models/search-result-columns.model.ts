import { FieldType } from '@aqua/aqua-component/aqua-grid/model/field-type.enum';

export class SearchResultColumns {
  public key?: number;
  public displayName: string;
  public fieldName: string;
  public fieldType?: FieldType = FieldType.STRING;
  public fieldOrder?: number;
  public tabId?: string;
  public tabName?: string;
  public tabOrder?: number;
  public isSearchable?: boolean;
  public isDefaultDisplay?: boolean;
  public tabVoyagerId?: string;
}
