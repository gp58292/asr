import { Bookmark } from "./bookmark.model";

export interface BookmarkWithStatus {
    bookmark: Bookmark;
    bookmarkStatus: 'SAVED' | 'UPDATED';
}