import { CeftDataSetStatus } from '@aqua/models';

import { LoadingTypes } from './loading-types.enum';

export class UILoadingStatus {
  constructor(public type: LoadingTypes, public isStarted: boolean = false, public data?: CeftDataSetStatus) {}
}
