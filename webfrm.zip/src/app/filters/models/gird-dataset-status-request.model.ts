import { IServerSideGetRowsRequest } from 'ag-grid-community';

import { CeftDataSetStatus } from '@aqua/models';

export class GridDataSetStatusRequest {
  constructor(public gridFilter: IServerSideGetRowsRequest, public dataSetStatus: CeftDataSetStatus) {}
}
