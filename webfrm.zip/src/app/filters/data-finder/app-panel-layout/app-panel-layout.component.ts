import { Component, OnInit } from "@angular/core";

@Component({
	selector: "app-panel-layout",
	templateUrl: "./app-panel-layout.component.html",
	styleUrls: ["./app-panel-layout.component.scss"]
})
export class AppPanelLayoutComponent implements OnInit {
	constructor() {
		console.debug("AppPanelLayoutComponent::constructor");
	}

	public ngOnInit() {
		console.debug("AppPanelLayoutComponent::ngOnInit");
	}
	public ngAfterViewInit() {
		console.debug("AppPanelLayoutComponent::ngAfterViewInit");
	}
	public ngOnDestroy() {
		console.debug("AppPanelLayoutComponent::ngOnDestroy");
	}
}
