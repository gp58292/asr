import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { DataFinderComponent } from "./data-finder.component";

describe("DataFinderComponent", () => {
	let component: DataFinderComponent;
	let fixture: ComponentFixture<DataFinderComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [DataFinderComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(DataFinderComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
