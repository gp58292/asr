import { NestedTreeControl } from '@angular/cdk/tree';
import { ChangeDetectionStrategy, Component, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatTree, MatTreeNestedDataSource } from '@angular/material/tree';
import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { DataTreeStorageService, FiltersService } from '@aqua/filters/services';
import { CommonUtils } from '@aqua/util';
import { cloneDeep } from 'lodash';
import { combineLatest, Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged, map, shareReplay, startWith, tap } from 'rxjs/operators';

import { AttributeNode, AttributesTree, AttributesViewMode as ViewMode, WhoCanWhoHas } from '../../filters.types';

@Component({
  selector: 'settings-side-panel',
  templateUrl: './settings-side-panel.component.html',
  styleUrls: ['./settings-side-panel.component.scss'] /*,
  changeDetection: ChangeDetectionStrategy.OnPush*/
})
export class SettingsSidePanelComponent {
  /**
   * Attributes view modes for template.
   */
  public readonly ViewMode = ViewMode;

  /**
   * WhoCanWhoHas constants.
   */
  public readonly WhoCanWhoHas = WhoCanWhoHas;

  /**
   * Nested Tree Control to manage expandable nodes recursively.
   */
  public attributesTreeControl = new NestedTreeControl<AttributeNode>(node => node.children);
  public dataSource = new MatTreeNestedDataSource();
  public childrenCounts = new Map();

  /**
   * Indicator of sidebar expand state.
   */
  public fieldsExpanded = true;

  /**
   * Simple Form control for search filter.
   */
  public filterControl = new FormControl();

  /**
   * Observer of WhoCanWhoHas value from service.
   */
  public whoCanWhoHas$ = this.dataStorageTreeService.listenForWhoHasWhoCanChanged().pipe(shareReplay());

  /**
   * Observer of Attribute View Mode value from service.
   */
  public viewMode$ = this.dataStorageTreeService.listenForAttributesViewModeChanged().pipe(
    startWith(ViewMode.FLAT),
    shareReplay()
  );

  /**
   * Observe of Filters View Mode value from service.
   */
  public isFiltersViewMode$ = this.filtersService.listenFiltersViewMode$();

  /**
   * Tree Data from service observer.
   */
  public sourceData$: Observable<AttributesTree> = combineLatest(
    this.viewMode$,
    this.dataStorageTreeService.listenState(),
    this.dataStorageTreeService.listenStateGroupTree()
  ).pipe(
    map(([viewMode, flatData, groupData]) => (viewMode === ViewMode.FLAT ? cloneDeep(flatData) : cloneDeep(groupData))),
    distinctUntilChanged(),
    shareReplay(1)
  );

  /**
   * Observer of filterControl changes.
   */
  public filter$ = this.filterControl.valueChanges.pipe(
    startWith(''),
    debounceTime(300),
    distinctUntilChanged(),
    shareReplay()
  );

  /**
   * Filtered Tree Structure to display via mat-tree.
   */
  public filteredData$ = combineLatest(this.sourceData$, this.filter$, this.whoCanWhoHas$).pipe(
    map(([sourceData, filterValue, whoCanWhoHas]) => {
      // Should not display 'Current Posting' the Node. If view mode is WhoCanWhoHas.CAN.
      const filteredData = this.attributeFilter(sourceData, whoCanWhoHas);
      // console.debug('SettingsSidePanelComponent::filteredData$::', sourceData, filterValue, whoCanWhoHas, filteredData);
      // Filter nodes by search value.
      return this.searchFilter(filteredData, filterValue);
    }),
    shareReplay(1)
  );

  // private listenSourceData() {
  //   // this.sourceData$.subscribe(data => {
  //   //   console.debug('SettingsSidePanelComponent::listenSourceData::', data);
  //   // });
  //   // this.viewMode$.subscribe(data => {
  //   //   console.debug('SettingsSidePanelComponent::viewMode::', data);
  //   // });

  //   this.dataStorageTreeService.listenState().subscribe(data => {
  //     console.debug('SettingsSidePanelComponent::listenState::', data);
  //   });

  //   // this.dataStorageTreeService.listenStateGroupTree().subscribe(data => {
  //   //   console.debug('SettingsSidePanelComponent::listenStateGroupTree::', data);
  //   // });
  // }
  // private listenFilter() {
  //   this.filter$.subscribe(data => {
  //     console.debug('SettingsSidePanelComponent::listenFilter::', data);
  //   });
  // }
  // private listenWhoCanWhoHas() {
  //   this.whoCanWhoHas$.subscribe(data => {
  //     console.debug('SettingsSidePanelComponent::listenWhoCanWhoHas::', data);
  //   });
  // }

  // private listenFilterData() {
  //   this.filteredData$.subscribe(data => {
  //     console.debug('SettingsSidePanelComponent::listenFilterData::', data);
  //   });
  // }

  // private listenFilterList() {
  //   this.filtersService.listenFiltersList$().subscribe(data => {
  //     console.debug('SettingsSidePanelComponent::listenFilterList::', data);
  //   });
  // }

  /**
   * Filtered Tree Structure ordered by fieldInUse param.
   */
  public data$ = combineLatest(
    this.filteredData$,
    this.filtersService.listenFiltersList$().pipe(
      debounceTime(50),
      map(filteredAttributes => [...filteredAttributes].reverse())
    )
  ).pipe(
    map(([data, filteredAttributes]) => {
      // In order to keep original data sorting (by name) we need to clone initial data.
      const treeData = cloneDeep(data);
      // console.debug('SettingsSidePanelComponent::toggleWhoCanWhoHasTree::MAP::', data, treeData, filteredAttributes);
      if (filteredAttributes.length > 0) {
        // Initially data sorted by name. But all filtered attributes should be on the top.
        for (const filteredAttribute of filteredAttributes) {
          this.dataStorageTreeService.sortAttributesTree(treeData, filteredAttribute);
        }
      }

      return treeData;
    }),
    debounceTime(300),
    tap(data => {
      // console.debug('SettingsSidePanelComponent::toggleWhoCanWhoHasTree', data);
      // Expand all nodes.
      this.attributesTreeControl.dataNodes = data;
      this.attributesTreeControl.expandAll();
      // Children counting.
      this.childrenCounts = new Map();
      this.attributesTreeControl.dataNodes.forEach(parentNode => this.fillCountsMap(parentNode));
    })
  );

  /**
   * Indicator of Initial data is exist.
   */
  public hasData$ = this.sourceData$.pipe(map(data => !!(data && data.length)));

  /**
   * Attributes tree 'mat-tree' instance.
   */
  @ViewChild('attributesTree') private attributesTreeRef: MatTree<AttributeNode>;

  constructor(private dataStorageTreeService: DataTreeStorageService, private filtersService: FiltersService) {
    // this.listenFilterData();
    // this.listenFilterList();
    // this.listenSourceData();
    // this.listenFilter();
    // this.listenWhoCanWhoHas();
  }

  /**
   *  "number" css class when data type is numeric, integer, double
   *  "text" css class when data type is string
   *  "date" css class when data type is date
   */
  public getCssByType(type: FieldType) {
    return CommonUtils.getClassByDataType(type);
  }

  /**
   * Handles toggling of attribute in filter.
   */
  public onToggleAttribute(attribute) {
    // Don't trigger tree re-rendering in order to avoid nested nodes auto expanding.
    console.debug('SettingsSidePanelComponent::onToggleAttribute::', attribute);
    this.dataStorageTreeService.updateNode(attribute, 'filter', false);
  }

  /**
   * Checks if TreeNode has nested attributes.
   */
  public isRootAttribute(_: number, node) {
    return !!node.children && node.children.length;
  }

  /**
   * Wraps odd treeIterator with the pure deterministic function, to filter nodes by search criteria.
   */
  public searchFilter(nodes: AttributesTree, filterValue: string) {
    if (!filterValue) {
      return nodes;
    }

    const filteredTreeResult: any[] = [];

    this.dataStorageTreeService.treeIterator(filterValue, nodes, '', filteredTreeResult);
    // console.debug('SettingsSidePanelComponent::searchFilter$::', filterValue, nodes, filteredTreeResult);
    return filteredTreeResult;
  }

  /**
   * Rejects 'Current Posting' node for WhoCanWhoHas.CAN mode.
   */
  public attributeFilter(nodes: AttributesTree, whoCanWhoHas: WhoCanWhoHas): AttributesTree {
    let resultNodes: AttributesTree;
    if (whoCanWhoHas === WhoCanWhoHas.CAN) {
      resultNodes = nodes.filter(node => node.name !== 'Current Posting');
    } else {
      resultNodes = nodes;
    }
    return resultNodes;
  }

  /**
   * Handle sidebar expand toggle.
   */
  public toggleSideBarStage() {
    this.fieldsExpanded = !this.fieldsExpanded;
  }

  /**
   * Handle changing of WhoCanWhoHas value.
   */
  public whoCanHasToggleChange(event) {
    this.dataStorageTreeService.toggleWhoCanWhoHasTree(event.value);
  }

  /**
   * Handle changing of View Mode value.
   */
  public onChangeViewMode(event) {
    this.dataStorageTreeService.toggleAttributesViewMode(event.value);
  }

  private fillCountsMap(parentNode) {
    const allChildren = this.attributesTreeControl.getDescendants(parentNode);
    const leavesChildren = allChildren.filter(node => !node.children);
    this.childrenCounts.set(parentNode, leavesChildren.length);

    const branchChildren = allChildren.filter(node => node.children);
    branchChildren.forEach(nextParentNode => this.fillCountsMap(nextParentNode));
  }
}
