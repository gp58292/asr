import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Bookmark, SearchField } from '@aqua/filters/models';
import { DataTreeStorageService, FiltersUrlConfig } from '@aqua/filters/services';
import { VizNotificationService } from '@aqua/services';
import { BehaviorSubject, Observable } from 'rxjs';
import { distinctUntilChanged, shareReplay } from 'rxjs/operators';

import { BookmarkRequest } from '@aqua/filters/data-finder/bookmark/bookmark-request.model';
import { ChartConfirmationDialogComponent } from '@aqua/filters/data-finder/bookmark/chart-confirmation-dialog/chart-confirmation-dialog.component';

const defalutSettingsName = 'default';

@Injectable()
export class BookmarkService {
  public get activeBookmark() {
    return this._activeBookmark$.value;
  }

  public get selectedBookmark() {
    return this._selectedBookmark;
  }
  public set selectedBookmark(bookmark: Bookmark) {
    console.debug('BookmarkComponent::BookmarkService::selectedBookmark::', bookmark);
    if (bookmark) {
      this.loadBookmark(bookmark.key);
    }
    this.setInternalBookmark(bookmark);
  }

  public bookmarkIsLoad$ = new BehaviorSubject(false);

  public get bookmarkList$(): Observable<Bookmark[]> {
    return this._bookmarkList$.asObservable().pipe(shareReplay(1));
  }
  private _bookmarksList: Bookmark[];
  private _bookmarkList$: BehaviorSubject<Bookmark[]> = new BehaviorSubject(null);

  private _selectedBookmark: Bookmark;

  private _activeBookmark$ = new BehaviorSubject<Bookmark>(undefined);


  constructor(
    private http: HttpClient,
    private urlConfig: FiltersUrlConfig,
    private vizNotification: VizNotificationService,
    private dataStorageTreeService: DataTreeStorageService,
    private dialog: MatDialog
  ) {
    // this.loadAllBookmarks();
  }
  public setInternalBookmark(bookmark: Bookmark): void {
    this._selectedBookmark = bookmark;
    this.setActiveBookmark(bookmark);
  }

  public activeBookmark$() {
    return this._activeBookmark$.asObservable().pipe(
      distinctUntilChanged(),
      shareReplay(1)
    );
  }

  public setActiveBookmarkByKey(bookmarkKey: number) {
    if (this._activeBookmark$.value && this._activeBookmark$.value.key !== bookmarkKey) {
      this._activeBookmark$.next(this._bookmarkList$.value.find(bookmark => bookmark.key === bookmarkKey));
    }
  }
  public setActiveBookmark(bookmark: Bookmark) {
    this._activeBookmark$.next(bookmark);
  }

  // Load selected bookmark from rest service
  public loadBookmark(id: number) {
    console.debug('BookmarkService:: loadBookmark::', id, this._activeBookmark$.value && this._activeBookmark$.value.key);
    if (id > 0 && (!this._activeBookmark$.value || (this._activeBookmark$.value && this._activeBookmark$.value.key !== id))) {
      this.bookmarkIsLoad$.next(true);
      this.getBookmark(id).subscribe((fields: SearchField[]) => {
        console.debug('BookmarkService:: loadBookmark :: ', fields);
        this.bookmarkIsLoad$.next(false);
        if (fields) {
          this.dataStorageTreeService.setFiltersBasedOfBookmark(fields);
        }
      });
    }
  }

  // Load all bookmarks
  public loadAllBookmarks(isReloadBookmark: boolean = true): void {
    console.debug('BookmarkService:: loadAllBookmarks::', isReloadBookmark);
    this.getBookmarks().subscribe((bookmarks: Bookmark[]) => {
      console.debug('BookmarkService:: loadAllBookmarks :: this.selectedCriteria', bookmarks);
      this._bookmarksList = bookmarks || [];
      this.informBookmarkListListener();
    });
  }

  // =================== apis for add , delete , up date and retrive bookmark starts ===========================
  public getBookmarks() {
    const requestUrl: string = this.urlConfig.EP_BOOKMARK;
    console.debug('BookmarkService:: getBookmarks ' + requestUrl);
    // Boomarks service require to specify userId. Pipe http service to userId$ here.
    return this.http.get(this.urlConfig.EP_BOOKMARK);
  }

  public getBookmark(bookmarkId: number): Observable<SearchField[] | any> {
    const requestUrl: string = this.urlConfig.EP_BOOKMARK + '/' + bookmarkId;
    console.debug('BookmarkService:: getBookmark' + requestUrl);
    return this.http.get(requestUrl).pipe(shareReplay(1));
  }

  public updateBookmark(bookmarkRequest: BookmarkRequest): Observable<Bookmark | any> {
    console.debug('BookmarkService::updateBookmark', bookmarkRequest);
    return this.http.put(this.urlConfig.EP_BOOKMARK, bookmarkRequest);
  }

  public updateOriginalAndDeleteTemporaryBookmark(bookmarkRequest: BookmarkRequest): void {
    console.debug('BookmarkService::updateOriginalAndDeleteTemporaryBookmark', bookmarkRequest);
    this.http.put(this.urlConfig.EP_BOOKMARK_REPLACE, bookmarkRequest).subscribe(
      (data: Bookmark) => {
        const newBbookmark = data;
        let bookmarkFound = this._bookmarksList.findIndex((bookmark: Bookmark) => bookmark.key === bookmarkRequest.bookmarkId);
        if (bookmarkFound !== -1) {
          this._bookmarksList.splice(bookmarkFound, 1);
          bookmarkFound = this._bookmarksList.findIndex((bookmark: Bookmark) => bookmark.key === newBbookmark.key);
          this._bookmarksList[bookmarkFound] = newBbookmark;
          this.sortBookmarkList();
          // this.setInternalBookmark(newBbookmark);
          this.informBookmarkListListener();
        }
        this.vizNotification.showMessage('Successfully updated original bookmark and deleted temporary.');
      },
      error => {
        this.vizNotification.showError('There is error while doing save on temporary functionality, Please contact AQUA CEFT Build Team.');
      }
    );
  }

  public wrapperUpdateBookmark(bookmarkRequest: BookmarkRequest) {
    this.updateBookmark(bookmarkRequest).subscribe((bookmark: Bookmark) => {
      if (bookmark) {
        if (!bookmarkRequest.isSilent) {
          this.vizNotification.showMessage('Successfully saved bookmark.');
        }

        const bookmarkFound = this._bookmarksList.findIndex(bookmarkItem => bookmarkItem.key === bookmarkRequest.bookmarkId);
        if (bookmarkFound !== -1) {
          this._bookmarksList[bookmarkFound] = bookmark;
          this.sortBookmarkList();
          this.setInternalBookmark(bookmark);
        }
      }
    });
  }

  public updateBookmarkInUI(bookmark: Bookmark) {
    const bookmarkFound = this._bookmarksList.findIndex(bookmarkItem => bookmarkItem.key === bookmark.key);
    if (bookmarkFound !== -1) {
      this._bookmarksList[bookmarkFound] = bookmark;
      this.sortBookmarkList();
      this.selectedBookmark = bookmark;
    }
  }

  public addBookmarkInUI(bookmark: Bookmark) {
    const existBookmark: Bookmark = this.getBookmarkByName(bookmark.name);
    console.debug('BookmarkService:: addBookmarkInUI ', bookmark.name, existBookmark);
    if (existBookmark) {
      const index = this._bookmarksList.indexOf(existBookmark);
      console.debug('BookmarkService:: addBookmarkInUI ', index, existBookmark);
      if (index >= 0) {
        this._bookmarksList[index] = bookmark;
      }
    } else {
      this._bookmarksList.push(bookmark);
    }
    this.sortBookmarkList();
    this.informBookmarkListListener();
    console.debug('BookmarkService::wrapperAddBookmark', this._bookmarksList);
  }

  public deleteBookmark(bookmarkId: number, callback?: (id: number) => void): void {
    const requestUrl: string = this.urlConfig.EP_BOOKMARK + '/' + bookmarkId;
    console.debug('BookmarkService:: deleteBookmark ' + requestUrl);
    this.http.delete(requestUrl).subscribe((response: boolean | string[]) => {
      console.debug('BookmarkComponent::deleteBookmark::', response);
      if (response && response instanceof Array) {
        this.alertUserIfChartExist(response);
      } else if (response) {
        this.vizNotification.showMessage('Bookmark deleted successfully');
        const isTemporary: boolean = this.isCurrentBookmarkTemporary();
        const bookmark: Bookmark = this.selectedBookmark;
        // Remove successfully deleted bookmark from data base along with UI as well
        this._bookmarksList.splice(this._bookmarksList.indexOf(bookmark), 1);
        const tempBookmark: Bookmark = this.getCorrespondingTempBookmark(bookmark.key);
        if (tempBookmark) {
          this._bookmarksList.splice(this._bookmarksList.indexOf(tempBookmark), 1);
        }
        this.sortBookmarkList();
        if (isTemporary) {
          this.selectedBookmark = this.getBookmarkByKey(bookmark.parentId);
        } else {
          this.informBookmarkListListener();
        }
        // this._bookmarkList$.next([...this._bookmarksList]);
        callback && callback(bookmarkId);
      }
    });
  }

  // Add Bookmark to database
  public addBookmark(bookmarkRequest: BookmarkRequest): Observable<Bookmark | any> {
    console.debug('BookmarkService::addBookmark', bookmarkRequest);
    return this.http.post(this.urlConfig.EP_BOOKMARK, bookmarkRequest);
  }

  public wrapperAddBookmark(bookmarkRequest: BookmarkRequest) {
    console.debug('BookmarkService::wrapperAddBookmark', bookmarkRequest);
    this.addBookmark(bookmarkRequest).subscribe((bookmark: Bookmark) => {
      if (bookmark) {
        if (!bookmarkRequest.isSilent) {
          this.vizNotification.showMessage('Successfully created new bookmark.');
        }
        this._bookmarksList.push(bookmark);
        this.sortBookmarkList();
        console.debug('BookmarkService::wrapperAddBookmark', bookmarkRequest.isReload, this._bookmarksList.length);
        /*if (bookmarkRequest.isReload) {
          this.informBookmarkListListener();
        } else {
          this.setInternalBookmark(bookmark);
        }*/
        this.informBookmarkListListener();
        console.debug('BookmarkService::wrapperAddBookmark', this._bookmarksList);
      }
    });
  }

  // Delete all temporary bookmark for specific user id
  public deleteAllTemporaryBookmarkByUserId(): Observable<boolean | any> {
    const url: string = this.urlConfig.EP_BOOKMARK_DELETE_ALL_TEMPORARY;
    console.debug('BookmarkService::deleteAllTemporaryBookmarkByUserId::', url);
    return this.http.delete(url);
  }

  public deleteTempBookmarkWrapper(): void {
    this.deleteAllTemporaryBookmarkByUserId().subscribe((response: boolean) => {
      if (response) {
        this.vizNotification.showMessage('All your temporary bookmark removed successfully.');
        const bookmark = this.selectedBookmark;
        const isTemporary = this.isCurrentBookmarkTemporary();
        console.debug('BookmarkService::deleteTempBookmarkWrapper::', isTemporary, bookmark.parentId);
        this.removeTemporaryBookmarkFromUI();
        if (isTemporary) {
          this.selectedBookmark = this.getBookmarkByKey(bookmark.parentId);
        }
        // this._bookmarkList$.next(this._bookmarksList);
        this.informBookmarkListListener();
      }
    });
  }

  // Delete all temporary bookmark for specific user id
  public restoreAllBookmarkByUserId(): void {
    const url: string = this.urlConfig.EP_BOOKMARK_RESTORE_ALL_DELETED;
    console.debug('BookmarkService::restoreAllBookmarkByUserId::', url);
    this.http.get(url).subscribe((bookmarks: Bookmark[]) => {
      if (bookmarks.length > 0) {
        this.vizNotification.showMessage('All your recently deleted bookmark restored successfully.');
        this.restoreBookmarkInUI(bookmarks);
      } else {
        this.vizNotification.showError('No recently deleted bookmarks available to restore.');
      }
    });
  }

  // get default bookmark if selected
  public getDefaultBookmarkIfSelected(): Bookmark {
    const selectedBookmark: Bookmark = this.selectedBookmark;
    return selectedBookmark && selectedBookmark.name === defalutSettingsName ? selectedBookmark : undefined;
  }

  public isBookmarkNameExist(name: string): boolean {
    const bookmarkFound: Bookmark = this._bookmarksList.find(bookmark => bookmark.name === name);
    return !!bookmarkFound;
  }

  // Find is any temporary bookmark exist
  public isAnyTemporaryBookmarkExist(): boolean {
    return this._bookmarksList.filter(bookmark => !!bookmark.parentId).length > 0;
  }

  // Find is any temporary bookmark exist
  public isCurrentBookmarkTemporary(): boolean {
    const bookmarkFound: Bookmark = this.selectedBookmark;
    return bookmarkFound && !!bookmarkFound.parentId;
  }

  public shareBookmark(bookmarkRequest: BookmarkRequest): void {
    console.debug('BookmarkService::shareBookmark::');
    this.http.post(this.urlConfig.EP_BOOKMARK_SHARE, bookmarkRequest).subscribe((response: boolean) => {
      if (response) {
        this.vizNotification.showMessage('Bookmark has been shared successfully.');
      }
    });
  }

  // =================== apis for add , delete , up date and retrive bookmark Ends ===========================

  // Get corresponding temporary bookmark of givin parent id
  private getCorrespondingTempBookmark(key: number): Bookmark {
    const correspondingBookmark: Bookmark = this._bookmarksList.find(bookmark => bookmark.parentId && bookmark.parentId === key);
    return correspondingBookmark;
  }

  // Get bookmark by bookmark key
  private getBookmarkByKey(id: number): Bookmark {
    return this._bookmarksList.find(bookmark => bookmark.key === id);
  }

  // Get bookmark by bookmark name
  private getBookmarkByName(name: string): Bookmark {
    return this._bookmarksList.find(bookmark => bookmark.name === name);
  }
  // Sort bookmark list by updated timestamp
  private sortBookmarkList(): void {
    this._bookmarksList = this._bookmarksList.sort((a: Bookmark, b: Bookmark) => {
      if (a.lastAccessTime === b.lastAccessTime) {
        return 0;
      } else if (a.lastAccessTime < b.lastAccessTime) {
        return 1;
      } else {
        return -1;
      }
    });
  }

  private informBookmarkListListener(): void {
    this._bookmarkList$.next(this._bookmarksList);
    if (this._bookmarksList[0]) {
      this.selectedBookmark = this._bookmarksList[0];
    }
  }

  // Remove temporary bookmark from UI
  private removeTemporaryBookmarkFromUI(): void {
    this._bookmarksList = this._bookmarksList.filter((bookmark: Bookmark) => !bookmark.parentId);
    this.sortBookmarkList();
  }

  // Restore bookmark in UI
  private restoreBookmarkInUI(restoreBookmakrs: Bookmark[]): void {
    this._bookmarksList = this._bookmarksList.concat(restoreBookmakrs);
    this.informBookmarkListListener();
  }

  private alertUserIfChartExist(listOfCharts: string[]): void {
    console.debug('BookmarkService::alertUserIfChartExist::', listOfCharts);
    const dialogRef = this.dialog.open(ChartConfirmationDialogComponent, {
      panelClass: 'confirm-dailog-container',
      data: listOfCharts
    });

    dialogRef.afterClosed().subscribe((action: any) => {
      console.debug('BookmarkService::alertUserIfChartExist::Subscribe::', action);
    });
  }
}
// public isCurrentBookmarkModified(data: SearchField[]): boolean {
//   const props: string[] = ['filtered', 'distinctRequired', 'key', 'filterOnlyFlag'];
//   const isObjectEqual = lodash.isEqual(
//     CommonUtils.omitFalsyAndProps(this.selectedBookmarkCriteria || [], props, true),
//     CommonUtils.omitFalsyAndProps(data, props, true)
//   );

//   return !isObjectEqual;
// }

// // On search bookmark creation and updation handling
// public onSearchCreateOrModifyBookmark(data: SearchField[]) {
//   console.debug('BookmarkService:: createOrModifyBookmark ', this.selectedBookmarkKey, this._bookmarksList);

//   console.debug(
//     'BookmarkService:: createOrModifyBookmark ',
//     this.selectedBookmarkKey,
//     !this.isAnyBookmarkExist(),
//     this.isDefaultBookmarkSelected(),
//     this.isCurrentBookmarkModified(data),
//     this.isModifiedBookmarkTemporary()
//   );
//   const ADD: string = 'add';
//   const UPDATE: string = 'update';

//   if (!this.isAnyBookmarkExist() || (!this.isDefaultBookmarkExist() && this.selectedBookmarkKey === -1)) {
//     const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
//     bookmarkRequest.bookmarkData = data;
//     bookmarkRequest.bookmarkName = defalutSettingsName;
//     bookmarkRequest.userId = this.userId;
//     // this.wrapperAddBookmark(bookmarkRequest);
//     this.find(bookmarkRequest, ADD);
//   } else {
//     if (this.isDefaultBookmarkSelected() || this.selectedBookmarkKey === -1) {
//       // As we already checked, current selected bookmark is default, that means we can use same selected bookmark key which is pointing to default
//       // And Even in selected default case, if bookmark modifed, we want to override it anyway.
//       const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
//       bookmarkRequest.bookmarkData = data;
//       bookmarkRequest.bookmarkId = this.getDefaultBookmarkKey();
//       bookmarkRequest.isSilent = true;
//       bookmarkRequest.userId = this.userId;
//       // this.wrapperUpdateBookmark(bookmarkRequest);
//       this.find(bookmarkRequest, UPDATE);
//       this.selectedBookmarkKey = this.getDefaultBookmarkKey();
//     } else {
//       // Now we need to check bookmark is modified or not
//       if (this.isCurrentBookmarkModified(data)) {
//         // const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
//         // bookmarkRequest.addSearchCriteria(data);
//         // bookmarkRequest.bookmarkId = this.getDefaultBookmarkKey();
//         // bookmarkRequest.isSilent = true;
//         // this.wrapperUpdateBookmark(bookmarkRequest);
//         // this.selectedBookmarkKey = this.getDefaultBookmarkKey();
//         // Disabling temporary bookmark creation, as voyager integration has problems
//         // DON"T REMOVE THIS COMMENTED CODE
//         // If modifed bookmark is temporary, then simply update it
//         if (this.isModifiedBookmarkTemporary()) {
//           const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
//           bookmarkRequest.bookmarkData = data;
//           bookmarkRequest.bookmarkId = this.selectedBookmarkKey;
//           bookmarkRequest.isSilent = true;
//           bookmarkRequest.userId = this.userId;
//           // this.wrapperUpdateBookmark(bookmarkRequest);
//           this.find(bookmarkRequest, UPDATE);
//         } else {
//           const tempBookmark = this.getCorrespondingTempBookmark(this.selectedBookmarkKey);
//           console.debug('BookmarkService:: createOrModifyBookmark::tempBookmark:: ', tempBookmark);
//           if (tempBookmark) {
//             const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
//             bookmarkRequest.bookmarkData = data;
//             bookmarkRequest.bookmarkId = tempBookmark.key;
//             bookmarkRequest.isSilent = true;
//             bookmarkRequest.userId = this.userId;
//             // this.wrapperUpdateBookmark(bookmarkRequest);
//             this.find(bookmarkRequest, UPDATE);
//             this.updateBookmarkKeyAndNotifyListener(tempBookmark.key);
//           } else {
//             // If modified bookmark is not temporary, then create new temporary bookmark.
//             const bookmark = this.getBookmarkByKey(this.selectedBookmarkKey);
//             const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
//             bookmarkRequest.bookmarkData = data;
//             bookmarkRequest.parentBookmarkId = this.selectedBookmarkKey;
//             bookmarkRequest.bookmarkName = bookmark.name + '_temp';
//             bookmarkRequest.userId = this.userId;
//             // this.wrapperAddBookmark(bookmarkRequest);
//             this.find(bookmarkRequest, ADD);
//           }
//         }
//       } else {
//         const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
//         bookmarkRequest.bookmarkData = data;
//         bookmarkRequest.bookmarkId = this.selectedBookmarkKey;
//         bookmarkRequest.isSilent = true;
//         bookmarkRequest.userId = this.userId;
//         // If bookmark is not modifed, then simply update it
//         // this.wrapperUpdateBookmark(bookmarkRequest);
//         this.find(bookmarkRequest, UPDATE);
//       }
//     }
//   }
// }

// Small interal API to know states of bookmark

// Get default bookmark id
// private getDefaultBookmarkKey(): number {
//   const deafultBookmark: Bookmark = this._bookmarksList.find(bookmark => bookmark.name && bookmark.name === defalutSettingsName);
//   if (deafultBookmark) {
//     return deafultBookmark.key;
//   }
//   return -1;
// }

// // Find is bookmark list is empty
// private isAnyBookmarkExist(): boolean {
//   return this._bookmarksList ? this._bookmarksList.length > 0 : false;
// }

// // is Currently default bookmark selected
// private isModifiedBookmarkTemporary(): boolean {
//   const selectedBookmark: Bookmark = this.getBookmarkByKey(this.selectedBookmarkKey);
//   console.debug('BookmarkService::isModifiedBookmarkTemporary', selectedBookmark, selectedBookmark && selectedBookmark.parentId);
//   return !!(selectedBookmark && selectedBookmark.parentId);
// }

// // is Currently default bookmark selected
// private isDefaultBookmarkSelected(): boolean {
//   const selectedBookmark: Bookmark = this.getBookmarkByKey(this.selectedBookmarkKey);
//   return selectedBookmark && selectedBookmark.name === defalutSettingsName;
// }

// // is Currently default bookmark selected
// private isDefaultBookmarkExist(): boolean {
//   const correspondingBookmark: Bookmark = this._bookmarksList.find(bookmark => bookmark && bookmark.name === defalutSettingsName);
//   return !!correspondingBookmark;
// }
