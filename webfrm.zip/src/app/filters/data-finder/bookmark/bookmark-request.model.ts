import { SearchField } from '@aqua/filters/models';
import { CommonUtils } from '@aqua/util';

export class BookmarkRequest {
  private static transformBookmarkState(list: SearchField[]): any[] {
    console.debug('BookmarkRequest::transformBookmarkState');
    return list.map(item => ({ key: item.key, value: item.value || '', whoHasFlag: item.whoHasFlag }));
  }

  /*
   * @deprecated, We are removing user id for eahc request
   */
  // TODO: Remove user id for request
  public userId: string;

  // TODO: Remove search Criteria from this request
  public searchCriteria: SearchField[];

  public bookmarkId: number;
  public bookmarkName: string;
  public parentBookmarkId: number;
  public sharedUserId: string;

  // Acutal bookmark, which hold key, value and who has flag
  public set bookmarkData(_bookmarkData: SearchField[]) {
    this._bookmarkData = BookmarkRequest.transformBookmarkState(_bookmarkData);
    this.searchCriteria = CommonUtils.deepClone(_bookmarkData);
  }
  public get bookmarkData() {
    return this._bookmarkData;
  }
  private _bookmarkData: any[];

  // Below are UI only fields, not for backend.
  // tslint:disable-next-line:member-ordering
  public isSilent: boolean = false;
  // tslint:disable-next-line:member-ordering
  public isReload: boolean = false;

  public toJSON() {
    return {
      userId: this.userId,
      searchCriteria: this.searchCriteria,
      bookmarkId: this.bookmarkId,
      bookmarkName: this.bookmarkName,
      parentBookmarkId: this.parentBookmarkId,
      bookmarkData: this.bookmarkData,
      sharedUserId: this.sharedUserId
    };
  }
}
