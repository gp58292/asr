import { ChangeDetectionStrategy, Component, EventEmitter, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { MatDialog, MatSelectChange } from '@angular/material';
import { BookmarkRequest } from '@aqua/filters/data-finder/bookmark/bookmark-request.model';
import { BookmarkService } from '@aqua/filters/data-finder/bookmark/bookmark.service';
import { DialogSaveAsComponent } from '@aqua/filters/data-finder/bookmark/dialog-save-as/dialog-save-as.component';
import { DialogShareComponent } from '@aqua/filters/data-finder/bookmark/dialog-share/dialog-share.component';
import { ConfirmationDialogComponent } from '@aqua/filters/data-finder/confirmation-dialog/confirmation-dialog.component';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import { Bookmark } from '@aqua/filters/models';
import { SearchResultDataSetBookmark } from '@aqua/filters/models/search-result-bookmark-dataset.model';
import { TabsSearchService } from '@aqua/filters/services';
import { DataTreeStorageService } from '@aqua/filters/services/datatree-storage.service';
import { FiltersService } from '@aqua/filters/services/filters.service';
import { SearchPlusBookmarkService } from '@aqua/filters/services/search-plus-bookmark.service';
import { VizNotificationService } from '@aqua/services/viz-notification.service';
import { Subject } from 'rxjs';
import { filter, shareReplay, takeUntil } from 'rxjs/operators';

@Component({
  selector: 'bookmark-panel',
  templateUrl: './bookmark.component.html',
  styleUrls: ['./bookmark.component.scss'],
  encapsulation: ViewEncapsulation.Emulated,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class BookmarkComponent implements OnInit {
  public set selectedBookmark(bookmark: Bookmark) {
    console.debug('BookmarkComponent::selectedBookmark::', bookmark);
    this.bookmarkService.selectedBookmark = bookmark;
  }
  public get selectedBookmark() {
    // console.debug('BookmarkComponent::GET::selectedBookmark::', this.bookmarkService.selectedBookmark);
    return this.bookmarkService.selectedBookmark;
  }

  @Output() public change = new EventEmitter<any>();

  public readonly bookmarks$ = this.bookmarkService.bookmarkList$.pipe(
    filter((bookmarkList: Bookmark[]) => bookmarkList && bookmarkList.length > 0),
    shareReplay(1)
  );

  private alive: Subject<void> = new Subject();

  constructor(
    private bookmarkService: BookmarkService,
    private vizNotification: VizNotificationService,
    private dialog: MatDialog,
    private searchService: SearchService,
    private dataStorageTreeService: DataTreeStorageService,
    private filtersService: FiltersService,
    private searchPlusBookmark: SearchPlusBookmarkService,
    private tabsSearchService: TabsSearchService
  ) {
    console.debug('BookmarkComponent::constructor');
    this.listenSearchResult();
  }

  public ngOnInit() {
    console.debug('BookmarkComponent::ngOnInit::');
    this.bookmarkService.loadAllBookmarks();
  }

  public compareBookmarks(o1: Bookmark, o2: Bookmark): boolean {
    return o1 && o2 && o1.key === o2.key;
  }
  public get activeBookmark$() {
    return this.bookmarkService.activeBookmark$();
  }

  public openConfirmationDialog() {
    const isTemporary: boolean = this.bookmarkService.isCurrentBookmarkTemporary();
    this.dialog
      .open(ConfirmationDialogComponent, {
        panelClass: 'confirm-dailog-container',
        data: {
          confirmationMessage: isTemporary
            ? 'Are you sure you want to delete temporary and load original bookmark?'
            : 'Are you sure you want to delete bookmark?'
        },
        disableClose: false
      })
      .afterClosed()
      .subscribe(result => {
        if (result) {
          // do confirmation actions
          if (this.selectedBookmark) {
            this.deleteBookmark(this.selectedBookmark.key);
          } else {
            this.vizNotification.showError('Unable to delete bookmark as no bookmark is selected');
          }
        }
      });
  }

  public onBookmarkChange(matSelectChange: MatSelectChange) {
    console.debug('BookmarkComponent::onSearchCriteriaChange : ', matSelectChange.value);
    // this.loadBookmark(matSelectChange.value);
    this.change.emit(matSelectChange.value);
  }

  public clearBookmarkState() {
    console.debug('BookmarkComponent::onSearchCriteriaChange : ');
    this.dataStorageTreeService.clearAllFilters();
    this.selectedBookmark = undefined;
    // this.bookmarkService.loadBookmark(this.selectedBookmarkKey);
  }

  public onNewBookmark() {
    console.debug('BookmarkComponent::onNewBookmark');
    this.clearBookmarkState();
    this.change.emit();
  }

  public deleteBookmark(id: number) {
    console.debug('BookmarkComponent::deleteBookmark');
    this.bookmarkService.deleteBookmark(id, bookmarkId => this.change.emit());
  }

  public onSaveAs(title?: string, newBookmarkName?: string, isDefault: boolean = false) {
    console.debug('BookmarkComponent::onSaveAs');

    const dialogRef = this.dialog.open(DialogSaveAsComponent, {
      panelClass: 'confirm-dailog-container',
      data: {
        name: '',
        bookmarkName: newBookmarkName,
        type: title ? title : 'Save Bookmark As'
      }
    });

    dialogRef.afterClosed().subscribe((bookmarkName: string) => {
      console.debug(
        'BookmarkComponent::onSaveAs::The dialog was closed, user has enter criteriaName as :' + bookmarkName,
        this.bookmarkService.isBookmarkNameExist(bookmarkName)
      );
      if (bookmarkName) {
        bookmarkName = bookmarkName.trim();
        if (bookmarkName !== '') {
          if (this.bookmarkService.isBookmarkNameExist(bookmarkName)) {
            this.vizNotification.showError('Such Bookmark name is already exists, please choose another name');
          } else {
            console.debug(
              'BookmarkComponent::onSaveAs::The dialog was closed, user has enter criteriaName as :',
              bookmarkName,
              this.bookmarkService.isBookmarkNameExist(bookmarkName)
            );
            if (!isDefault) {
              const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
              bookmarkRequest.bookmarkData = this.filtersService.filtersList;
              bookmarkRequest.bookmarkName = bookmarkName;
              bookmarkRequest.isReload = true;

              this.bookmarkService.wrapperAddBookmark(bookmarkRequest);
            } else {
              const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
              bookmarkRequest.bookmarkData = this.filtersService.filtersList;
              bookmarkRequest.bookmarkId = this.selectedBookmark.key;
              bookmarkRequest.bookmarkName = bookmarkName;
              bookmarkRequest.isReload = true;
              this.bookmarkService.wrapperUpdateBookmark(bookmarkRequest);
            }
          }
        } else {
          this.vizNotification.showError('Bookmark name can not be blank');
        }
      }
    });
  }

  public onShare(title?: string, sharedUserId?: string, isDefault: boolean = false) {
    console.debug('BookmarkComponent::onShare');

    const dialogRef = this.dialog.open(DialogShareComponent, {
      panelClass: 'confirm-dailog-container',
      data: {
        name: '',
        // tslint:disable-next-line:object-literal-shorthand
        sharedUserId: sharedUserId,
        type: title ? title : 'Share Bookmark with'
      }
    });

    dialogRef.afterClosed().subscribe((sharedUserId: string) => {
      console.debug(
        'BookmarkComponent::onShare::The dialog was closed, user has enter criteriaName as :' + sharedUserId
        // this.bookmarkService.isBookmarkNameExist(bookmarkName)
      );
      if (sharedUserId) {
        sharedUserId = sharedUserId.trim();
        if (sharedUserId !== '') {
          // if (this.bookmarkService.isBookmarkNameExist(sharedUserId)) {
          //  this.vizNotification.showError('Such Bookmark name is already exists, please choose another name');
          // } else {
          const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
          bookmarkRequest.bookmarkData = this.filtersService.filtersList;
          bookmarkRequest.bookmarkName = this.selectedBookmark.name;
          bookmarkRequest.sharedUserId = sharedUserId;
          bookmarkRequest.bookmarkId = this.selectedBookmark.key;
          this.bookmarkService.shareBookmark(bookmarkRequest);
          console.debug('BookmarkComponent::onShare::shareBookmark called with:', this.selectedBookmark.key, sharedUserId);
        } else {
          this.vizNotification.showError('User soeid can not be blank');
        }
      }
    });
  }
  public onSave() {
    const bookmark: Bookmark = this.bookmarkService.getDefaultBookmarkIfSelected();

    console.debug('BookmarkComponent::onSave', bookmark, this.selectedBookmark, this.bookmarkService.isCurrentBookmarkTemporary());
    if (bookmark) {
      this.onSaveAs('Save Bookmark', bookmark.name, true); // Show bookmark dialog so user can enter a name
    } else if (!this.selectedBookmark) {
      this.onSaveAs('Save Bookmark', ''); // Show bookmark dialog so user can enter a name
    } else if (this.bookmarkService.isCurrentBookmarkTemporary()) {
      // TODO :: Write confirmation dialog before replacing original with temporary

      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        panelClass: 'confirm-dailog-container',
        data: { confirmationMessage: 'Do you want to override original version and delete temporary bookmark' },
        disableClose: false
      });

      dialogRef.afterClosed().subscribe((result: any) => {
        // console.debug("BookmarkComponent::onSave:: Bookmark Replace::", result);
        if (result) {
          const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
          bookmarkRequest.bookmarkData = this.filtersService.filtersList;
          bookmarkRequest.bookmarkId = this.selectedBookmark.key;
          this.bookmarkService.updateOriginalAndDeleteTemporaryBookmark(bookmarkRequest);
        }
      });
    } else {
      const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
      bookmarkRequest.bookmarkData = this.filtersService.filtersList;
      bookmarkRequest.bookmarkId = this.selectedBookmark.key;

      this.bookmarkService.wrapperUpdateBookmark(bookmarkRequest);
    }
  }

  // Delete temporary bookmarks
  public deleteTemporary(): void {
    console.debug('BookmarkComponent::deleteTemporary::');
    if (this.bookmarkService.isAnyTemporaryBookmarkExist()) {
      this.dialog
        .open(ConfirmationDialogComponent, {
          panelClass: 'confirm-dailog-container',
          data: {
            confirmationMessage: 'Do you really want to delete all temporary bookmarks?'
          },
          disableClose: false
        })
        .afterClosed()
        .subscribe(result => {
          if (result) {
            this.bookmarkService.deleteTempBookmarkWrapper();
          }
        });
    } else {
      this.vizNotification.showError('No temporary bookmarks available to delete');
    }
  }

  // Restore temporary bookmarks
  public restoreTemporary(): void {
    console.debug('BookmarkComponent::restoreTemporary::');
    this.bookmarkService.restoreAllBookmarkByUserId();
  }

  public ngOnDestroy() {
    this.alive.next();
    this.alive.complete();
    this.alive.unsubscribe();
  }

  private listenSearchResult(): void {
    this.searchPlusBookmark.searchInitiateObervable$
      .pipe(
        filter((searchResult: any) => this.tabsSearchService.isListedTabActive), // Only listen on first tab where bookmark available
        takeUntil(this.alive)
      )
      .subscribe((searchResult: SearchResultDataSetBookmark) => {
        console.debug('BookmarkComponent::listenSearchResult::', searchResult.bookmarkWithStatus);
        if (searchResult && searchResult.bookmarkWithStatus) {
          // Incase silentet update, then we don't
          if (searchResult.bookmarkWithStatus.bookmarkStatus === 'SAVED') {
            console.debug('BookmarkComponent::listenSearchResult::SAVED::', searchResult.bookmarkWithStatus.bookmark);
            this.bookmarkService.addBookmarkInUI(searchResult.bookmarkWithStatus.bookmark);
            if (searchResult.bookmarkWithStatus.bookmark) {
              this.vizNotification.showMessage('Successfully created new bookmark');
            }
          } else {
            console.debug('BookmarkComponent::listenSearchResult::UPDATED', searchResult.bookmarkWithStatus.bookmark);
            this.bookmarkService.updateBookmarkInUI(searchResult.bookmarkWithStatus.bookmark);
            if (searchResult.bookmarkWithStatus.bookmark && searchResult.bookmarkWithStatus.bookmarkStatus) {
              this.vizNotification.showMessage('Successfully updated bookmark');
            }
          }
        }
      });
  }
}
