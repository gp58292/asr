import { Component, Inject } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";

@Component({
	selector: "dataviz-dialog-share",
	templateUrl: "./dialog-share.component.html",
	styleUrls: ["./dialog-share.component.scss"]
})
export class DialogShareComponent {
	constructor(
		public dialogRef: MatDialogRef<DialogShareComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any
	) { }

	public onNoClick(): void {
		this.dialogRef.close();
	}
}
