import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'ceft-chart-confirmation',
  templateUrl: './chart-confirmation-dialog.component.html',
  styleUrls: ['./chart-confirmation-dialog.component.scss']
})
export class ChartConfirmationDialogComponent {
  constructor(public dialogRef: MatDialogRef<ChartConfirmationDialogComponent>, @Inject(MAT_DIALOG_DATA) public chartsData: any) {
    console.debug('ChartConfirmationDialogComponent::constructor::', chartsData);
  }
}
