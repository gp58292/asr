import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { GridUtils } from '@aqua/aqua-component/aqua-grid/utils';
import { BookmarkService } from '@aqua/filters/data-finder/bookmark';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import { UserDataset } from '@aqua/filters/models';
import { FilterCancelService, FiltersService, TabsSearchService } from '@aqua/filters/services';
import { SearchPlusBookmarkService } from '@aqua/filters/services/search-plus-bookmark.service';
import { CeftDataSetStatus, DataSet } from '@aqua/models';
import { ComponentInstanceService, VizNotificationService } from '@aqua/services';
import { FrmCommunicationHandlerService } from '@aqua/services/frm-communication-handler.service';
import { MatProgressButtonOptions } from 'mat-progress-buttons';
import { Observable, Subject, Subscription } from 'rxjs';
import { finalize, map, shareReplay, takeUntil } from 'rxjs/operators';

import { SearchReferenceService } from '../../services/search-reference.service';
import { SearchComponent } from '../search/search.component';

@Component({
  selector: 'filter-panel',
  templateUrl: './filter-panel.component.html',
  styleUrls: ['./filter-panel.component.scss']
})
export class FilterPanelComponent implements OnInit, AfterViewInit {
  public resultsExpanded: boolean = false;
  public filtersExpanded: boolean = true;
  public resultSetCount: number;
  public eligibleContractCount: number;
  public cobDate: string | Date;
  public isFiltersViewMode$ = this.filtersService.listenFiltersViewMode$().pipe(shareReplay());
  public hasFilters$ = this.filtersService.listenFiltersList$().pipe(
    map(filtersList => filtersList.length > 0),
    shareReplay()
  );
  public bookmarkIsLoad$ = this.bookmarkService.bookmarkIsLoad$.pipe(shareReplay(1));

  // public userDatasets: UserDataset[] = [];
  public userDatasetsSrc: UserDataset[] = [];
  public isLoadingDataSets: boolean = false;
  public currentDataset: DataSet;
  public spinnerButtonOptions: MatProgressButtonOptions = {
    active: false,
    text: 'Export',
    spinnerSize: 18,
    raised: false,
    stroked: false,
    buttonColor: '',
    spinnerColor: 'warn',
    fullWidth: false,
    disabled: false,
    mode: 'indeterminate'
  };

  public userDatasets$: Observable<UserDataset[]>;

  // @ViewChild('voyagerLinksButton')
  // set fetchVoyagerLinkButton(button: ElementRef) {
  //   console.debug('FilterPanelComponent::ViewChild::fetchVoyagerLinkButton::', button);
  //   if (!!button && this._voyagerLinksButton !== button) {
  //     this._voyagerLinksButton = button;
  //     console.debug('FilterPanelComponent::ViewChild::fetchVoyagerLinkButton::NewInstance::', button.nativeElement);
  //     fromEvent(button.nativeElement, 'click').pipe(
  //       tap((event: Event) => console.debug('FilterPanelComponent::userDatasets$::', event)),
  //       startWith((this.isLoadingDataSets = true)),
  //       switchMap((event: Event) => {
  //         return this.searchService.getUserDataset(this.bookmarkService.activeBookmark.key).pipe(
  //           takeUntil(this.alive),
  //           map((userDatasets: UserDataset[]) => this.filterVoyagerLinks(userDatasets)),
  //           finalize(() => (this.isLoadingDataSets = false)),
  //           shareReplay(1)
  //         );
  //       })
  //     );
  //   }
  // }

  @ViewChild('aquaSearch') private aquaSearchRef: SearchComponent;

  private alive: Subject<void> = new Subject();
  // Keep active data exporting subscription. So we can cancel it
  private exportingSubscription: Subscription = null;

  // -------------------------------------------------------------------------------------------------------------------
  constructor(
    private searchReferenceService: SearchReferenceService,
    private searchService: SearchService,
    private filterCancelService: FilterCancelService,
    private filtersService: FiltersService,
    private vizNotification: VizNotificationService,
    private searchPlusBookmarkService: SearchPlusBookmarkService,
    private frmCommunicationHandlerService: FrmCommunicationHandlerService,
    public tabsSearchService: TabsSearchService,
    private bookmarkService: BookmarkService,
    public dialog: MatDialog,
    private componentInstanceService: ComponentInstanceService
  ) {
    console.debug('FilterPanelComponent::constructor');
    this.componentInstanceService.component=this;
  }

  public ngOnInit() {
    console.debug('FilterPanelComponent::ngOnInit');
    this.resultChangeListener();
    this.searchReferenceService.getCOBDate().subscribe(response => {
      console.debug('FilterPanelComponent::resultChangeListener::Got cobDate response::', response);
      if (response) {
        this.cobDate = response;
        console.debug('FilterPanelComponent::resultChangeListener::Got cobDate::', this.cobDate);
      }
    });
  }
  public ngAfterViewInit() {
    // console.debug('FilterPanelComponent::ngAfterViewInit::', this.fetchVoyagerLinkButton);
    // this.userDatasets$ = fromEvent(this.fetchVoyagerLinkButton, 'click').pipe(
    //   tap((event: Event) => console.debug('FilterPanelComponent::userDatasets$::', event)),
    //   startWith((this.isLoadingDataSets = true)),
    //   switchMap((event: Event) => {
    //     return this.searchService.getUserDataset(this.bookmarkService.activeBookmark.key).pipe(
    //       takeUntil(this.alive),
    //       map((userDatasets: UserDataset[]) => this.filterVoyagerLinks(userDatasets)),
    //       finalize(() => (this.isLoadingDataSets = false)),
    //       shareReplay(1)
    //     );
    //   })
    // );
  }

  public ngOnDestroy() {
    this.alive.next();
    this.alive.complete();
    this.alive.unsubscribe();
  }

  public onChangeBookmark() {
    this.switchEditMode(false);
  }

  public pullDataSetId(): void {
    console.debug('FilterPanelComponent::pullDataSetId::');

    this.userDatasets$ = this.searchReferenceService.getUserDataset(this.bookmarkService.activeBookmark.key).pipe(
      takeUntil(this.alive),
      map((userDatasets: UserDataset[]) =>
        userDatasets.filter(
          (dataSet: UserDataset) => dataSet.shortName !== (!this.tabsSearchService.isFilteredSearch ? 'curr_post_filtered' : 'curr_post')
        )
      ),
      finalize(() => (this.isLoadingDataSets = false)),
      shareReplay(1)
    );
  }

  public onClickSearch() {
    this.filtersService.setFiltersViewMode(true);
    this.resultsExpanded = true;
    this.aquaSearchRef.doSearch();
  }

  public onClickReset() {
    this.aquaSearchRef.openConfirmationDialog();
  }

  public onClickEditFilter() {
    this.switchEditMode();
  }

  public onExportData() {
    if (this.isExportInProgress()) {
      // cancel active data exporting
      this.exportingSubscription.unsubscribe();
      this.vizNotification.showWarning('Export To Excel has been canceled');
    } else {
      // start data exporting
      // using object for export file to manipulate its name in service
      const exportFile: { name: string } = { name: 'CEFT_' + new Date().toISOString().slice(0, 10) };

      this.beforeDataExport();
      this.exportingSubscription = this.searchService
        .exportData(exportFile, this.resultSetCount, this.tabsSearchService.activeTabInfo.dataSetRequest)
        .pipe(finalize(() => this.afterDataExport()))
        .subscribe((response: any) => {
          if (response) {
            GridUtils.downloadCSV(response, exportFile.name);
          } else {
            this.vizNotification.showError('Exception in Export To Excel');
          }
        });
    }
  }

  public onVoyagerNavigate(event, datasets) {
    if (datasets.length > 4) {
      event.stopPropagation();
      return;
    } else if (datasets.length === 0) {
      return;
    }

    const TEMP_CONST_VOYAGER_CLIENT_NAME = 'frm-data-exp-client';
    const TEMP_CONST_PORTAL_CLIENT_NAME = 'frm-portal-client';
    const TEMP_CONST_VOYAGER_NAME_IN_PORTAL_APP = 'data_exp';
    const TEMP_CONST_CEFT_DATA_PROVIDER_ID = 'CEFT_SPROC';

    const voyagerNavigationPayload = JSON.stringify(
      datasets.map(dataset => ({
        datasetId: `ceft_${dataset.value.bookmarkId}_${dataset.value.shortName}`,
        datasetProvider: TEMP_CONST_CEFT_DATA_PROVIDER_ID
      }))
    );

    // Check if the application is running in a standalone mode.
    // @todo Postponed navigation.
    // if (window.parent === window) {
    //   // Temp stub.
    //   const VOYAGER_URL = 'VOYAGER_URL';
    //   const httpParams = new HttpParams({ fromObject: { 'frm-datasets': voyagerNavigationPayload } });
    //   window.open(`${VOYAGER_URL}?${httpParams.toString()}`, '_blank');
    //   return;
    // }

    // Ask Portal to mount Voyager Application.
    this.frmCommunicationHandlerService.emit({
      destinationApplicationId: TEMP_CONST_PORTAL_CLIENT_NAME,
      command: 'navigate',
      payload: `appId=${TEMP_CONST_VOYAGER_NAME_IN_PORTAL_APP}`
    });

    // Ask Voyager Application to open the dataset.
    this.frmCommunicationHandlerService.emit({
      destinationApplicationId: TEMP_CONST_VOYAGER_CLIENT_NAME,
      command: 'openDataset',
      payload: voyagerNavigationPayload
    });
  }

  /**
   * Check whether RWA Details data exporting in progress
   */
  private isExportInProgress() {
    return this.exportingSubscription && !this.exportingSubscription.closed;
  }

  private beforeDataExport() {
    this.spinnerButtonOptions.active = true;
    this.spinnerButtonOptions.text = 'Cancel Export';
  }

  private afterDataExport() {
    this.spinnerButtonOptions.active = false;
    this.spinnerButtonOptions.text = 'Export';
  }

  private switchEditMode(cancelCurrentSearch = true) {
    this.filtersService.setFiltersViewMode(false);
    this.filtersExpanded = true;
    this.resultsExpanded = false;
    // TODO::: When we cancels search application rxjs observable going in loop , check console logs
    // if (cancelCurrentSearch) {
    //   this.filterCancelService.cancelSubject();
    // }
  }

  private resultChangeListener(): void {
    this.searchPlusBookmarkService.searchResultDataReadyObervable$.pipe(takeUntil(this.alive)).subscribe((result: CeftDataSetStatus) => {
      console.debug('FilterPanelComponent::resultChangeListener::Got new result::', result);
      if (result) {
        // this.cobDate = 'NA';
        this.resultSetCount = result.total ? result.total : 0;
        // this.userDatasets = [];
        this.currentDataset = result.dataSet;
      }

      if (result.dataSet.type.toString() === 'listed') {
        console.debug('FilterPanelComponent::resultChangeListener::eligibleContractCount::', result.total);
        this.eligibleContractCount = result.total ? result.total : 0;
      }
    });
  }
}
