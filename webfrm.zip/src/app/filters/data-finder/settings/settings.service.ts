import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Group } from '@aqua/filters/models/group.model';
import { SearchField } from '@aqua/filters/models/search-field.model';
import { FiltersUrlConfig } from '@aqua/filters/services/filters-url-config.service';
import { Observable } from 'rxjs';
import { publishReplay, refCount } from 'rxjs/operators';

@Injectable()
export class SettingsService {
  constructor(private http: HttpClient, private urlConfig: FiltersUrlConfig) {}

  public getFilterListForFlatView(): Observable<SearchField[] | any> {
    console.debug('SettingsService::getFilterListForFlatView');
    return this.http.get(this.urlConfig.EP_SETTINGS_COLUMNS_LIST).pipe(
      publishReplay(1),
      refCount()
    );
  }

  public getFilterListForTreeView(): Observable<Group[] | any> {
    console.debug('SettingService::getFilterListForTreeView');
    return this.http.get(this.urlConfig.EP_SETTINGS_COLUMNS_TREE).pipe(
      publishReplay(1),
      refCount()
    );
  }

  // public saveUserSettings (userId: string, settingsName: string, selectedFieldsKeys: string[]): Observable<any> {
  //   console.debug('SettingService:: saveSettings ');
  //   return this.http.put(this.urlConfig.EP_SETTINGS_USER_COLUMNS, { userId, columnSettingName: settingsName, selectedFieldsKeys });
  // }
}
