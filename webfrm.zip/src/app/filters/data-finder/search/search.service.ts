import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoadingTypes, SearchBookmarkRequest, SearchResultModel, UILoadingStatus } from '@aqua/filters/models';
import { SearchField } from '@aqua/filters/models/search-field.model';
import { FilterCancelService, FiltersUrlConfig, LoadingNotificationsService } from '@aqua/filters/services';
import { DataSetRequest } from '@aqua/models';
import { Observable } from 'rxjs';
import { distinctUntilChanged, finalize, takeUntil } from 'rxjs/operators';

@Injectable()
export class SearchService {
  constructor(
    private http: HttpClient,
    private urlConfig: FiltersUrlConfig,
    private loadingNotificationsService: LoadingNotificationsService,
    private filterCancelService: FilterCancelService
  ) {
    console.debug('SearchService::constructor:: Loading Search Service ..................................');
  }

  public exportSearchResult(source: string, criteria: SearchField[], agreementKeys: number[]): Observable<any> {
    console.debug('SearchService::exportSearchResult');
    return this.http
      .post(this.urlConfig.EP_RESULT_EXPORT, { source, criteria, agreementKeys }, { responseType: 'blob' })
      .pipe(takeUntil(this.filterCancelService.getSubject()));
  }

  // -------------------------------------------------------------------------------------
  public requestDataset(bookmarkRequest: SearchBookmarkRequest): Observable<any> {
    console.debug('SearchService::requestDataset::');
    // this.loadingNotificationsService.dataLoading = new UILoadingStatus(LoadingTypes.SEARCH_REQUEST, true);
    return this.http.post(this.urlConfig.EP_REQUEST_DATASET, bookmarkRequest);
    // .pipe(finalize(() => (this.loadingNotificationsService.dataLoading = new UILoadingStatus(LoadingTypes.SEARCH_REQUEST, false))));

    // TODO ^ Finally block will be replaced once we create subscribe functionality.
  }

  public requestData(dataSetRequest: DataSetRequest): Observable<SearchResultModel | any> {
    console.debug('SearchService::requestData::');
    // this.loadingNotificationsService.dataLoading = new UILoadingStatus(LoadingTypes.DATA_REQUEST, true);
    return this.http.post(this.urlConfig.EP_RETRIEVE_DATASET, dataSetRequest).pipe(
      // takeUntil(this.filterCancelService.getSubject()),
      distinctUntilChanged(),
      finalize(() => (this.loadingNotificationsService.dataLoading = new UILoadingStatus(LoadingTypes.DATA_REQUEST, false)))
    );
    // TODO ^ Finally block will be replaced once we create subscribe functionality.
  }

  public exportData(fileName: { name: string }, resultSetCount: number, dataSetRequest: DataSetRequest): Observable<any> {
    console.debug('SearchService::requestData::');

    if (dataSetRequest) {
      // Removing paging parameters to load all data for export
      dataSetRequest = Object.assign({}, dataSetRequest);
      dataSetRequest.gridRequest.startRow = 0;
      dataSetRequest.gridRequest.endRow = resultSetCount;
      fileName.name = fileName.name + '_' + dataSetRequest.bookmarkId + '_' + dataSetRequest.type + '.csv';
      const requestOptionsArgs = { responseType: 'text/plain;charset=utf-8;' };
      return this.http.post(this.urlConfig.EP_EXPORT_DATASET + fileName.name, dataSetRequest, { responseType: 'text' });
    }
    return null;
  }
}
