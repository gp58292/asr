import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { MultiIncludeExcludeComponent } from "./multi-include-exclude.component";

describe("IncludeExcludeComponent", () => {
	let component: MultiIncludeExcludeComponent;
	let fixture: ComponentFixture<MultiIncludeExcludeComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [MultiIncludeExcludeComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(MultiIncludeExcludeComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
