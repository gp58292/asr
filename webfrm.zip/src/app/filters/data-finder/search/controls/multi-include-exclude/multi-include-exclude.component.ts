import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { Options } from '@aqua/aqua-component/models';
import { SearchField } from '@aqua/filters/models/search-field.model';
import { ReferenceDataService } from '@aqua/services/reference-data.service';
import { CommonUtils } from '@aqua/util';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'ceft-multi-include-exclude',
  templateUrl: './multi-include-exclude.component.html',
  styleUrls: ['./multi-include-exclude.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MultiIncludeExcludeComponent implements OnInit, OnDestroy {
  @Input('field')
  public field: SearchField;

  @Input() public form: FormGroup;

  public referenceData: Options[];
  private alive: Subject<void> = new Subject();

  constructor(private referenceDataService: ReferenceDataService, private _changeDetectorRef: ChangeDetectorRef) {
    // console.debug('MultiIncludeExcludeComponent::constructor');
  }

  public ngOnInit() {
    // console.debug('MultiIncludeExcludeComponent::ngOnInit');
    this.loadReferenceData();
  }

  public loadReferenceData() {
    // console.debug('MultiIncludeExcludeComponent::loadReferenceData', this.field);
    this.referenceDataService
      .getReferenceData(this.field.key)
      .pipe(takeUntil(this.alive))
      .subscribe((response: Options[]) => {
        this.referenceData = response;
        this._changeDetectorRef.markForCheck();
      });
  }

  public ngOnDestroy(): void {
    //     console.debug('MultiIncludeExcludeComponent::ngOnDestroy::');
    this.alive.next();
    this.alive.complete();
    this.alive.unsubscribe();
  }

  /**
   *  "number" css class when data type is numeric, integer, double
   *  "text" css class when data type is string
   *  "date" css class when data type is date
   */
  public getCssByType(type: FieldType) {
    return CommonUtils.getClassByDataType(type);
  }
}
