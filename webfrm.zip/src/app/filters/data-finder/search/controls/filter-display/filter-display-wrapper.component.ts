import {Component} from '@angular/core';
import { WhoCanWhoHas } from '@aqua/filters/filters.types';

@Component({
  selector: 'fiter-display-wrapper',
  template: `
    <div class="panels-wrapper">
      <div class="panel left">
        <div class="title">
          <label>Contractual Eligibility Filters</label>
        </div>
        <div class="panel-body">
          <derivz-filter-display [whoHas]="WhoCanWhoHas.CAN"></derivz-filter-display>
        </div>
      </div>

      <div class="panel right">
        <div class="title">
          <label>Actual Postings Filters</label>
        </div>
        <div class="panel-body">
          <derivz-filter-display [whoHas]="WhoCanWhoHas.HAS"></derivz-filter-display>
        </div>
      </div>
    </div>
  `,
  styles: [
      `
      :host {
        width: 60vw;
        height: 100%;
        min-width: 0;
        display: flex;
      }

      .panels-wrapper {
        display: flex;
        flex-direction: row;
        width: 100%;
      }

      .panels-wrapper .panel {
        display: flex;
        flex: 1 1 auto;
        height: 100%;
        border: 1px solid #99bdd9;
        flex-direction: column;
      }

      .panels-wrapper .panel.right{
        border-left: 5px solid #99bdd9;
      }
      
      .panels-wrapper .panel .title {
        height: 20px;
        line-height: 20px;
        border-bottom: 1px dotted #97999b;
        padding: 0 10px;
      }

      .panels-wrapper .panel .title label {
        font-weight: bold;
        color: #005aa1;
      }
      .panels-wrapper .panel .panel-body {
        overflow: auto;
      }

    `
  ]
})
export class FilterDisplayWrapperComponent{
  public readonly WhoCanWhoHas = WhoCanWhoHas;
}
