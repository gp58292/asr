import { Component, Input } from '@angular/core';
import { FormGroup, AbstractControl } from '@angular/forms';
import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { DropDownModel } from '@aqua/aqua-component/dropdown-range';
import { SearchField } from '@aqua/filters/models/search-field.model';
import { SearchReferenceService } from '@aqua/filters/services';
import { ReferenceDataService } from '@aqua/services/reference-data.service';
import { CommonUtils } from '@aqua/util';
import { Observable, of } from 'rxjs';
import { shareReplay } from 'rxjs/operators';

@Component({
  selector: 'ceft-event-rating',
  templateUrl: './event-rating.component.html',
  styleUrls: ['./event-rating.component.scss']
})
export class EventRatingComponent {
  // public get dropDown$() {
  //   return this.field ? this.referenceDataService.getReferenceData(this.field.key).pipe(shareReplay(1)) : of([]);
  // }
  @Input() public form: FormGroup;
  public dropDown$: Observable<DropDownModel[]> = of([]);

  // public readonly dropDown$ = this.referenceDataService.getReferenceData(this.field.key).pipe(shareReplay(1));
  public readonly ratingList$ = this.searchReferenceService.ratingList$;
  private _field: SearchField;
  // public readonly ratingListAndDropDown$ = combineLatest(this.dropDown$, this.ratingList$);
  constructor(private referenceDataService: ReferenceDataService, private searchReferenceService: SearchReferenceService) {}

  @Input('field')
  public set field(field: SearchField) {
    this._field = field;
    this.dropDown$ = this.referenceDataService.getReferenceData(this._field.key).pipe(shareReplay(1));
    // of([
    //   new DropDownModel(1, 'Aaa'),
    //   new DropDownModel(2, 'Aa1'),
    //   new DropDownModel(3, 'Aa2'),
    //   new DropDownModel(3, 'Aa3'),
    //   new DropDownModel(4, 'A1'),
    //   new DropDownModel(5, 'A2')
    // ]);
  }
  public get field() {
    return this._field;
  }
  /**
   *  "number" css class when data type is numeric, integer, double
   *  "text" css class when data type is string
   *  "date" css class when data type is date
   */
  public getCssByType(type: FieldType) {
    return CommonUtils.getClassByDataType(type);
  }

  public getErrorMessage() {
    // console.debug("NumberRangeComponent::getErrorMessage::");
    let msg: string = '';
    const eventRangeControl = this.form.controls[this.field.fieldName + '_' + this.field.key + '_' + this.field.whoHasFlag];
    switch (true) {
      case eventRangeControl.hasError('validateEventRating'):
        msg = 'Please enter valid range and  if range entered then must select period ';
        break;
      default:
        msg = '';
    }
    // console.debug("NumberRangeComponent::getErrorMessage::",msg);
    return msg;
  }

  public isErrorState(): boolean {
    const control: AbstractControl = this.form.controls[this.field.fieldName + '_' + this.field.key + '_' + this.field.whoHasFlag];
    // console.debug("EventRatingComponent::isErrorState::",control,(control && control.invalid && (control.dirty || control.touched)));
    return control && control.invalid && (control.dirty || control.touched);
  }
}
