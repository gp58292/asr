import { Component, Input } from '@angular/core';
import { AbstractControl, FormGroup } from '@angular/forms';
import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { SearchField } from '@aqua/filters/models/search-field.model';
import { CommonUtils } from '@aqua/util';

@Component({
  selector: 'derivz-number-range',
  templateUrl: './number-range.component.html',
  styleUrls: ['./number-range.component.scss']
})
export class NumberRangeComponent {
  @Input('field') public field: SearchField;

  @Input() public form: FormGroup;

  public getErrorMessage() {
    // console.debug("NumberRangeComponent::getErrorMessage::");
    let msg: string = '';
    const numberRangeControl = this.form.controls[this.field.fieldName + '_' + this.field.key + '_' + this.field.whoHasFlag];
    switch (true) {
      case numberRangeControl.hasError('validateNumberRange'):
        msg = 'Please enter valid range';
        break;
      default:
        msg = '';
    }
    // console.debug("NumberRangeComponent::getErrorMessage::",msg);
    return msg;
  }

  public isErrorState(): boolean {
    const control: AbstractControl = this.form.controls[this.field.fieldName + '_' + this.field.key + '_' + this.field.whoHasFlag];
    // console.debug("NumberRangeComponent::isErrorState::",control,(control && control.invalid && (control.dirty || control.touched)));
    return control && control.invalid && (control.dirty || control.touched);
  }

  /**
   *  "number" css class when data type is numeric, integer, double
   *  "text" css class when data type is string
   *  "date" css class when data type is date
   */
  public getCssByType(type: FieldType) {
    return CommonUtils.getClassByDataType(type);
  }
}
