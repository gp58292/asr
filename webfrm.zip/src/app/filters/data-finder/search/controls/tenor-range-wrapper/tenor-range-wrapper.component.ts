import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { SearchField } from '@aqua/filters/models/search-field.model';
import { CommonUtils } from '@aqua/util';

@Component({
	selector: "ceft-tenor-range-wrapper",
	templateUrl: "./tenor-range-wrapper.component.html",
	styleUrls: ["./tenor-range-wrapper.component.scss"]
})
export class TenorRangeComponent {
	@Input("field") public field: SearchField;

	@Input() public form: FormGroup;

  /**
   *  "number" css class when data type is numeric, integer, double
   *  "text" css class when data type is string
   *  "date" css class when data type is date
   */
  public getCssByType(type: FieldType) {
    return CommonUtils.getClassByDataType(type);
  }
}
