import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { DropDownModel } from '@aqua/aqua-component/dropdown-range';
import { SearchField } from '@aqua/filters/models/search-field.model';
import { ReferenceDataService } from '@aqua/services/reference-data.service';
import { CommonUtils } from '@aqua/util';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'derivz-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DropdownComponent implements OnInit, OnDestroy {
  @Input('field') public field: SearchField;
  @Input() public form: FormGroup;
  public referenceData: DropDownModel[];

  private alive: Subject<void> = new Subject();

  constructor(private referenceDataService: ReferenceDataService, private changeDetection: ChangeDetectorRef) {}

  public ngOnInit() {
    // console.debug('DropdownComponent::ngOnInit');
    // this.changeDetection.detach();
    this.loadReferenceData();
  }

  public loadReferenceData() {
    // console.debug('DropdownComponent::loadReferenceData', this.field);
    this.referenceDataService
      .getReferenceData(this.field.key)
      .pipe(takeUntil(this.alive))
      .subscribe((response: any) => {
        this.referenceData = response;
        this.changeDetection.markForCheck();
      });
  }
  public ngOnChanges(values) {
    // console.debug('DropdownComponent::ngOnChanges::', values, this.field, this.form);
    // this.changeDetection.detectChanges();
  }
  // ngAfterViewInit() {
  //   this.changeDetection.detectChanges();
  // }
  public ngOnDestroy() {
    this.alive.next();
    this.alive.complete();
    this.alive.unsubscribe();
  }

  /**
   *  "number" css class when data type is numeric, integer, double
   *  "text" css class when data type is string
   *  "date" css class when data type is date
   */
  public getCssByType(type: FieldType) {
    return CommonUtils.getClassByDataType(type);
  }
}
