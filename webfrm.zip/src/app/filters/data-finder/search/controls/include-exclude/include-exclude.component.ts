import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { Options } from '@aqua/aqua-component/models';
import { SearchField } from '@aqua/filters/models/search-field.model';
import { ReferenceDataService } from '@aqua/services/reference-data.service';
import { CommonUtils } from '@aqua/util/commons.util';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'derivz-include-exclude',
  templateUrl: './include-exclude.component.html',
  styleUrls: ['./include-exclude.component.scss']
})
export class IncludeExcludeComponent implements OnInit, OnDestroy {
  @Input('field')
  public field: SearchField;

  @Input() public form: FormGroup;

  public referenceData: Options[];
  private alive: Subject<void> = new Subject();

  constructor(private referenceDataService: ReferenceDataService) {
    // console.debug('IncludeExcludeComponent::constructor');
  }

  public ngOnInit() {
    // console.debug('IncludeExcludeComponent::ngOnInit');
    this.loadReferenceData();
  }

  public loadReferenceData() {
    console.debug('IncludeExcludeComponent::loadReferenceData', this.field);
    this.referenceDataService
      .getReferenceData(this.field.key)
      .pipe(takeUntil(this.alive))
      .subscribe((response: Options[]) => (this.referenceData = response));
  }

  public ngOnDestroy(): void {
    console.debug('IncludeExcludeComponent::ngOnDestroy::');
    this.alive.next();
    this.alive.complete();
    this.alive.unsubscribe();
  }

  /**
   *  "number" css class when data type is numeric, integer, double
   *  "text" css class when data type is string
   *  "date" css class when data type is date
   */
  public getCssByType(type: FieldType) {
    return CommonUtils.getClassByDataType(type);
  }
}
