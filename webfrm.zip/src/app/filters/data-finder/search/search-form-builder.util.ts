import { AbstractControl, FormControl, FormGroup } from '@angular/forms';
import { SearchField } from '@aqua/filters/models';

export class SearchFormBuilder {
  public static addOrReplaceControl(form: FormGroup, name: string, value: any) {
    const formControl: AbstractControl = form.get(name);
    // console.debug('SearchBuilder::addOrReplaceControl::: Control::', name, formControl, value);
    if (!!formControl) {
      //  console.debug('SearchBuilder::addOrReplaceControl::: Setting existing control::', name, formControl, value);
      // form.setControl(name, new FormControl(value))
      formControl.reset();
      formControl.setValue(value);
    } else {
      // console.debug('SearchBuilder::addOrReplaceControl::: Adding existing control::', name, form.get(name));
      form.addControl(name, new FormControl(value));
    }
  }

  public static toFormGroup(fields: SearchField[], form: FormGroup) {
    // console.debug('SearchBuilder::toFormGroup:::...', !form);
    if (!form) {
      const group: any = {};
      // console.debug('SearchBuilder::toFormGroup::: Adding New Form Controls again.');
      fields.forEach(field => {
        group[field.fieldName + '_' + field.key + '_' + field.whoHasFlag] = new FormControl(field.value);
        // console.debug('#### SearchBuilder::toFormGroup : other ::' + field.fieldName + '-' + field.key);
      });
      return new FormGroup(group);
    }

    // This include exclude will be removed, when include exclude component updated
    Object.keys(form.controls).forEach(key => {
      const item = fields.find((f: SearchField) => {
        return key === f.fieldName + '_' + f.key + '_' + f.whoHasFlag;
      });

      if (!item) {
        form.removeControl(key);
        // console.debug('SearchBuilder::toFormGroup::Not found removing control named [' + key + '] = ', item);
      }
    });
    fields.forEach(field => {
      SearchFormBuilder.addOrReplaceControl(form, field.fieldName + '_' + field.key + '_' + field.whoHasFlag, field.value);
    });
    form.updateValueAndValidity();
    // console.debug('SearchBuilder::toFormGroup::END::...', form.value, form.controls);

    return form;
  }

  /**
   * Field name is based on pattern {fieldName}_{key}_{whoHasFlag(0|1)} (defined by this.toFormGroup()).
   */
  public static testFieldNameByWhoCanFlag(fieldName: string) {
    // return /_0$/.test(fieldName);
    return fieldName.endsWith('_0');
  }

  /**
   * Field name is based on pattern {fieldName}_{key}_{whoHasFlag(0|1)} (defined by this.toFormGroup()).
   */
  public static testFieldNameByWhoHasFlag(fieldName: string) {
    // return /_1$/.test(fieldName);
    return fieldName.endsWith('_1');
  }
}
