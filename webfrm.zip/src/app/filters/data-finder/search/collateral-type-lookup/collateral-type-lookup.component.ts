import { Component, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ColumnsDefinitionGrid, FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { GridUtils } from '@aqua/aqua-component/aqua-grid/utils';
import { ConfirmationDialogComponent } from '@aqua/filters/data-finder/confirmation-dialog/confirmation-dialog.component';
import { GridColumnsDef, GridColumnsDefBuilder, SearchField } from '@aqua/filters/models';
import { LoadingNotificationsService } from '@aqua/filters/services';
import { VizNotificationService } from '@aqua/services';
import { GridOptions } from 'ag-grid-community';
import { Observable, Subject } from 'rxjs';
import { map, shareReplay, take, takeUntil, tap } from 'rxjs/operators';

import { SearchFormBuilder } from '../search-form-builder.util';
import { CollateralTypeLookupService } from './collateral-type-lookup.service';

@Component({
  selector: 'derivz-collateral-type-lookup',
  templateUrl: './collateral-type-lookup.component.html',
  styleUrls: ['./collateral-type-lookup.component.scss'],
  providers: [CollateralTypeLookupService]
})
export class CollateralTypeLookupComponent {
  @ViewChild('collateralLookupForm')
  set setForm(myForm: FormGroup) {
    console.debug('CollateralTypeLookupComponent::setForm::', myForm);
    if (myForm && this.previousForm !== myForm) {
      console.debug('CollateralTypeLookupComponent::setting new Form Instance::');
      this.previousForm = myForm;
    }
  }

  public get searchStatus$(): Observable<boolean> {
    return this.loadingNotificationsService.searchingStatus$;
  }
  public static readonly gridOptions: GridOptions = GridUtils.gridOptionsWithoutPivoting;

  public gridHeight: number = 40;
  public searchingStatus: boolean;
  public selectedRows: any[];
  public fields: SearchField[] = [];
  public displayColumn: ColumnsDefinitionGrid[] = [];

  public payLoad = '';
  public form: FormGroup;

  public lookupResultData: any[];

  public resultsExpanded = false;
  public filtersExpanded = true;

  public readonly collateralTypeLookupColumns$ = this.collateralTypeLookupService.getCollateralTypeLookupColumns().pipe(
    take(1),
    map((fields: SearchField[]) => {
      let displayColumn: ColumnsDefinitionGrid[] = [];
      if (fields) {
        const displayColumnHold: GridColumnsDef[] = [];
        const selectColumn: GridColumnsDef = new GridColumnsDefBuilder('Collateral Type Name', 'collateralTypeName')
          .isDefaultDisplay(true)
          .width(380)
          .fieldType(FieldType.STRING)
          .enableRowGroup()
          .build();
        displayColumnHold.push(selectColumn);

        this.fields = fields;

        this.fields.forEach((field: SearchField) =>
          displayColumnHold.push(
            new GridColumnsDefBuilder(field.name, field.fieldName)
              .fieldType(FieldType[field.dataType])
              .isDefaultDisplay(field.defaultSelected === 1)
              .enableRowGroup()
              .build()
          )
        );
        displayColumn = GridUtils.buildColumns(displayColumnHold, false, true);
        // displayColumn.push(ColumnDefaultGrid.checkbox);
        console.debug('CollateralTypeLookupComponent::loadReferenceData:: Data >> ', displayColumn, this.fields);
        this.renderSearchData(this.fields);
      }
      return displayColumn;
    }),
    tap((data: any) => console.debug('CollateralTypeLookupComponent::loadReferenceData:: TAP >> ', data)),
    shareReplay(1)
  );

  private alive: Subject<void> = new Subject<void>();

  /* REQUIRED: PERFORMANCE FIX: This is getting multiple times, so those many subscription are generating */
  private previousForm: FormGroup;

  constructor(
    private collateralTypeLookupService: CollateralTypeLookupService,
    private loadingNotificationsService: LoadingNotificationsService,
    private vizNotification: VizNotificationService,
    private dialog: MatDialog,
    private dialogRef: MatDialogRef<CollateralTypeLookupComponent>
  ) {}

  public getGridOptions() {
    return CollateralTypeLookupComponent.gridOptions;
  }

  public renderSearchData(responseData) {
    console.debug('CollateralTypeLookupComponent::listenBookmark::renderSearchData');

    if (this.form) {
      this.form.reset();
    }
    // If no fields exist in the response. Clear all the filters
    if (responseData.length === 0) {
      this.fields = [];
      return;
    }

    this.form = SearchFormBuilder.toFormGroup(responseData, this.form);
  }

  // ====================== Event Handlers ============================================

  // TODO : what about non standard values like exclude, range component
  // Needs to be further investigated as I did not create this onSearch function. It does search with those filters though if you examine network traffic
  public onSearchClick() {
    console.debug('CollateralTypeLookupComponent::onSearchClick');

    const criteria = this.getCurrentCriteria();
    this.payLoad = JSON.stringify(criteria);
    //  this.searchingStatus = true;
    this.collateralTypeLookupService.lookupCollateralType(criteria).subscribe((lookupResultData: any | any[]) => {
      if (lookupResultData) {
        this.lookupResultData = lookupResultData;
        this.vizNotification.showMessage('Collateral Type Name lookup data fetched successfully');
      }
    });
    this.resultsExpanded = true;
  }

  public onResetClick() {
    this.userConfirmation('Are you sure you want to reset Filter selection?', () => this.resetCallBack());
  }

  public resetCallBack() {
    const group: any = {};
    this.fields.forEach(field => {
      group[field.fieldName + '-' + field.key] = null;
    });
    this.form.patchValue(group);
    this.form.markAsTouched();
    this.form.reset();
  }

  public onCancel(): void {
    this.userConfirmation('Are you sure you want to Cancel Selection?', () => this.cancelCallBack());
  }

  public cancelCallBack() {
    this.dialogRef.close();
  }

  public userConfirmation(msg: string, callback: () => void) {
    this.dialog
      .open(ConfirmationDialogComponent, { width: '300px', data: { confirmationMessage: msg }, disableClose: false })
      .afterClosed()
      .pipe(takeUntil(this.alive))
      .subscribe(result => {
        if (result && callback) {
          callback();
        }
      });
  }

  public onApply(operation: string): void {
    if (this.selectedRows && this.selectedRows.length > 0) {
      const collateralTypeSet: Set<string> = new Set(this.selectedRows.map(item => item.collateralTypeName));
      const result: any[] = [];
      result.push(operation);
      result.push(collateralTypeSet);
      this.dialogRef.close(result);
    }
  }

  public onSelectedRows(selectedRows: any[]): void {
    this.selectedRows = selectedRows;
  }

  // ========= helper methods=============================
  public getCurrentCriteria(): SearchField[] {
    return this.fields.filter(field => field.value);
  }

  public ngOnDestroy() {
    console.debug('CollateralTypeLookupComponent::ngOnDestroy::', this.payLoad);
    this.alive.next();
    this.alive.complete();
    this.alive.unsubscribe();
    this.alive = undefined;
  }
}
