import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FilterCancelService, FiltersUrlConfig, LoadingNotificationsService } from '@aqua/filters/services';
import { CacheService } from '@aqua/services';
import { cloneDeep } from 'lodash';
import { of } from 'rxjs';
import { distinctUntilChanged, finalize, shareReplay, takeUntil, tap } from 'rxjs/operators';

@Injectable()
export class CollateralTypeLookupService {
  constructor(
    private http: HttpClient,
    private urlConfig: FiltersUrlConfig,
    private loadingNotificationsService: LoadingNotificationsService,
    private filterCancelService: FilterCancelService,
    private cacheService: CacheService
  ) {}

  public lookupCollateralType(criteria) {
    console.debug('CollateralTypeLookupService::searchCriteria');
    this.loadingNotificationsService.searchStarted = true;
    return this.http.post(this.urlConfig.EP_SEARCH_COLLATERAL_TYPE, { criteria }).pipe(
      takeUntil(this.filterCancelService.getSubject()),
      distinctUntilChanged(),
      finalize(() => (this.loadingNotificationsService.searchStarted = false))
    );
  }

  public getCollateralTypeLookupColumns() {
    const requestUrl: string = this.urlConfig.EP_SEARCH_COLLATERAL_TYPE;
    console.debug('CollateralTypeLookupService::getCollateralTypeLookupColumns' + requestUrl);
    const CACHE_KEY = 'LOOKUP_CTN_DATA';
    const dropDownData: any = this.cacheService.get(CACHE_KEY);
    if (dropDownData) {
      return of(cloneDeep(dropDownData));
    } else {
      console.debug('CollateralTypeLookupService::getCollateralTypeLookupColumns:: Real Data ');
      return this.http.get(requestUrl).pipe(
        shareReplay(1),
        tap((data: any) => this.cacheService.put(CACHE_KEY, cloneDeep(data)))
      );
    }
  }
}
