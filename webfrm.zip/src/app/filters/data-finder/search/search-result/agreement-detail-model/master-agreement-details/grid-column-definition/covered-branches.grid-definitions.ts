import { FieldType } from '@aqua/aqua-component/aqua-grid/model/field-type.enum';
import { GridColumnsDef, GridColumnsDefBuilder } from '@aqua/filters/models';

export const COVERED_BRANCHES_GRID_DEFINITION: GridColumnsDef[] = [
  new GridColumnsDefBuilder('GFCID', 'partyGfcId').build(),
  new GridColumnsDefBuilder('Branch Name', 'partyBranchName').build(),
  new GridColumnsDefBuilder('Location', 'partyLocation').build(),
  new GridColumnsDefBuilder('Funding Index', 'fundingIndex').fieldType(FieldType.NUMERIC).build()
];
