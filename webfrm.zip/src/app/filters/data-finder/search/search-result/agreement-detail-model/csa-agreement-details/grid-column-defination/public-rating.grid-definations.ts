import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { GridColumnsDef, GridColumnsDefBuilder } from '@aqua/filters/models';

export const PUBLIC_RATING_GRID_DEFINATION: GridColumnsDef[] = [
  new GridColumnsDefBuilder('Date', 'ratingDate').fieldType(FieldType.DATE).build(),
  new GridColumnsDefBuilder('Agency', 'agency').build(),
  new GridColumnsDefBuilder('Rating', 'rating').build()
];
