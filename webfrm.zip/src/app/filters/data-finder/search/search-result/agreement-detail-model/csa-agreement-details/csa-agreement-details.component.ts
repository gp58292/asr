import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, Output } from '@angular/core';
import { ColumnDefaultGrid, GridUtils } from '@aqua/aqua-component/aqua-grid/utils';
import { Agreement } from '@aqua/filters/models';
import { VizNotificationService } from '@aqua/services';
import { GridOptions } from 'ag-grid-community';
import { Subject } from 'rxjs';
import { catchError, finalize, takeUntil } from 'rxjs/operators';

import { AgreementDetailsService } from '../agreement-details.service';
import { CSADetails } from './../csa-details-model';
import { AC_CASH_GRID_DEFINATION } from './grid-column-defination/ac-cash.grid-definations';
import { AC_COVERED_GRID_DEFINATION } from './grid-column-defination/ac-covered.grid-definations';
import { AC_HAIRCUT_SCHEDULES_GRID_DEFINATION } from './grid-column-defination/ac-haircut-schedules.grid-definations';
import { CREDIT_THRESHOLD_GRID_DEFINATION } from './grid-column-defination/credit-threshold.grid-definations';
import { PARTY_SCHDULED_THRESHOLD_GRID_DEFINATION } from './grid-column-defination/party-scheduled-threshold.grid-definations';
import { PARTY_THRESHOLD_GRID_DEFINATION } from './grid-column-defination/party-threshold.grid-definations';
import { PUBLIC_RATING_GRID_DEFINATION } from './grid-column-defination/public-rating.grid-definations';

@Component({
  selector: 'ceft-csa-agreement-details',
  templateUrl: './csa-agreement-details.component.html',
  styleUrls: ['./csa-agreement-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CsaAgreementDetailsComponent implements OnDestroy {
  @Input()
  public set csaDetails(_csaDetails: CSADetails) {
    this._csaDetails = _csaDetails;
    console.debug('CsaAgreementDetailsComponent::csaDetails', this._csaDetails);

    if (this._csaDetails && this._csaDetails.agreementId && this._csaDetails.csaDetailsName && !this._isDataLoaded) {
      this.getAgreementCSADetails(this._csaDetails.agreementId, this._csaDetails.csaDetailsName);
    } else if (this._csaDetails && !this._csaDetails.agreementId && this._csaDetails.csaDetailsName) {
      // this.vizNotification.showWarning(
      // 	"Unfortunately, We have not received any agreement id or csa name, Please contact support team!"
      // );
      console.warn(
        'CsaAgreementDetailsComponent::csaDetails::Unfortunately, We have not received any agreement id or csa name, Please contact support team'
      );
    }
  }

  public static gridOptions: GridOptions = GridUtils.gridOptionsWithoutPivoting;

  public acHaircutScheduleColDef: ColumnDefaultGrid[] = GridUtils.buildColumns(AC_HAIRCUT_SCHEDULES_GRID_DEFINATION);
  public partyThresholdColDef: ColumnDefaultGrid[] = GridUtils.buildColumns(PARTY_THRESHOLD_GRID_DEFINATION);
  public creditThresholdColDef: ColumnDefaultGrid[] = GridUtils.buildColumns(CREDIT_THRESHOLD_GRID_DEFINATION);
  public partyScheduledThresholdColDef: ColumnDefaultGrid[] = GridUtils.buildColumns(PARTY_SCHDULED_THRESHOLD_GRID_DEFINATION);
  public publicRatingColDef: ColumnDefaultGrid[] = GridUtils.buildColumns(PUBLIC_RATING_GRID_DEFINATION);
  public acCashColDef: ColumnDefaultGrid[] = GridUtils.buildColumns(AC_CASH_GRID_DEFINATION);
  public acCoveredProdColDef: ColumnDefaultGrid[] = GridUtils.buildColumns(AC_COVERED_GRID_DEFINATION);

  public agreementDetailsCSAList: any;
  @Output() public notify: EventEmitter<string> = new EventEmitter<string>();

  public _isLoadingData = false;

  private alive: Subject<void> = new Subject();

  private _csaDetails: CSADetails;
  private _isDataLoaded: boolean = false;

  constructor(
    private agreementDetailsService: AgreementDetailsService,
    private vizNotification: VizNotificationService,
    private _changeDetectorRef: ChangeDetectorRef
  ) {}

  // agreementId, AgreementCsa
  public getAgreementCSADetails(userAgreementId, userAgreementCsa) {
    console.debug('CsaAgreementDetailsComponent::getAgreementCSADetails::', this._csaDetails);
    if (!this._isLoadingData) {
      this._isLoadingData = true;
      this.notify.emit('true');
      this.agreementDetailsService
        .getAgreementCSADetails(
          /// this._csaDetails.agreementId,
          // this._csaDetails.csaDetailsName
          userAgreementId,
          userAgreementCsa
        )
        .pipe(
          takeUntil(this.alive),
          finalize(() => {
            this._isLoadingData = false;
            this._isDataLoaded = true;
          }),
          catchError(err => {
            console.error('CsaAgreementDetailsComponent::getAgreementCSADetails::', err);
            this.vizNotification.showError('Failed to load data for tab [' + this._csaDetails.csaDetailsName + ']');
            return err;
          })
        )
        .subscribe((response: Agreement) => {
          if (response) {
            this.vizNotification.showMessage('Agreement ' + this._csaDetails.csaDetailsName + ' details fetched successfully');
            this.updateDataSources(response);
          }
        });
    }
  }

  public ngOnDestroy() {
    console.debug('CsaAgreementDetailsComponent::ngOnDestroy');
    this.alive.next();
    this.alive.complete();
    this.alive.unsubscribe();
  }

  public getOptions(name: string): any {
    return {
      ...CsaAgreementDetailsComponent.gridOptions,
      ...GridUtils.getDefaultExcelExportParam(name)
    };
  }

  private updateDataSources(response): void {
    this.agreementDetailsCSAList = response;
    this._changeDetectorRef.markForCheck();
  }
}
