import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { ColumnDefaultGrid, GridUtils } from '@aqua/aqua-component/aqua-grid/utils';
import { GridOptions } from 'ag-grid-community';

import { COVERED_BRANCHES_GRID_DEFINITION } from './grid-column-definition/covered-branches.grid-definitions';
import { COVERED_PRODUCTS_GRID_DEFINITION } from './grid-column-definition/covered-products.grid-definitions';

@Component({
  selector: 'ceft-master-agreement-details',
  templateUrl: './master-agreement-details.component.html',
  styleUrls: ['./master-agreement-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MasterAgreementDetailsComponent {
  public static gridOptions: GridOptions = GridUtils.gridOptionsWithoutPivoting;

  public coveredBranchesColDef: ColumnDefaultGrid[] = GridUtils.buildColumns(COVERED_BRANCHES_GRID_DEFINITION);
  public coveredProductsColDef: ColumnDefaultGrid[] = GridUtils.buildColumns(COVERED_PRODUCTS_GRID_DEFINITION);

  @Input()
  public agreementDetails: any;

  public getOptions(name: string): any {
    return {
      ...MasterAgreementDetailsComponent.gridOptions,
      ...GridUtils.getDefaultExcelExportParam(name)
    };
  }
}
