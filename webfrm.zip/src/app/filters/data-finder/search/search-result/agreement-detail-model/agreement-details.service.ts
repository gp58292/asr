import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Agreement } from '@aqua/filters/models';
import { FiltersUrlConfig, LoadingNotificationsService } from '@aqua/filters/services';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';

@Injectable()
export class AgreementDetailsService {
  constructor(
    private http: HttpClient,
    private urlConfig: FiltersUrlConfig,
    private loadingNotificationsService: LoadingNotificationsService
  ) {
    console.debug('AgreementDetailsService::constructor:: Loading Search Service ..................................');
  }

  public getAgreementDetails(agreementKeys: number[]): Observable<Agreement[] | any> {
    console.debug('AgreementDetailsService::getAgreementDetails');
    return this.http
      .get(this.urlConfig.EP_GET_AGREEMENT_DETAILS + '/' + agreementKeys)
      .pipe(finalize(() => (this.loadingNotificationsService.searchStarted = false)));
  }

  public getAgreementCSADetails(agreementId: number, csaType: string): Observable<Agreement[] | any> {
    console.debug('AgreementDetailsService::getAgreementDetails');
    const url = this.urlConfig.EP_GET_CSA_TYPE_DETAILS + '/' + agreementId + '/' + csaType;
    return this.http.get(url).pipe(finalize(() => (this.loadingNotificationsService.searchStarted = false)));
  }
}
