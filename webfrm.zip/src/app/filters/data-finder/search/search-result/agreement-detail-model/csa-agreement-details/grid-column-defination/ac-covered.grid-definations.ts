import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { GridColumnsDef, GridColumnsDefBuilder } from '@aqua/filters/models';

export const AC_COVERED_GRID_DEFINATION: GridColumnsDef[] = [
  new GridColumnsDefBuilder('Include/Exclude', 'includeExclude').build(),
  new GridColumnsDefBuilder('Code', 'instrumentCode').build(),
  new GridColumnsDefBuilder('Instr Code', 'parentInstrCode').build(),
  new GridColumnsDefBuilder('Type', 'covProdType').fieldType(FieldType.NUMERIC).build(),
  new GridColumnsDefBuilder('Name', 'instrumentName').build()
];
