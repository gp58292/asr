import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { GridColumnsDef, GridColumnsDefBuilder } from '@aqua/filters/models';

export const AC_HAIRCUT_SCHEDULES_GRID_DEFINATION: GridColumnsDef[] = [
  new GridColumnsDefBuilder('Type', 'achType').build(),
  new GridColumnsDefBuilder('Min Term', 'achMinTerm').build(),
  new GridColumnsDefBuilder('Max Term', 'achMaxTerm').build(),
  new GridColumnsDefBuilder('Haircut%', 'achHaicutPercentage').fieldType(FieldType.NUMERIC).build(),
  new GridColumnsDefBuilder('Issue Rating', 'achRating').minWidth(250).build(),
  new GridColumnsDefBuilder('Issuer Rating', 'achIssuerRating ').minWidth(250).build(),
  new GridColumnsDefBuilder('Collateral Applied', 'achCollateralApplied').build(),
  new GridColumnsDefBuilder('Collateral Party', 'collateralParty').build(),
  new GridColumnsDefBuilder('Ranking', 'achRanking').build()
];
