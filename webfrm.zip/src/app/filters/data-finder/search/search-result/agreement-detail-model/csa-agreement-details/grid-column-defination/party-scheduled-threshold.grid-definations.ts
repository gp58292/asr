import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { GridColumnsDef, GridColumnsDefBuilder } from '@aqua/filters/models';

export const PARTY_SCHDULED_THRESHOLD_GRID_DEFINATION: GridColumnsDef[] = [
  new GridColumnsDefBuilder('Type', 'type').build(),
  new GridColumnsDefBuilder('Basis', 'basis').build(),
  new GridColumnsDefBuilder('Currency', 'currency').build(),
  new GridColumnsDefBuilder('Amount', 'amount').fieldType(FieldType.NUMERIC).build(),
  new GridColumnsDefBuilder('Start Date', 'startDate').fieldType(FieldType.DATE).build(),
  new GridColumnsDefBuilder('End Date', 'endDate').fieldType(FieldType.DATE).build()
];
