import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import { Agreement, CSAStatus } from '@aqua/filters/models';
import { VizNotificationService } from '@aqua/services';

import { AgreementDetailsService } from './agreement-details.service';
import { CsaAgreementDetailsComponent } from './csa-agreement-details/csa-agreement-details.component';
import { CSADetails } from './csa-details-model';

@Component({
  selector: 'ceft-agreement-model',
  templateUrl: './agreement-model.component.html',
  styleUrls: ['./agreement-model.component.scss'],
  providers: [AgreementDetailsService],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AgreementModelComponent implements OnInit {
  public agreementDetailsList: any;
  public spinnerStatus: boolean = true;

  @ViewChild(CsaAgreementDetailsComponent)
  public csaAgreementDetailsComponent: CsaAgreementDetailsComponent;

  public csaStatus: any = CSAStatus;
  private tabList: Map<string, CSADetails> = new Map<string, CSADetails>();

  constructor(
    private agreementDetailsService: AgreementDetailsService,
    private vizNotification: VizNotificationService,
    public dialogRef: MatDialogRef<AgreementModelComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _changeDetectorRef: ChangeDetectorRef
  ) {
    dialogRef.disableClose = true;
  }

  public ngOnInit() {
    this.getAgreementDetails();
  }

  public agreementTabChanged($event) {
    console.debug('AgreementModelComponent::agreementTabChanged', $event.index);
    const _currentTabKey = this.data.agreementId + this.agreementDetailsList.csaTypeDescList[$event.index - 1].csa_description;

    let tabDetails = this.tabList.get(_currentTabKey);
    if (!tabDetails) {
      tabDetails = new CSADetails(
        this.data.agreementId,
        this.agreementDetailsList.csaTypeDescList[$event.index - 1].csa_description,
        this.agreementDetailsList.csaTypeDescList[$event.index - 1].csa_status
      );
      this.tabList.set(_currentTabKey, tabDetails);
    }
  }

  public getCurrentCSA(listOfCsaType) {
    const _currentTabKey = this.data.agreementId + listOfCsaType;
    // console.debug("AgreementModelComponent::getCurrentCSA::", _currentTabKey);
    return this.tabList.get(_currentTabKey);
  }

  public onCancel(): void {
    this.dialogRef.close();
  }

  private getAgreementDetails() {
    console.debug('AgreementModelComponent::getBOXData');
    this.agreementDetailsService.getAgreementDetails(this.data.name).subscribe((agreement: Agreement) => {
      if (agreement) {
        this.vizNotification.showMessage('Agreement details fetched successfully');
        console.debug('AgreementModelComponent::getAgreementDetails::', agreement);
        this.agreementDetailsList = agreement;
        this.spinnerStatus = false;
        this._changeDetectorRef.markForCheck();
      }
    });
  }
}
