import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { AggrementPopinComponent } from "@aqua/filters/data-finder/search/search-result/filter-popin/aggrement-popin.component";

describe("AggrementPopinComponent", () => {
	let component: AggrementPopinComponent;
	let fixture: ComponentFixture<AggrementPopinComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [AggrementPopinComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(AggrementPopinComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
