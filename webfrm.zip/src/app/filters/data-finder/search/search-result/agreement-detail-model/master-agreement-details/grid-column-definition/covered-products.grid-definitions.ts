import { GridColumnsDef, GridColumnsDefBuilder } from '@aqua/filters/models';

export const COVERED_PRODUCTS_GRID_DEFINITION: GridColumnsDef[] = [
  new GridColumnsDefBuilder('Include/Exclude', 'includeExclude').enableFilter().build(),
  new GridColumnsDefBuilder('Code', 'instrumentCode').build(),
  new GridColumnsDefBuilder('Parent Instr Code', 'parentInstrCode').build(),
  new GridColumnsDefBuilder('Type', 'covProdType').build(),
  new GridColumnsDefBuilder('Name', 'instrumentName').build()
];
