import { GridColumnsDef, GridColumnsDefBuilder } from '@aqua/filters/models';

export const AC_CASH_GRID_DEFINATION: GridColumnsDef[] = [
  new GridColumnsDefBuilder('Currency', 'accCurrency').build(),
  new GridColumnsDefBuilder('Interest Index', 'accInterestMatrix').build(),
  new GridColumnsDefBuilder('Interest Spread', 'accInterestSpread').build(),
  new GridColumnsDefBuilder('Compounding', 'accCompounding').build(),
  new GridColumnsDefBuilder('Payment Frequency', 'achaccPaymentFrequencyType').build(),
  new GridColumnsDefBuilder('Reset Frequency', 'accResetFrequency').build(),
  new GridColumnsDefBuilder('Ranking', 'accRanking').build()
];
