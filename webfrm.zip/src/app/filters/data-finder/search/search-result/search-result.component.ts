import { AfterViewInit, Component, Input, OnDestroy, OnInit, QueryList, ViewChildren } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material';
import { AquaGrid } from '@aqua/aqua-component/aqua-grid';
import { NumberRenderer } from '@aqua/aqua-component/aqua-grid/inline-cell-renderer';
import { ColumnsDefinitionGrid, FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { GridUtils } from '@aqua/aqua-component/aqua-grid/utils';
import { SearchService } from '@aqua/filters/data-finder/search/search.service';
import {
  FieldNames,
  LoadingTypes,
  SearchResultColumns,
  SearchResultDataSetBookmark,
  SearchResultModel,
  UILoadingStatus
} from '@aqua/filters/models';
import { SearchField } from '@aqua/filters/models/search-field.model';
import {
  FilterCancelService,
  GridNotificationService,
  LoadingNotificationsService,
  SearchResultColumnService,
  TabsSearchService
} from '@aqua/filters/services';
import { FiltersService } from '@aqua/filters/services/filters.service';
import { SearchPlusBookmarkService } from '@aqua/filters/services/search-plus-bookmark.service';
import { CeftDataSetStatus, ColumnValueRequest, DataStatus, TabsInfo } from '@aqua/models';
import { VizNotificationService } from '@aqua/services';
import { combineLatest, from, Subject } from 'rxjs';
import { debounceTime, distinct, distinctUntilChanged, filter, map, shareReplay, switchMap, takeUntil, toArray } from 'rxjs/operators';

import { SearchResultService } from './search-result.service';
import { SearchResultUtil } from './search-result.util';
import { SearchResultDataSource } from './server-grid-api/search-result.server.datasource';

@Component({
  selector: 'ceft-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.scss']
})
export class SearchResultComponent implements OnInit, OnDestroy, AfterViewInit {
  @Input()
  set filtersExpanded(_filterExpanded: boolean) {
    // this.gridHeight = _filterExpanded ? 41.1 : 77.8;
  }

  set isFilterd(isFilterdData: boolean) {
    console.debug('SearchResultComponent::isFilterd::', isFilterdData, this.isActualPostingCTNExist);
    this._isFilterd = isFilterdData;
    this.tabsSearchService.setIsFilteredSearch(this._isFilterd);
  }

  get isFilterd(): boolean {
    return this._isFilterd;
  }

  // public get isListedEmpty(): boolean {
  //   return this._isListedEmpty;
  // }

  @ViewChildren(AquaGrid) private set resultTables(grids: QueryList<AquaGrid>) {
    console.debug('SearchResultComponent::resultTables::SET::', grids.length, grids);
    this._resultTables = grids;
  }

  public get isCurrentPostingActive(): boolean {
    return this.tabsSearchService.isCurrentPostingTabActive;
  }

  // --------------------------------- Column filter code -----------------------------------------------------

  @Input() public resultsExpanded: boolean = false;

  public gotResult: boolean = false;
  public resultTabSelectedIndex: number = 0;

  //   public gridHeight: number = 41.1;

  public searchingStatus: boolean = false;

  public searchColumnsList: ColumnsDefinitionGrid[];

  public _isFilterd: boolean = false;
  public isContractualCTNExist: boolean = false;

  // New variables
  public tabsList: TabsInfo[];
  public resultColumnsList: ColumnsDefinitionGrid[];
  public isActualPostingCTNExist: boolean = false;
  public isListedEmpty: boolean = true;

  private _alive$: Subject<void> = new Subject();

  private smcColumns: SearchResultColumns[] = [];

  private _resultTables: QueryList<AquaGrid>;

  private _resultsServerDataSource: Map<string, SearchResultDataSource> = new Map<string, SearchResultDataSource>();

  constructor(
    private searchService: SearchService,
    private searchResultService: SearchResultService,
    private filtersService: FiltersService,
    private vizNotification: VizNotificationService,
    private filterCancelService: FilterCancelService,
    private searchResultColumnService: SearchResultColumnService,
    private searchPlusBookmarkService: SearchPlusBookmarkService,
    private tabsSearchService: TabsSearchService,
    private gridNotificationService: GridNotificationService,
    private loadingNotificationsService: LoadingNotificationsService
  ) {}

  public getGridOptions(name: string) {
    return { ...SearchResultUtil.gridOptions, ...GridUtils.getDefaultExcelExportParam(name) };
  }
  public spinnerCancelled(event: Event, name?: string) {
    console.debug('SearchResultComponent::spinnerCancelled::', event, name);
    this.filterCancelService.cancelSubject();
  }

  public ngOnInit() {
    console.debug('SearchResultComponent::ngOnInit::');

    this.getAllTabs();

    this.listenResultDataChange();
    this.listenCriteriaChange();
    this.searchResultColumnService.loadResultColumns();
    this.getTabColumns(this.tabsSearchService.activeTabInfo.tabName);
    this.listenForDataSetReady();
    this.listenForDataSearch();
    this.listenForTabChange();
  }

  public ngAfterViewInit() {
    console.debug('SearchResultComponent::ngAfterViewInit::', this._resultTables.length);
    this.listenLoadingNotifications();
  }

  public ngOnDestroy() {
    console.debug('SearchResultComponent::ngOnDestroy');
    this._alive$.next();
    this._alive$.complete();
    this._alive$.unsubscribe();
  }

  public onFiltered(event: MouseEvent): void {
    const element: any = event.target || event.srcElement || event.currentTarget;
    const isDisabled: any = element.getAttribute('disabled');

    console.debug('SearchResultComponent::onFiltered::', this.isFilterd, isDisabled);
    if (isDisabled) {
      return;
    }
    this.isFilterd = !this.isFilterd;
    this.tabsSearchService.triggerFilteredSearch(true);
  }

  public onSelectedRows(_selectedRows: any[]): void {
    const agreementKeys: number[] = [...new Set(_selectedRows.map((data: any) => data[FieldNames.AGREEMENT_KEY]))];
    console.debug('SearchResultComponent::onSelectedRows::AgreementsKeys::', agreementKeys);
    this.tabsSearchService.selectedRows = agreementKeys;
  }

  public tabChanged(tabChangeEvent: MatTabChangeEvent): void {
    console.debug('SearchResultComponent::tabChanged Tab Changed: ', tabChangeEvent, tabChangeEvent.tab.textLabel);
    const activeTabName = tabChangeEvent.tab.textLabel;
    const activeTabInfo: TabsInfo = this.tabsList.find(item => item.tabName === activeTabName);
    this.tabsSearchService.setTabInfo(activeTabInfo);

    if (this.tabsSearchService.isListedTabActive) {
      this.getActiveAgGrid()
        .gridApi.getSelectedNodes()
        .forEach(node => node.setSelected(false, true));
    }
  }

  public getTabColumns(tabName: string): void {
    console.debug('SearchResultComponent::getTabColumns:: ', tabName);
    this.searchResultColumnService
      .getColumnsListByTab(tabName)
      .pipe(takeUntil(this._alive$))
      .subscribe((columns: SearchResultColumns[]) => {
        console.debug('SearchResultComponent::getTabColumns::', columns.filter(p => p.isDefaultDisplay && p.tabName === 'Listed'));
        let finalColumns = [...columns];
        if (tabName === 'Current Postings' || tabName === 'Box') {
          finalColumns = GridUtils.mergeColumnsIfNotExistOtherwiseIgnore(this.smcColumns, finalColumns);
        }
        const aquaGird: AquaGrid = this.getActiveAgGrid();
        if (aquaGird && aquaGird.gridApi) {
          this.resultColumnsList = [];
          aquaGird.gridApi.setColumnDefs([]); // need to reset column definition to avoid duplicate columns name issues
        }

        this.resultColumnsList = GridUtils.buildColumns(finalColumns, true, tabName === 'Listed');
        console.debug('SearchResultComponent::getTabColumns:: Result Column::', tabName, this.resultColumnsList.length);
      });
  }

  public getAllTabs(): void {
    // console.debug("SearchResultComponent::getAllTabs:: ");
    this.searchResultColumnService
      .getTabList()
      .pipe(takeUntil(this._alive$))
      .subscribe(tabs => {
        console.debug('SearchResultComponent::getAllTabs:: ', tabs);
        this.tabsList = tabs;
      });
  }

  public onSelectedAgreement($event) {
    this.searchResultService.openMasterDetails($event);
  }

  public onFilterModelChange(filterModel: any) {
    console.debug('SearchResultComponent::onFilterModelChange ');
    // this.resultFilterModel$$.next(filterModel);
    const aquaGrid: AquaGrid = this.getActiveAgGrid();
    if (aquaGrid && aquaGrid.gridApi) {
      aquaGrid.gridApi.hidePopupMenu();
    } // hide active floating filter popup
  }

  public clearAllFilters() {
    console.debug('SearchResultComponent::clearAllFilters ');
    const aquaGrid: AquaGrid = this.getActiveAgGrid();
    if (aquaGrid && aquaGrid.gridApi) {
      aquaGrid.gridApi.setFilterModel({});
      aquaGrid.gridApi.setSortModel([]);
    }
  }

  private listenForTabChange(): void {
    this.tabsSearchService
      .activeTabInfo$()
      .pipe(takeUntil(this._alive$))
      .subscribe((activeTab: TabsInfo) => {
        console.debug('SearchPlusBookmarkService::listenForTabChange::', activeTab);
        if (this.resultTabSelectedIndex !== activeTab.tabOrder) {
          this.resultTabSelectedIndex = activeTab.tabOrder;
        }
      });
  }
  private listenForDataSearch(): void {
    this.searchPlusBookmarkService.searchInitiateObervable$.pipe(takeUntil(this._alive$)).subscribe((data: SearchResultDataSetBookmark) => {
      const ceftDataSetStatus: CeftDataSetStatus = data.dataSetStatus;
      if (ceftDataSetStatus && ceftDataSetStatus.ready && ceftDataSetStatus.total <= 0) {
        this.vizNotification.showWarning(
          'No records found, data set total record (' + ceftDataSetStatus.total + ') and status is ' + ceftDataSetStatus.status
        );
      }
    });
  }

  private listenForDataSetReady(): void {
    this.searchPlusBookmarkService.searchResultDataReadyObervable$
      .pipe(
        filter((ceftDataSetStatus: CeftDataSetStatus) => {
          // console.debug(
          //   'SearchResultComponent::listenForLastRow::',
          //   ceftDataSetStatus,
          //   ceftDataSetStatus.dataSet.type,
          //   this.tabsSearchService.activeTabInfo.getDataSetType(this.tabsSearchService.isFilteredCurrentPostingTabActive)
          // );
          return (
            ceftDataSetStatus.dataSet.type ===
            this.tabsSearchService.activeTabInfo.getDataSetType(this.tabsSearchService.isFilteredCurrentPostingTabActive)
          );
        }),
        takeUntil(this._alive$)
      )
      .subscribe(
        (ceftDataSetStatus: CeftDataSetStatus) => {
          console.debug('SearchResultComponent::listenForDataSetReady::', ceftDataSetStatus);
          const aquaGrid: AquaGrid = this.getActiveAgGrid();
          this.getTabColumns(this.tabsSearchService.activeTabInfo.tabName);
          if (this.tabsSearchService.activeTabInfo.getDataSetType() === ceftDataSetStatus.dataSet.type) {
            this.tabsSearchService.activeTabInfo.tabRecordCount = ceftDataSetStatus.total;
          }
          if (ceftDataSetStatus.total <= 0) {
            this.vizNotification.showWarning('No records found, data set total returned ' + ceftDataSetStatus.total);
            if (aquaGrid && aquaGrid.gridApi) {
              aquaGrid.gridApi.showNoRowsOverlay();
            }
            if (this.tabsSearchService.isListedTabActive) {
              this.isListedEmpty = true; // Only in case of Listed data this flag has to set.
            }
          } else {
            this.isListedEmpty = false;
            this.vizNotification.showMessage('Search requested successfully, data will be loaded soon', 'Dismiss', 500);
            if (ceftDataSetStatus.dataSet.type.toUpperCase() === 'GSST') {
              this.showGSSTTabMessage(ceftDataSetStatus.dataSet.type, ceftDataSetStatus.total);
            }
            this.searchResultService.initResultColumnFilters(aquaGrid, ceftDataSetStatus, this.resultColumnsList);
            this.reInitializeServerDataSource(aquaGrid, ceftDataSetStatus.total);
          }
        },
        error => {
          console.debug('SearchResultComponent::listenForLastRow::error::', error);
        }
      );
    combineLatest(this.tabsSearchService.startSearch$(), this.tabsSearchService.activeTabInfo$())
      .pipe(
        filter(([isStarted, activeTabInfo]: any) => isStarted),
        map(([isStarted, activeTabInfo]: any) => [isStarted, activeTabInfo, this.filtersService.filterListWithValues]),
        filter(([isStarted, activeTabInfo, criteria]: any) => criteria.length > 0),
        shareReplay(1)
      )
      .subscribe((data: any) => {
        console.debug('SearchResultComponent::listenForDataSetReady::');
        const aquaGrid: AquaGrid = this.getActiveAgGrid();
        aquaGrid.gridColumnApi.setPivotMode(false);
        // this.clearServerDataSource(aquaGrid);
      });

    this.tabsSearchService.startSearch$().subscribe((iStart: boolean) => {
      if (iStart) {
        this.clearServerDataSource();
      }
    });
  }

  private getActiveAgGrid(): AquaGrid {
    return this._resultTables && this._resultTables.find((grid: AquaGrid) => grid.gridId === this.tabsSearchService.activeTabInfo.tabId);
  }

  private clearServerDataSource(aquaGrid?: AquaGrid): void {
    console.debug('SearchResultComponent::clearServerDataSource::');
    this._resultsServerDataSource.clear();

    this._resultTables &&
      this._resultTables.forEach((grid: AquaGrid) => {
        if (grid && grid.gridApi) {
          grid.gridApi.setServerSideDatasource(undefined);
          grid.gridApi.getSelectedNodes().forEach(node => node.setSelected(false, true));
          // Need to destroy all filters in order to ask server for new values each time when Criteria changed
          this.searchResultService.destroyAllResultColumnFilters(grid);
          grid.gridColumnApi.setPivotMode(false);
          grid.gridApi.setFilterModel(undefined);
        }
      });
  }

  // Clear existing data from grid when user search or open new tab, so use won't see any stale data
  // this may need to improve, when we load all grids data simultaneously
  private reInitializeServerDataSource(aquaGrid: AquaGrid, totalRecord: number) {
    if (aquaGrid) {
      let serverDataSource: SearchResultDataSource = this._resultsServerDataSource.get(aquaGrid.gridId);
      console.debug('SearchResultComponent::reInitializeServerDataSource::', serverDataSource);
      if (!serverDataSource) {
        serverDataSource = new SearchResultDataSource(
          this.gridNotificationService,
          this.searchPlusBookmarkService,
          this.tabsSearchService,
          this.loadingNotificationsService,
          aquaGrid.gridId,
          totalRecord,
          aquaGrid
        );
        this._resultsServerDataSource.set(aquaGrid.gridId, serverDataSource);
      }
      if (aquaGrid.gridApi) {
        aquaGrid.gridApi.setServerSideDatasource(serverDataSource);
      } else {
        aquaGrid.serverDataSource = serverDataSource;
      }
    }
  }

  private listenCriteriaChange(): void {
    // listen current search criteria
    this.filtersService
      .filterValueChanged$()
      .pipe(
        takeUntil(this._alive$),
        debounceTime(500),
        map((data: SearchField[]) => data && data.filter(field => !!field.value))
      )
      .subscribe((data: SearchField[]) => {
        if (data.length > 0) {
          this.prepareColumnList();
          this.isActualPostingCTNExist = SearchResultUtil.checkCollatralType(data, false) > 0;
          this.isContractualCTNExist = SearchResultUtil.checkCollatralType(data) > 0;
          this.isFilterd = this.isActualPostingCTNExist;
          console.debug('SearchResultComponent::listenCriteriaChange::', this.isActualPostingCTNExist, this.isContractualCTNExist);
          // this.searchService.onFilterFlagChange(this.isActualPostingCTNExist);
        }
      });
  }

  private listenLoadingNotifications() {
    // TODO: Sometimes observed random behavior, Web socket return ready first status, then loading status, causes unnecessary notification
    // this happens when no record is there
    // TODO: If any exception occur while fetching data search, data request or web socket, loading notification may behave inconsistently
    // This will work correctly with happy flow
    this.filterCancelService
      .getSubject()
      .pipe(takeUntil(this._alive$))
      .subscribe(() => {
        this.gridShowMessage(false, undefined); // Cancelling overlay and any request
      });

    this.loadingNotificationsService.dataLoading$
      .pipe(
        debounceTime(20),
        distinctUntilChanged(),
        takeUntil(this._alive$)
      )
      .subscribe((loadingStatus: UILoadingStatus) => {
        console.debug('SearchResultComponent::listenLoadingNotifications::subscribe::', loadingStatus);
        switch (loadingStatus.type) {
          case LoadingTypes.SEARCH_REQUEST:
            const aquaGrid: AquaGrid = this.getActiveAgGrid();
            // if (aquaGrid && aquaGrid.gridApi && loadingStatus.isStarted) {
            //   aquaGrid.gridApi.setRowData([]);
            // }
            this.gridShowMessage(true, 'Please wait, Search is in progress...');
            break;
          case LoadingTypes.WEB_SOCKET_REQUEST:
            if (loadingStatus.data && loadingStatus.data.status === DataStatus.NOT_LOADED) {
              console.debug('SearchResultComponent::listenLoadingNotifications::NOT_LOADED::', loadingStatus);
              const aquaGird: AquaGrid = this.getActiveAgGrid();
              aquaGird.gridApi.hideOverlay();
              aquaGird.customNoRowMessage = 'DataSet can not be loaded now, If problem persists please contact SL3 support.';
              aquaGird.showNowRowMessage();
              if (this.tabsSearchService.isListedTabActive) {
                this.isListedEmpty = true;
              }
            } else if (loadingStatus.data && !loadingStatus.data.ready) {
              this.gridShowMessage(true, 'Please wait, Search is in progress...');
            }

            break;
          case LoadingTypes.DATA_REQUEST:
            this.gridShowMessage(loadingStatus.isStarted, 'Please wait, Loading data...');
            break;
        }
      });
  }

  private gridShowMessage(isShow: boolean, message: string, delay: number = 0): void {
    const aquaGird: AquaGrid = this.getActiveAgGrid();
    // console.debug('SearchResultComponent::listenLoadingNotifications::subscribe::', isShow, message);
    if (aquaGird && aquaGird.gridApi) {
      if (isShow) {
        aquaGird.customMessage = message;
        aquaGird.showOverlayMessage();
      } else {
        setTimeout(() => aquaGird.gridApi.hideOverlay(), delay);
      }
    }
  }

  private prepareColumnList(): void {
    const smsSearchField = this.filtersService.filtersList.filter(p => p.logicalGroupName === 'SMC Attributes');

    const smcColumns: SearchResultColumns[] = [];
    let count = 1000;
    for (const searchField of smsSearchField) {
      const src: SearchResultColumns = new SearchResultColumns();
      src.fieldName = searchField.fieldName;
      src.displayName = searchField.name;
      src.isDefaultDisplay = true;
      src.fieldType = FieldType[searchField.dataType.toUpperCase()];
      src.fieldOrder = count++;
      smcColumns.push(src);
    }
    this.smcColumns = smcColumns;
  }

  // we can use data set request instead of result
  private listenResultDataChange() {
    console.debug('SearchResultComponent::listenResultDataChange');
    this.searchPlusBookmarkService.searchResultObervable$
      .pipe(takeUntil(this._alive$))
      .subscribe((searchResultModel: SearchResultModel) => {
        console.debug(
          'SearchResultComponent::listenResultDataChange::Got new result::',
          searchResultModel,
          // this.firstTabName,
          this.resultTabSelectedIndex,
          this.tabsSearchService.activeTabInfo,
          this.tabsSearchService.isListedTabActive,
          this.gotResult
        );
      });
  }

  // ---------------------------------------------------------------------------------------------------------------------

  private showGSSTTabMessage(tabName: string, resultLength: number) {
    console.debug('SearchResultComponent::showGSSTTabMessage::', tabName, resultLength, this.isContractualCTNExist);
    if (!this.isContractualCTNExist && resultLength > 0) {
      this.vizNotification.showWarning(
        'GSST exposure is not calculated as collateral type name is not selected in contractual eligibility',
        'Dismiss',
        { duration: 60000 }
      );
    }
  }
}
