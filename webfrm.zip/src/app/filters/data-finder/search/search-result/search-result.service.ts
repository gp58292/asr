import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { AquaGrid } from '@aqua/aqua-component/aqua-grid';
import { ColumnsDefinitionGrid } from '@aqua/aqua-component/aqua-grid/model';
import { FieldNames } from '@aqua/filters/models';
import { TabsSearchService } from '@aqua/filters/services';
import { CeftDataSetStatus, ColumnValueRequest } from '@aqua/models';
import { map } from 'rxjs/operators';

import { SearchReferenceService } from '../../../services/search-reference.service';
import { AgreementModelComponent } from './agreement-detail-model';
import { SearchResultUtil } from './search-result.util';

@Injectable({ providedIn: 'root' })
export class SearchResultService {
  private static compareFn = (a, b) => {
    if (a < b) {
      return -1;
    }
    if (a > b) {
      return 1;
    }
    return 0;
  };
  constructor(
    private dialog: MatDialog,
    private searchReferenceService: SearchReferenceService,
    private tabsSearchService: TabsSearchService
  ) {}

  public openMasterDetails($event: any) {
    console.debug('SearchResultService::openMasterDetails:: ', $event);
    const selectedAgreement = $event.data[FieldNames.AGREEMENT_KEY];
    const selectedAgreementId = $event.data[FieldNames.AGREEMENT_ID];

    if ($event.colDef.field === 'agreement_id' && selectedAgreementId) {
      // agreement model start
      const dialogRef = this.dialog.open(AgreementModelComponent, {
        width: '95%',
        maxWidth: '95%',
        height: '90%',
        data: {
          name: selectedAgreement,
          agreementId: selectedAgreementId
        }
      });

      console.debug('SearchResultService::openMasterDetails:: ', selectedAgreementId);
      dialogRef.afterClosed().subscribe(result => {
        console.debug('SearchResultService::afterClosed:: ');
      });
    }
  }

  public initResultColumnFilters(aquaGrid: AquaGrid, ceftDataSetStatus: CeftDataSetStatus, resultColumnsList: ColumnsDefinitionGrid[]) {
    const gridColumns: ColumnsDefinitionGrid[] = this.colDefsByFilterAvailability(resultColumnsList);
    // console.debug('SearchResultService::initResultColumnFilters::gridColumns::', gridColumns);
    gridColumns.forEach(colDef => {
      colDef.filterParams.values = params => {
        const columnValueRequest = new ColumnValueRequest();
        columnValueRequest.column = colDef.field;
        columnValueRequest.dataSet = ceftDataSetStatus.dataSet;
        if (aquaGrid && aquaGrid.gridApi) {
          columnValueRequest.filters = SearchResultUtil.updateFiltersByFilterModel(aquaGrid.gridApi.getFilterModel());
          if (!this.tabsSearchService.isListedTabActive) {
            this.processFilters(columnValueRequest);
          }
        }

        this.searchReferenceService
          .getDistinctFieldValuesForColumn(columnValueRequest)
          .pipe(
            map(data => {
              data.map((item: string | number) => {
                if (!!item && !isNaN(Number(item))) {
                  item = item.toString().trim();
                }
                if (item === undefined || item === null || item === '') {
                  return '(Blanks)';
                } else {
                  return item;
                }
              });
              data = [...new Set(data)];
              return data.sort(SearchResultService.compareFn);
            })
          )
          .subscribe((response: any[]) => {
            // const list = response.map(item => (item === null || item === '' ? undefined : item));
            console.debug('SearchResultService::initResultColumnFilters::subscribe::', response);
            params.success(response);
          });
      };
    });
  }

  // const activeGrid: AquaGrid = grid ? grid : this.getActiveAgGrid();
  public destroyAllResultColumnFilters(grid?: AquaGrid) {
    this.colDefsByFilterAvailability(grid._columnDefs).forEach(colDef => grid.gridApi.destroyFilter(colDef.field));
  }

  private colDefsByFilterAvailability(resultColumnsList: ColumnsDefinitionGrid[]): ColumnsDefinitionGrid[] {
    return resultColumnsList ? resultColumnsList.filter(colDef => colDef.filterParams && colDef.filterParams.apply === true) : [];
  }

  private processFilters(columnValueRequest: ColumnValueRequest) {
    const agreementData: { filterType: 'set'; values: any[] } = columnValueRequest.filters[FieldNames.AGREEMENT_KEY];
    if (this.tabsSearchService.selectedRows && this.tabsSearchService.selectedRows.length) {
      if (agreementData) {
        const setData = new Set(...agreementData.values, ...this.tabsSearchService.selectedRows);
        agreementData.values = Array.from(setData.values);
      } else {
        columnValueRequest.filters[FieldNames.AGREEMENT_KEY] = {
          filterType: 'set',
          values: []
        };
        columnValueRequest.filters[FieldNames.AGREEMENT_KEY].values = this.tabsSearchService.selectedRows;
      }
    }
  }
}
