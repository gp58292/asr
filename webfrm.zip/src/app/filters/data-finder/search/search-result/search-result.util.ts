import { ComponentType, SearchField } from '@aqua/filters/models';
import { GridOptions } from 'ag-grid-community';

export class SearchResultUtil {
  public static readonly gridOptions: GridOptions = {
    maxBlocksInCache: 20,
    // suppressMultiSort: false,
    // sortingOrder: ['asc', 'desc'],
    blockLoadDebounceMillis: 1500,
    defaultColDef: {
      sortable: true,
      filter: true,
      resizable: true
    },
    autoGroupColumnDef: {
      headerName: 'Hierarchy',
      width: 250
    },
    rowModelType: 'serverSide',
    cacheBlockSize: 100,
    // rowGroupPanelShow: 'always',
    pivotPanelShow: 'always',
    suppressAggFuncInHeader: true,
    pivotMode: false,
    animateRows: false,
    suppressCsvExport: true,
    suppressExcelExport: true,
    getChildCount: data => (data && data.__child_count ? data.__child_count : undefined)
  };

  public static checkCollatralType(criteria: SearchField[], withContractualEligibilityOnly: boolean = true): any {
    return criteria.filter(field => {
      // if (withContractualEligibilityOnly) {
      //   console.debug(
      //     'SearchResultUtil::checkCollatralType::',
      //     withContractualEligibilityOnly,
      //     field.whoHasFlag,
      //     field.fieldName,
      //     field.logicalGroupName === 'Optimality Attributes',
      //     field,
      //     (withContractualEligibilityOnly ? field.whoHasFlag === 0 : field.whoHasFlag) &&
      //       ((field.componentType === ComponentType.MULTI_INCLUDE_EXCLUDE && field.value) ||
      //         (field.logicalGroupName === 'Optimality Attributes' && field.value))
      //   );
      // }
      return (
        (withContractualEligibilityOnly ? field.whoHasFlag === 0 : field.whoHasFlag) &&
        ((field.componentType === ComponentType.MULTI_INCLUDE_EXCLUDE && field.value) ||
          (field.logicalGroupName === 'Optimality Attributes' && field.value))
      );
    }).length;
  }

  /**
   * Build criteria filters by ag-grid filter model
   * @param filterModel
   */
  public static buildCriteriaFiltersByFilterModel(filterModel: any): Array<{ column: string; values: string[] }> {
    const filters = [];
    if (Object.keys(filterModel).length) {
      console.debug('SearchResultService::buildCriteriaFiltersByFilterModel::', filterModel);
      for (const colId of filterModel) {
        filters.push({ field: colId, values: filterModel[colId].values.map(item => (item === '(Blanks)' ? '' : item)) });
      }
    }

    return filters;
  }

  /**
   * Build criteria filters by ag-grid filter model
   * @param filterModel
   */
  public static updateFiltersByFilterModel(filterModel: any): any {
    const filters = {};
    if (Object.keys(filterModel).length > 0) {
      // tslint:disable-next-line:forin
      for (const colId in filterModel) {
        filters[colId] = {};
        // tslint:disable-next-line:no-string-literal
        filters[colId].filterType = filterModel[colId].filterType;
        filters[colId].values = filterModel[colId].values.map(item => (item === '(Blanks)' ? '' : item));
      }
    }

    return filters;
  }
}
