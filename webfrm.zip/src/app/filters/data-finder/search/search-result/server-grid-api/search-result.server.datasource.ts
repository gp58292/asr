import { AquaGrid } from '@aqua/aqua-component/aqua-grid';
import { GridDataSetStatusRequest, SearchResultModel } from '@aqua/filters/models';
import { GridNotificationService, LoadingNotificationsService, TabsSearchService } from '@aqua/filters/services';
import { SearchPlusBookmarkService } from '@aqua/filters/services/search-plus-bookmark.service';
import { CeftDataSetStatus, GridNotificationModel } from '@aqua/models';
import { IServerSideDatasource, IServerSideGetRowsParams } from 'ag-grid-community';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { GridUtils } from '@aqua/aqua-component/aqua-grid/utils';

export class SearchResultDataSource implements IServerSideDatasource {
  private _alive$: Subject<void> = new Subject();

  private _params: IServerSideGetRowsParams;
  private _lastRow: number = 10;
  private _dataSourceId: string;
  private _ceftDataSetStatus: CeftDataSetStatus;
  private _aquaGrid: AquaGrid;

  constructor(
    private gridNotificationService: GridNotificationService,
    private searchPlusBookmarkService: SearchPlusBookmarkService,
    private tabsSearchService: TabsSearchService,
    private loadingNotificationsService: LoadingNotificationsService,
    private dataSourceId?: string,
    private totalRecord?: number,
    private aquaGrid?: AquaGrid
  ) {
    this._dataSourceId = dataSourceId;
    this._lastRow = totalRecord;
    this._aquaGrid = aquaGrid;
    this._aquaGrid.customMessage = undefined;
    this._aquaGrid.customNoRowMessage = undefined;
    console.debug('SearchResultDataSource::constructor::', dataSourceId, totalRecord);
    // this._aquaGrid.gridApi.setInfiniteRowCount(this._lastRow, true); // It will adjust vertical scroll height
    // this._aquaGrid.gridApi.setVirtualRowCount(this._lastRow, true);
    // this._aquaGrid.gridApi.refreshView();
    // console.debug('SearchResultDataSource::constructor::', dataSourceId, totalRecord, this._aquaGrid.gridApi.getCacheBlockState());
    this.listenResults();
  }
  public getRows(params: IServerSideGetRowsParams): void {
    const gridFilterDataSet: GridDataSetStatusRequest = new GridDataSetStatusRequest(params.request, this._ceftDataSetStatus);
    console.debug('SearchResultDataSource::getRows::', params, gridFilterDataSet);
    if (this._dataSourceId === this.tabsSearchService.activeTabInfo.tabId) {
      console.debug('SearchResultDataSource::getRows::', this._aquaGrid.gridId, this._aquaGrid.gridColumnApi.isPivotMode());
      const gridParams: GridNotificationModel = { serverSideGetRowsRequest: params.request, aquaGrid: this._aquaGrid };
      this.gridNotificationService.updateRowsParam(gridParams);
    }
    // this.gridNotificationService.updateGirdPlusDataSetStautsRequest(gridFilterDataSet);
    this._params = params; // For holding
  }
  public destroy?(): void {
    console.debug('SearchResultDataSource::destroy::');
    // this._alive$.next();
    // this._alive$.complete();
    // this._alive$.unsubscribe();
  }

  private listenResults(): void {
    this.searchPlusBookmarkService.searchResultObervable$
      .pipe(
        filter((searchResultModel: SearchResultModel) => {
          console.debug(
            'SearchResultDataSource::listenResults::filter::',
            searchResultModel,
            this._dataSourceId,
            this.tabsSearchService.activeTabInfo.tabId
          );
          return this._dataSourceId === this.tabsSearchService.activeTabInfo.tabId;
        }),
        takeUntil(this._alive$)
      )
      .subscribe(
        (searchResultModel: SearchResultModel) => {
          console.debug('SearchResultDataSource::listenResults::', searchResultModel, this._params, this._aquaGrid);

          if (this._params && searchResultModel && searchResultModel.listOfRecords) {
            if (searchResultModel.count <= 0) {
              if (this._aquaGrid && this._aquaGrid.gridApi) {
                // this.clearServerDataSource(aquaGrid);
                setTimeout(() => this._aquaGrid.gridApi.showNoRowsOverlay(), 1000);
              }
            }
            // Check if its last row or not for smooth scrolling
            const lastRow = this._params.request.endRow < this._lastRow ? -1 : this._lastRow;

            this._params.successCallback(searchResultModel.listOfRecords as any, searchResultModel.count);
            this.updateSecondaryColumns(this._params.request, searchResultModel);
            console.debug(
              'SearchResultDataSource::listenResults::',
              searchResultModel,
              this._params.request.endRow,
              lastRow,
              this._aquaGrid.gridApi.getCacheBlockState()
            );
          }
        },
        error => {
          if (this._params) {
            this._params.failCallback();
            this._aquaGrid.gridOptions.columnApi.setSecondaryColumns([]);
          }
          console.debug('SearchResultDataSource::listenResults::error::', error);
        }
      );
  }

  private updateSecondaryColumns(request, result: SearchResultModel) {
    console.debug('SearchResultDataSource::updateSecondaryColumns::Column API={%o} ', this._aquaGrid.gridOptions.columnApi);
    if (this._aquaGrid.gridOptions.columnApi) {
      console.debug('SearchResultDataSource::updateSecondaryColumns::Pivote={%o},Pivote Length={%o}, Secondary Column Length={%o} ', request.pivotMode, request.pivotCols.length, result.secondaryColDefs && result.secondaryColDefs.length);
      if (request.pivotMode && request.pivotCols.length > 0 && result.secondaryColDefs && result.secondaryColDefs.length > 0) {

        console.debug('SearchResultDataSource::updateSecondaryColumns::', result, result.secondaryColDefs);
        console.debug('SearchResultDataSource::pivotColumnOverflow ', result.pivotColumnOverflow, result.pivotColumnOverflow === true)
        if (result.pivotColumnOverflow) {
          this._aquaGrid.gridApi.hideOverlay();
          this._aquaGrid.customNoRowMessage = 'Too Many Pivot columns. Please change pivot parameters to try again.';
          this._aquaGrid.showOverlayMessage();
        } else {
          const secondaryColDefs = GridUtils.processSecondaryColumns(this.createSecondaryColumns(result.secondaryColDefs));
          console.debug('SearchResultDataSource::updateSecondaryColumns::', secondaryColDefs);
          this._aquaGrid.gridOptions.columnApi.setSecondaryColumns(secondaryColDefs);
        }
      } else {
        this._aquaGrid.gridOptions.columnApi.setSecondaryColumns([]);
      }
    }
  }

  private createSecondaryColumns(fields) {
    const secondaryCols = [];
    fields.sort();
    fields.forEach(field => {
      secondaryCols.push(field);
    });
    return secondaryCols;
  }
}
