import { Injectable } from '@angular/core';
import { CeftDataSetStatus, DataSetRequest, DataStatus, TabsInfo, GridNotificationModel } from '@aqua/models';
import { VizNotificationService } from '@aqua/services';
import { LocalAtmosphereHandlerService } from '@aqua/services/local-atmosphere-handler.service';
import { IServerSideGetRowsRequest } from 'ag-grid-community';
import { combineLatest, Observable, of } from 'rxjs';
import { filter, map, refCount, shareReplay, switchMap, tap } from 'rxjs/operators';

import { BookmarkService } from '../data-finder/bookmark/bookmark.service';
import { SearchResultUtil } from '../data-finder/search/search-result/search-result.util';
import { SearchService } from '../data-finder/search/search.service';
import { Bookmark, LoadingTypes, SearchField, SearchResultModel, UILoadingStatus } from '../models';
import { SearchBookmarkRequest } from '../models/search-bookmark-request.model';
import { SearchResultDataSetBookmark } from '../models/search-result-bookmark-dataset.model';
import { FilterCancelService } from './filter-cancel.service';
import { FiltersService } from './filters.service';
import { GridNotificationService } from './grid-notification.service';
import { LoadingNotificationsService } from './loading-notifications.service';
import { SearchRequestBuilderService } from './search-request-builder.service';
import { TabsSearchService } from './tabs-search.service';

@Injectable()
export class SearchPlusBookmarkService {
  private _searchInitiateObervable$: Observable<SearchResultDataSetBookmark>;
  private _searchResultDataReadyObervable$: Observable<CeftDataSetStatus>; // Subject<CeftDataSetStatus> = new Subject<CeftDataSetStatus>();
  private _searchResultObervable$: Observable<SearchResultModel>; // = new Subject<SearchBookmarkModel>();

  constructor(
    private searchService: SearchService,
    private bookmarkService: BookmarkService,
    private filtersService: FiltersService,
    private localAtmosphereHandlerService: LocalAtmosphereHandlerService,
    private tabsSearchService: TabsSearchService,
    private gridNotificationService: GridNotificationService,
    private searchRequestBuilderService: SearchRequestBuilderService,
    private loadingNotificationsService: LoadingNotificationsService,
    private vizNotification: VizNotificationService,
    private filterCancelService: FilterCancelService
  ) {
    console.debug('SearchPlusBookmarkService::constructor');
    this.listenStartSearch();
    this.listenDataReady();
    this.listenData();

    // Below listeners are debugging purpose
    // this.listenCriteriaChange();
    // this.listenSearchActivity();
    // this.listenTabNameActivity();
    // this.listenBookmarkActivity();
    // this.listenFilterActivity();
  }
  // private listenCriteriaChange(): void {
  //   // listen current search criteria
  //   this.filtersService
  //     .listenFiltersList$()
  //     .pipe(
  //       debounceTime(500),
  //       map((critieria: SearchField[]) => {
  //         return critieria && critieria.filter(field => !!field.value);
  //       })
  //     )
  //     .subscribe((critieria: SearchField[]) => {
  //       if (critieria.length > 0) {
  //         this.searchRequest.searchCriteria = critieria;
  //       }
  //     });
  // }

  // private listenSearchActivity() {
  //   this.tabsSearchService
  //     .startSearch$()
  //     .pipe(filter((isStarted: boolean) => isStarted))
  //     .subscribe(data => console.debug('SearchPlusBookmarkService::listenSearchActivity::', data));
  // }

  // private listenTabNameActivity() {
  //   this.tabsSearchService.activeTabInfo$().subscribe(data => console.debug('SearchPlusBookmarkService::listenTabNameActivity::', data));
  // }

  // private listenBookmarkActivity() {
  //   this.bookmarkService.activeBookmark$().subscribe(data => console.debug('SearchPlusBookmarkService::listenBookmarkActivity::', data));
  // }

  // private listenFilterActivity() {
  //   this.tabsSearchService.isFilterdSearch$.subscribe(data =>
  //     console.debug(
  //       'SearchPlusBookmarkService::listenFilterActivity::',
  //       data,
  //       this.tabsSearchService.activeTabInfo,
  //       this.tabsSearchService.startSearch
  //     )
  //   );
  // }

  // Will listen search initiate result
  public get searchInitiateObervable$(): Observable<SearchResultDataSetBookmark> {
    return this._searchInitiateObervable$;
  }
  // Will listen data ready event ( notfication may come from web socket)
  public get searchResultDataReadyObervable$(): Observable<CeftDataSetStatus> {
    return this._searchResultDataReadyObervable$;
  }
  // Listen actual (may be paged data) data from server
  public get searchResultObervable$(): Observable<SearchResultModel> {
    return this._searchResultObervable$.pipe(shareReplay({ refCount: true, bufferSize: 2 }));
  }

  private listenStartSearch(): void {
    this._searchInitiateObervable$ = combineLatest(
      this.tabsSearchService.startSearch$(),
      this.tabsSearchService.activeTabInfo$()
      // ,
      // this.tabsSearchService.isFilterdSearch$
    ).pipe(
      tap(([isStarted, activeTabInfo]: any) =>
        console.debug('SearchPlusBookmarkService::listenStartSearch::tap::', isStarted, activeTabInfo)
      ),
      filter(([isStarted, activeTabInfo]: any) => isStarted),

      map(([isStarted, activeTabInfo]: any) => [isStarted, activeTabInfo, this.filtersService.filterListWithValues]),
      filter(([isStarted, activeTabInfo, criteria]: any) => criteria.length > 0),
      switchMap(([isStarted, activeTabInfo, criteria]: [boolean, TabsInfo, SearchField[], boolean]) => {
        const searchBookmarkRequest: SearchBookmarkRequest = this.searchRequestBuilderService.getBookmarkWithDataSet();
        console.debug('SearchPlusBookmarkService::listenStartSearch::switchMap', searchBookmarkRequest);
        this.loadingNotificationsService.dataLoading = new UILoadingStatus(LoadingTypes.SEARCH_REQUEST, true);
        return this.searchService.requestDataset(searchBookmarkRequest);
      }),
      shareReplay({ refCount: true, bufferSize: 1 }),
      tap((data: SearchResultDataSetBookmark) => {
        console.debug('SearchPlusBookmarkService::listenStartSearch::tap::', data);
      })
    );
  }
  private listenDataReady(): void {
    this._searchResultDataReadyObervable$ = this.searchInitiateObervable$.pipe(
      switchMap((dataSetReqResponse: SearchResultDataSetBookmark) => {
        console.debug('SearchPlusBookmarkService::listenDataReady::switchMap::', dataSetReqResponse);
        const uuid: string = this.localAtmosphereHandlerService.getConnectionUuid();
        const ceftDataSetStatus: CeftDataSetStatus = dataSetReqResponse.dataSetStatus;
        if (ceftDataSetStatus && ceftDataSetStatus.ready) {
          console.debug('SearchPlusBookmarkService::listenDataReady::switchMap::Ready::', dataSetReqResponse);
          return of(ceftDataSetStatus);
        } else {
          console.debug('SearchPlusBookmarkService::listenDataReady::switchMap::Loading::', dataSetReqResponse, uuid);
          return this.localAtmosphereHandlerService.registerDataRequest(uuid).pipe(
            filter((data: CeftDataSetStatus) => {
              console.debug(
                'SearchPlusBookmarkService::listenDataReady::switchMap::localAtmosphereHandlerService::',
                data,
                data.status === DataStatus.NOT_LOADED
              );
              this.loadingNotificationsService.dataLoading = new UILoadingStatus(LoadingTypes.WEB_SOCKET_REQUEST, true, data);
              if (data.status === DataStatus.READY) {
                console.debug(
                  'SearchPlusBookmarkService::listenDataReady::switchMap::localAtmosphereHandlerService::',
                  data,
                  data.status === DataStatus.READY
                );
              }

              if (data.status === DataStatus.NOT_LOADED) {
                this.vizNotification.showError(
                  'DataSet can not be loaded now, If problem persists please contact SL3 support.',
                  'Dismiss',
                  1000
                );
                // this.filterCancelService.cancelSubject();
              }
              return data.status === DataStatus.READY;
            })
          );
        }
      }),
      shareReplay({ refCount: true, bufferSize: 1 }),
      tap((data: CeftDataSetStatus) => {
        console.debug('SearchPlusBookmarkService::listenDataReady::tap::', data, data.status === DataStatus.READY);
      })
      // shareReplay({ refCount: true, bufferSize: 1 })
    );
    // .subscribe((data: CeftDataSetStatus) =>
    //   console.debug('SearchPlusBookmarkService::subscribe::tap::', data, data.status === DataStatus.READY)
    // );
  }

  private listenData(): void {
    this._searchResultObervable$ = combineLatest(this.gridNotificationService.rowsParam$).pipe(
      map(([gridNotificationModel]: [GridNotificationModel]) => [
        gridNotificationModel,
        this.bookmarkService.activeBookmark,
        this.tabsSearchService.activeTabInfo
      ]),
      filter(([gridNotificationModel, activeBookmark, activeTabInfo]: [GridNotificationModel, Bookmark, TabsInfo]) => {
        console.debug(
          'SearchPlusBookmarkService::listenData::filter::',
          !!activeBookmark,
          //  gridFilterDataSet && gridFilterDataSet.dataSetStatus.dataSet.type,
          gridNotificationModel,
          activeTabInfo,
          activeBookmark.key
        );
        return !!activeBookmark && !!gridNotificationModel.serverSideGetRowsRequest;
      }),
      switchMap(([gridNotificationModel, activeBookmark, activeTabInfo]: [GridNotificationModel, Bookmark, TabsInfo]) => {
        console.debug('SearchPlusBookmarkService::listenData::switchMap::', gridNotificationModel, activeBookmark, activeTabInfo);

        const dataSetRequest: DataSetRequest = this.searchRequestBuilderService.getDataSetRequest();
        dataSetRequest.gridRequest = gridNotificationModel.serverSideGetRowsRequest;

        dataSetRequest.gridRequest.filterModel = SearchResultUtil.updateFiltersByFilterModel(dataSetRequest.gridRequest.filterModel);
        // console.debug('SearchPlusBookmarkService::listenData::switchMap::', dataSetRequest, gridNotificationModel);
        this.loadingNotificationsService.dataLoading = new UILoadingStatus(LoadingTypes.DATA_REQUEST, true);
        this.tabsSearchService.activeTabInfo.dataSetRequest = dataSetRequest; // This used in export method
        return this.searchService.requestData(dataSetRequest);
      }),
      shareReplay({ refCount: true, bufferSize: 3 })
    );
  }
}
