import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RatingRankingModel } from '@aqua/aqua-component/models/rating-ranking.model';
import { UserDataset } from '@aqua/filters/models';
import { ColumnValueRequest } from '@aqua/models';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, publishReplay, refCount, share, shareReplay } from 'rxjs/operators';

import { FiltersUrlConfig } from './filters-url-config.service';

@Injectable({ providedIn: 'root' })
export class SearchReferenceService {
  private _ratingRankingList$ = new BehaviorSubject<RatingRankingModel[]>(undefined);
  constructor(private http: HttpClient, private urlConfig: FiltersUrlConfig) {
    console.debug('SearchReferenceService::constructor:: Loading Search Service ..................................');
    this.loadRatingRakingList();
  }

  public getCOBDate(): Observable<any> {
    const requestUrl: string = this.urlConfig.EP_GET_COB_DATE;
    console.debug('SearchReferenceService::getCOBDate' + requestUrl);
    return this.http.get(requestUrl).pipe(
      publishReplay(1),
      refCount(),
      share()
    );
  }

  // Gets the datasetId given the soeid and datasetTypeName
  public getDatasetId(soeid: string, datasetTypeName: string): Observable<any> {
    const requestUrl = this.urlConfig.EP_FINDER_DATASET_ID;
    console.debug('SearchReferenceService:: getDatasetId' + requestUrl);
    return this.http.post(requestUrl, { soeid, datasetTypeName });
  }

  public getUserDataset(bookmarkId: number): Observable<UserDataset[]> {
    const requestUrl: string = this.urlConfig.EP_GET_USER_DATASET + '/' + bookmarkId;
    console.debug('SearchReferenceService:: getDatasetId' + requestUrl);
    return this.http.get(requestUrl).pipe(map((data: UserDataset[]) => data));
  }

  public getDistinctFieldValuesForColumn(columnValueRequest: ColumnValueRequest): Observable<any> {
    const rwaColumnDetailsURI = this.urlConfig.EP_DISTINCT_COLUMN_VALUES;
    return this.http.post(rwaColumnDetailsURI, columnValueRequest);
  }

  private loadRatingRakingList(): void {
    this.http
      .get(this.urlConfig.EP_GET_REFERENCE_RATING_RANKINGS)
      .pipe(
        publishReplay(1),
        refCount(),
        share()
      )
      .subscribe((rankingList: RatingRankingModel[]) => this._ratingRankingList$.next(rankingList));
  }

  public get ratingList$() {
    return this._ratingRankingList$.asObservable().pipe(shareReplay(1));
  }
}
