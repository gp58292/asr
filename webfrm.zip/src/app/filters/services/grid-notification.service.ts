import { Injectable } from '@angular/core';
import { GridNotificationModel } from '@aqua/models';
import { Subject } from 'rxjs';
import { shareReplay } from 'rxjs/operators';

import { GridDataSetStatusRequest } from '../models';

@Injectable({ providedIn: 'root' })
export class GridNotificationService {
  public get rowsParam$() {
    return this._rowsParam$.asObservable().pipe(shareReplay(1));
  }

  public get gridFilterPlusDataSetStatus$() {
    return this._gridFilterPlusDataSetStatus$.asObservable().pipe(shareReplay(1));
  }
  private _rowsParam$ = new Subject<GridNotificationModel>();

  private _gridFilterPlusDataSetStatus$ = new Subject<GridDataSetStatusRequest>();

  public updateRowsParam(params: GridNotificationModel): void {
    this._rowsParam$.next(params);
  }

  public updateGirdPlusDataSetStautsRequest(params: GridDataSetStatusRequest): void {
    this._gridFilterPlusDataSetStatus$.next(params);
  }
}
