import { Injectable } from '@angular/core';
import { Group, TableNode } from '@aqua/filters/models';
import { FiltersService } from '@aqua/filters/services/filters.service';
import { cloneDeep, map as lodashMap, orderBy } from 'lodash';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';

import { SettingsService } from '../data-finder/settings/settings.service';
import { AttributeNode, AttributesTree, AttributesViewMode, WhoCanWhoHas } from '../filters.types';

@Injectable()
export class DataTreeStorageService {
  private static mapGroupNodes(data: Group[], whoCanWhoHas: WhoCanWhoHas): void {
    data.forEach(topNode => DataTreeStorageService.mapTableNodes(topNode.children, whoCanWhoHas));
  }
  private static filterGroupNodes(data: Group[], whoCanWhoHas: WhoCanWhoHas): Group[] {
    return data.filter(topNode => {
      topNode.children = DataTreeStorageService.filterTableNodes(topNode.children, whoCanWhoHas);
      return topNode.children.length > 0;
    });
  }

  private static mapTableNodes(data: TableNode[], whoCanWhoHas: WhoCanWhoHas): void {
    data.forEach(topNode => {
      topNode.children.forEach(field => {
        if (field.filterOnlyFlag === 0) {
          field.whoHasFlag = WhoCanWhoHas.CAN;
        }
      });
    });
  }

  private static filterTableNodes(data: TableNode[], whoCanWhoHas: WhoCanWhoHas): TableNode[] {
    return data.filter(tableName => {
      tableName.children = tableName.children.filter(field => field.whoHasFlag === whoCanWhoHas);
      return tableName.children.length > 0;
    });
  }
  public originalFlatCopy: any;
  public originalGroupedCopy: any;
  // Who can trees
  private flatTree: any[];
  private groupTree: any[];

  // Who has trees
  private flatTreeWhoHas: any[];
  private groupTreeWhoHas: any[];

  private flatTreeNotifier = new Subject<any[]>();
  private groupDataTreeNotifier = new Subject<any[]>();
  private whoCanWhoHas$ = new BehaviorSubject(WhoCanWhoHas.CAN);
  private attributesViewModeChanged = new Subject<AttributesViewMode>();

  /**
   * @name  :constructor
   * @description :
   */
  constructor(private searchSettingService: SettingsService, private filtersService: FiltersService) {
    console.debug('DataTreeStorageService::constructor');
    this.getSettingsTreeData();
    this.getSettingsFlatData();
  }

  public orderNodesByName(nodes) {
    const newNodes = lodashMap(nodes, node => (node.children ? { ...node, children: this.orderNodesByName(node.children) } : node));
    return orderBy(newNodes, item => item.name.toUpperCase(), 'asc');
  }

  /**
   * @name  :getSettingsFlatData
   * @description :
   */
  public getSettingsFlatData() {
    console.debug('SearchSettingsComponent::getFilterListForTreeView');

    this.searchSettingService
      .getFilterListForFlatView()
      .pipe(map(data => this.orderNodesByName(data)))
      .subscribe((data: TableNode[]) => {
        this.originalFlatCopy = cloneDeep(data);
        this.flatTree = cloneDeep(data);
        this.setHasFields(cloneDeep(data), AttributesViewMode.FLAT);
        this.setCanFields(cloneDeep(data), AttributesViewMode.FLAT);
        // console.debug('SettingsSidePanelComponent::getFilterListForTreeView::1', this.flatTree);
        this.flatTreeNotifier.next(this.flatTree);
      });
  }

  /**
   * @name  :getSettingsTreeData
   * @description :
   */
  public getSettingsTreeData() {
    console.debug('SearchSettingsComponent::getFilterListForTreeView');
    this.searchSettingService
      .getFilterListForTreeView()
      .pipe(map(data => this.orderNodesByName(data)))
      .subscribe((data: Group[]) => {
        this.originalGroupedCopy = cloneDeep(data);
        this.groupTree = cloneDeep(data);
        this.setHasFields(cloneDeep(data), AttributesViewMode.GROUP);
        this.setCanFields(cloneDeep(data), AttributesViewMode.GROUP);
        this.groupDataTreeNotifier.next(this.groupTree);
      });
  }

  /**
   * @name  :updateNode
   * @description : Given a given filterField it finds that field in both trees and toggles the appropiate flag( 'exported || 'filtered')
   */
  // TODO currently we check for matching key. We should also check the whocanwhohas flags match up because a field can be in both sections
  public updateNode(filter: any, toggleFilterOrExport: 'filter' | 'export', triggerTreeNotifier = true) {
    // console.debug('DataTreeStorageService::updateNode filter', filter);

    // Update Flat Tree
    let myWorkNodeElement = this.getCurrentTreeStructureInView(AttributesViewMode.FLAT, filter.whoHasFlag) as any;
    if (!myWorkNodeElement) {
      return;
    }

    myWorkNodeElement = myWorkNodeElement.find(obj => obj.name === filter.logicalGroupName);
    // console.debug('DataTreeStorageService::updateNode flat parent', myWorkNodeElement, myWorkNodeElement.children);

    myWorkNodeElement = myWorkNodeElement.children.find(obj => obj.key === filter.key && obj.whoHasFlag === filter.whoHasFlag);

    if (myWorkNodeElement) {
      // console.debug('DataTreeStorageService::updateNode flat itemFilter', myWorkNodeElement);
      myWorkNodeElement.filtered = !myWorkNodeElement.filtered;

      if (triggerTreeNotifier) {
        // console.debug('SettingsSidePanelComponent::getFilterListForTreeView::2', this.flatTree, triggerTreeNotifier);
        this.flatTreeNotifier.next(this.getCurrentTreeStructureInView(AttributesViewMode.FLAT, this.whoCanWhoHas$.value));
      }
    }

    // Update grouped tree
    // Point the first node to the top of the tree.
    myWorkNodeElement = this.getCurrentTreeStructureInView(AttributesViewMode.GROUP, filter.whoHasFlag) as any;
    /**
     *  Filter struct info
     *    - logicalGroupName: either MAC,SMC,or BOX  LEVEL 1
     *    - nodeName: the table name                 LEVEL 2
     */
    if (!myWorkNodeElement) {
      return;
    }

    // Find filter and update the node. We must traverse the tree and update the bottom most child in question.
    let index = myWorkNodeElement.findIndex(obj => obj.name === filter.logicalGroupName);
    // console.debug('DataTreeStorageService::updateNode grouped', filter, index);
    // Next level. Pointed to the highest level
    myWorkNodeElement = myWorkNodeElement[index].children;
    // console.debug('DataTreeStorageService::updateNode grouped topNode found', myWorkNodeElement);
    // Find the table where the 'filter' var belongs.
    index = myWorkNodeElement.findIndex(obj => obj.name === filter.nodeDisplayName);
    // console.debug('DataTreeStorageService::updateNode grouped index after topNode', index, myWorkNodeElement[index]);

    // Now set the myWorkNodeElement to that index. We are at the table level.
    myWorkNodeElement = myWorkNodeElement[index].children as any;
    // console.debug('DataTreeStorageService::updateNode grouped direct parent found');
    // Next we must traverse all the columns in the table to find the table we want.
    index = myWorkNodeElement.findIndex(obj => obj.key === filter.key && obj.whoHasFlag === filter.whoHasFlag);
    // Now we have reached the bottom most filter level and can now update the filter.
    myWorkNodeElement = myWorkNodeElement[index] as any;

    if (!myWorkNodeElement) {
      return;
    }

    // console.debug('DataTreeStorageService::updateNode grouped final node found');
    if (toggleFilterOrExport === 'filter') {
      myWorkNodeElement.filtered = !myWorkNodeElement.filtered;
    }
    if (triggerTreeNotifier) {
      this.groupDataTreeNotifier.next(this.getCurrentTreeStructureInView(AttributesViewMode.GROUP, this.whoCanWhoHas$.value));
    }
    // console.debug('DataTreeStorageService::updateNode grouped final node found::',myWorkNodeElement['value'],filter.value);
    myWorkNodeElement.value = filter.value;
    // console.debug('DataTreeStorageService::updateNode final node updated value::',filter,myWorkNodeElement);

    this.filtersService.filterToggle(cloneDeep(myWorkNodeElement));
  }

  /**
   * @name  :listenState
   * @description :
   */
  public listenState(): Observable<any> {
    // console.debug('DataTreeStorageService::listenState');
    return this.flatTreeNotifier.asObservable();
  }

  /**
   * @name  :listenStateGroupTree
   * @description :
   */
  public listenStateGroupTree(): Observable<any> {
    // console.debug('DataTreeStorageService::listenStateGroupTree');
    return this.groupDataTreeNotifier.asObservable();
  }

  public listenForWhoHasWhoCanChanged(): Observable<WhoCanWhoHas> {
    return this.whoCanWhoHas$.asObservable();
  }

  public listenForAttributesViewModeChanged() {
    return this.attributesViewModeChanged.asObservable();
  }

  /**
   * @name  :treeIterator
   * @description :
   */
  public treeIterator(searchCriteria: string, data: any[], ipath: string, filteredTree: any[], type?: AttributesViewMode) {
    // console.debug("DataTreeStorageService::treeIterator");
    if (searchCriteria === '') {
      if (type === AttributesViewMode.GROUP) {
        filteredTree = data;
        return filteredTree;
      }

      return this.getCurrentTreeStructureInView(AttributesViewMode.FLAT, this.whoCanWhoHas$.value);
    }

    const struct = false;

    for (const tNode of data) {
      let path = ipath;
      // console.debug("DataTreeStorageService::treeIterator tNode", tNode);
      if (tNode.children && tNode.children.length > 0) {
        path += path ? '|' + tNode.name : tNode.name;
        this.treeIterator(searchCriteria, tNode.children, path, filteredTree);
      } else {
        const match: boolean = tNode.name.toLowerCase().indexOf(searchCriteria.toLowerCase()) >= 0;
        // console.debug("DataTreeStorageService::treeIterator match", match);
        // Clone function
        if (match) {
          path += path ? '|' + tNode.name : tNode.name;
          this.cloneNode(tNode, path, filteredTree);
        }
      }
    }
    return struct;
  }

  /**
   * @name  :clearAllFilters
   * @description :
   */
  public clearAllFilters() {
    console.debug('DataTreeStorageService::clearAllFilters');
    this.flatTree &&
      this.flatTree.forEach(topNode => {
        topNode.children.forEach(filter => {
          filter.filtered = false;
        });
      });
    this.flatTreeWhoHas &&
      this.flatTreeWhoHas.forEach(topNode => {
        topNode.children.forEach(filter => {
          filter.filtered = false;
        });
      });

    this.groupTree &&
      this.groupTree.forEach(topNode => {
        topNode.children.forEach(tableNode => {
          tableNode.children.forEach(filter => {
            filter.filtered = false;
          });
        });
      });
    this.groupTreeWhoHas &&
      this.groupTreeWhoHas.forEach(topNode => {
        topNode.children.forEach(tableNode => {
          tableNode.children.forEach(filter => {
            filter.filtered = false;
          });
        });
      });
    // TODO on reset do we want to reset only the selected section (Who Can / Who has fields) or reset all.
    // this.setCanFields(cloneDeep(this.originalFlatCopy),'flat')
    // this.setHasFields(cloneDeep(this.originalFlatCopy),'flat')
    // this.setCanFields(cloneDeep(this.originalGroupedCopy),'grouped')
    // this.setHasFields(cloneDeep(this.originalGroupedCopy),'grouped')

    const whoCanWhoHas = this.whoCanWhoHas$.value;

    this.filtersService.resetFiltersList();
    // console.debug('SettingsSidePanelComponent::getFilterListForTreeView::3', this.flatTree);
    this.flatTreeNotifier.next(this.getCurrentTreeStructureInView(AttributesViewMode.FLAT, whoCanWhoHas));
    this.groupDataTreeNotifier.next(this.getCurrentTreeStructureInView(AttributesViewMode.GROUP, whoCanWhoHas));
  }

  /**
   * @name  :setFiltersBasedOfBookmark
   * @description :
   */
  public setFiltersBasedOfBookmark(fields: any) {
    console.debug('DataTreeStorageService::setFiltersBasedOfBookmark', fields);
    this.clearAllFilters();
    for (let i = 0, last = fields.length - 1; i <= last; i++) {
      const field = fields[i];
      field.filtered = false;
      // In order to avoid multiple tree re-rendering. Trigger tree notifire only on the last updated field.
      this.updateNode(field, 'filter', i === last);
    }
  }

  public toggleWhoCanWhoHasTree(newWhoCanWhoHas: WhoCanWhoHas) {
    const oldWhoCanWhoHas = this.whoCanWhoHas$.value;
    console.debug('DataTreeStorageService::toggleWhoCanWhoHasTree', oldWhoCanWhoHas, newWhoCanWhoHas);

    this.whoCanWhoHas$.next(newWhoCanWhoHas);

    if (oldWhoCanWhoHas !== newWhoCanWhoHas) {
      // console.debug('SettingsSidePanelComponent::getFilterListForTreeView::4', this.flatTree);
      this.flatTreeNotifier.next(this.getCurrentTreeStructureInView(AttributesViewMode.FLAT, newWhoCanWhoHas));
      this.groupDataTreeNotifier.next(this.getCurrentTreeStructureInView(AttributesViewMode.GROUP, newWhoCanWhoHas));
    }
  }

  public toggleAttributesViewMode(viewMode: AttributesViewMode) {
    this.attributesViewModeChanged.next(viewMode);
  }

  /**
   * Sort Attributes tree recursively by filtered attribute.
   * But all filtered attributes should be on the top.
   */
  public sortAttributesTree(nodes: AttributesTree, filteredAttribute: AttributeNode) {
    // console.debug('DataTreeStorageService::sortAttributesTree::', nodes);
    for (const node of nodes) {
      if (node.children && node.children.length > 0) {
        const i = node.children.findIndex(
          attribute => attribute.key === filteredAttribute.key && attribute.whoHasFlag === filteredAttribute.whoHasFlag
        );

        if (i !== -1) {
          node.children = [filteredAttribute, ...node.children.slice(0, i), ...node.children.slice(i + 1)];
          return;
        }

        this.sortAttributesTree(node.children, filteredAttribute);
      }
    }

    return;
  }

  /**
   * @name  :cloneNode
   * @description :
   */
  private cloneNode(node: any, path: string, filteredTree: any[]) {
    const pathHeirachy = path.split('|');
    // console.debug("DataTreeStorageService::cloneNode", path, pathHeirachy);
    let myWorkNodeElement: any[] = filteredTree;
    // console.debug("DataTreeStorageService::cloneNode pointer", myWorkNodeElement);
    // 2. To go through path and create Nodes as needed
    for (const p of pathHeirachy) {
      // console.debug("DataTreeStorageService::cloneNode pathHeirachy p", p);
      // Get children on myWorkNodeElement if it exists:
      const index = myWorkNodeElement.findIndex(obj => {
        return obj.name === p;
      });
      // console.debug("DataTreeStorageService::cloneNode index p", index);
      // The heirachy does not exist so we must add it to the filteredTree
      if (index === -1) {
        // Last level of heiracrhy
        if (pathHeirachy.indexOf(p) === pathHeirachy.length - 1) {
          myWorkNodeElement.push(node);
        } else {
          myWorkNodeElement.push({ name: p, children: [] });
        }
        myWorkNodeElement = myWorkNodeElement[myWorkNodeElement.length - 1].children; // Points to the latest inserted element;
      } else {
        myWorkNodeElement = myWorkNodeElement[index].children;
      }
    }
    // Update subscriber
    // this.subject.next(filteredTree);
    return filteredTree;
  }

  private setHasFields(data: Group[] | TableNode[], typeTree: AttributesViewMode) {
    //  console.debug('DataTreeStorageService::setHasFields', JSON.parse(JSON.stringify(data)));
    if (typeTree === AttributesViewMode.FLAT) {
      this.flatTreeWhoHas = DataTreeStorageService.filterTableNodes(data as TableNode[], WhoCanWhoHas.HAS);
    } else if (typeTree === AttributesViewMode.GROUP) {
      this.groupTreeWhoHas = DataTreeStorageService.filterGroupNodes(data as Group[], WhoCanWhoHas.HAS);
    }
    // console.debug('DataTreeStorageService::setHasFields::', this.flatTreeWhoHas, this.groupTreeWhoHas);
  }

  private setCanFields(data: Group[] | TableNode[], typeTree: AttributesViewMode) {
    // console.debug('DataTreeStorageService::setCanFields', JSON.parse(JSON.stringify(data)));
    if (typeTree === AttributesViewMode.FLAT) {
      DataTreeStorageService.mapTableNodes(data as TableNode[], WhoCanWhoHas.CAN);
      this.flatTree = DataTreeStorageService.filterTableNodes(data as TableNode[], WhoCanWhoHas.CAN);
      // console.debug('DataTreeStorageService::setCanFields flattree', JSON.parse(JSON.stringify(this.flatTree)));
    } else if (typeTree === AttributesViewMode.GROUP) {
      DataTreeStorageService.mapGroupNodes(data as Group[], WhoCanWhoHas.CAN);
      this.groupTree = DataTreeStorageService.filterGroupNodes(data as Group[], WhoCanWhoHas.CAN);
      // console.debug('DataTreeStorageService::setCanFields whocangroup', JSON.parse(JSON.stringify(this.groupTree)));
    }
  }

  private getCurrentTreeStructureInView(type: AttributesViewMode, whoHasFlag: WhoCanWhoHas) {
    if (type === AttributesViewMode.FLAT) {
      return whoHasFlag === WhoCanWhoHas.CAN ? this.flatTree : this.flatTreeWhoHas;
    }
    return whoHasFlag === WhoCanWhoHas.CAN ? this.groupTree : this.groupTreeWhoHas;
  }
}
