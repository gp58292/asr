import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { shareReplay } from 'rxjs/operators';

import { LoadingTypes, UILoadingStatus } from '../models';

@Injectable({ providedIn: 'root' })
export class LoadingNotificationsService {
  private _searchStarted$: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private _dataLoadingStarted$: BehaviorSubject<UILoadingStatus> = new BehaviorSubject(new UILoadingStatus(LoadingTypes.SEARCH_REQUEST));

  constructor() {
    console.debug('LoadingNotificationsService::constructor::');
  }
  // Simple search loading notification
  public get searchingStatus$(): Observable<boolean> {
    return this._searchStarted$.asObservable();
  }
  public set searchStarted(isStarted: boolean) {
    this._searchStarted$.next(isStarted);
  }

  public get dataLoading$(): Observable<UILoadingStatus> {
    return this._dataLoadingStarted$.asObservable().pipe(shareReplay(1));
  }
  public get dataLoading(): UILoadingStatus {
    return this._dataLoadingStarted$.value;
  }
  public set dataLoading(uiLoadingStatus: UILoadingStatus) {
    this._dataLoadingStarted$.next(uiLoadingStatus);
  }
}
