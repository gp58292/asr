import { Injectable } from '@angular/core';
import { DataSetRequest, TabsInfo, GridNotificationModel } from '@aqua/models';
import { LocalAtmosphereHandlerService } from '@aqua/services/local-atmosphere-handler.service';
import { IServerSideGetRowsRequest } from 'ag-grid-community';
import { BehaviorSubject, combineLatest } from 'rxjs';
import { debounceTime, filter, map, shareReplay, tap } from 'rxjs/operators';

import { BookmarkRequest } from '../data-finder/bookmark/bookmark-request.model';
import { BookmarkService } from '../data-finder/bookmark/bookmark.service';
import { Bookmark, SearchBookmarkRequest, SearchField, SearchRequest } from '../models';
import { FiltersService } from './filters.service';
import { GridNotificationService } from './grid-notification.service';
import { TabsSearchService } from './tabs-search.service';

@Injectable()
export class SearchRequestBuilderService {
  private _searchRequestBuilder$: BehaviorSubject<SearchBookmarkRequest> = new BehaviorSubject<SearchBookmarkRequest>(undefined);
  private _dataRequestBuilder$: BehaviorSubject<DataSetRequest> = new BehaviorSubject<DataSetRequest>(undefined);

  private _latestCurrentCriteria: SearchField[] = [];

  constructor(
    private bookmarkService: BookmarkService,
    private filtersService: FiltersService,
    private localAtmosphereHandlerService: LocalAtmosphereHandlerService,
    private tabsSearchService: TabsSearchService,
    private gridNotificationService: GridNotificationService
  ) {
    console.debug('SearchRequestBuilderService::constructor');
    this.listenCriteria();

    this.listenVaruiousSearchRequestCriteria();
    this.listenVaruiousDataRequestCriteria();
  }

  public get searchBookmarkRequest() {
    return this._searchRequestBuilder$.value;
  }
  public get searchDataRequest() {
    return this._dataRequestBuilder$.value;
  }

  public getBookmarkWithDataSet(): SearchBookmarkRequest {
    const activeBookmark: Bookmark = this.bookmarkService.activeBookmark;
    const activeTabInfo: TabsInfo = this.tabsSearchService.activeTabInfo;

    const searchBookmarkRequest: SearchBookmarkRequest = new SearchBookmarkRequest();
    const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
    const searchRequest = new SearchRequest();

    searchBookmarkRequest.atmosphereResourceUuid = this.localAtmosphereHandlerService.getConnectionUuid();
    // Update data set type before requesting data
    searchRequest.datasetType = activeTabInfo.getDataSetType(this.tabsSearchService.isFilteredCurrentPostingTabActive);

    searchRequest.searchCriteria = this._latestCurrentCriteria;

    bookmarkRequest.bookmarkData = this._latestCurrentCriteria;
    if (activeBookmark) {
      bookmarkRequest.bookmarkId = activeBookmark.key;
      bookmarkRequest.parentBookmarkId = activeBookmark.parentId;
    }

    searchBookmarkRequest.bookmarkRequest = bookmarkRequest;
    searchBookmarkRequest.searchRequest = searchRequest;
    return searchBookmarkRequest;
  }

  public getDataSetRequest(): DataSetRequest {
    const activeBookmark: Bookmark = this.bookmarkService.activeBookmark;
    const activeTabInfo: TabsInfo = this.tabsSearchService.activeTabInfo;

    const dataSetRequest: DataSetRequest = new DataSetRequest();
    // dataSetRequest.gridRequest =  this.gridNotificationService.rowsParam$;
    dataSetRequest.type = activeTabInfo.getDataSetType(this.tabsSearchService.isFilteredCurrentPostingTabActive);
    dataSetRequest.bookmarkId = activeBookmark.key;
    if (this.tabsSearchService.selectedRows && this.tabsSearchService.selectedRows.length > 0) {
      dataSetRequest.agreementKeys = this.tabsSearchService.selectedRows;
    }

    return dataSetRequest;
  }

  private listenCriteria(): void {
    this.filtersService.filterValueChanged$().subscribe((criteria: SearchField[]) => {
      console.debug('SearchRequestBuilderService::listenCriteria::', criteria);
      this._latestCurrentCriteria = criteria;
    });
  }

  private listenVaruiousSearchRequestCriteria(): void {
    combineLatest(
      this.filtersService.filterValueChanged$(),
      this.bookmarkService.activeBookmark$(),
      this.tabsSearchService.activeTabInfo$()
    )
      .pipe(
        shareReplay(1),
        // map(([criteria, activeBookmark, activeTabInfo]: [SearchField[], Bookmark, TabsInfo]) => [
        //   criteria ? criteria.filter((field: SearchField) => !!field.value) : [],
        //   activeBookmark,
        //   activeTabInfo
        // ]),
        filter(([criteria, activeBookmark, activeTabInfo]: [SearchField[], Bookmark, TabsInfo]) => activeTabInfo && criteria.length > 0),
        tap(([criteria, activeBookmark, activeTabInfo]: [SearchField[], Bookmark, TabsInfo]) => {
          console.debug(
            'SearchRequestBuilderService::listenVaruiousSearchRequestCriteria::tap::',
            criteria,
            activeBookmark,
            activeTabInfo,
            this.filtersService.filterListWithValues,
            this.tabsSearchService.isCurrentPostingTabActive,
            this.tabsSearchService.isFilteredSearch
          );
          const searchBookmarkRequest: SearchBookmarkRequest = new SearchBookmarkRequest();
          const bookmarkRequest: BookmarkRequest = new BookmarkRequest();
          const searchRequest = new SearchRequest();

          searchBookmarkRequest.atmosphereResourceUuid = this.localAtmosphereHandlerService.getConnectionUuid();
          // Update data set type before requesting data
          searchRequest.datasetType = activeTabInfo.getDataSetType(this.tabsSearchService.isFilteredCurrentPostingTabActive);
          searchRequest.searchCriteria = criteria;

          bookmarkRequest.bookmarkData = criteria;
          if (activeBookmark) {
            bookmarkRequest.bookmarkId = activeBookmark.key;
            bookmarkRequest.parentBookmarkId = activeBookmark.parentId;
          }

          searchBookmarkRequest.bookmarkRequest = bookmarkRequest;
          searchBookmarkRequest.searchRequest = searchRequest;

          console.debug('SearchRequestBuilderService::listenVaruiousSearchRequestCriteria::tap::', searchBookmarkRequest);
          this._searchRequestBuilder$.next(searchBookmarkRequest);
        })
      )
      .subscribe((data: any) => {
        // console.debug(
        //   'SearchRequestBuilderService::listenVaruiousSearchRequestCriteria::subscribe:: As we dont have any subscriber to trigger ',
        //   dataX
        // );
      });
  }

  private listenVaruiousDataRequestCriteria(): void {
    combineLatest(this.bookmarkService.activeBookmark$(), this.tabsSearchService.activeTabInfo$(), this.gridNotificationService.rowsParam$)
      .pipe(
        debounceTime(500),
        shareReplay(1),
        map(([activeBookmark, activeTabInfo, gridNotificationModel]: [Bookmark, TabsInfo, GridNotificationModel]) => [
          activeBookmark,
          activeTabInfo,
          gridNotificationModel
        ]),
        filter(
          ([activeBookmark, activeTabInfo, gridNotificationModel]: [Bookmark, TabsInfo, GridNotificationModel]) =>
            !!activeBookmark && !!activeTabInfo
        ),
        tap(([activeBookmark, activeTabInfo, gridNotificationModel]: [Bookmark, TabsInfo, GridNotificationModel]) => {
          // console.debug('SearchRequestBuilderService::listenVaruiousDataRequestCriteria::tap::', activeBookmark, activeTabInfo, gridFilter);
          const dataSetRequest: DataSetRequest = new DataSetRequest();
          dataSetRequest.gridRequest = gridNotificationModel.serverSideGetRowsRequest;

          dataSetRequest.type = activeTabInfo.getDataSetType(this.tabsSearchService.isFilteredCurrentPostingTabActive);
          dataSetRequest.bookmarkId = activeBookmark.key;
          if (this.tabsSearchService.selectedRows && this.tabsSearchService.selectedRows.length > 0) {
            dataSetRequest.agreementKeys = this.tabsSearchService.selectedRows;
          }

          console.debug('SearchRequestBuilderService::listenVaruiousDataRequestCriteria::tap::', dataSetRequest);
          this._dataRequestBuilder$.next(dataSetRequest);
        })
      )
      .subscribe((data: any) => {
        // console.debug(
        //   'SearchRequestBuilderService::listenVaruiousDataRequestCriteria::subscribe:: As we dont have any subscriber to trigger ',
        //   data
        // );
      });
  }
}
