import { Injectable } from '@angular/core';
import { ComponentType, SearchField } from '@aqua/filters/models';
import { reject, some } from 'lodash';
import { BehaviorSubject, from, of } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, map, shareReplay, switchMap } from 'rxjs/operators';

@Injectable()
export class FiltersService {
  private filtersPool$ = new BehaviorSubject<SearchField[]>([]);

  private filtersViewMode$ = new BehaviorSubject<boolean>(false);

  private _isFilterValueChanged$ = new BehaviorSubject<boolean>(false);

  public listenFiltersList$() {
    return this.filtersPool$.asObservable().pipe(
      shareReplay(1),
      distinctUntilChanged()
    );
  }

  public filterValueChanged$() {
    return this._isFilterValueChanged$.asObservable().pipe(
      debounceTime(100),
      shareReplay(1),
      switchMap((isChanged: boolean) => {
        const rawCriteria = this.filtersPool$.value.filter((field: SearchField) => !!field.value);
        if (rawCriteria.length > 0) {
          return of(rawCriteria);
        } else {
          return of([]);
        }
      })
    );
  }

  public get filtersList() {
    return this.filtersPool$.value;
  }

  public get filterListWithValues() {
    // return this.filtersPool$.pipe(map((filterList:SearchField[])=>filterList.filter((field: SearchField) => !!field.value)),shareReplay(1));
    return this.filtersPool$.value ? this.filtersPool$.value.filter((field: SearchField) => !!field.value) : [];
  }

  public setFiltersList(filters: SearchField[]) {
    // console.debug('SearchComponent::setFiltersList$::', filters);
    // filters.forEach(data => console.debug('SearchComponent::setFiltersList$::Value::', JSON.stringify(data.value)));
    this.filtersPool$.next(filters);
  }
  public isFilterValueChanged(isChanged: boolean) {
    this._isFilterValueChanged$.next(isChanged);
  }

  public resetFiltersList() {
    this.setFiltersList([]);
  }

  public filterToggle(newFieldIn: SearchField) {
    const fieldsList = this.filtersPool$.value;
    const newFieldsList = some(fieldsList, { key: newFieldIn.key, whoHasFlag: newFieldIn.whoHasFlag })
      ? reject(fieldsList, { key: newFieldIn.key, whoHasFlag: newFieldIn.whoHasFlag })
      : [...fieldsList, newFieldIn];

    this.setFiltersList(newFieldsList);
  }

  public get filtersViewMode() {
    return this.filtersViewMode$.value;
  }

  public setFiltersViewMode(newViewMode: boolean) {
    this.filtersViewMode$.next(newViewMode);
  }

  public listenFiltersViewMode$() {
    return this.filtersViewMode$.asObservable();
  }

  // public get isContractualCTNExist() {
  //   return this.listenFiltersList$().pipe(
  //     filter((data: SearchField[]) => data && data.length > 0),
  //     switchMap((data: SearchField[]) => {
  //       return from(data).pipe(
  //         filter(
  //           (field: SearchField) =>
  //             (field.componentType === ComponentType.MULTI_INCLUDE_EXCLUDE && field.value) ||
  //             (field.logicalGroupName === 'Optimality Attributes' && field.value)
  //         )
  //       );
  //     })
  //   );
  // }
}
