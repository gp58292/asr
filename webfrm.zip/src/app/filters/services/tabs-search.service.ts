import { Injectable } from '@angular/core';
import { TabsInfo } from '@aqua/models';
import { BehaviorSubject } from 'rxjs';
import { shareReplay } from 'rxjs/operators';

@Injectable()
export class TabsSearchService {
  private _listedTab: TabsInfo = new TabsInfo('listed', 'Listed', 0);
  private _activeTabInfo$ = new BehaviorSubject<TabsInfo>(this._listedTab);
  private _startSearch$ = new BehaviorSubject<boolean>(false);
  private _isFilteredSearch$ = new BehaviorSubject<boolean>(false);

  private _selectedRows$ = new BehaviorSubject<number[]>([]);

  public get isListedTabActive() {
    return this._listedTab.equals(this.activeTabInfo);
  }

  public get isCurrentPostingTabActive() {
    return this.activeTabInfo.tabId === 'curr_post';
  }
  public get isFilteredCurrentPostingTabActive() {
    return this.isCurrentPostingTabActive && this.isFilteredSearch;
  }

  public activeTabInfo$() {
    return this._activeTabInfo$.asObservable().pipe(shareReplay(1));
  }

  public get activeTabInfo() {
    return this._activeTabInfo$.value;
  }

  public setTabInfo(tabInfo: TabsInfo) {
    if (!tabInfo.equals(this.activeTabInfo)) {
      console.debug('SearchPlusBookmarkService::setTabInfo::', tabInfo);
      this._activeTabInfo$.next(tabInfo);
    }
  }

  // Below API's are start search and of selected rows
  public startSearch$() {
    return this._startSearch$.asObservable().pipe(shareReplay(1));
  }
  public get startSearch() {
    return this._startSearch$.value;
  }

  public setStartSearch(isStarted: boolean) {
    this.setTabInfo(this._listedTab); // When user click on search button always reset tab to first listed Tab as this tab drives other tabs
    this._startSearch$.next(isStarted);
    this.selectedRows = []; // Clear perviously selected rows
  }

  public triggerFilteredSearch(isStarted: boolean) {
    this._startSearch$.next(isStarted);
  }

  public get isFilteredSearch$() {
    return this._isFilteredSearch$.asObservable().pipe(shareReplay(1));
  }
  public get isFilteredSearch() {
    return this._isFilteredSearch$.value;
  }

  public setIsFilteredSearch(isFiltered: boolean) {
    console.debug('TabsSearchService::setIsFilteredSearch::', isFiltered, this.isFilteredSearch);
    if (isFiltered !== this.isFilteredSearch) {
      this._isFilteredSearch$.next(isFiltered);
    }
  }

  public set selectedRows(rows: number[]) {
    this._selectedRows$.next(rows);
  }
  public get selectedRows(): number[] {
    return this._selectedRows$.value;
  }
}
