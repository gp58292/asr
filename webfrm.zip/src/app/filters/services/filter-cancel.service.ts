import { Injectable, OnDestroy } from '@angular/core';
import { VizNotificationService } from '@aqua/services';
import { Observable, Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';

import { LoadingNotificationsService } from './loading-notifications.service';

@Injectable()
export class FilterCancelService implements OnDestroy {
  private cancel: Subject<void> = new Subject();

  constructor(private vizNotificationService: VizNotificationService, private loadingNotificationsService: LoadingNotificationsService) {
    console.debug('FilterCancelService::constructor');
    this.watchCancel();
  }

  public getSubject(): Observable<void> {
    return this.cancel;
  }

  public cancelSubject(): void {
    console.debug('FilterCancelService::cancelSubject::', this.cancel, this.loadingNotificationsService.dataLoading);
    if (this.cancel && !this.cancel.isStopped && this.loadingNotificationsService.dataLoading.isStarted) {
      this.cancel.next();
    }
  }

  public ngOnDestroy() {
    this.cancel.complete();
    this.cancel.unsubscribe();
  }

  public watchCancel(): void {
    this.cancel.pipe(debounceTime(200)).subscribe(() => {
      this.vizNotificationService.showMessage('Cancelled search request successfully');
    });
  }
}
