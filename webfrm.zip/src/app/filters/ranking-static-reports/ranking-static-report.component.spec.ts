import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { RankingStaticReportComponent } from "./ranking-static-report.component";


describe("RankingStaticReportComponent", () => {
	let component: RankingStaticReportComponent;
	let fixture: ComponentFixture<RankingStaticReportComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [RankingStaticReportComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(RankingStaticReportComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
