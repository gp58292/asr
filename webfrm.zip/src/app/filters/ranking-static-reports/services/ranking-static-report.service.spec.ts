import { inject, TestBed } from "@angular/core/testing";
import { RankingStaticReportService } from "./ranking-static-report-service";

describe("RankingStaticReportService", () => {
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [RankingStaticReportService]
		});
	});

	it("should be created", inject([RankingStaticReportService], (service: RankingStaticReportService) => {
		expect(service).toBeTruthy();
	}));
});
