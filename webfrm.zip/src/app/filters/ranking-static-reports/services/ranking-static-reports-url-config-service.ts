import { Injectable } from '@angular/core';



@Injectable()
export class RankingStaticReportsUrlConfigService {
    // Base settings
    public API: string = "/api";


    //controller end point
    public EP_REPORTS: string = "/reports";
    public EP_GET_RANKING_STATIC_REPORT: string = this.API + this.EP_REPORTS + "/geRankingStaticDetails";

    public DMT_SERVER_URL: string = "https://aqua-prd-linux-cld-web-01.nam.nsroot.net:8999/AquaCoreServicesDMT";

}