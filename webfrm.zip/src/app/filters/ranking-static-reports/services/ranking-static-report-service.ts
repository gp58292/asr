import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { shareReplay } from 'rxjs/operators';

import { RankingStaticReportsUrlConfigService } from './ranking-static-reports-url-config-service';

@Injectable()
export class RankingStaticReportService {
  constructor(private http: HttpClient, private urlConfig: RankingStaticReportsUrlConfigService) {
    console.debug('RankingStaticReportService::constructor:: Loading RankingStaticReportService');
  }
  public getAllRankingStaticReportData(reportType: string): Observable<any> {
    console.debug('RankingStaticReportService::getAllRankingStaticReportData');
    return this.http.get(this.urlConfig.EP_GET_RANKING_STATIC_REPORT + '/' + reportType).pipe(shareReplay(1));
  }
}
