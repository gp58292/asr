export interface RankingStaticReport {
    collateralType: string;
    discountCurve: string;
    ccy: string;
    hqla: string;
    country: string;
    esph: string;
    attribute: string;
    groupDisagg: string;
    groupAgg: string;
    fundingRanking: number;
    postingRanking: number;
}
