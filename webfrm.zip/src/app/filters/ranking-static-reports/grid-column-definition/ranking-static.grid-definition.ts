import { FieldType } from '@aqua/aqua-component/aqua-grid/model';
import { GridColumnsDef, GridColumnsDefBuilder } from '@aqua/filters/models';

export const RANKING_STATIC_GRID_DEFINITION: GridColumnsDef[] = [
  new GridColumnsDefBuilder('Collateral Type', 'collateralType').build(),
  new GridColumnsDefBuilder('Discount Curve', 'discountCurve').build(),
  new GridColumnsDefBuilder('CCY', 'ccy').build(),
  new GridColumnsDefBuilder('HQLA', 'hqla').build(),
  new GridColumnsDefBuilder('Country', 'country').build(),
  new GridColumnsDefBuilder('ESPH', 'esph').build(),
  new GridColumnsDefBuilder('Group Disagg', 'groupDisagg').build(),
  new GridColumnsDefBuilder('Group Agg', 'groupAgg').build(),
  new GridColumnsDefBuilder('Funding Ranking', 'fundingRanking').fieldType(FieldType.NUMERIC).build(),
  new GridColumnsDefBuilder('Posting Ranking', 'postingRanking').fieldType(FieldType.NUMERIC).build()
];
