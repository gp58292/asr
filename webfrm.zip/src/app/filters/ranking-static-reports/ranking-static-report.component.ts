import { Component, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { AquaGrid } from '@aqua/aqua-component/aqua-grid';
import { ColumnDefaultGrid, GridUtils } from '@aqua/aqua-component/aqua-grid/utils';
import { VizNotificationService } from '@aqua/services';
import { GridOptions } from 'ag-grid-community';
import { Subject } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';

import { RANKING_STATIC_GRID_DEFINITION } from './grid-column-definition/ranking-static.grid-definition';
import { RankingStaticReport } from './models/ranking-static-report';
import { RankingStaticReportService } from './services/ranking-static-report-service';

@Component({
  selector: 'ranking-static-report',
  templateUrl: './ranking-static-report.component.html',
  styleUrls: ['./ranking-static-report.component.scss']
})
export class RankingStaticReportComponent {
  public static gridOptions: GridOptions = GridUtils.gridOptionsWithoutPivoting;
  public rankingStaticColDef: ColumnDefaultGrid[] = GridUtils.buildColumns(RANKING_STATIC_GRID_DEFINITION);

  public readonly rankingStaticReportData$ = this.rankingStaticReportService.getAllRankingStaticReportData('view').pipe(
    catchError(err => {
      this.vizNotification.showError('Failed to load data for Ranking Static!');
      return err;
    })
  );

  constructor(
    private rankingStaticReportService: RankingStaticReportService,
    private vizNotification: VizNotificationService,
    public dialogRef: MatDialogRef<RankingStaticReportComponent>
  ) {}

  public onCancel() {
    this.dialogRef.close();
  }

  public getOptions(name: string): any {
    return {
      ...RankingStaticReportComponent.gridOptions,
      ...GridUtils.getDefaultExcelExportParam(name)
    };
  }
}
