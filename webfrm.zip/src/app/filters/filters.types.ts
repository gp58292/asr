export interface AttributeNode {
  name: string;

  // Parent specific attributes.
  children?: AttributeNode[];

  // Child specific attributes.
  // TODO: Need to describe whole model.
  key?: number;
  whoHasFlag?: WhoCanWhoHas;
}

export type AttributesTree = AttributeNode[];

export enum AttributesViewMode {
  FLAT,
  GROUP
}

export enum WhoCanWhoHas {
  // Contractual Eligibility.
  CAN,

  // Actual Postings.
  HAS
}
