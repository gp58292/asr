import { A11yModule } from '@angular/cdk/a11y';
import { OverlayModule } from '@angular/cdk/overlay';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AquaGridModule } from '@aqua/aqua-component/aqua-grid';
import { AutoCompleteModule } from '@aqua/aqua-component/autocomplete';
import { CurrentSelectionFiltersModule } from '@aqua/aqua-component/current-selection-filters';
import { DateRangeModule } from '@aqua/aqua-component/date-range';
import { DropDownRangeModule } from '@aqua/aqua-component/dropdown-range';
import { IncludeExcludeModule } from '@aqua/aqua-component/include-exclude';
import { MultiIncludeExcludeModule } from '@aqua/aqua-component/multi-include-exclude';
import { NumberRangeModule } from '@aqua/aqua-component/number-range';
import { AquaSpinnerModule } from '@aqua/aqua-component/progress-spinner';
import { RatingRangeListModule } from '@aqua/aqua-component/rating-range-list';
import { AquaSelectModule } from '@aqua/aqua-component/select/aqua-select-module';
import { TenorRangeModule } from '@aqua/aqua-component/tenor-range';
import { TenorRangeInNotInWrapperModule } from '@aqua/aqua-component/tenor-range-innotin-wrapper';
import { ValidationModule } from '@aqua/aqua-component/validations';
import { FilterItemWrapperModule } from '@aqua/components/filter-item-wrapper/filter-item-wrapper.module';
import { MaterialModule } from '@aqua/material.module';
import { MatProgressButtonsModule } from 'mat-progress-buttons';

import { EventRatingWrapperModule } from './event-rating-wrapper';
import { RatingRangeListWrapperModule } from './rating-range-list-wrapper';

@NgModule({
  imports: [
    MaterialModule,
    MatProgressButtonsModule,
    CommonModule,
    BrowserAnimationsModule,
    A11yModule,
    OverlayModule,
    FormsModule,
    AquaSelectModule,
    NumberRangeModule,
    DateRangeModule,
    AutoCompleteModule,
    IncludeExcludeModule,
    MultiIncludeExcludeModule,
    CurrentSelectionFiltersModule,
    AquaSpinnerModule,
    AquaGridModule,
    ValidationModule,
    DropDownRangeModule,
    RatingRangeListModule,
    TenorRangeModule,
    TenorRangeInNotInWrapperModule,
    RatingRangeListWrapperModule,
    FilterItemWrapperModule,
    EventRatingWrapperModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [
    AquaSelectModule,
    NumberRangeModule,
    DateRangeModule,
    AutoCompleteModule,
    IncludeExcludeModule,
    MultiIncludeExcludeModule,
    CurrentSelectionFiltersModule,
    AquaSpinnerModule,
    AquaGridModule,
    ValidationModule,
    DropDownRangeModule,
    RatingRangeListModule,
    TenorRangeModule,
    TenorRangeInNotInWrapperModule,
    RatingRangeListWrapperModule,
    FilterItemWrapperModule,
    EventRatingWrapperModule
  ]
})
export class AquaComponentModule {}
