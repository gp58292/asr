import { OverlayModule } from '@angular/cdk/overlay';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ErrorStateMatcher, MatCommonModule, MatOptionModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';

import { AquaSelectModule } from '../select';
import { DropDownRange } from './dropdown-range';

@NgModule({
  imports: [CommonModule, OverlayModule, MatCommonModule, FormsModule, ReactiveFormsModule, MatOptionModule, AquaSelectModule],
  exports: [MatFormFieldModule, MatCommonModule, DropDownRange],
  declarations: [DropDownRange],
  providers: [ErrorStateMatcher]
})
export class DropDownRangeModule {}
