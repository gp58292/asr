import { OverlayModule } from "@angular/cdk/overlay";
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatTooltipModule } from "@angular/material";
import { MatCommonModule } from "@angular/material/core";
import { PipeModule } from "@aqua/aqua-component/pipes";
import { CurrentSelectionFilters } from "./current-selection-filters";
import { FilterItemWrapperModule } from '@aqua/components/filter-item-wrapper/filter-item-wrapper.module';

@NgModule({
	imports: [
		CommonModule,
		OverlayModule,
		MatCommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatTooltipModule,
		PipeModule,
    FilterItemWrapperModule
	],
	exports: [CurrentSelectionFilters],
	declarations: [CurrentSelectionFilters]
})
export class CurrentSelectionFiltersModule {}
