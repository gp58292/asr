import { Component, Input } from '@angular/core';
import { CommonUtils } from '@aqua/util';

import { DisplaySet, FieldType } from '../aqua-grid/model';

@Component({
  selector: 'aqua-current-selection-filters',
  templateUrl: './current-selection-filters.html',
  styleUrls: ['./current-selection-filters.scss']
})
export class CurrentSelectionFilters {
  @Input('data')
  set currentSelection(data: Map<string, DisplaySet>) {
    // Adapt odd Map<Set> construction to the normal collection.
    const filters = [];

    data.forEach((valuesSet, fieldName) => {
      const fieldData: any = { fieldName, values: Array.from(valuesSet.value), dataType: FieldType[valuesSet.dataType] };

      if (fieldData.values.length > 4) {
        fieldData.displayString = `${fieldData.values.slice(0, 4).join('; ')} <b>...</b>`;
        fieldData.tooltipString = fieldData.values.join('; ');
        fieldData.showTooltip = true;
      } else {
        fieldData.displayString = fieldData.values.join('; ');
      }

      filters.push(fieldData);
    });

    this.adaptedFilters = filters;
  }

  public adaptedFilters: any;

  /**
   *  "number" css class when data type is numeric, integer, double
   *  "text" css class when data type is string
   *  "date" css class when data type is date
   */
  public getCssByType(type: FieldType) {
    return CommonUtils.getClassByDataType(type);
  }
}
