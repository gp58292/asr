import { DropDownModel } from '../dropdown-range';
import { OPERATOR } from './operator.enum';
import { RangeValue } from './range-value';

export class RatingRangeModel {
  public static undefinedValuesIfNull(ratingRangeModel: RatingRangeModel): RatingRangeModel {
    if (!ratingRangeModel || ratingRangeModel == null) {
      return undefined;
    }
    if (ratingRangeModel.agencyName == null) {
      ratingRangeModel.agencyName = undefined;
    }
    if (ratingRangeModel.period == null) {
      ratingRangeModel.period = undefined;
    }
    if (ratingRangeModel.value == null) {
      ratingRangeModel.value = undefined;
    }
    if (!ratingRangeModel.agencyName && !ratingRangeModel.period && !ratingRangeModel.value) {
      return undefined;
    }

    return ratingRangeModel;
  }
  public operation: OPERATOR = OPERATOR.OR;
  public agencyName: string = null;
  public numIndex: number = 1;
  constructor(public period: string = null, public value: RangeValue<DropDownModel> = null) {}
}
