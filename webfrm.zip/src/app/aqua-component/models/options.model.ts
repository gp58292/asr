import { DropDownModel } from '../dropdown-range/drop-down.model';

export class Options extends DropDownModel {
  public id?: string;
  constructor(private _key: string, private _value: string, public selected?: boolean) {
    super(_key, _value);
  }

  public toJSON() {
    const json = {
      key: this._key,
      value: this._value
    };
    if (this.selected !== undefined) {
      // tslint:disable-next-line:no-string-literal
      json['selected'] = this.selected;
    }
    return json;
  }
}
