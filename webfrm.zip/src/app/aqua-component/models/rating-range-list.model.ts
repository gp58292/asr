import { RatingRangeModel } from './rating-range.model';

export class RatingRangeListModel {
  public static undefinedValuesIfNull(ratingRangeModels: RatingRangeListModel): RatingRangeListModel {
    if (!ratingRangeModels || ratingRangeModels == null) {
      return undefined;
    }
    if (ratingRangeModels.valueList == null || ratingRangeModels.valueList === undefined || ratingRangeModels.valueList.length === 0) {
      return undefined;
    }
    const valueList = ratingRangeModels.valueList;
    for (const value of valueList) {
      if (value.agencyName == null) {
        value.agencyName = undefined;
      }
      if (value.period == null) {
        value.period = undefined;
      }
      if (value.value == null) {
        value.value = undefined;
      }
    }

    return ratingRangeModels;
  }
  constructor(public valueList?: RatingRangeModel[]) {}
}
