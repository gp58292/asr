import { IncludeExcludeModel } from '.';

export class IncludeExcludeListModel {
  public static undefineValuesIfNull(includExcludeList: IncludeExcludeListModel): IncludeExcludeListModel {
    if (!includExcludeList || includExcludeList == null) {
      return undefined;
    }
    if (includExcludeList.valueList == null || includExcludeList.valueList === undefined || includExcludeList.valueList.length === 0) {
      includExcludeList = undefined;
    } else if (includExcludeList.valueList && includExcludeList.valueList.length >= 0) {
      const hasValue: IncludeExcludeModel[] = [];
      for (const [index, includeExclude] of includExcludeList.valueList.entries()) {
        // console.debug(
        // 	"IncludeExcludeListModel::undefineValuesIfNull::Splice",
        // 	index,
        // 	includeExclude,
        // 	includeExclude.value,
        // 	includeExclude.butNotValue
        // );
        if (!includeExclude.value && !includeExclude.butNotValue) {
          // console.debug(
          // 	"IncludeExcludeListModel::undefineValuesIfNull::Deleting::Before::",
          // 	includExcludeList.valueList.length,
          // 	index
          // );
          includExcludeList.valueList.splice(index, 1);
          // console.debug(
          // 	"IncludeExcludeListModel::undefineValuesIfNull::Deleting::After::",
          // 	includExcludeList.valueList.length,
          // 	index
          // );
        } else {
          hasValue.push(includeExclude);
        }
      }
      // if (includExcludeList.valueList.length === 0) {
      // 	delete includExcludeList.valueList;
      // }
      delete includExcludeList.valueList;
      if (hasValue.length > 0) {
        includExcludeList.valueList = hasValue;
      } else {
        includExcludeList = undefined;
      }
      // console.debug(
      // 	"IncludeExcludeListModel::undefineValuesIfNull::Final::",
      // 	includExcludeList
      // );
    }
    return includExcludeList;
  }
  constructor(public valueList?: IncludeExcludeModel[]) {}
}
