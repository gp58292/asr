export class RatingRankingModel {
	public ratingRankingKey: number;
	public agencyName: string;
	public term: string;
	public rating: string;
	public rank: number;
}
