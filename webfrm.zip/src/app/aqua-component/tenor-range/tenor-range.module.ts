import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonToggleModule, MatFormFieldModule, MatOptionModule } from '@angular/material';
import { NumberRangeModule } from '@aqua/aqua-component/number-range';

import { AquaSelectModule } from '../select';
import { TenorRange } from './tenor-range';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatButtonToggleModule,
    MatOptionModule,
    AquaSelectModule,
    NumberRangeModule
  ],
  exports: [TenorRange],
  declarations: [TenorRange]
})
export class TenorRangeModule {}
