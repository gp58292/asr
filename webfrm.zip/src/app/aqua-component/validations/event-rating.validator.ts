import { Directive, forwardRef } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, Validator } from '@angular/forms';
import { DropDownModel } from '@aqua/aqua-component/dropdown-range';
import { RangeValue, RatingRangeModel } from '@aqua/aqua-component/models';

@Directive({
  selector:
    // tslint:disable-next-line:directive-selector
    '[validateEventRating][ngModel],[validateEventRating][formControl]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => EventRatingValidator),
      multi: true
    }
  ]
})
export class EventRatingValidator implements Validator {
  public static validateEventRating() {
    return (c: AbstractControl) => {
      // console.debug('EventRatingValidator::validateRange::value', c.value);
      const ratingRangeModel: RatingRangeModel = c.value;
      if (ratingRangeModel) {
        // console.debug('EventRatingValidator::validateRange::value', ratingRangeModel);
        if (EventRatingValidator.isValid(ratingRangeModel)) {
          c.markAsTouched();
          c.markAsDirty();
          return { validateEventRating: { valid: false } };
        }
      }
      return null;
    };
  }

  public static isValid(ratingModel: RatingRangeModel): boolean {
    let isValid = true;
    // console.debug('EventRatingValidator::isValid::value', ratingModel);
    if (ratingModel) {
      const range: RangeValue<DropDownModel> = ratingModel.value;
      if (range && !ratingModel.period) {
        isValid = false;
      } else if (range && range.start && range.end && !EventRatingValidator.isRangeValid(range)) {
        isValid = false;
      }
    }
    // console.debug('EventRatingValidator::isValid[{%o}]:: ', isValid);
    return !isValid;
  }

  public static isRangeValid(range: RangeValue<DropDownModel>): boolean {
    return range.start.key >= range.end.key;
  }
  // tslint:disable-next-line:ban-types
  public validator: Function;

  constructor() {
    this.validator = EventRatingValidator.validateEventRating();
    // console.debug("EventRatingValidator::constructor:: initializing ");
  }

  public validate(c: AbstractControl) {
    return this.validator(c);
  }
}
