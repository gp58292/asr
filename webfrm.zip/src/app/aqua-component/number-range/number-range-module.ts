import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { MatCommonModule } from "@angular/material/core";
import { OverlayModule } from "@angular/cdk/overlay";
import { MatFormFieldModule } from "@angular/material/form-field";
import { ErrorStateMatcher } from "@angular/material/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NumberRange } from "./number-range";

@NgModule({
	imports: [
		CommonModule,
		OverlayModule,
		MatCommonModule,
		FormsModule,
		ReactiveFormsModule
	],
	exports: [MatFormFieldModule, MatCommonModule, NumberRange],
	declarations: [NumberRange],
	providers: [ErrorStateMatcher]
})
export class NumberRangeModule {}
