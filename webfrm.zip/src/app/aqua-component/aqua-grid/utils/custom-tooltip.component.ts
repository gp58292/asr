import { Component } from '@angular/core';
import { ITooltipAngularComp } from 'ag-grid-angular';
import { ITooltipParams } from 'ag-grid-community';

@Component({
  selector: 'tooltip-component',
  template: `
    <div class="custom-tooltip">
      <p>
        <span>{{ columnName }}:</span>
      </p>
      <p>{{ valueToDisplay }}</p>
    </div>
  `,
  styles: [
    `
      :host {
        position: absolute;
        width: 150px;
        height: 70px;
        border: 1px solid cornflowerblue;
        overflow: hidden;
        pointer-events: none;
        transition: opacity 1s;
      }

      :host.ag-tooltip-hiding {
        opacity: 0;
      }

      .custom-tooltip p {
        margin: 5px;
        white-space: nowrap;
      }

      .custom-tooltip p:first-of-type {
        font-weight: bold;
      }
    `
  ]
})
export class CustomTooltip implements ITooltipAngularComp {
  public valueToDisplay: string;
  public columnName: string = 'NA';

  private params: ITooltipParams;

  public agInit(params: ITooltipParams): void {
    this.params = params;
    console.debug('CustomTooltip::agInit::', this.params.value, this.params);
    // this.valueToDisplay = this.params.value.value ? this.params.value.value : '- Missing -';
  }
}
