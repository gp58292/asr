import { ColumnsDefinitionGrid } from '@aqua/aqua-component/aqua-grid/model';

export class ColumnDefaultGrid {
  public static checkbox: ColumnsDefinitionGrid = {
    headerName: '#',
    headerCheckboxSelection: true,
    field: undefined,
    minWidth: 40,
    maxWidth: 40,
    checkboxSelection: true,
    enablePivot: false,
    enableValue: false,
    enableRowGroup: false,
    suppressMenu: true,
    pinned: true,
    filter: false,
    resizable: true,
    sortable: false
  };
  public static stringDef: ColumnsDefinitionGrid = {
    headerName: undefined,
    field: undefined
  };
}
