import { FieldNames, GridColumnsDef, SearchResultColumns } from '@aqua/filters/models';
import { ColDef, ColGroupDef, GridOptions, GridApi, ClientSideRowModel } from 'ag-grid-community';
import moment from 'moment';

import { CommonExcelStyleRule } from '../excel-styles';
import { FieldType } from '../model';
import { ColumnsDefinitionGrid } from '../model/columns-definitions.grid';
import { DateRenderer, HyperlinkRenderer, NumberRenderer } from './../inline-cell-renderer';
import { CustomTooltip } from './custom-tooltip.component';

export class GridUtils {
  public static gridOptionsWithoutPivoting: GridOptions = {
    sideBar: null,
    enableRangeSelection: true,
    statusBar: {
      statusPanels: [
        { statusPanel: 'agFilteredRowCountComponent' },
        { statusPanel: 'agSelectedRowCountComponent' },
        {
          statusPanel: 'agAggregationComponent',
          statusPanelParams: {
            // possible values are: 'count', 'sum', 'min', 'max', 'avg'
            aggFuncs: ['count', 'min', 'max', 'avg']
          }
        }
      ]
    },
    suppressHorizontalScroll: false,
    groupSelectsChildren:true,
    pagination: false,
    rowHeight: 30,
    rowBuffer: 10,
    defaultColDef: {
      sortable: true,
      resizable: true,
      filter: true
    }
    // frameworkComponents: {
    //   customTooltip: CustomTooltip
    // }
  };
  public static buildColumns(
    resultColumnsList: SearchResultColumns[] | GridColumnsDef[],
    isCustomFilterRequired: boolean = false,
    isCheckboxRequired: boolean = false
  ): ColumnsDefinitionGrid[] {
    const columnsList: ColumnsDefinitionGrid[] = [];
    if (resultColumnsList && resultColumnsList.length > 0) {
      for (const [index, resultColumn] of resultColumnsList.entries()) {
        const columnsDef: ColumnsDefinitionGrid = new ColumnsDefinitionGrid(resultColumn.displayName, resultColumn.fieldName);
        columnsDef.hide = !resultColumn.isDefaultDisplay;
        columnsDef.tooltipField = resultColumn.fieldName;
        columnsDef.tooltipValueGetter = GridUtils.tooltip;

        if (resultColumn.fieldType === FieldType.NUMERIC || resultColumn.fieldType === FieldType.INTEGER) {
          columnsDef.type = ['numericColumn', 'dimension'];
          columnsDef.cellRendererFramework = NumberRenderer;
          // columnsDef.valueFormatter = params => {
          //   return NumberRenderer.formatNumber(params.value);
          // };
          columnsDef.toolPanelClass = params => {
            return 'number';
          };
        }
        // DOUBLE is only considered as measure in ag grid, so user can only drag these fields in values of pivoting
        if (resultColumn.fieldType === FieldType.DOUBLE) {
          columnsDef.type = ['measure', 'numericColumn'];
          columnsDef.cellRendererFramework = NumberRenderer;
          // columnsDef.valueFormatter = params => {
          //   return NumberRenderer.formatNumber(params.value);
          // };
          columnsDef.toolPanelClass = params => {
            return 'number';
          };
        }
        if (resultColumn.fieldType === FieldType.STRING) {
          // columnsDef.cellRendererFramework = TooltipRenderer;
          // columnsDef.tooltipValueGetter = GridUtils.tooltip;
          columnsDef.type = 'dimension';
          columnsDef.cellClassRules = { ...CommonExcelStyleRule };
          columnsDef.toolPanelClass = params => {
            return 'text';
          };
        }
        if (resultColumn.fieldType === FieldType.DATE) {
          columnsDef.type = 'dimension';
          columnsDef.tooltipField = resultColumn.fieldName;
          columnsDef.cellClassRules = { ...CommonExcelStyleRule };
          columnsDef.tooltipValueGetter = GridUtils.tooltip;
          columnsDef.cellRendererFramework = DateRenderer;
          columnsDef.toolPanelClass = params => {
            return 'date';
          };
        }
        // This codes need to be moved outside, as this is very specific application
        if (FieldNames.AGREEMENT_ID === resultColumn.fieldName) {
          columnsDef.cellRendererFramework = HyperlinkRenderer;
          // columnsDef.type = 'id';
          // GridUtils.updateRendererFramework(columnsDef, HyperlinkRenderer);
          columnsDef.type = ['dimension']; // ['numericColumn', 'dimension'];
          // if (isCheckboxRequired) {
          //   columnsDef.checkboxSelection = true;
          // }
        }
        if (isCheckboxRequired && index === 0) {
          columnsDef.checkboxSelection = true;
          columnsDef.headerCheckboxSelection = (grid: any) => {
            const api: GridApi = grid.api;
            return api.getModel() instanceof ClientSideRowModel;
          };
        }
        if (resultColumn instanceof GridColumnsDef) {
          if (resultColumn.isHyperLink) {
            // columnsDef.cellRendererFramework = HyperlinkRenderer;
            GridUtils.updateRendererFramework(columnsDef, HyperlinkRenderer);
          }
          if (resultColumn.minWidth) {
            columnsDef.minWidth = resultColumn.minWidth;
          }
          if (resultColumn.width) {
            columnsDef.width = resultColumn.width;
          }
          GridUtils.updateRendererFramework(columnsDef, resultColumn.rendererFramework);
          columnsDef.enablePivot = resultColumn.enablePivot;
          columnsDef.enableRowGroup = resultColumn.enableRowGroup;
          columnsDef.enableValue = resultColumn.enableValue;
        }
        if (isCustomFilterRequired) {
          columnsDef.filterParams = { values: [], newRowsAction: 'keep', apply: true, clearButton: true };
          columnsDef.suppressFilter = false;
        }
        columnsList.push(columnsDef);
      }
    }
    return columnsList;
  }

  public static processSecondaryColumns(colsDef: Array<ColDef | ColGroupDef>): Array<ColDef | ColGroupDef> {
    colsDef.forEach((colDef: ColDef | ColGroupDef) => {
      if ('colId' in colDef) {
        GridUtils.applyNumericProps(colDef);
      }
      if ('children' in colDef) {
        GridUtils.processSecondaryColumns(colDef.children);
      }
    });

    return colsDef;
  }

  public static mergeColumnsIfNotExistOtherwiseIgnore(source: SearchResultColumns[], dest: SearchResultColumns[]): SearchResultColumns[] {
    const finalColumns: SearchResultColumns[] = [];
    for (const resultColumn of source) {
      if (!GridUtils.checkColumnExist(resultColumn.fieldName, dest)) {
        finalColumns.push(resultColumn);
      }
    }
    return [...finalColumns, ...dest];
  }

  public static checkColumnExist(fieldName: string, dest: SearchResultColumns[]): boolean {
    const foundColumn = dest.find((col: SearchResultColumns) => col.fieldName === fieldName);
    return !!foundColumn;
  }

  public static tooltip(data: any): string {
    return data.value;
  }

  public static getDefaultExcelExportParam(name: string): any {
    return {
      defaultExportParams: {
        fileName: name + ' exported on ' + moment().format('Do MMMM YYYY h:mm A'),
        sheetName: name
      }
    };
  }

  public static downloadCSV(data: any, exportFileName: string) {
    if (navigator.msSaveBlob) {
      // IE 10+
      navigator.msSaveBlob(data, exportFileName);
    } else {
      const link = document.createElement('a');
      if (link.download !== undefined) {
        // feature detection
        // Browsers that support HTML5 download attribute
        const blob = new Blob([data], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', exportFileName);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

  public static downloadExcel(data: any, exportFileName: string) {
    if (navigator.msSaveBlob) {
      // IE 10+
      navigator.msSaveBlob(data, this.createFileName(exportFileName));
    } else {
      const link = document.createElement('a');
      if (link.download !== undefined) {
        // feature detection
        // Browsers that support HTML5 download attribute
        const url = URL.createObjectURL(data);
        link.setAttribute('href', url);
        link.setAttribute('download', exportFileName);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

  private static applyNumericProps(colDef: ColDef) {
    colDef.type = 'measure';
    colDef.cellRendererFramework = NumberRenderer;
  }

  private static createFileName(exportFileName: string): string {
    const date = new Date();
    return exportFileName + date.toLocaleDateString() + '_' + date.toLocaleTimeString() + '.csv';
  }

  private static updateRendererFramework(columnsDef: ColumnsDefinitionGrid, rendererFramework: any) {
    if (rendererFramework) {
      if (!columnsDef.cellRendererFramework) {
        columnsDef.cellRendererFramework = rendererFramework;
      } else if (columnsDef.cellRendererFramework instanceof Object) {
        columnsDef.cellRendererFramework = [columnsDef.cellRendererFramework, rendererFramework];
      } else {
        columnsDef.cellRendererFramework.push(rendererFramework);
      }
    }
  }
}
