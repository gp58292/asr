import { Component } from '@angular/core';
import { INoRowsOverlayAngularComp } from 'ag-grid-angular';

import { CustomNoRowMessageService } from '../service/custom-no-row-message.service';

@Component({
  selector: 'aqua-grid-norows-overlay',
  template: `
    <div class="ag-overlay-loading-center">
      <h4 *ngIf="!customMessage" class="note">No data exists for the selected criteria.</h4>
      <h4 *ngIf="!!customMessage" class="note">{{ customMessage }}</h4>
    </div>
  `,
  styles: [
    `
      :host {
        display: flex;
        flex-direction: column;
        height: 100%;
        width: 100%;
        align-content: center;
        justify-content: center;
        z-index: 100;
      }
      .note {
        font-style: italic;
        padding: 20px;
        color: #97999b;
        font-size: 1.1rem;
      }
    `
  ]
})
export class CustomNoRowsOverlay implements INoRowsOverlayAngularComp {
  constructor(private customNoRowMessageService: CustomNoRowMessageService) {}

  // tslint:disable-next-line:no-empty
  public agInit(): void {}

  public get customMessage(): string {
    return this.customNoRowMessageService.customMessage;
  }
}
