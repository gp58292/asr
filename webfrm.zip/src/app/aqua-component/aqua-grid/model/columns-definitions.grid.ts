export class ColumnsDefinitionGrid {
  public width?: number = 0;
  public minWidth?: number = 50;
  public maxWidth?: number = 500;
  public checkboxSelection?: boolean | any;
  public suppressSorting?: boolean;
  public suppressMenu?: boolean;
  public suppressFilter?: boolean;
  public headerCheckboxSelection?: boolean | any;
  public headerCheckboxSelectionFilteredOnly?: boolean;
  public headerValueGetter?: any;
  public pinned?: boolean;
  public hide?: boolean = false;
  public cellRenderer?: any[];
  public cellRendererFramework?: any;
  public frameworkComponents?: any;
  public filterFramework?: any;
  public valueFormatter?: any;
  public type?: string | string[];
  public dataType?: string;
  public cellClassRules?: any;
  public enablePivot?: boolean;
  public enableValue?: boolean;
  public enableRowGroup?: boolean;
  public tooltipValueGetter?: any;
  public toolPanelClass?: any;
  public valueGetter?: any;
  public filterValueGetter?: any;
  public filter?: boolean = true;
  public resizable?: boolean = true;
  public sortable?: boolean = true;
  public value?: string;
  public tooltipField?: any;
  public filterParams?: {
    filterOptions?: any;
    values?: any;
    newRowsAction?: string;
    apply: boolean;
    suppressMiniFilter?: boolean;
    clearButton?: boolean;
  };
  constructor(public headerName: string, public field: string) {}
}
