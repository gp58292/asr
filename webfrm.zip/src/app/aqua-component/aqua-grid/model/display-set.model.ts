export class DisplaySet {
  constructor(public value: Set<string>, public dataType: string) {}
}
