export enum FieldType {
  NUMERIC = 'NUMERIC',
  INTEGER = 'INTEGER',
  DOUBLE = 'DOUBLE',
  STRING = 'STRING',
  DATE = 'DATE'
}
