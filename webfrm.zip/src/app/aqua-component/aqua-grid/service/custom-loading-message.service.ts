import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { shareReplay } from 'rxjs/operators';

@Injectable()
export class CustomLoadingMessageService {
  private _messageBus$: BehaviorSubject<string> = new BehaviorSubject(undefined);

  public get messageBus$(): Observable<string> {
    return this._messageBus$.pipe(shareReplay(1));
  }

  public get customMessage() {
    return this._messageBus$.value;
  }

  public set customMessage(message: string) {
    this._messageBus$.next(message);
  }
}
