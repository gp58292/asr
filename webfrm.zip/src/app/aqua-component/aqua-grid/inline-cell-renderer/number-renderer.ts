import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'aqua-number-renderer',
  template: `
    <span [style.color]="params.value >= 0 ? 'black' : 'red'">{{ formatedValue }} </span>
  `,
  styles: [
    `
      .number-align {
        justify-content: flex-end;
        display: flex;
      }
    `
  ]
})
// tslint:disable-next-line:component-class-suffix
export class NumberRenderer implements ICellRendererAngularComp {
  public static formatNumber(num: number): string {
    return NumberRenderer.negateNumberWithBracket(NumberRenderer.numberWithCommas(NumberRenderer.roundAll(num)));
  }
  public static round(value: number, precision: number): number {
    const multiplier = Math.pow(10, precision || 0);
    return Math.round(value * multiplier) / multiplier;
  }

  public static roundAll(value: number): string {
    return NumberRenderer.round(value, 1).toFixed(0);
  }

  public static numberWithCommas = x => {
    const parts = x.toString().split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return parts.join('.');
  };
  public static negateNumberWithBracket = (x: string) => {
    if (x.indexOf('-') === 0) {
      x = x.replace('-', '(') + ')';
    }
    return x;
  };
  public params: any;
  public formatedValue: string;
  public agInit(params: any): void {
    this.params = params;
    if (params.value !== undefined) {
      this.formatedValue = NumberRenderer.formatNumber(params.value);
    }
  }

  public refresh(): boolean {
    return false;
  }
}
