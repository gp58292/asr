import { Component } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-delete-renderer",
    template: `        
	  <i class="icon trash-grey" title="Delete" *ngIf="isDelete"></i>
	`
})
// tslint:disable-next-line:component-class-suffix
export class DeleteRenderer implements ICellRendererAngularComp {
    public isDelete: boolean;

	public agInit(params: any): void {
        this.isDelete = params.node.data.chartFlag === 1 ? false : true;
	}

	public refresh(): boolean {
		return false;
	}
}
