import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import moment from 'moment';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'aqua-date-renderer',
  template: `
    <span class="date-align">{{ params }} </span>
  `,
  styles: [
    `
      .date-align {
        justify-content: center;
        display: flex;
      }
    `
  ]
})
// tslint:disable-next-line:component-class-suffix
export class DateRenderer implements ICellRendererAngularComp {
  public params: any;

  public agInit(params: any): void {
    if (params.value) {
      try {
        this.params = moment(params.value).format('YYYY-DD-MM');
      } catch (e) {
        this.params = params.value;
        console.error('Error occurred while converting date in grid::', e);
      }
    }
  }

  public refresh(): boolean {
    return false;
  }
}
