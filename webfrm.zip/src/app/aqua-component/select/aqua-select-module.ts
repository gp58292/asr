import { OverlayModule } from '@angular/cdk/overlay';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MAT_SELECT_SCROLL_STRATEGY_PROVIDER, MatChipsModule, MatSelectModule } from '@angular/material';
import { ErrorStateMatcher, MatCommonModule, MatOptionModule } from '@angular/material/core';
import { PipeModule } from '@aqua/aqua-component/pipes';
import { MaterialModule } from '@aqua/material.module';

import { AquaFilterSelect } from './aqua-filter-select';
import { AquaSelect } from './aqua-select';

@NgModule({
  imports: [
    CommonModule,
    OverlayModule,
    MaterialModule,
    MatOptionModule,
    MatCommonModule,
    MatChipsModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    PipeModule
  ],
  exports: [AquaFilterSelect, AquaSelect],
  declarations: [AquaFilterSelect, AquaSelect],
  providers: [MAT_SELECT_SCROLL_STRATEGY_PROVIDER, ErrorStateMatcher]
})
export class AquaSelectModule {}
