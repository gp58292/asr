import { FocusMonitor } from '@angular/cdk/a11y';
import { Component, ElementRef, Input, OnDestroy, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgModelCommon } from '@aqua/aqua-component/common';
import { IncludeExcludeModel, OPERATOR, Options } from '@aqua/aqua-component/models';
import { cloneDeep } from 'lodash';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'aqua-include-exclude',
  templateUrl: './include-exclude.html',
  styleUrls: ['./include-exclude.scss'],
  providers: [NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(IncludeExclude), NgModelCommon.CUSTOM_MAT_FORM_FIELD(IncludeExclude)]
})
export class IncludeExclude extends NgModelCommon<IncludeExcludeModel> implements OnDestroy {
  @Input()
  get referenceData() {
    return this._startReferenceData || this._endReferenceData;
  }

  set referenceData(data: Options[]) {
    this._startReferenceData = cloneDeep(data);
    this._endReferenceData = cloneDeep(data);
  }

  @Input()
  get value(): IncludeExcludeModel | null {
    // console.debug("IncludeExclude::get Value::["+this.id+"]::",this.form.value);
    const n = this._innerValue;
    if (n && (n.value || n.butNotValue)) {
      return new IncludeExcludeModel(n.operation, n.value, n.butNotValue);
    }
    return null;
  }

  set value(includeExclude: IncludeExcludeModel | null) {
    includeExclude = includeExclude || new IncludeExcludeModel();
    // console.debug("IncludeExclude::Set Value::["+this.id+"]::",includeExclude,this.checkObjectEqual(this._innerValue,includeExclude));
    if (!this.checkObjectEqual(this._innerValue, includeExclude)) {
      // console.debug("IncludeExclude::Set Value:: to Model["+this.id+"]::", this._innerValue,includeExclude,this.checkObjectEqual(this._innerValue,includeExclude));
      IncludeExcludeModel.undefineValuesIfNull(includeExclude); // This will remove value if null
      this._innerValue = includeExclude;
      this.onChangedCallback(!includeExclude.butNotValue && !includeExclude.value ? undefined : includeExclude);
      this.stateChanges && this.stateChanges.next();
    }
  }

  get empty() {
    return !this.value || (!this.value.value && !this.value.butNotValue);
  }

  public form: FormGroup;
  public ENUMOPER: any = OPERATOR;
  public _startReferenceData: Options[];
  public _endReferenceData: Options[];

  constructor(public fb: FormBuilder, private fm: FocusMonitor, private elRef: ElementRef, private render2: Renderer2) {
    super(elRef, render2);
    if (fm && elRef) {
      fm.monitor(elRef.nativeElement, true)
        .pipe(takeUntil(this.alive))
        .subscribe(origin => {
          this.focused = !!origin;
          this.stateChanges.next();
        });
    }
    this.updateControlType('aqua-include-exclude');
    this.form = this.fb.group({
      operation: OPERATOR.OR,
      value: undefined,
      butNotValue: undefined
    });
    this.form.valueChanges
      .pipe(
        takeUntil(this.alive),
        debounceTime(300),
        distinctUntilChanged()
      )
      .subscribe(value => (this.value = value));
  }

  // writeValue(newValue:any) { console.debug('IncludeExclude::writeValue::',newValue); this.value=newValue;}
  public writeValue(newValue: any) {
    // console.debug('IncludeExclude::writeValue::', newValue, this.form.value, this.checkObjectEqual(this.form.value, newValue));
    if (!this.checkObjectEqual(this.form.value, newValue) || newValue == null) {
      const value = (newValue && newValue.value) || null;
      const butNotValue = (newValue && newValue.butNotValue) || null;
      const model: IncludeExcludeModel = new IncludeExcludeModel(newValue != null ? newValue.operation : OPERATOR.OR, value, butNotValue);
      // console.debug('IncludeExclude::writeValue::', butNotValue, model);
      this.form.setValue(model);
      this.value = model;
    }
  }

  // Focus first child input element
  public onContainerClick(event: MouseEvent) {
    console.debug('IncludeExclude::onContainerClick::', event.srcElement);
    // if((event.srcElement as any).name != "end") {
    //   let startInput:HTMLElement=this.elRef.nativeElement.querySelector('[name="start"]');
    //   startInput.focus();
    // }
    super.onContainerClick(event);
  }

  public ngOnDestroy(): void {
    console.debug('IncludeExclude::ngOnDestroy::');
    this.fm.stopMonitoring(this.elRef.nativeElement);
    super.ngOnDestroy();
  }

  private checkObjectEqual(source: IncludeExcludeModel, destination: IncludeExcludeModel): boolean {
    let isEqual: boolean = true;
    if ((source == null || source === undefined) && (destination != null && destination !== undefined)) {
      isEqual = false;
    } else if (
      destination != null &&
      destination !== undefined &&
      (source.operation !== destination.operation ||
        (source.value !== destination.value || (destination.value && (!source.value || source.value == null))) ||
        (source.butNotValue !== destination.butNotValue ||
          (destination.butNotValue && (!source.butNotValue || source.butNotValue == null))))
    ) {
      isEqual = false;
    }

    return isEqual;
  }
}
