import { CommonModule } from "@angular/common";
import { MaterialModule } from "@aqua/material.module";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatButtonToggleModule, MatFormFieldModule } from "@angular/material";
import { AquaSelectModule } from "@aqua/aqua-component/select/aqua-select-module";

import { CoreMultiIncludeExclude } from "./core-multi-include-exclude/cor-multi-include-exclude";
import { MultiIncludeExclude } from "./multi-include-exclude";

@NgModule({
	imports: [
	  MaterialModule,
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatFormFieldModule,
		MatButtonToggleModule,
		AquaSelectModule,
	],
	exports: [MultiIncludeExclude],
	declarations: [MultiIncludeExclude, CoreMultiIncludeExclude]
})
export class MultiIncludeExcludeModule {}
