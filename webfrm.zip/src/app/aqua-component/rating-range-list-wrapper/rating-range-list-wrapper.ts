import { FocusMonitor } from '@angular/cdk/a11y';
import { ChangeDetectionStrategy, Component, ElementRef, Input, OnDestroy, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgModelCommon } from '@aqua/aqua-component/common';
import { RatingRangeListWrapperModel, RatingRankingModel } from '@aqua/aqua-component/models';
import * as lodash from 'lodash';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'aqua-rating-range-list-wrapper',
  templateUrl: './rating-range-list-wrapper.html',
  styleUrls: ['./rating-range-list-wrapper.scss'],
  providers: [
    NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(RatingRangeListWrapper),
    NgModelCommon.CUSTOM_MAT_FORM_FIELD(RatingRangeListWrapper)
  ],
  changeDetection: ChangeDetectionStrategy.OnPush
})
// tslint:disable-next-line:component-class-suffix
export class RatingRangeListWrapper extends NgModelCommon<RatingRangeListWrapperModel> implements OnDestroy {
  @Input()
  public referenceData: RatingRankingModel[];

  @Input()
  get value(): RatingRangeListWrapperModel | null {
    // console.debug("RatingRangeListWrapper::get Value::["+this.id+"]::",this.form.value);
    const n: RatingRangeListWrapperModel = this._innerValue;
    if (n && (n.inValueList || n.notInValueList)) {
      return new RatingRangeListWrapperModel(n.inValueList, n.notInValueList);
    }
    return null;
  }
  set value(ratingRangeList: RatingRangeListWrapperModel | null) {
    ratingRangeList = ratingRangeList || new RatingRangeListWrapperModel();
    // console.debug(
    // 	"RatingRangeListWrapper::Set Value::[" + this.id + "]::",
    // 	ratingRangeList,
    // 	this.checkObjectEqual(this._innerValue, ratingRangeList)
    // );
    if (!this.checkObjectEqual(this._innerValue, ratingRangeList)) {
      // console.debug("RatingRangeListWrapper::Set Value:: to Model["+this.id+"]::", this._innerValue,ratingRangeList,this.checkObjectEqual(this._innerValue,ratingRangeList));
      ratingRangeList = RatingRangeListWrapperModel.undefinedValuesIfNull(ratingRangeList); // This will remove value if null
      this._innerValue = ratingRangeList;
      // console.debug(
      // 	"RatingRangeListWrapper::ratingRangeList::",
      // 	RatingRangeListValidator.isValid(ratingRangeList)
      // );
      this.onChangedCallback(ratingRangeList);
      this.stateChanges && this.stateChanges.next();
    }
  }
  // -------------------------------------------------------------------------------------------------------------------------

  get empty() {
    return !this.value || !(this.value && this.value.inValueList && this.value.notInValueList);

    // return (
    // 	!this.value ||
    // 	!(
    // 		this.value &&
    // 		(this.value.inValueList || this.value.inValueList.length >= 0) &&
    // 		(this.value.notInValueList || this.value.notInValueList.length >= 0)
    // 	)
    // );
  }

  public form: FormGroup;

  @Input() public label: string;

  constructor(public fb: FormBuilder, private fm: FocusMonitor, private elRef: ElementRef, public render: Renderer2) {
    super(elRef, render);
    if (fm && elRef) {
      fm.monitor(elRef.nativeElement, true)
        .pipe(takeUntil(this.alive))
        .subscribe(origin => {
          this.focused = !!origin;
          this.stateChanges.next();
        });
    }
    this.form = this.fb.group({
      inValueList: undefined,
      notInValueList: undefined
    });
    this.form.valueChanges
      .pipe(
        takeUntil(this.alive),
        debounceTime(300),
        distinctUntilChanged()
      )
      .subscribe(value => {
        this.value = value;
      });
    this.updateControlType('aqua-rating-range-list-wrapper');
    // console.debug("RatingRangeList::constructor::", this.form);
  }

  // writeValue(newValue:any) { console.debug('RatingRangeList::writeValue::',newValue); this.value=newValue;}
  public writeValue(newValue: RatingRangeListWrapperModel) {
    // console.debug(
    // 	"RatingRangeListWrapper::writeValue::",
    // 	newValue,
    // 	this.form.value,
    // 	this.checkObjectEqual(this.form.value, newValue)
    // );
    if (!newValue) {
      const model: RatingRangeListWrapperModel = new RatingRangeListWrapperModel();

      // console.debug(
      // 	"RatingRangeListWrapper::writeValue:: Setting value ::",
      // 	model
      // );
      this.form.patchValue(model, { onlySelf: true, emitEvent: false });
      this.value = model;
      // this._emtChangeDetectorRef.markForCheck();
    } else if (!this.checkObjectEqual(this.form.value, newValue)) {
      const model: RatingRangeListWrapperModel = new RatingRangeListWrapperModel(newValue.inValueList, newValue.notInValueList);
      // console.debug(
      // 	"RatingRangeListWrapper::writeValue:: Setting value ::",
      // 	model
      // );
      this.form.patchValue(model, { onlySelf: true, emitEvent: false });
      this.value = model;
      // this._emtChangeDetectorRef.markForCheck();
    }
  }
  // Focus first child input element
  public onContainerClick(event: MouseEvent) {
    // console.debug("RatingRangeListWrapper::onContainerClick::", event.srcElement);
    // if((event.srcElement as any).name != "end") {
    //   let startInput:HTMLElement=this.elRef.nativeElement.querySelector('[name="start"]');
    //   startInput.focus();
    // }
    // super.onContainerClick(event);
  }

  public ngOnDestroy(): void {
    // console.debug("RatingRangeList::ngOnDestroy::");
    this.fm.stopMonitoring(this.elRef.nativeElement);
    super.ngOnDestroy();
  }

  private checkObjectEqual(source: RatingRangeListWrapperModel, destination: RatingRangeListWrapperModel): boolean {
    let isEqual = true;
    if ((source == null || source === undefined) && (destination != null && destination !== undefined)) {
      isEqual = false;
    } else if (source != null && source !== undefined && (destination == null || destination === undefined)) {
      isEqual = false;
    } else if (!lodash.isEqual(source, destination)) {
      isEqual = false;
    }

    return isEqual;
  }
}
