import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
	MatButtonToggleModule,
	MatFormFieldModule,
	MatOptionModule,
	MatSelectModule,
	MatTabsModule
} from "@angular/material";
import { DropDownRangeModule } from "@aqua/aqua-component/dropdown-range";
import { RatingRangeListModule } from "../rating-range-list";
import { RatingRangeListWrapper } from "./rating-range-list-wrapper";

@NgModule({
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatFormFieldModule,
		MatButtonToggleModule,
		MatOptionModule,
		MatSelectModule,
		DropDownRangeModule,
		RatingRangeListModule,
		MatTabsModule
	],
	exports: [RatingRangeListWrapper],
	declarations: [RatingRangeListWrapper]
})
export class RatingRangeListWrapperModule {}
