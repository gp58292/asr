import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  Output,
  Renderer2,
  ViewChild,
  ViewEncapsulation
} from '@angular/core';
import { MatDialog, MatListOption, matSelectAnimations, MatSelectionListChange } from '@angular/material';
import { MessageBox } from '@aqua/aqua-component/autocomplete/message-box/message-box';
import { PastedNotMacthing } from './pasted-not-macthing/pasted-not-macthing';

import { CdkConnectedOverlay } from '@angular/cdk/overlay';
import { NgModelCommon } from '@aqua/aqua-component/common';
import { Options } from '@aqua/aqua-component/models';

import * as lodash from 'lodash';
import { PastedData } from './pasted-data.model';

@Component({
  selector: 'aqua-auto-complete',
  templateUrl: './auto-complete.html',
  styleUrls: ['./auto-complete.scss'],
  encapsulation: ViewEncapsulation.Emulated,
  providers: [NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(AquaAutoComplete), NgModelCommon.CUSTOM_MAT_FORM_FIELD(AquaAutoComplete)],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [matSelectAnimations.transformPanel, matSelectAnimations.fadeInContent]
})
export class AquaAutoComplete extends NgModelCommon<Options[]> implements OnDestroy {
  @Input()
  set data(sourceData: Options[]) {
    this._data = sourceData;
    this.restoreSelection(this._data);
  }

  get data(): Options[] {
    return this._data;
  }

  get empty() {
    return !(this._selectedData && this._selectedData.length > 0);
  }

  set value(newValue: Options[] | null) {
    newValue = newValue && newValue.length !== 0 ? newValue : undefined;
    this.onChangedCallback(newValue);
  }

  get value(): Options[] | undefined {
    return this._innerValue || void 0;
  }

  @Input()
  get autoCompleteText() {
    return this._autoCompleteText;
  }

  set autoCompleteText(text: string) {
    console.debug('AquaAutoComplete::autoCompleteText::', text);
    this._autoCompleteText = text;
    if (text !== undefined) {
      console.debug('AquaAutoComplete::listenTextChange::', text);
      this.autoCompleteTextChange.next(text);
      this.calculateWidth();
    }
  }

  @Input()
  set pastedData(sourceData: PastedData) {
    if (sourceData && sourceData.FOUND) {
      this.addSelection(sourceData.FOUND);
      this.updateValue();
    }
    if (sourceData && sourceData.NOT_FOUND && sourceData.NOT_FOUND.length > 0) {
      this.dialog.open(PastedNotMacthing, { width: 'auto', data: { NOT_FOUND: sourceData.NOT_FOUND } });
    }
  }

  get isPasted(): boolean {
    return this._isPasted;
  }

  public typingMessage: string = 'Please start typing....';

  public _data: Options[];
  public _selectedData: Options[];

  public _autoCompleteWidth: number;
  public _autoCompleteLength: number;
  public _autoCompleteText: string;
  @Output() public autoCompleteTextChange: EventEmitter<string> = new EventEmitter();
  @ViewChild('autoText') public inputText: any;

  /** Trigger that opens the select. */
  @ViewChild('trigger') public trigger: ElementRef;

  /** Overlay pane containing the options. */
  @ViewChild(CdkConnectedOverlay) public overlayDir: CdkConnectedOverlay;

  @Output() public pastedValueChange: EventEmitter<string[]> = new EventEmitter();

  /** Whether or not the overlay panel is open. */
  public panelOpen = false;

  private _isPasted: boolean = false;

  constructor(private _emtElementRef: ElementRef, private render2: Renderer2, public dialog: MatDialog) {
    super(_emtElementRef, render2);
  }

  public writeValue(newValue: string[]) {
    // console.debug("AquaAutoComplete::writeValue::", newValue);
    if ((newValue && this._innerValue && newValue.length !== this._innerValue.length) || (newValue !== undefined && newValue != null)) {
      this._innerValue = newValue;
      this.updateSelection();
    } else {
      this.clearAll();
    }
  }

  public onContainerClick(event: MouseEvent) {
    console.debug('AquaAutoComplete::onContainerClick:', event, this.inputText);
    this.focusonText();
    super.onContainerClick(event);
  }

  public ngOnDestroy() {
    super.ngOnDestroy();
  }

  public selectOption(event: MatSelectionListChange): void {
    const matOption: MatListOption = event.option;
    if (event.option) {
      const item: Options = new Options(matOption.value.key, matOption.value.value);
      this.addOrRemoveItemFromSelect(item);
      this.updateValue();
      return;
    }
  }

  public addOrRemoveItemFromSelect(item: Options): void {
    let foudItemIndex: number = -1;
    if (this._selectedData) {
      foudItemIndex = this._selectedData.findIndex(data => data.value === item.value);
    } else {
      this._selectedData = [];
    }
    if (foudItemIndex !== -1) {
      this._selectedData.splice(foudItemIndex, 1);
    } else {
      this._selectedData.push(item);
    }
  }

  // Remove selected value on click of close icon in chips remove
  public removeSelected(itemOptions: Options, event: Event): void {
    // console.debug("AquaAutoComplete::removeSelected::", itemOptions, event);
    const item: Options = this._selectedData.find(f => f.value === itemOptions.value);
    // console.debug("AquaAutoComplete::removeSelected::", itemOptions, item);
    if (item) {
      item.selected = false;
      this.addOrRemoveItemFromSelect(item);
    }
    this.updateValue();
    event.preventDefault();
    event.stopPropagation();
    return;
  }

  public clearAll(): void {
    delete this._selectedData;
    this._selectedData = [];
    lodash.forEach(this._data, option => {
      option.selected = false;
    });
    this.autoCompleteText = undefined;
    this.value = undefined;
  }

  public focusonText(): void {
    this.inputText && this.inputText.nativeElement.focus();
  }

  /** Toggles the overlay panel open or closed. */
  public toggle(): void {
    this.panelOpen ? this.close() : this.open();
  }

  public onBlur() {
    if (!this.panelOpen) {
      this._isPasted = false;
      this.autoCompleteText = '';
    }
  }

  /** Opens the overlay panel. */
  public open(): void {
    if (this.disabled || this.panelOpen) {
      return;
    }

    this.panelOpen = true;
  }

  /** Closes the overlay panel and focuses the host element. */
  public close(): void {
    if (this.panelOpen) {
      this.panelOpen = false;
      this.autoCompleteText = undefined;
      this._data = [];
    }
  }

  public trackByKey(item: Options, index: number) {
    return item.key;
  }

  public pastedValue(event: any): void {
    this._isPasted = true;
    const rawData: string = event.clipboardData.getData('text/plain');

    console.debug('AquaAutoComplete::pastedValue::', this.autoCompleteText);
    const columnData = rawData.split('\n');
    if (columnData && columnData.length > 5000) {
      this.dialog.open(MessageBox, { width: 'auto' });
    } else {
      this.pastedValueChange.next(columnData);
    }
  }

  private restoreSelection(data: Options[]): void {
    lodash
      .filter(data, (options: Options) => lodash.some(this._selectedData, { value: options.value }))
      .forEach((dataRec: Options) => {
        dataRec.selected = true;
      });
  }

  private updateSelection(): void {
    if (this._innerValue && this._innerValue.length > 0) {
      this._selectedData = this._innerValue;
    }
  }

  private updateValue(): void {
    this.value = this._selectedData || this._selectedData.length > 0 ? this._selectedData : undefined;
  }

  private calculateWidth(): void {
    if (!this._autoCompleteText) {
      this._autoCompleteWidth = 35;
      return;
    }
    if (this._autoCompleteText.length === this._autoCompleteLength) {
      return;
    }

    if (this._autoCompleteText.length > 3) {
      this._autoCompleteWidth = 8 * this._autoCompleteText.length;
      this._autoCompleteLength = this._autoCompleteText.length;
    } else {
      this._autoCompleteWidth = 35;
      this._autoCompleteLength = this._autoCompleteText ? this._autoCompleteText.length : 0;
    }
  }

  private addSelection(data: Options[]): void {
    console.debug('AquaAutoComplete::addSelection::', this._selectedData, data);

    if (!this._selectedData && data && data.length) {
      this._selectedData = [];
    }

    lodash
      .reject(data, (options: Options) => lodash.some(this._selectedData, { key: options.key, value: options.value }))
      .forEach((dataRec: Options) => {
        dataRec.selected = true;
        this._selectedData.push(dataRec);
      });
  }
}
