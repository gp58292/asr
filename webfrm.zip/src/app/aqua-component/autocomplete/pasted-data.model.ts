import { Options } from "@aqua/aqua-component/models";
export interface PastedData {
	FOUND: Options[];
	NOT_FOUND: Options[];
}
