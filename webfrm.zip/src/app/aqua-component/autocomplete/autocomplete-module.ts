import { OverlayModule } from "@angular/cdk/overlay";
import { CommonModule } from "@angular/common";
import { MaterialModule } from "@aqua/material.module";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
	MatChipsModule,
	MatCommonModule,
	MatFormFieldModule,
	MatIconModule,
	MatListModule
} from "@angular/material";
import { MessageBox } from "./message-box/message-box";
import { PastedNotMacthing } from "./pasted-not-macthing/pasted-not-macthing";

import { PipeModule } from "@aqua/aqua-component/pipes";
import { AquaAutoComplete } from "./auto-complete";

@NgModule({
	imports: [
		CommonModule,
		OverlayModule,
    MaterialModule,
		MatCommonModule,
		MatChipsModule,
		FormsModule,
		ReactiveFormsModule,
		MatFormFieldModule,
		MatListModule,
		MatIconModule,
		PipeModule
	],
	exports: [AquaAutoComplete],
	declarations: [PastedNotMacthing, MessageBox, AquaAutoComplete],
	entryComponents: [PastedNotMacthing, MessageBox]
})
export class AutoCompleteModule {}
