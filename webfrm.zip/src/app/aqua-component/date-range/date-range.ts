import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, ElementRef, Input, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgModelCommon } from '@aqua/aqua-component/common';
import { RangeValue } from '@aqua/aqua-component/models/range-value';
import { DateRangeValidator } from '@aqua/aqua-component/validations';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';

@Component({
  selector: 'aqua-date-range',
  templateUrl: './date-range.html',
  styleUrls: ['./date-range.scss'],
  providers: [NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(DateRange), NgModelCommon.CUSTOM_MAT_FORM_FIELD(DateRange)],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DateRange extends NgModelCommon<RangeValue<string>> {
  public static initDate(range: RangeValue<string>): RangeValue<any> {
    const newRange = new RangeValue();
    newRange.start = range.start ? new Date(Date.parse(range.start)) : null;
    newRange.end = range.end ? new Date(Date.parse(range.end)) : null;
    return newRange;
  }

  public dateRangeFormGroup: FormGroup;

  private _rangeValue: RangeValue<string>;
  private datePipe: DatePipe = new DatePipe('en-US');

  @Input()
  get value(): RangeValue<string> | null {
    return this._rangeValue;
  }

  set value(dateRange: RangeValue<string> | null) {
    dateRange = dateRange || new RangeValue<string>();

    if (this.value !== dateRange || this.value.start !== dateRange.start || this.value.end !== dateRange.end) {
      let range: RangeValue<string> = this.formatDate(dateRange);
      range = RangeValue.undefinedValuesIfNull(range); // This will remove value if null

      this.errorState = !DateRangeValidator.isValid(range);
      this.onChangedCallback(range);

      if (this.dateRangeFormGroup.value.start || this.dateRangeFormGroup.value.end) {
        this._rangeValue = new RangeValue<string>(this.dateRangeFormGroup.value.start, this.dateRangeFormGroup.value.end);
      }
      this._rangeValue = null;
    }
  }

  constructor(public fb: FormBuilder, private elRef: ElementRef, private render2: Renderer2) {
    super(elRef, render2);

    this.dateRangeFormGroup = this.fb.group({ start: undefined, end: undefined });
    this.dateRangeFormGroup.valueChanges
      .pipe(
        takeUntil(this.alive),
        debounceTime(300),
        distinctUntilChanged()
      )
      .subscribe(value => (this.value = value));
  }

  public writeValue(newValue: RangeValue<string>) {
    if (
      (newValue && newValue !== this.dateRangeFormGroup.value && newValue.start != null && newValue.end != null) ||
      (newValue !== undefined && newValue != null)
    ) {
      this.dateRangeFormGroup.setValue(DateRange.initDate(newValue) as any);
    } else {
      this.dateRangeFormGroup.setValue({ start: null, end: null });
    }
  }

  public onDatePick(from: string) {
    const inputElement: HTMLElement = this.elRef.nativeElement.querySelector(`[name="${from}"]`);
    if (inputElement) {
      inputElement.focus();
    }
  }

  public ngOnDestroy() {
    super.ngOnDestroy();
  }

  private formatDate(range: RangeValue<string>): RangeValue<string> {
    const newRange = new RangeValue<string>();
    if (range.start) {
      newRange.start = this.datePipe.transform(range.start, 'yyyy-MM-dd');
    }
    if (range.end) {
      newRange.end = this.datePipe.transform(range.end, 'yyyy-MM-dd');
    }

    return newRange;
  }
}
