import { Pipe, PipeTransform } from '@angular/core';
import { from, of } from 'rxjs';
import { debounceTime, defaultIfEmpty, distinct, map, switchMap, toArray } from 'rxjs/operators';

import { Options } from './../models/options.model';

@Pipe({
  name: 'filterOptions'
})
export class FilterOptionsPipe implements PipeTransform {
  public resultsFromSearch: Options[] = [];

  public transform(items: Options[], searchText?: string): any {
    return of(items).pipe(
      debounceTime(1300),
      defaultIfEmpty([]),
      map(_items => (!searchText ? _items : this.filterOutData(_items, searchText))),
      switchMap((_items: Options[]) =>
        from(_items).pipe(
          distinct(item => item.value),
          toArray()
        )
      )
      // ,tap(x => console.debug("FilterOptionsPipe::transform::tap::", x))
    );
  }

  public findExactMatch(items: Options[], searchText?: string): any {
    return items.filter((option: Options) => {
      //  return option.value.toLowerCase().match(searchText);
      return option.value.toLowerCase() === searchText;
    });
  }

  public findStartingCase(items: Options[], searchText?: string): any {
    return items.filter((option: Options) => {
      return option.value.toLowerCase().startsWith(searchText);
    });
  }

  public findContainingCase(items: Options[], searchText?: string): any {
    return items.filter((option: Options) => {
      return option.value.toLowerCase().includes(searchText);
    });
  }

  private filterOutData(items: Options[], searchText?: string): Options[] {
    searchText = searchText.toLowerCase();

    const exactPattersMatch: Options[] = this.findExactMatch(items, searchText);

    const startingPatternMatch: Options[] = this.findStartingCase(items, searchText);
    const containingWordMatch: Options[] = this.findContainingCase(items, searchText);

    const resultsFromSearch: Options[] = [...exactPattersMatch, ...startingPatternMatch, ...containingWordMatch];

    return resultsFromSearch;
  }
}
