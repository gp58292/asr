import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NumberFormatPipe } from '@aqua/components/pipes/number-formating-pipe';

import { PrintCountPipe } from '././print-count.pipe';
import { ArraySortPipe } from './array-sort.pipe';
import { DataTableExportFormatter } from './data-table-export-formatter.pipe';
import { EscapeHtmlPipe } from './escape-html.pipe';
import { FilterOptionsPipe } from './filter-options.pipe';
import { MapKeys } from './map.Keys.pipe';
import { PrintTextPipe } from './print-text.pipe';
import { TruncatePipe } from './truncate.pipe';

const ALL_CUSTOMS_CEFT_PIPES = [
  FilterOptionsPipe,
  TruncatePipe,
  MapKeys,
  EscapeHtmlPipe,
  DataTableExportFormatter,
  ArraySortPipe,
  NumberFormatPipe,
  PrintCountPipe,
  PrintTextPipe
];
@NgModule({
  imports: [CommonModule],
  exports: [...ALL_CUSTOMS_CEFT_PIPES],
  declarations: [...ALL_CUSTOMS_CEFT_PIPES],
  providers: [...ALL_CUSTOMS_CEFT_PIPES]
})
export class PipeModule {}
