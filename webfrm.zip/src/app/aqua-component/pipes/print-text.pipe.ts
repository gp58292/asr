import { Pipe, PipeTransform } from '@angular/core';

/**
 * Print array length.
 * @usage
 * {{ 'Some Value' | printText }}               // 'Some Value'
 * {{ 'Some Value' | printText:'NO TEXT' }}     // 'Some Value'
 * {{ '' | printText }}                         // 'N/A'
 * {{ '' | printText:'NO TEXT' }}               // 'NO TEXT'
 */
@Pipe({ name: 'printText' })
export class PrintTextPipe implements PipeTransform {
  public transform(text: string, defaultValue: string = 'N/A'): string {
    return text ? text : defaultValue;
  }
}
