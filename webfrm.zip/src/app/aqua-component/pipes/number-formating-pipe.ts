// Framework
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'numberFormat' })
export class NumberFormatPipe implements PipeTransform {
  public transform(input: string, isAddComma: boolean): string {
    return this.formatNumber(input, isAddComma);
  }

  public parse(input: string, isAddComma: boolean): string {
    return this.formatNumber(input, isAddComma);
  }

  private formatNumber(input: string, isAddComma: boolean): string {
    // console.debug('NumberFormatPipe::formatNumber');
    if (!isAddComma) {
      return input.replace(new RegExp(',', 'g'), '');
    } else {
      const _input = parseInt(input, 0) || 0;
      if (typeof _input === 'number') {
        let numberStr: string = _input.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

        // formatting negative red value within parenthesis
        if (numberStr.indexOf('-') === 0) {
          numberStr = numberStr.replace('-', '(') + ')';
        }
        return numberStr;
      } else {
        return input;
      }
    }
  }
}
