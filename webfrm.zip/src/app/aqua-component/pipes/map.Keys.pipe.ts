// Framework
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mapKeys'
})
export class MapKeys implements PipeTransform {
  public transform(value: Map<string, any> | Set<string | number>, args: any[] = null): any[] {
    // console.debug("MapKeys::transform::",(value?Array.from(value.keys()):undefined),value?value.keys():undefined,value);
    return value ? Array.from(value.keys()) : undefined;
  }
}
