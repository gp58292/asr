import { FocusMonitor } from '@angular/cdk/a11y';
import { ChangeDetectionStrategy, Component, ElementRef, Input, OnDestroy, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NgModelCommon } from '@aqua/aqua-component/common';
import { DropDownModel } from '@aqua/aqua-component/dropdown-range';
import { RatingRangeModel, RatingRankingModel } from '@aqua/aqua-component/models';
import * as lodash from 'lodash';
import { from, Observable, of } from 'rxjs';
import { debounceTime, distinct, distinctUntilChanged, map, switchMap, takeUntil, toArray } from 'rxjs/operators';
import { EventRatingValidator } from '../validations';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'aqua-event-rating-wrapper',
  templateUrl: './event-rating-wrapper.html',
  styleUrls: ['./event-rating-wrapper.scss'],
  providers: [NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(EventRatingWrapper), NgModelCommon.CUSTOM_MAT_FORM_FIELD(EventRatingWrapper)],
  changeDetection: ChangeDetectionStrategy.OnPush
})
// tslint:disable-next-line:component-class-suffix
export class EventRatingWrapper extends NgModelCommon<RatingRangeModel> implements OnDestroy {
  @Input()
  public ratingDropDown: DropDownModel[];

  @Input()
  public ratingList$: Observable<RatingRankingModel[]>;

  // public readonly terms$ = this.ratingList$.pipe(
  //   takeUntil(this.alive),
  //   switchMap(ratings =>
  //     from(ratings).pipe(
  //       map(rating => rating.term),
  //       distinct(),
  //       toArray()
  //     )
  //   )
  // );
  public get terms$() {
    return this.ratingList$
      ? this.ratingList$.pipe(
          takeUntil(this.alive),
          switchMap(ratings =>
            from(ratings).pipe(
              map(rating => rating.term),
              distinct(),
              toArray()
            )
          )
        )
      : of([]);
  }

  @Input()
  get value(): RatingRangeModel | null {
    // console.debug("EventRatingWrapper::get Value::["+this.id+"]::",this.form.value);
    const n: RatingRangeModel = this._innerValue;
    if (n && n.period) {
      return new RatingRangeModel(n.period, n.value);
    }
    return null;
  }
  set value(ratingRangeModel: RatingRangeModel | null) {
    ratingRangeModel = ratingRangeModel || new RatingRangeModel();
    // console.debug(
    // 	"EventRatingWrapper::Set Value::[" + this.id + "]::",
    // 	ratingRangeList,
    // 	this.checkObjectEqual(this._innerValue, ratingRangeList)
    // );
    if (!this.checkObjectEqual(this._innerValue, ratingRangeModel)) {
      ratingRangeModel = new RatingRangeModel(ratingRangeModel.period, ratingRangeModel.value);
      // console.debug("EventRatingWrapper::Set Value:: to Model["+this.id+"]::", this._innerValue,ratingRangeList,this.checkObjectEqual(this._innerValue,ratingRangeList));
      ratingRangeModel = RatingRangeModel.undefinedValuesIfNull(ratingRangeModel); // This will remove value if null
      this._innerValue = ratingRangeModel;
      // console.debug(
      // 	"EventRatingWrapper::ratingRangeList::",
      // 	RatingRangeListValidator.isValid(ratingRangeList)
      // );
      this.errorState = EventRatingValidator.isValid(ratingRangeModel);
      this.onChangedCallback(ratingRangeModel);
      this.stateChanges && this.stateChanges.next();
    }
  }
  // -------------------------------------------------------------------------------------------------------------------------

  get empty() {
    return !this.value || !(this.value && this.value.period && this.value.value);
  }

  public form: FormGroup;

  @Input() public label: string;

  constructor(public fb: FormBuilder, private fm: FocusMonitor, private elRef: ElementRef, public render: Renderer2) {
    super(elRef, render);
    if (fm && elRef) {
      fm.monitor(elRef.nativeElement, true)
        .pipe(takeUntil(this.alive))
        .subscribe(origin => {
          this.focused = !!origin;
          this.stateChanges.next();
        });
    }
    this.form = this.fb.group({
      period: undefined,
      value: undefined
    });
    this.form.valueChanges
      .pipe(
        takeUntil(this.alive),
        debounceTime(300),
        distinctUntilChanged()
      )
      .subscribe(value => {
        this.value = value;
      });
    this.updateControlType('aqua-event-rating-wrapper');
  }
  public comparePeriods(o1: string, o2: string): boolean {
    return o1 && o2 && o1 === o2;
  }

  // writeValue(newValue:any) { console.debug('RatingRangeList::writeValue::',newValue); this.value=newValue;}
  public writeValue(newValue: RatingRangeModel) {
    // console.debug(
    // 	"EventRatingWrapper::writeValue::",
    // 	newValue,
    // 	this.form.value,
    // 	this.checkObjectEqual(this.form.value, newValue)
    // );
    if (!newValue) {
      const model: RatingRangeModel = new RatingRangeModel();

      // console.debug(
      // 	"EventRatingWrapper::writeValue:: Setting value ::",
      // 	model
      // );
      this.form.patchValue(model, { onlySelf: true, emitEvent: false });
      this.value = model;
      // this._emtChangeDetectorRef.markForCheck();
    } else if (!this.checkObjectEqual(this.form.value, newValue)) {
      const model: RatingRangeModel = new RatingRangeModel(newValue.period, newValue.value);
      // console.debug('EventRatingWrapper::writeValue:: Setting value ::', model);
      this.form.patchValue(model, { onlySelf: true, emitEvent: false });
      this.value = model;
      // this._emtChangeDetectorRef.markForCheck();
    }
  }
  // Focus first child input element
  public onContainerClick(event: MouseEvent) {
    // console.debug("EventRatingWrapper::onContainerClick::", event.srcElement);
    // if((event.srcElement as any).name != "end") {
    //   let startInput:HTMLElement=this.elRef.nativeElement.querySelector('[name="start"]');
    //   startInput.focus();
    // }
    // super.onContainerClick(event);
  }

  public ngOnDestroy(): void {
    // console.debug("RatingRangeList::ngOnDestroy::");
    this.fm.stopMonitoring(this.elRef.nativeElement);
    super.ngOnDestroy();
  }

  public clearItem() {
    this.form.reset();
  }

  private checkObjectEqual(source: RatingRangeModel, destination: RatingRangeModel): boolean {
    let isEqual = true;
    if ((source == null || source === undefined) && (destination != null && destination !== undefined)) {
      isEqual = false;
    } else if (source != null && source !== undefined && (destination == null || destination === undefined)) {
      isEqual = false;
    } else if (!lodash.isEqual(source, destination)) {
      isEqual = false;
    }

    return isEqual;
  }
}
