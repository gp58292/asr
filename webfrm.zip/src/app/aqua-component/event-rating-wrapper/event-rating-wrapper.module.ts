import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonToggleModule, MatFormFieldModule, MatOptionModule, MatSelectModule, MatTabsModule } from '@angular/material';
import { DropDownRangeModule } from '@aqua/aqua-component/dropdown-range';

import { AquaSelectModule } from '../select/aqua-select-module';
import { EventRatingWrapper } from './event-rating-wrapper';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatButtonToggleModule,
    MatOptionModule,
    MatSelectModule,
    DropDownRangeModule,
    MatTabsModule,
    AquaSelectModule
  ],
  exports: [EventRatingWrapper],
  declarations: [EventRatingWrapper]
})
export class EventRatingWrapperModule {}
