import { OverlayModule } from "@angular/cdk/overlay";
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { MatCommonModule } from "@angular/material/core";

import { PopopContent, PopopHoverContent, Popup } from "./popup";

@NgModule({
	imports: [CommonModule, OverlayModule, MatCommonModule],
	exports: [Popup, PopopContent, PopopHoverContent],
	declarations: [Popup, PopopContent, PopopHoverContent],
	providers: []
})
export class PopupModule {}
