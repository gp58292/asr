import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-ui-guide',
  templateUrl: './ui-guide.component.html',
  styleUrls: ['./ui-guide.component.scss'],
})
export class UIGuideComponent {
  constructor (private route: ActivatedRoute) {
    route.fragment.subscribe(fragment => {
      if (fragment) {
        try {
          document.querySelector('#' + fragment).scrollIntoView();
        } catch (e) {
        }
      }
    });
  }
}
