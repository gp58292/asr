from frm_asr import get_app
from flask_cors import CORS

app = get_app()
#CORS(app)
cors = CORS(app, resources={r"/python/*": {"origins": "*"}})
# Start of Program from main 
if __name__ == '__main__':
    app.run(host='0.0.0.0',port=8080)
	#app.run(host='10.106.14.19',port=8443,ssl_context=('server.crt','server.key')) 