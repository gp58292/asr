# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 13:12:48 2019

@author: ab57286

@author: gp58292 - modfied for logic, seperate put app and project structure
"""


from . import UtilityFunctions as util
import json
from collections import OrderedDict
from flask import Flask, jsonify,request
from flask_cors import CORS, cross_origin
import pandas as pd
import re
import socket
import collections
from . import Sentence as sen
from . import STT as st
import wave

 
                
def get_app():

	app = Flask(__name__)
	CORS(app)
	
	@app.route('/python/get/name', methods=['GET'])
	@cross_origin() # allow all origins all methods.
	def get_name():
		print('get name method called')
		
		return 'Hello World'
	
	@app.route('/python/collateral', methods=['POST'])
	@cross_origin() # allow all origins all methods.        
	def get_tasks():
		
		soeid = request.files['audioBlob'].filename
		data = request.files['audioBlob'].read()
		
		print(soeid)

		name = 'audio/output_'+soeid+'.wav'
		
		CHUNK = 1024
		RATE = 16000
		RECORD_SECONDS = 10
	 
		blob = data
	  
		audio = wave.open(name,'wb')
		
		audio.setnchannels(1)
		audio.setsampwidth(2)
		audio.setframerate(16000)
		audio.setnframes(1)
	   
		audio.writeframes(blob)
		audio.close()
		
		############################### Common Parameters ############################
		
		text=st.main(name)
		
		print(text)
		
		list1,list2=sen.Sent(text)
		
		if(len(list1)>0): 
			listWhoCan=list1[0]
		else:
			listWhoCan=[]
			
		if(len(list2)>0):
			listButNot=list2[0]
		else:
			listButNot=[]
			
		if(len(list1)>1):    
			listWhoHas= list1[1]
		else:
			listWhoHas = []
			
		if(len(list2)>1):
			listButNotHas= list2[1]
		else:
			listButNotHas = []
				
		# This list holds the final JSON structure
		jsonList = []
		
		#this list will hold all the words of sentence and to check whether any command is presesnt in it or not,
		command_list = text.split()
		
		if 'gilt' in command_list or 'linker' in command_list:
			representativeValues=['Both','VM','NON_US_GOVT_GB','NON_US_GOVT_UK','NON_US_I/L_BOND_GB','UNITED_KINGDOM_GILTS','UNITED_KINGDOM_GILTS_I/L','No','Principal','EXECUTED']
			representativeType = ['collateral_applied','collateral_applied','collateral_type_name','collateral_type_name','collateral_type_name','collateral_type_name','collateral_type_name','exchangecleared_agreement','exchangecleared_agreement','csa_status']
			valueDictMap = collections.defaultdict(list)
			for i in range(0,len(representativeValues)):
				valueDictMap[representativeType[i]].append(representativeValues[i])
			util.populateJson(valueDictMap,0,[],jsonList)
			
			representativeValues.clear()
			representativeType.clear()
			with open('audio/JsonFile.json', 'w') as outfile:
				return (json.dumps(jsonList, indent=4))

		# to check whether hotwords like hi aqua, aqua are present in sentence or not
		flag_hotword = True
		'''
		if 'hi' in command_list or 'aqua' in command_list:
			newdict= OrderedDict([('command','aqua')])
			jsonList.append(newdict)
			flag_hotword = True

		elif 'search' in command_list:
			newdict1= OrderedDict([('command','clear')])
			jsonList.append(newdict1)'''

		if flag_hotword:
			
			# eg uscor,cgmi,inrca ---> [US_CORP,CGMI,INR_CASH]
			#	                          [collateral_type_name,party_legal_entity_collateral_type_name]   
			representativeValues=[]
			representativeType = []
			
		
			# This dictionary is used to hold mapping of values against their fieldname'
			# {'collateral_type_name':[US_CROP,INR_CASH],'party_legal_entity':[CGMI]}
			valueDictMap = collections.defaultdict(list)
		
			# This holds the percent match for input values wrt to exact values
			percentMatch=0
			
			############################ Contractual Posting  ###################################
			
			# This is call to function to get correct values for input values for who_can_post (box1) with flag 0
			util.getRepresentativeId(listWhoCan,representativeValues,representativeType,percentMatch,0)
			
			# This loop will map the fieldname and output from above function
			for i in range(0,len(representativeValues)):
				valueDictMap[representativeType[i]].append(representativeValues[i])
			 
			print(valueDictMap)
			
			# Clear all results for next iteration
			representativeValues.clear()
			representativeType.clear()
			
			# This is call to function to get correct values for but not input values( box2) with flag 0
			util.getRepresentativeId(listButNot,representativeValues,representativeType,percentMatch,0)
			
			#This will map all values except but not values for collateral type name
			for i in range(0,len(representativeValues)):
				if representativeType[i]!='collateral_type_name':
						valueDictMap[representativeType[i]].append(representativeValues[i])
				 
			# List to hold results for but not value 
			representativeButNot = []			 
			
			for i in range(0,len(representativeValues)):
				if representativeType[i]=='collateral_type_name':
						representativeButNot.append(representativeValues[i])				 
			  
			representativeType.clear()
			representativeValues.clear()
			
			# This function will populate the JSON structure with values
			util.populateJson(valueDictMap,0,representativeButNot,jsonList)
						
			#Clear all results for next iteration
			valueDictMap.clear()
			representativeButNot.clear()
						
			############################################ Actual Posting  ####################################
						
			# This is call to function to get correct values for input values for who_has_posted (box3) with flag 1
			util.getRepresentativeId(listWhoHas,representativeValues,representativeType,percentMatch,1)
						
			# This loop will map the fieldname and output from above function
			for i in range(0,len(representativeValues)):
				valueDictMap[representativeType[i]].append(representativeValues[i])
			 			
			print(valueDictMap)
			 
			#Clear all results for next iteration
			representativeValues.clear()
			representativeType.clear()
						
			# This is call to function to get correct values for input values for but not (box4) with flag 1
			util.getRepresentativeId(listButNotHas,representativeValues,representativeType,percentMatch,1)
				
			#This will map all values except but not values for collateral type name
			for i in range(0,len(representativeValues)):
				if representativeType[i]!='collateral_type_name':
						valueDictMap[representativeType[i]].append(representativeValues[i])
			 
			for i in range(0,len(representativeValues)):
				if representativeType[i]=='collateral_type_name':
						representativeButNot.append(representativeValues[i])
				 
			representativeType.clear()
			representativeValues.clear()
			
			# This function will populate the JSON structure with values
			util.populateJson(valueDictMap,1,representativeButNot,jsonList)
			
			# This will return results (JSON structure) 
		with open('audio/JsonFile.json', 'w') as outfile:
			return (json.dumps(jsonList, indent=4))
    
	return app
