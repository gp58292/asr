# -*- coding: utf-8 -*-
"""
Created on Tue May 28 16:00:53 2019

@author: ab57286
"""

import numpy as np
import pandas as pd
import re 
import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

def Sent(text):
        
    #dataset = pd.read_csv('sentence_dataset.tsv',delimiter='\t')
    #dataset=" I want  select collateral id uscor,usmuni but posted inrcash"
    #fd = open('sentence_dataset.tsv')
    #numlines = len(fd.readlines())
    #numlines-=1
    sentence = text
    dataset = sentence.split('has')
    stopwords = nltk.corpus.stopwords.words('english')
    
    
    stopwords.extend(['select','name','want','collateral','id','posted','selected','choose','choosen','type','entity','legal','give','search','hi','aqua'])
    corpus = []
    for i in range(0,len(dataset)):
        #sentence = re.sub('[^a-zA-Z]',' ',dataset[i])
        sentence = dataset[i] 
        print(dataset[i])
        sentence=sentence.lower()
        sentence=sentence.split()
       
        ps = PorterStemmer()
        
        #stopwords.words('english').remove('but')
        #new_stopwords = set(stopwords.words('english')) - {'this', 'these'}
        #sentence = [ps.stem(word) for word in sentence if not word in set(stopwords) - {'but'}]
        sentence = [word  for word in sentence if not word in set(stopwords) - {'but'}]
        
        #sentence =  ' '.join(sentence)
        corpus.append(sentence)
        
    list1 = []
    list2 = []
    flag=0
    
    
    for i in range(0,len(corpus)):
        flag=0
        tmplist1=[]
        tmplist2=[]
        for j in range(0,len(corpus[i])):
            if corpus[i][j]!='but' and flag==0:
                tmplist1.append(corpus[i][j])
            else:
                flag=1
                if flag==1 and corpus[i][j]!='but':
                    tmplist2.append(corpus[i][j])
        
        list1.append(tmplist1)
        list2.append(tmplist2)
        #return list1,list2
          
    print(list1)    
    print(list2)    
    return list1,list2


    
    
    
        
                
            
            
            
        
        
    

    
    
    
    
    
    
    
