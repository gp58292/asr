import sys
import re
import pandas as pd
from collections import OrderedDict
import json
from flask import Flask, jsonify,request
from . import AppConstant as app



# This function will create JSON structure for every component present in input on the basis of key and list values
def createJson(key,valueDictMap,valueList,component,flag,representativeButNot,jsonList):
    switcher={
            
            'MULTI_INCLUDE_EXCLUDE':OrderedDict([
                          ('fieldName',key),                           
                          ('componentType', 'MULTI_INCLUDE_EXCLUDE'),
                          ('dataType', 'string'),
                          ('key',-1),
                          ('whoHasFlag',flag),
                          ('value',  OrderedDict([
                                                    #('keyword', k),
                                                    #('term_freq', len(v)),
                                                    ('valueList',  [ OrderedDict([
                                                    ('operation', 'or'),
                                                    #('term_freq', len(v)),
                                                    ('value', [{'value': i,'selected':True,'key':-1} for i in valueList]),
                                                    ('butNotValue',[{'value': u,'selected':True,'key':-1} for u in representativeButNot])
                                                                    ]) ])
                                                 ]))
                        ]),
            
            
            'DROPDOWN': OrderedDict([
                      ('fieldName', key),
                      ('componentType', 'DROPDOWN'),
                      ('dataType', 'string'),
                      ('distinctRequired',1),
                      ('key',-1),
                      ('whoHasFlag',flag),
                      
                              ('key',-1),
                              ('selected',True),
                              ('value', [{'value': j,'selected':True,'key':-1} for j in valueList])
                              
                             
                      
                      ])                                                    
           }
    
    # To get component using switch case 
    Dict = switcher.get(component)
    print(json.dumps(Dict, indent=4))
    jsonList.append(Dict)  # appending results to final JSON list


# This function will extract all keys from dictionary and corresponding list values    
def populateJson(valueDictMap,flag,representativeButNot,jsonList):
        
    compMap = app.getComponent()
    keyList = []
    for key in valueDictMap.keys():
        keyList.append(key)
    #keyList = valueDictMap.keys()
   
    
    for i in range(0,len(keyList)):
        valueListTmp= valueDictMap.get(keyList[i])
        valueSet=set(valueListTmp)
        valueList = list(valueSet)
        
        
        # Getting component name from fieldname and component mapping
        component=compMap.get(keyList[i])
        
        #Call to createJson function 
        createJson(keyList[i],valueDictMap,valueList,component,flag,representativeButNot,jsonList)
        
            
            
        
    # This is tpo handle special case when only but not values are present, in this case component has to be created 
    if 'collateral_type_name' not in keyList and len(representativeButNot)>=1:
            #valueDictMap['collateral_type_name'].append([])
            
            createJson('collateral_type_name',valueDictMap,[],'MULTI_INCLUDE_EXCLUDE',flag,representativeButNot,jsonList)

# minOfThree function return minimum of three value
def minOfThree(x,y,z):
        return min(min(x,y),z)
    
#  editDistance function returns minimum changes required to convert item to review   
def editDistance(item,review):
        array2D = []
        itemLength = len(item)     
        reviewLength  =len(review)
        for i in range (itemLength+1):
            array2D.append([])
            for j in range(reviewLength+1):
                array2D[i].append(0)
               
        
        for i in range(0,itemLength+1):
            for j in range(0,reviewLength+1):
                if(i==0):
                    array2D[i][j]=j
                elif(j==0):
                    array2D[i][j]=i
                elif(item[i-1]==review[j-1]):    #if current character of both string matches then no change required
                    array2D[i][j]=array2D[i-1][j-1]
                else:                           #checks for best possible change 
                    array2D[i][j]=1+minOfThree(array2D[i][j-1],array2D[i-1][j],array2D[i-1][j-1])
                    
            
        return array2D[itemLength][reviewLength]

    
#Representative_Id function identifies the representative id for each user input and stores it into list
def getRepresentativeId(listValues,representativeValues,representativeType,percentMatch,flagCheck):
    
    dataSet = pd.read_csv('DataFile.txt')   
    fileId=open("DataFile.txt")
    rows =  len(fileId.readlines())
            
    # To hold mapping of component name and fielName
    dataSetMapCan,dataSetMapHas=app.getSetMap()
        
    # iterate each item in list
    for item in listValues:
        flag = False
        item=item.lower()
        matchDistance=sys.maxsize
        matchPer = 0
        
        # itearting each value in data set 
        for i in range(0, rows-1):
            #review = re.sub('[^0-9a-zA-Z_-][.]', ' ', dataSet['Review'][i])
            review = dataSet['Review'][i]
            review = review.lower()
                
                
            currDistance=editDistance(item,review)
            
            if(currDistance<=matchDistance):
                matchDistance=currDistance
            
           
        for i in range(0, rows-1):
            
            #review = re.sub('[^a-zA-Z_-]', ' ', dataSet['Review'][i])
            review = dataSet['Review'][i]
            
            review = review.lower()
               
                
            currDistance=editDistance(item,review)
            
            
            if(currDistance==matchDistance):
                index=i
                currMatch=(max(len(item),len(review))-matchDistance)/max(len(item),len(review))
                if(currMatch>0.5) and representativeValues.count(review.upper())==0:
                    flag=True
                    representativeValues.append(review.upper())
                    #j=(int)(index/186)
                    if flagCheck==0:        
                        representativeType.append(dataSetMapCan.get(index))
                    else:
                        representativeType.append(dataSetMapHas.get(index))
                        
                    
                    
                    
        if(len(representativeValues)>=1) and flag==True:
            percentMatch += (max(len(item),len(representativeValues[-1]))-matchDistance)/max(len(item),len(representativeValues[-1]))
    
