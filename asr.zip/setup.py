import setuptools # This is important for the setup to build a wheel  
from distutils.core import setup  
  
setup(  
    name='msst-aqua-163206-frm_asr', # must follow icg-msst-aqua-<package name>
    version='0.0.1',  
    packages=['frm_asr'],  
    url='https://cedt-icg-bitbucket.nam.nsroot.net/bitbucket/projects/AQUA/repos/frm-asr-nlp',  
    license='',  
    author='gp58292',  
    author_email='gp58292@citi.com',  
    description='Aqua Voice Search ',  
    install_requires=[  
        'deepspeech==0.5.0a5',
        'flask==1.1.1',
        'numpy==1.16.4',
        'pandas==0.25.0',
        'xdg==3.0.1',
        'progressbar==2.5',
        'attrdict==2.0.1.',
        'nltk==3.4.4',
        'wave==0.0.2',
        'werkzeug==0.15.5',
		'flask_cors==3.0.8'
    ],
)  