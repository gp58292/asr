export const environment = {
  production: false,
  pythonApiUrl: "https://aqua-uat-linux-cld-app-01.nam.nsroot.net:8443/python/collateral"
};
