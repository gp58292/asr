export const environment = {
  production: false,
  pythonApiUrl: "https://10.106.14.19:8443/python/collateral"
};
