export const environment = {
  production: true,
  pythonApiUrl: "https://aqualinuxappr1.nam.nsroot.net:8443/python/collateral"
};
