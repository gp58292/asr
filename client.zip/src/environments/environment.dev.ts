export const environment = {
  production: false,
  pythonApiUrl: "https://sd-f5fe-d07d.nam.nsroot.net:8443/python/collateral"
};
