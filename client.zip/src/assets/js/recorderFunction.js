//webkitURL is deprecated but nevertheless
URL = window.URL || window.webkitURL;

var gumStream; //stream from getUserMedia()
var rec; //Recorder.js object
var input; //MediaStreamAudioSourceNode we'll be recording

var AudioContext = window.AudioContext || window.webkitAudioContext;
var audioContext; //audio context to help us record

function startRecording() {
  console.debug("AQUA-ASR::RECORDER:Start RecordButton clicked..!!");

  var constraints = {
    audio: true,
    video: false
  };

  navigator.mediaDevices.getUserMedia(constraints).then(function (stream) {
    console.debug("AQUA-ASR::getUserMedia() success, stream created, initializing Recorder...");
    //create an audio context after getUserMedia is called, sampleRate might change after getUserMedia is called
    audioContext = new AudioContext();

    /*  assign to gumStream for later use  */
    gumStream = stream;

    /* use the stream */
    input = audioContext.createMediaStreamSource(stream);

    /*
    	Create the Recorder object and configure to record mono sound (1 channel)
    	Recording 2 channels  will double the file size
    */
    rec = new Recorder(input, {
      numChannels: 1
    });

    //start the recording process
    rec.record();
    console.debug("AQUA-ASR::RECORDER::Recording started..!!");
  }).catch(function (err) {
    console.error(err);
  });
}

function stopRecording(angularThis) {
  console.debug("AQUA-ASR::RECORDER:Stop RecordButton clicked..!!");


  //tell the recorder to stop the recording

  rec.stop();
  console.debug("AQUA-ASR::RECORDER::Recording Stopped..!!");

  //stop microphone access
  gumStream.getAudioTracks()[0].stop();

  angularThis.vizNotification.showMessageWithoutDismiss("SpeechToText conversion is in pogress...", 12000);

  rec.exportWAV(function (blob) {
    console.debug("AQUA-ASR::RECORDER::Export WAV Blob..!!", blob);
    var formData = new FormData();
    formData.append("audioBlob", blob, angularThis.soeId);

    //var url = angularThis.pythonApiUrl;
	var url = 'https://frm-nlp.namicgrut10u.nam.nsroot.net/python/collateral'
	//var url = 'https://sd-f5fe-d07d.nam.nsroot.net:8443/python/collateral'
    var httpRequest = new XMLHttpRequest();
    //httpRequest.open('POST', '/python/collateral');
    httpRequest.open('POST', url);
	httpRequest.setRequestHeader("Access-Control-Allow-Origin", "*");
    httpRequest.send(formData);
    httpRequest.onreadystatechange = () => {
      angularThis.vizNotification.snackbarClose();
      if (httpRequest.readyState === 4 && httpRequest.status === 200) {
        angularThis.vizNotification.showMessageWithoutDismiss("SpeechToText conversion is completed.", 2000);
        var result = JSON.parse(httpRequest.responseText);
        console.debug("AQUA-ASR::RECORDER:Deep Speech json result: " + httpRequest.responseText);
        console.debug("AQUA-ASR::RECORDER:Parsed Result:", result);
        angularThis.renderComponent(result);
      } else {
        angularThis.vizNotification.showMessageWithoutDismiss("SpeechToText conversion is failed.", 2000);
      }
    };
  });
}
