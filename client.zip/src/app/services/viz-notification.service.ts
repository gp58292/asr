import { Injectable } from "@angular/core";
import {
	MatSnackBar,
	MatSnackBarConfig,
	MatSnackBarRef,
	SimpleSnackBar
} from "@angular/material";
import { SnackBarPosition } from "@aqua/models";

@Injectable()
export class VizNotificationService {
	private duration: number = 5000;
	private defaultAction: string = "Dismiss";

	constructor(
		private snackBar: MatSnackBar,
		private snackBarConfig: MatSnackBarConfig
	) {}

	public snackbarClose() {
		console.debug("VizNotificationService::snackbarClose");
		if (this.snackBar) {
			this.snackBar.dismiss();
		}
	}

	public showError(
		message: string,
		action?: string,
		snackbarConfig?: MatSnackBarConfig
	): MatSnackBarRef<SimpleSnackBar> {
		console.debug("VizNotificationService::showError");
		this.setDefaultConfig();

		if (!snackbarConfig) {
			snackbarConfig = this.snackBarConfig;
		}
		snackbarConfig.panelClass = ["snackbar-error"];

		return this.snackBar.open(
			message,
			action || this.defaultAction,
			snackbarConfig
		);
	}

	public showInternalSystemError(): void {
		console.debug("VizNotificationService::showInternalSystemError::");
		this.showError(
			"Internal server error occured, Please contact AQAU CEFT Build Team"
		);
	}

	public showErrorWithoutDismiss(
		message: string,
		duration: number,
		snackbarConfig?: MatSnackBarConfig
	): MatSnackBarRef<SimpleSnackBar> {
		console.debug("VizNotificationService::showError");
		this.snackBarConfig.horizontalPosition = SnackBarPosition.RIGHT;
		this.snackBarConfig.verticalPosition = SnackBarPosition.TOP;
		this.snackBarConfig.duration = duration;

		if (!snackbarConfig) {
			snackbarConfig = this.snackBarConfig;
		}
		snackbarConfig.panelClass = ["snackbar-error"];

		return this.snackBar.open(message, "", snackbarConfig);
	}

	public showMessage(
		message: string,
		action?: string,
		snackbarConfig?: MatSnackBarConfig
	): MatSnackBarRef<SimpleSnackBar> {
		console.debug("VizNotificationService::showMessage");
		this.setDefaultConfig();

		if (!snackbarConfig) {
			snackbarConfig = this.snackBarConfig;
		}
		snackbarConfig.panelClass = ["snackbar-success"];

		return this.snackBar.open(
			message,
			action || this.defaultAction,
			snackbarConfig
		);
	}

	public showMessageWithoutDismiss(
		message: string,
		duration: number,
		snackbarConfig?: MatSnackBarConfig
	): MatSnackBarRef<SimpleSnackBar> {
		console.debug("VizNotificationService::showMessageWithoutDismiss");
		this.snackBarConfig.horizontalPosition = SnackBarPosition.RIGHT;
		this.snackBarConfig.verticalPosition = SnackBarPosition.TOP;
		this.snackBarConfig.duration = duration;

		if (!snackbarConfig) {
			snackbarConfig = this.snackBarConfig;
		}
		snackbarConfig.panelClass = ["snackbar-success"];

		return this.snackBar.open(message, "", snackbarConfig);
	}
	public showWarning(
		message: string,
		action?: string,
		snackbarConfig?: MatSnackBarConfig
	): MatSnackBarRef<SimpleSnackBar> {
		console.debug("VizNotificationService::showWarning");

		this.setDefaultConfig();

		if (!snackbarConfig) {
			snackbarConfig = this.snackBarConfig;
		}
		snackbarConfig.panelClass = ["snackbar-warning"];

		return this.snackBar.open(
			message,
			action || this.defaultAction,
			snackbarConfig
		);
	}

	private setDefaultConfig(): void {
		this.snackBarConfig.horizontalPosition = SnackBarPosition.RIGHT;
		this.snackBarConfig.verticalPosition = SnackBarPosition.TOP;
		this.snackBarConfig.duration = this.duration;
	}
}
