import { Injectable, OnDestroy } from "@angular/core";
import { Router } from "@angular/router";
import { JsonHttp } from "@aqua/http-service";
import { AppHttpResponse, AppLoginStatus } from "@aqua/models";
import { UserParams, UserToken } from "@aqua/models/dto";
import { Observable, Subject } from "rxjs";
import { map, takeUntil } from "rxjs/operators";

import { AppSessionStorage } from "./session-storage-wrapper";
import { UrlConfig } from "./url-config.service";
import { VizNotificationService } from "./viz-notification.service";

@Injectable()
export class AuthService implements OnDestroy {
	public static readonly dataVizSupportMail =
		"mailto:dl.gt.global.aqua.data.viz.build.team@imcnam.ssmb.com?subject=Data Visualization";
	public userLoggedIn: boolean = false;
	private sessionStorage = new AppSessionStorage();

	private userParams: UserParams;
	private subject: Subject<UserParams> = new Subject<UserParams>();
	private geIDSubject: Subject<any> = new Subject<any>();

	private alive: Subject<void> = new Subject();

	constructor(
		private router: Router,
		private http: JsonHttp,
		private vizNotification: VizNotificationService,
		private urlConfig: UrlConfig
	) {
		console.debug("AuthService::constructor");
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	public setUserGlobalID(soeid: any) {
		console.debug("AuthService::setUserGlobalID", soeid);
		// Get user GEID
		this.getUserGEID(soeid)
			.pipe(
				takeUntil(this.alive),
				map(info => info._body)
			)
			.subscribe(
				response => {
					console.debug("AuthService::setUserGlobalID::subscribe::", response);
					if (
						response &&
						response.people &&
						response.people.docs &&
						response.people.docs.length > 0
					) {
						const geid = response.people.docs[0].geid[0];
						this.userParams.geid = geid;
						this.sessionStorage.setStorageKey("userParams_geid", geid);
						// emmit the change to subscribed listeners
						this.geIDSubject.next(geid);
					}
				},
				error => {
					console.debug("AuthService::setUserGlobalID::error::", error);
				},
				() => {
					console.debug("AuthService::setUserGlobalID::complete");
				}
			);
	}

	public getUserParams() {
		console.debug("AuthService::getUserParams");
		let up: UserParams = this.userParams;
		// is it empty?
		if (!up) {
			// check if the user is still logged in, then return from storage
			if (this.isSignedIn()) {
				up = {};
				up.name = this.sessionStorage.getStorageKey("userParams_name");
				up.email = this.sessionStorage.getStorageKey("userParams_email");
				up.soeid = this.sessionStorage.getStorageKey("userParams_soeid");
				up.role = this.sessionStorage.getStorageKey("userParams_role");
				up.geid = this.sessionStorage.getStorageKey("userParams_geid");
				up.token = this.sessionStorage.getStorageKey("userParams_token");
				console.debug(
					"AuthService::getUserParams... Empty. Reading user from local Storage"
				);
			}
		}
		return up;
	}

	public extractUserData(res: AppHttpResponse<UserParams>): UserParams {
		console.debug("AuthService::extractUserData", res);
		const data = res.responseData;
		if (data.statusCode === AppLoginStatus.DVIZ_200 && data.isAuthenticated) {
			// TO DO : Discuss with team idle session and tool to use
			// this.idleService.watch();
			// this.idleService.idle.onTimeout.subscribe(() => {
			//     this.logout();
			// });

			// init user
			this.setUserParams(data);

			this.userLoggedIn = true;
		} else {
			this.userLoggedIn = false;

			this.vizNotification.showError(data.statusMessage);
		}
		return data;
	}

	public subscribeToUserChange(): Observable<UserParams> {
		console.debug("AuthService::subscribeToUserChange");
		return this.subject.asObservable();
	}

	public login(user, password): Observable<UserParams> {
		console.debug("AuthService::login", user);
		const body = { soeid: user, password };
		return this.http
			.post(this.urlConfig.EP_SSO_AUTHENTICATE, body)
			.pipe(map(res => this.extractUserData(res)));
	}

	public subscribeToGEIDUpdate(): Observable<any> {
		console.debug("AuthService::subscribeToGEIDSet");
		return this.geIDSubject.asObservable();
	}

	public getUserGEID(soeid: any): Observable<any> {
		console.debug("AuthService::getUserGEID", soeid);
		// return this.jsonp.get(this.urlConfig.EP_CITI_SEARCH_PEOPLE_BY_SOEID + "&q=" + soeid + "&callback=JSONP_CALLBACK").map((res) => res.json());
		return this.http.jsonp(
			this.urlConfig.EP_CITI_SEARCH_PEOPLE_BY_SOEID + "&q=" + soeid
		);
	}

	public changePwd(
		soeid,
		oldPassword,
		newPassword
	): Observable<AppHttpResponse<UserParams>> {
		console.debug("AuthService::changePwd for user: ", soeid);
		const body = {
			soeid,
			password: oldPassword,
			newpassword: newPassword
		};
		return this.http.post(this.urlConfig.EP_SSO_CHANGE_PASSWORD, body);
	}

	public logout(): void {
		console.debug("AuthService::logout");
		this.invokelogout()
			.pipe(takeUntil(this.alive))
			.subscribe((apiResponse: AppHttpResponse<any>) => {
				console.debug(apiResponse);
				if (apiResponse.responseStatus) {
					this.vizNotification.showMessage(apiResponse.message);
					this.router.navigate(["login"]);
				} else {
					this.vizNotification.showError(apiResponse.message);
				}
			});

		/**
		 *
		 * Regardless of success or failure on Server side - client side to be reset!
		 */
		this.userLoggedIn = false;
		// Clear all storage user parameters if NULL passed
		this.setUserParams(null);
		// Clean up
		// TO DO: App State approach and strategies
		// this.appStateService.clearAppState();
	}

	public invokelogout(): Observable<AppHttpResponse<any>> {
		console.debug("AuthService::invokelogout");
		return this.http.get(this.urlConfig.EP_SSO_LOGOUT);
	}

	public isSignedIn(): boolean {
		// console.debug("AuthService::isSignedIn",this.sessionStorage,this.sessionStorage.getStorageKey('jwt'));
		let logged = false;
		if (this.sessionStorage) {
			logged = this.sessionStorage.getStorageKey("jwt") !== null;
		} else {
			console.debug(
				"AuthService::isSignedIn: No sessionStorage service loaded yet - false"
			);
			logged = false;
		}
		//   if (!logged)
		//       this.setUserParams(null);
		return logged;
	}

	public clearUserData() {
		console.debug("AuthService::clearUserData");
		this.setUserParams(null);
		localStorage.clear();
		if (this.sessionStorage) {
			this.sessionStorage.cleanUp();
		}
	}

	public getUserSoeId() {
		const up = this.getUserParams();
		console.debug("AuthService::getUserSoeId", up.soeid);
		if (up != null) {
			return up.soeid;
		}
	}

	public getUserToken() {
		console.debug("AuthService::getUserToken");
		const up = this.getUserParams();
		if (up != null) {
			return up.token;
		}
	}

	public validateToken(): Observable<UserToken> {
		const token = this.getUserToken();
		const body = { token };
		return this.http
			.post(this.urlConfig.EP_SSO_VALIDATE_TOKEN, body)
			.pipe(map(res => res.responseData));
	}

	public removeUserParams() {
		console.debug("AuthService::removeUserParams");
		this.sessionStorage.removeStorageKey("userParams_name");
		this.sessionStorage.removeStorageKey("userParams_email");
		this.sessionStorage.removeStorageKey("userParams_soeid");
		this.sessionStorage.removeStorageKey("userParams_role");
		this.sessionStorage.removeStorageKey("userParams_cbaAccess");
		this.sessionStorage.removeStorageKey("userParams_geid");
		this.sessionStorage.removeStorageKey("userParams_token");
	}

	private setUserParams(userParams: UserParams): void {
		console.debug(
			"AuthService::setUserParams ",
			userParams,
			this.sessionStorage
		);
		// capture user params
		this.userParams = userParams;
		if (userParams) {
			this.userParams.isAccessible = (userParams as any).isAccessible;
		}
		// place them to storage, so can read between refresh
		if (this.userParams) {
			// TODO: Add all the relevant data to storage if required
			// get user geid
			this.setUserGlobalID(userParams.soeid);
			if (this.sessionStorage) {
				console.debug(
					"AuthService::setUserParams Writing to sessionStorage SessionID"
				);
				this.sessionStorage.setStorageKey(
					"isAuthenticated",
					userParams.isAuthenticated
				);
				this.sessionStorage.setStorageKey(
					"ssoSessionID",
					userParams.ssoSessionID
				);
				this.sessionStorage.setStorageKey("jwt", userParams.ssoSessionID);
				this.sessionStorage.setStorageKey(
					"isAuthorized",
					userParams.isAuthorized
				);
				this.sessionStorage.setStorageKey("userParams_name", userParams.name);
				this.sessionStorage.setStorageKey("userParams_email", userParams.email);
				this.sessionStorage.setStorageKey("userParams_soeid", userParams.soeid);
				this.sessionStorage.setStorageKey("userParams_token", userParams.token);
			} else {
				console.debug(
					"AuthService::setUserParams Direct Storage write SessionID"
				);
				localStorage.setItem("jwt", userParams.ssoSessionID);
				localStorage.setItem("JSESSIONID", userParams.JSESSIONID);
			}
		} else {
			// If we set user parameters with NULL - means we want to clean it
			if (this.sessionStorage) {
				console.debug(
					"AuthService::setUserParams Writing to sessionStorage SessionID"
				);
				this.sessionStorage.cleanUp();
			} else {
				localStorage.removeItem("jwt");
				localStorage.removeItem("JSESSIONID");
			}
		}
		// emmit the change to subscribed listeners
		this.subject.next(userParams);
	}
}
