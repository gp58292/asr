import { Injectable, NgZone } from "@angular/core";
import { Observable } from "rxjs";

interface IWindow extends Window {
	webkitSpeechRecognition: any;
	SpeechRecognition: any;
}

@Injectable()
export class SpeechRecognitionService {
	private speechRecognition: any;

	constructor(private zone: NgZone) {
		console.debug("AQUA-ASR::SpeechRecognitionService:initiated");
	}

	public speechToText(): Observable<string> {
		return Observable.create(observer => {
			const { webkitSpeechRecognition }: IWindow = <IWindow>window;
			this.speechRecognition = new webkitSpeechRecognition();
			this.speechRecognition.continuous = false;
			this.speechRecognition.lang = "en-us";
			this.speechRecognition.maxAlternatives = 1;

			this.speechRecognition.onresult = speech => {
				let text: string = "";
				if (speech.results) {
					var result = speech.results[speech.resultIndex];
					var transcript = result[0].transcript;
					if (result.isFinal) {
						if (result[0].confidence < 0.3) {
							console.debug("AQUA-ASR::Unrecognized result - Please try again");
						} else {
							text = transcript.trim();
							console.debug(
								"AQUA-ASR::Did you said? -> " +
									text +
									" , If not then say something else..."
							);
						}
					}
				}
				this.zone.run(() => {
					observer.next(text);
				});
			};

			this.speechRecognition.onerror = error => {
				observer.error(error);
			};

			this.speechRecognition.onend = () => {
				observer.complete();
			};

			this.speechRecognition.start();
		});
	}

	public start() {
		if (this.speechRecognition) {
			this.speechRecognition.start();
		}
	}

	public stop() {
		if (this.speechRecognition) {
			this.speechRecognition.stop();
		}
  }

  public abort() {
		if (this.speechRecognition) {
			this.speechRecognition.abort();
		}
	}
}
