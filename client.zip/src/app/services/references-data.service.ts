import { Injectable } from "@angular/core";
import { JsonHttp } from "@aqua/http-service";
import { AppHttpResponse } from "@aqua/models";
import { EnvironmentVersion } from "@aqua/models/dto";
import { Observable, Subject } from "rxjs";
import { UrlConfig } from "./url-config.service";

@Injectable()
export class ReferencesDataService {
	private env: EnvironmentVersion;
	private envDetails: Subject<EnvironmentVersion> = new Subject<
		EnvironmentVersion
	>();

	constructor(private http: JsonHttp, private urlConfig: UrlConfig) {
		this.getEnvDetails();
	}

	public subscribeEnvDetails(): Observable<EnvironmentVersion> {
		console.debug("ReferenceDataService::subscribeEnvDetails");
		return this.envDetails.asObservable();
	}
	public getEnvoirement(): EnvironmentVersion {
		return this.env;
	}

	private getEnvDetails(): void {
		console.debug("ReferenceDataService::getEnvDetails");
		this.http
			.get(this.urlConfig.EP_GET_ENVOIREMENT)
			.subscribe((response: AppHttpResponse<EnvironmentVersion>) => {
				const env: EnvironmentVersion = response.responseData;
				if (env && env.envName && env.envName !== "") {
					this.env = env;
					localStorage.setItem("envName", this.env.envName);
					this.envDetails.next(this.env);
				}
			});
	}
}
