import { Injectable } from "@angular/core";
import { AuthService } from "./auth.service";

import {
	ActivatedRouteSnapshot,
	CanActivate,
	Router,
	RouterStateSnapshot
} from "@angular/router";

@Injectable()
export class PrivatePageGuard implements CanActivate {
	constructor(private router: Router, private authService: AuthService) {
		console.debug("PrivatePageGuard::constructor");
	}

	public canActivate(
		route: ActivatedRouteSnapshot,
		state: RouterStateSnapshot
	) {
		console.debug("PrivatePageGuard::canActivate ", route, state);
		const result = this.authService.isSignedIn();
		if (!result) {
			console.debug(
				"PrivatePageGuard::canActivate  User is Not SignedIn, Error!"
			);
			this.router.navigate(["/login"]);
		} else {
			console.debug("PrivatePageGuard::canActivate User is SignedId, OK!");
		}
		return result;
	}
}
