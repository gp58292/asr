export class StaticReferences {}
