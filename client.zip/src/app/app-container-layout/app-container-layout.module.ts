import { NgModule } from "@angular/core";
import { FooterComponent } from "@aqua/layouts/footer/footer.component";
import { HeaderComponent } from "@aqua/layouts/header/header.component";

import { CommonModule } from "@angular/common";
import { AppContainerRoutingModule } from "@aqua/app-container-layout/app-conatiner.routing";
import { MaterialModule } from "@aqua/material.module";
import { FiltersModule } from "../filters/filters.module";

@NgModule({
	declarations: [HeaderComponent, FooterComponent],
	imports: [
		CommonModule,
		AppContainerRoutingModule,
		MaterialModule,
		FiltersModule
	],
	exports: [HeaderComponent, FooterComponent]
})
export class AppContainerLayoutModule {}
