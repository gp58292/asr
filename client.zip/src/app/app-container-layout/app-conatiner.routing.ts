import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { AppContainerLayoutComponent } from "@aqua/app-container-layout/app-container-layout.component";
import { PrivatePageGuard } from "@aqua/services";
import { AppPanelLayoutComponent } from "app/filters/data-finder/app-panel-layout/app-panel-layout.component";

const appContainerRoutes: Routes = [
	{
		path: "acl",
		component: AppContainerLayoutComponent,
		canActivate: [PrivatePageGuard],
		children: [
			{
				path: "dashboard",
				component: AppPanelLayoutComponent,
				canActivate: [PrivatePageGuard]
			},
			{
				path: "**",
				redirectTo: "dashboard",
				pathMatch: "full"
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(appContainerRoutes)],
	exports: [RouterModule]
})
export class AppContainerRoutingModule {}
