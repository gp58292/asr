import {
	HttpErrorResponse,
	HttpEvent,
	HttpHandler,
	HttpInterceptor,
	HttpRequest,
	HttpResponse
} from "@angular/common/http";
import { Injectable } from "@angular/core";

import { Observable } from "rxjs";

import { catchError, map } from "rxjs/operators";
import { UrlConfig } from "./../services/url-config.service";
import { ErrorHandlerService } from "./error-handler.service";

@Injectable()
export class HttpDataResponseInterceptor implements HttpInterceptor {
	constructor(
		private urlConfig: UrlConfig,
		private errorHandle: ErrorHandlerService
	) {
		console.debug("HttpDataResponseInterceptor::constructor:: ");
	}

	public intercept(
		req: HttpRequest<any>,
		next: HttpHandler
	): Observable<HttpEvent<any>> {
		console.debug("HttpDataResponseInterceptor::intercept:: ", req.url);
		// passing control to the handler in the chain
		return next.handle(req).pipe(
			map((event: HttpEvent<any>) => {
				if (event instanceof HttpResponse) {
					console.debug(
						"HttpDataResponseInterceptor::intercept::map:: ",
						event.status
					);
				}
				return event;
			}),
			catchError(err => {
				//    console.debug("HttpDataResponseInterceptor::intercept::catch:: ",req.url,(req.url!==this.urlConfig.EP_ERRORS_TO_BACKEND));
				if (req.url !== this.urlConfig.EP_ERRORS_TO_BACKEND) {
					if (err instanceof HttpErrorResponse) {
						this.errorHandle.handle(err, false);
					}
					return Observable.throw(err);
				}
				return undefined;
			})
		);
	}
}
