import { Injectable, OnDestroy } from "@angular/core";
import { JsonHttp } from "@aqua/http-service";
import { AppHttpResponse, TabsInfo } from "@aqua/models";
import { BehaviorSubject, from, Observable, Subject } from "rxjs";
import {
	debounceTime,
	distinct,
	filter,
	map,
	switchMap,
	takeUntil,
	toArray
} from "rxjs/operators";

import { SearchResultColumns } from "@aqua/filters/models";
import { VizNotificationService } from "@aqua/services";
import { FiltersUrlConfig } from "./filters-url-config.service";

@Injectable()
export class SearchResultColumnService implements OnDestroy {
	public searchResultColumnsNotify: BehaviorSubject<
		SearchResultColumns[]
	> = new BehaviorSubject([]);
	public searchResultColumnsData: SearchResultColumns[];

	private alive: Subject<void> = new Subject<void>();

	constructor(
		private http: JsonHttp,
		private urlConfig: FiltersUrlConfig,
		private vizNotification: VizNotificationService
	) {
		console.debug("SearchResultColumnService:: constructor::");
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	public loadResultColumns() {
		console.debug("SearchResultColumnService:: loadResultColumns::");
		const requestUrl: string = this.urlConfig.EP_CACHE_GET_RESULT_COLUMNS;
		this.http
			.get(requestUrl)
			.pipe(takeUntil(this.alive))
			.subscribe((response: AppHttpResponse<any>) => {
				if (response.responseStatus === 200) {
					// this.renderSearchData(response.responseData); TODO need to notify bookmark change by behavior subject and multiple lister
					console.debug(
						"SearchResultColumnService:: loadResultColumns :: ",
						response.responseData
					);
					this.searchResultColumnsData = response.responseData;
					this.searchResultColumnsNotify.next(this.searchResultColumnsData);
				} else {
					this.vizNotification.showError(response.restError.errorMessage);
				}
			});
	}

	public listenResultColumns(): Observable<SearchResultColumns[]> {
		console.debug("SearchResultColumnService:: listenResultColumns::");
		return this.searchResultColumnsNotify.pipe(takeUntil(this.alive));
	}
	public getVoyagerTabList(): Observable<string[]> {
		console.debug("SearchResultColumnService:: getVoyagerTabList::");

		return this.listenResultColumns().pipe(
			takeUntil(this.alive),
			switchMap(columns => this.extractVoyagerTabInfo(columns))
		);
	}
	public getTabList(): Observable<TabsInfo[]> {
		console.debug("SearchResultColumnService:: getTabList::");
		return this.listenResultColumns().pipe(
			takeUntil(this.alive),
			switchMap(searchCol => this.extractTabInfo(searchCol))
		);
	}
	public getColumnsListByTab(
		tabName: string
	): Observable<SearchResultColumns[]> {
		console.debug("SearchResultColumnService:: getVoyagerTabList::");

		return this.listenResultColumns().pipe(
			switchMap((column: SearchResultColumns[]) =>
				from(column).pipe(
					takeUntil(this.alive),
					filter((colum: SearchResultColumns) => colum.tabName === tabName),
					toArray()
				)
			)
		);
	}

	private extractTabInfo(items: SearchResultColumns[]) {
		return from(items).pipe(
			takeUntil(this.alive),
			map(
				(column: SearchResultColumns) =>
					new TabsInfo(column.tabId, column.tabName, column.tabOrder)
			),
			distinct((tab: TabsInfo) => tab.tabName),
			toArray(),
			map(array => array.sort(TabsInfo.comparator))
		);
	}

	private extractVoyagerTabInfo(items: SearchResultColumns[]) {
		return from(items).pipe(
			takeUntil(this.alive),
			map((column: SearchResultColumns) => column.tabVoyagerId),
			distinct(),
			toArray()
		);
	}
}
