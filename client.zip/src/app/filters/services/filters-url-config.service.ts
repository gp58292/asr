import { Injectable } from "@angular/core";

@Injectable()
export class FiltersUrlConfig {
	// Base settings
	public API: string = "/api";

	// Controller End Points

	public EP_REFERENCE: string = "/reference";
	public EP_SEARCH: string = "/search";
	public EP_SETTINGS: string = "/settings";
	public EP_RESULT: string = "/result";
	public EP_CACHE: string = "/cache";
	public EP_COLLATERAL_TYPE_LOOKUP: string = "/collateral-type-lookup";
	public EP_AGREEMENT: string = "/agreement";
	public EP_BATCH_STATUS: string = "/batchstatus";

	// BookmarkController
	public EP_BOOKMARK: string = this.API + "/bookmark";
	public EP_BOOKMARK_REPLACE: string = this.EP_BOOKMARK + "/replace";
	public EP_BOOKMARK_DELETE_ALL_TEMPORARY: string =
		this.EP_BOOKMARK + "/deletetemp";
	public EP_BOOKMARK_RESTORE_ALL_DELETED: string =
		this.EP_BOOKMARK + "/restore";

	// SearchController
	public EP_FINDER_DATASETID: string =
		this.API + this.EP_SEARCH + "/get/datasetId";
	public EP_GET_USER_DATASET: string =
		this.API + this.EP_SEARCH + "/getUserDataset";
	public EP_SEARCH_AGREEMENT: string =
		this.API + this.EP_SEARCH + "/collateral";
	public EP_SEARCH_POSTINGS: string = this.API + this.EP_SEARCH + "/postings";
	public EP_SEARCH_BOX: string = this.API + this.EP_SEARCH + "/box";
	public EP_SEARCH_CAPACITY: string = this.API + this.EP_SEARCH + "/capacity";
	public EP_SEARCH_FORWORD_MTM: string =
		this.API + this.EP_SEARCH + "/forward-mtm";
	public EP_SEARCH_MTM: string = this.API + this.EP_SEARCH + "/mtm";
	public EP_SEARCH_GSST: string = this.API + this.EP_SEARCH + "/gsst";
	public EP_SEARCH_FRTB: string = this.API + this.EP_SEARCH + "/frtb";
	public EP_RESULT_COLUMNS: string =
		this.API + this.EP_SEARCH + this.EP_RESULT + "/listed-columns";
	public EP_RESULT_EXPORT: string =
		this.API + this.EP_SEARCH + this.EP_RESULT + "/export";
	public EP_SEARCH_COLLATERAL_TYPE: string =
		this.API + this.EP_SEARCH + this.EP_COLLATERAL_TYPE_LOOKUP;

	// ReferenceDataController
	public EP_GET_REFERENCE_DATA: string =
		this.API + this.EP_REFERENCE + "/dropdown/";
	public EP_GET_TYPEAHEAD_DATA: string =
		this.API + this.EP_REFERENCE + "/typeahead/";
	public EP_GET_TYPEAHEAD_DATA_BY_PASTED_VALUES: string =
		this.API + this.EP_REFERENCE + "/typeahead/pasted/";

	// SettingsController
	public EP_SETTINGS_COLUMNS_LIST: string =
		this.API + this.EP_SETTINGS + "/columns-list";
	public EP_SETTINGS_COLUMNS_TREE: string =
		this.API + this.EP_SETTINGS + "/columns-tree";
	public EP_SETTINGS_USER_COLUMNS: string =
		this.API + this.EP_SETTINGS + "/columns/";

	// AgreementController
	public EP_GET_AGREEMENT_DETAILS: string =
		this.API + this.EP_AGREEMENT + "/getAgreementDetails";

	public EP_GET_BATCH_REPORT: string =
		this.API + this.EP_BATCH_STATUS + "/getReport";

	public EP_GET_CSA_TYPE_DETAILS: string =
		this.API + this.EP_AGREEMENT + "/getCsaTypeDetails";

	public EP_GET_REFERENCE_RATING_RANKINGS: string =
		this.API + this.EP_REFERENCE + "/ratingRanking";

	// Cache Service
	public EP_CACHE_GET_RESULT_COLUMNS: string =
		this.API + this.EP_CACHE + "/getResultColumns";

	public EP_SEARCH_TABS: string = this.API + this.EP_SEARCH + "/tabs";
}
