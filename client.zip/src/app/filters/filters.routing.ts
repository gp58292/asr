import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { PrivatePageGuard } from "@aqua/services";
import { DataFinderComponent } from "app/filters/data-finder/data-finder.component";
const filtersRoutes: Routes = [
	{
		path: "datafinder",
		component: DataFinderComponent,
		canActivate: [PrivatePageGuard],
		children: []
	},
	{
		path: "",
		redirectTo: "/datafinder",
		pathMatch: "full"
	}
];

@NgModule({
	imports: [RouterModule.forRoot(filtersRoutes)],
	exports: [RouterModule]
})
export class FiltersRoutingModule {}
