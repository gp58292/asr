export class SearchField {
	public fieldName: string;
	public nodeName?: string;
	public componentType?: string;
	public dataType: string;
	public logicalGroupName?: string;
	public name: string;
	public schemaName?: string;
	public nodeDisplayName?: string = "Missing";
	public distinctRequired?: number;
	public key?: number;
	public value?: any;
	public defaultSelected: number;
	public whoHasFlag?: number;
	public filterOnlyFlag?: number;

	// All below fields are present only in UI
	public selected?: boolean;
	public filtered?: boolean = false;
	public exported?: boolean = false;
	public attributeName?: string;
}
