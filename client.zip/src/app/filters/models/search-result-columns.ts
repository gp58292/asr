export class SearchResultColumns {
	public key?: number;
	public displayName: string;
	public fieldName: string;
	public fieldType: string;
	public fieldOrder?: number;
	public tabId?: string;
	public tabName?: string;
	public tabOrder?: number;
	public isSearchable?: boolean;
	public isDefaultDisplay?: boolean;
	public tabVoyagerId?: string;
}
