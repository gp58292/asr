export interface DerivzRestRequest {
	userId: string;
	criteriaName: string;
	criteria: any;
}
