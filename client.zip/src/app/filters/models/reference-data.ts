export interface ReferenceData {
	key: number;
	value: string;
}
