export class UserDataset {
	public datasetId: number;
	public displayFlag?: number;
	public displayName?: string;
	public shortName?: string;
	public navigationUrl: string;
}
