export interface BatchReport {
    sourceData: string;
    bau: string;
    sla: string;
    dbBusinessDate: Date;
    uiBusinessDate: Date;
    dataExist: number;
    delayedFeed: boolean;
}
