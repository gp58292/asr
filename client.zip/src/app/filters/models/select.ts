export interface Select {
	value: string;
	displayValue: string;
}
