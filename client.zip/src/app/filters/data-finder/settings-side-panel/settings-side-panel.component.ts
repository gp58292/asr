import { Component, EventEmitter, OnInit, Output } from "@angular/core";
import { FormControl } from "@angular/forms";
import { MatDialog } from "@angular/material";
import { Subject } from "rxjs";

import { ConfirmationDialogComponent } from "@aqua/filters/data-finder/confirmation-dialog/confirmation-dialog.component";
import { DataTreeStorageService } from "@aqua/filters/services";
import { debounceTime, distinctUntilChanged, takeUntil } from "rxjs/operators";

@Component({
	selector: "settings-side-panel",
	templateUrl: "./settings-side-panel.component.html",
	styleUrls: ["./settings-side-panel.component.scss"]
})
export class SettingsSidePanelComponent implements OnInit {
	public treeData: any[];
	public copyTreeData: any[] = [];
	public filterFieldSearch: string;

	public expandOrShrink: string = "Shrink All";
	public fieldsStage: string = "normal";
	public normalTreeIcon: string = "keyboard_arrow_left";
	public filterControl: FormControl = new FormControl();
	public whoCanWhoHasToggleCtrl: FormControl = new FormControl("can");
	@Output() public stage: EventEmitter<string> = new EventEmitter<string>();

	private alive: Subject<void> = new Subject();
	private filtering: boolean;
	private timeout: any;

	private shrinkAll: boolean = false;

	// -------------------------------------------------------------------------------------------------------------------
	constructor(
		private dataStorageTreeService: DataTreeStorageService,
		private dialog: MatDialog
	) {
		console.debug("SettingsSidePanelComponent::constructor");
		this.dataStorageTreeService
			.listenState()
			.pipe(takeUntil(this.alive))
			.subscribe(state => {
				this.setTree(state);
			});
		this.dataStorageTreeService
			.listenForWhoHasWhoCanChanged()
			.pipe(takeUntil(this.alive))
			.subscribe(status => {
				this.whoCanWhoHasToggleCtrl.setValue(status);
			});

		// ------------------ Search term change Set Component state and load data  ---------------
		// Bind search call to formControl
		this.filterControl.valueChanges
			.pipe(
				takeUntil(this.alive),
				debounceTime(300),
				distinctUntilChanged()
			)
			.subscribe(term => {
				console.debug(
					"SettingsSidePanelComponent::termvalue Events::searchTerm ",
					term
				);
				if (term !== undefined) {
					this.filterItem();
				}
			});
		// ------------------ Search term change Set Component state and load data  ---------------
	}

	public ngOnInit() {
		console.debug("SettingsSidePanelComponent::ngOnInit");
	}
	public ngAfterViewInit() {
		console.debug("SettingsSidePanelComponent::ngAfterViewInit");
	}
	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	public toggleSideBarStage() {
		this.fieldsStage = this.fieldsStage === "normal" ? "shrunk" : "normal";
		this.normalTreeIcon =
			this.normalTreeIcon === "keyboard_arrow_left"
				? "keyboard_arrow_right"
				: "keyboard_arrow_left";
		this.stage.emit("normalTree");
	}

	// private deleteFilter(filter: SearchField) {
	// 	console.debug("SettingsSidePanelComponent::deleteFilter");
	// 	this.dataStorageTreeService.updateNode(filter, "filter");
	// 	// this.filteredFields.splice(this.filteredFields.indexOf(filter),1);
	// }

	// Toggle between shrink and expanding the tree
	public expandShrinkTree() {
		console.debug("SettingsSidePanelComponent::expandShrinkTree");
		if (!this.shrinkAll) {
			this.shrinkAll = true;
			this.expandOrShrink = "Expand All";
		} else {
			this.shrinkAll = false;
			this.expandOrShrink = "Shrink All";
		}
	}

	public clearFilters() {
		console.debug("SettingsSidePanelComponent::clearFilters");
		const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
			data: { confirmationMessage: "Clear All Filters?" }
		});

		dialogRef.afterClosed().subscribe(confirmed => {
			console.debug("The dialog was closed, user has selected:" + confirmed);
			if (!confirmed) {
				return;
			} else {
				this.dataStorageTreeService.clearAllFilters();
			}
		});
	}
	public whoCanHasToggleChange(event) {
		console.debug("SettingsSidePanelComponent::whoCanHasToggleChange", event);
		if (event.value === "has") {
			this.getTreeByWhoCanWhoHas("has");
		} else if (event.value === "can") {
			this.getTreeByWhoCanWhoHas("can");
		}
	}

	public getTreeByWhoCanWhoHas(type: "can" | "has") {
		console.debug("SettingsSidePanelComponent::getTreeByWhoCanWhoHas");
		this.dataStorageTreeService.toggleWhoCanWhoHasTree(type);
	}

	private setTree(data: any[]) {
		console.debug("SettingsSidePanelComponent::setTree");
		if (this.filtering) {
			this.copyTreeData = data;
			this.filterItem();
			return;
		}
		this.treeData = data;
		this.copyTreeData = data;
	}

	private filterItem() {
		console.debug("SettingsSidePanelComponent::filterItem inputChange");
		if (this.filterFieldSearch.length === 0) {
			this.treeData = this.copyTreeData;
			this.filtering = false;
			return;
		}

		if (this.treeData.length === 0) {
			this.treeData = this.copyTreeData;
			this.filtering = false;
		}

		if (this.timeout) {
			clearTimeout(this.timeout);
		}

		this.timeout = setTimeout(() => {
			console.debug("SettingsSidePanelComponent::filterItem inputChange");
			const treeD = this.copyTreeData;
			this.filtering = true;
			const filteredTreeResult: any[] = [];
			// Call service to filter tree
			this.dataStorageTreeService.treeIterator(
				this.filterFieldSearch,
				treeD,
				"",
				filteredTreeResult
			);
			// If filteredSearch is empty and the response is blank, reset treeData to original value
			if (
				this.filterFieldSearch.length === 0 &&
				filteredTreeResult.length === 0
			) {
				this.treeData = this.copyTreeData;
			} else {
				console.debug(
					"SettingsSidePanelComponent::filterItem inputChange",
					filteredTreeResult
				);
				this.treeData = filteredTreeResult;
			}
		}, 500);
	}
}
