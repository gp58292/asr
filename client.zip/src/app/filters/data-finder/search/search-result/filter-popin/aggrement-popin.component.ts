import {
	ChangeDetectionStrategy,
	Component,
	Inject,
	OnDestroy,
	OnInit,
	ViewChild,
	ChangeDetectorRef
} from "@angular/core";
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from "@angular/material";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { Agreement, DerivzRestResponse } from "@aqua/filters/models";
import { VizNotificationService } from "@aqua/services";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";

import { CsaAgreementDetailsComponent } from "./csa-agreement-details/csa-agreement-details.component";
import { CSADetails } from "./csa-details-model";

@Component({
	selector: "ceft-aggrement-popin",
	templateUrl: "./aggrement-popin.component.html",
	styleUrls: ["./aggrement-popin.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class AggrementPopinComponent implements OnInit, OnDestroy {
	public agreementDetailsList: Agreement;
	public csaDetails: CSADetails;
	public spinnerStatus: boolean = true;
	public currentCSA;

	@ViewChild(CsaAgreementDetailsComponent)
	public csaAgrermentDetailsComponent: CsaAgreementDetailsComponent;
	private alive: Subject<void> = new Subject();
	private tabList: Map<string, CSADetails> = new Map<string, CSADetails>();

	constructor(
		private searchService: SearchService,
		private vizNotification: VizNotificationService,
		public dialogRef: MatDialogRef<AggrementPopinComponent>,
		private dialogConfirmation: MatDialog,
		@Inject(MAT_DIALOG_DATA) public data: any,
		private _changeDetectorRef: ChangeDetectorRef
	) {
		dialogRef.disableClose = true;
	}

	public onNoClick(): void {
		this.dialogRef.close();
	}

	public ngOnInit() {
		this.getAgreementDetails();
	}

	public ngOnDestroy() {
		console.debug("AggrementPopinComponent::ngOnDestroy");
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}
	public aggrementTabChanged($event) {
		console.debug("AggrementPopinComponent::aggrementTabChanged", $event.index);
		const _currentTabkey =
			this.data.aggrementId +
			this.agreementDetailsList.csaTypeDescList[$event.index - 1]
				.csa_description;

		let tabDetails = this.tabList.get(_currentTabkey);
		// console.debug(
		// 	"AggrementPopinComponent::aggrementTabChanged",
		// 	$event.index,
		// 	_currentTabkey,
		// 	tabDetails
		// );
		if (!tabDetails) {
			tabDetails = new CSADetails(
				this.data.aggrementId,
				this.agreementDetailsList.csaTypeDescList[
					$event.index - 1
				].csa_description,
				this.agreementDetailsList.csaTypeDescList[$event.index - 1].csa_status
			);
			this.tabList.set(_currentTabkey, tabDetails);
		}
	}

	public getCurrentCSA(listofcsatype) {
		const _currentTabKey = this.data.aggrementId + listofcsatype;
		// console.debug("AggrementPopinComponent::getCurrentCSA::", _currentTabKey);
		return this.tabList.get(_currentTabKey);
	}
	public onCancel(): void {
		this.dialogRef.close();
	}

	public cancelCallBack() {
		this.dialogRef.close();
	}

	private getAgreementDetails() {
		console.debug("AggrementPopinComponent::getBOXData");
		this.searchService
			.getAgreementDetails(this.data.name)
			.pipe(takeUntil(this.alive))
			.subscribe((response: DerivzRestResponse<Agreement[]>) => {
				if (response.responseStatus === 200) {
					this.vizNotification.showMessage(
						"Agreement details fetched successfully"
					);
					console.debug(
						"AggrementPopinComponent::getAgreementDetails::",
						response.responseData
					);
					this.agreementDetailsList = response.responseData;
					this.spinnerStatus = false;
					this._changeDetectorRef.markForCheck();
				} else {
					this.vizNotification.showError(response.restError.errorMessage);
				}
			});
	}
}
