import {
	CommonExcelStyleRule,
	NumericExcelStyleRule
} from "@aqua/aqua-component/aqua-grid/excel-styles";
import { NumberRenderer } from "@aqua/aqua-component/aqua-grid/inline-cell-renderer";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const COVERED_BRANCHES_GRID_DEFINATION: ColumnDefaultGrid[] = [
	{
		headerName: "GFCID",
		field: "partyGfcId",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Branch Name",
		field: "partyBranchName",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Location",
		field: "partyLocation",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Funding Index",
		field: "fundingIndex",
		cellRendererFramework: NumberRenderer,
		cellClassRules: { ...CommonExcelStyleRule, ...NumericExcelStyleRule }
	}
];
