import {
	CommonExcelStyleRule,
	NumericExcelStyleRule
} from "@aqua/aqua-component/aqua-grid/excel-styles";
import { NumberRenderer } from "@aqua/aqua-component/aqua-grid/inline-cell-renderer";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const AC_COVERED_GRID_DEFINATION: ColumnDefaultGrid[] = [
	{
		headerName: "Include/Exclude",
		field: "includeExclude",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Code",
		field: "instrumentCode",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Instr Code",
		field: "parentInstrCode",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Type",
		field: "covProdType",
		cellRendererFramework: NumberRenderer,
		cellClassRules: { ...CommonExcelStyleRule, ...NumericExcelStyleRule }
	},
	{
		headerName: "Name",
		field: "instrumentName",
		cellClassRules: CommonExcelStyleRule
	}
];
