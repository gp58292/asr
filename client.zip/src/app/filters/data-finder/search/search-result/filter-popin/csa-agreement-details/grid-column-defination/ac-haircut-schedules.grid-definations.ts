import {
	CommonExcelStyleRule,
	NumericExcelStyleRule
} from "@aqua/aqua-component/aqua-grid/excel-styles";
import { NumberRenderer } from "@aqua/aqua-component/aqua-grid/inline-cell-renderer";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const AC_HAIRCUT_SCHEDULES_GRID_DEFINATION: ColumnDefaultGrid[] = [
	{
		headerName: "Type",
		field: "achType",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Min Term",
		field: "achMinTerm",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Max Term",
		field: "achMaxTerm",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Haircut%",
		field: "achHaicutPercentage",
		cellRendererFramework: NumberRenderer,
		cellClassRules: { ...CommonExcelStyleRule, ...NumericExcelStyleRule }
	},
	{
		headerName: "Issue Rating",
		field: "achRating",
		minWidth: 250,
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Issuer Rating",
		field: "achIssuerRating",
		minWidth: 250,
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Collateral Applied",
		field: "achCollateralApplied",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Collateral Party",
		field: "collateralParty",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Ranking",
		field: "achRanking",
		cellClassRules: CommonExcelStyleRule
	}
];
