import {
	CommonExcelStyleRule,
	NumericExcelStyleRule
} from "@aqua/aqua-component/aqua-grid/excel-styles";
import { NumberRenderer } from "@aqua/aqua-component/aqua-grid/inline-cell-renderer";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const PARTY_SCHDULED_THRESHOLD_GRID_DEFINATION: ColumnDefaultGrid[] = [
	{
		headerName: "Type",
		field: "type",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Basis",
		field: "basis",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Currency",
		field: "currency",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Amount",
		field: "amount",
		cellRendererFramework: NumberRenderer,
		cellClassRules: { ...CommonExcelStyleRule, ...NumericExcelStyleRule }
	},
	{
		headerName: "Start Date",
		field: "startDate",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "End Date",
		field: "endDate",
		cellClassRules: CommonExcelStyleRule
	}
];
