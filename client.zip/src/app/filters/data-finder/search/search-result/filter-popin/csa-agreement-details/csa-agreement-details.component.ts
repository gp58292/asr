import {
	ChangeDetectionStrategy,
	ChangeDetectorRef,
	Component,
	EventEmitter,
	Input,
	OnDestroy,
	Output
} from "@angular/core";
import {
	ColumnDefaultGrid,
	GridUtils
} from "@aqua/aqua-component/aqua-grid/utils";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { DerivzRestResponse } from "@aqua/filters/models";
import { VizNotificationService } from "@aqua/services";
import { GridOptions } from "ag-grid-community";
import { Subject } from "rxjs";
import { catchError, finalize, takeUntil } from "rxjs/operators";

import { CSADetails } from "./../csa-details-model";
import { AC_CASH_GRID_DEFINATION } from "./grid-column-defination/ac-cash.grid-definations";
import { AC_COVERED_GRID_DEFINATION } from "./grid-column-defination/ac-covered.grid-definations";
import { AC_HAIRCUT_SCHEDULES_GRID_DEFINATION } from "./grid-column-defination/ac-haircut-schedules.grid-definations";
import { CREDIT_THRESHOLD_GRID_DEFINATION } from "./grid-column-defination/credit-threshold.grid-definations";
import { PARTY_SCHDULED_THRESHOLD_GRID_DEFINATION } from "./grid-column-defination/party-scheduled-threshold.grid-definations";
import { PARTY_THRESHOLD_GRID_DEFINATION } from "./grid-column-defination/party-threshold.grid-definations";
import { PUBLIC_RATING_GRID_DEFINATION } from "./grid-column-defination/public-rating.grid-definations";

@Component({
	selector: "ceft-csa-agreement-details",
	templateUrl: "./csa-agreement-details.component.html",
	styleUrls: ["./csa-agreement-details.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class CsaAgreementDetailsComponent implements OnDestroy {
	@Input()
	public set csaDetails(_csaDetails: CSADetails) {
		this._csaDetails = _csaDetails;
		console.debug("CsaAgreementDetailsComponent::csaDetails", this._csaDetails);

		if (
			this._csaDetails &&
			this._csaDetails.agreementId &&
			this._csaDetails.csaDetailsName &&
			!this._isDataLoaded
		) {
			this.getAgreementCSADetails(
				this._csaDetails.agreementId,
				this._csaDetails.csaDetailsName
			);
		} else if (
			this._csaDetails &&
			!this._csaDetails.agreementId &&
			this._csaDetails.csaDetailsName
		) {
			// this.vizNotification.showWarning(
			// 	"Unfortunatly, We have not received any agreement id or csa name, Please contact support team!"
			// );
			console.warn(
				"CsaAgreementDetailsComponent::csaDetails::Unfortunatly, We have not received any agreement id or csa name, Please contact support team"
			);
		}
	}

	public static gridOptions: GridOptions = {
		sideBar: null,
		// {
		// 	toolPanels: [
		// 		{
		// 			id: "columns",
		// 			labelDefault: "Columns",
		// 			labelKey: "columns",
		// 			iconKey: "columns",
		// 			toolPanel: "agColumnsToolPanel",
		// 			toolPanelParams: {
		// 				suppressRowGroups: true,
		// 				suppressValues: true,
		// 				suppressPivots: true,
		// 				suppressPivotMode: true,
		// 				suppressSideButtons: true,
		// 				suppressColumnFilter: true,
		// 				suppressColumnSelectAll: true,
		// 				suppressColumnExpandAll: true
		// 			}
		// 		}
		// 	],
		// 	defaultToolPanel: "columns"
		// }
		enableRangeSelection: true,
		statusBar: {
			statusPanels: [
				{ statusPanel: "agTotalRowCountComponent", align: "left" },
				{ statusPanel: "agFilteredRowCountComponent" },
				{ statusPanel: "agSelectedRowCountComponent" },
				{
					statusPanel: "agAggregationComponent",
					statusPanelParams: {
						// possible values are: 'count', 'sum', 'min', 'max', 'avg'
						aggFuncs: ["count", "min", "max", "avg"]
					}
				}
			]
		},
		suppressHorizontalScroll: false,
		pagination: false,
		rowHeight: 20,
		rowBuffer: 10,
		defaultColDef: {
			sortable: true,
			resizable: true,
			filter: true
		}
	};
	public acHaircutScheduleColDef: ColumnDefaultGrid[] = AC_HAIRCUT_SCHEDULES_GRID_DEFINATION;
	public partyThresholdColDef: ColumnDefaultGrid[] = PARTY_THRESHOLD_GRID_DEFINATION;
	public creditThresholdColDef: ColumnDefaultGrid[] = CREDIT_THRESHOLD_GRID_DEFINATION;
	public partyScheduledThresholdColDef: ColumnDefaultGrid[] = PARTY_SCHDULED_THRESHOLD_GRID_DEFINATION;
	public publicRatingColDef: ColumnDefaultGrid[] = PUBLIC_RATING_GRID_DEFINATION;
	public acCashColDef: ColumnDefaultGrid[] = AC_CASH_GRID_DEFINATION;
	public acCoveredProdColDef: ColumnDefaultGrid[] = AC_COVERED_GRID_DEFINATION;

	public agreementDetailsCSAList: any;
	@Output() public notify: EventEmitter<string> = new EventEmitter<string>();

	public _isLoadingData = false;

	public defaultGridHeight = 20;
	public minDefaultGridHeight = 15;
	private alive: Subject<void> = new Subject();

	private _csaDetails: CSADetails;
	private _isDataLoaded: boolean = false;

	constructor(
		private searchService: SearchService,
		private vizNotification: VizNotificationService,
		private _changeDetectorRef: ChangeDetectorRef
	) {}

	// agreementId, AgreementCsa
	public getAgreementCSADetails(userAgreementId, userAgreementCsa) {
		console.debug(
			"CsaAgreementDetailsComponent::getAgreementCSADetails::",
			this._csaDetails
		);
		if (!this._isLoadingData) {
			this._isLoadingData = true;
			this.notify.emit("true");
			this.searchService
				.getAgreementCSADetails(
					/// this._csaDetails.agreementId,
					// this._csaDetails.csaDetailsName
					userAgreementId,
					userAgreementCsa
				)
				.pipe(
					takeUntil(this.alive),
					finalize(() => {
						this._isLoadingData = false;
						this._isDataLoaded = true;
					}),
					catchError(err => {
						console.error(
							"CsaAgreementDetailsComponent::getAgreementCSADetails::",
							err
						);
						this.vizNotification.showError(
							"Failed to load data for tab [" +
								this._csaDetails.csaDetailsName +
								"]"
						);
						return err;
					})
				)
				.subscribe((response: DerivzRestResponse<any>) => {
					if (response.responseStatus === 200) {
						this.vizNotification.showMessage(
							"Agreement " +
								this._csaDetails.csaDetailsName +
								" details fetched successfully"
						);
						this.updateDataSources(response);
						// console.debug("CsaAgreementDetailsComponent::getAgreementCSADetails::",this._csaDetails);
					} else {
						this.vizNotification.showError(response.restError.errorMessage);
					}
				});
		}
	}

	public ngOnDestroy() {
		console.debug("CsaAgreementDetailsComponent::ngOnDestroy");
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}
	public getData(data: string): string {
		return data ? data : "N/A";
	}
	public getOptions(name: string): any {
		return {
			...CsaAgreementDetailsComponent.gridOptions,
			...GridUtils.getDefaultExcelExportParam(name)
		};
	}

	private updateDataSources(response): void {
		this.agreementDetailsCSAList = response.responseData;
		this._changeDetectorRef.markForCheck();
	}
}
