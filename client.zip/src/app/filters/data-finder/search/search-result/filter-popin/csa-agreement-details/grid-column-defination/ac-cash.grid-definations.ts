import { CommonExcelStyleRule } from "@aqua/aqua-component/aqua-grid/excel-styles";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const AC_CASH_GRID_DEFINATION: ColumnDefaultGrid[] = [
	{
		headerName: "Currency",
		field: "accCurrency",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Interest Index",
		field: "accInterestMatrix",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Interest Spread",
		field: "accInterestSpread",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Compounding",
		field: "accCompounding",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Payment Frequency",
		field: "accPaymentFrequency",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Reset Frequency",
		field: "accResetFrequency",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Ranking",
		field: "accRanking",
		cellClassRules: CommonExcelStyleRule
	}
];
