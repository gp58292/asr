import { CommonExcelStyleRule } from "@aqua/aqua-component/aqua-grid/excel-styles";
import { ColumnDefaultGrid } from "@aqua/aqua-component/aqua-grid/utils";

export const PUBLIC_RATING_GRID_DEFINATION: ColumnDefaultGrid[] = [
	{
		headerName: "Date",
		field: "ratingDate",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Agency",
		field: "agency",
		cellClassRules: CommonExcelStyleRule
	},
	{
		headerName: "Rating",
		field: "rating",
		cellClassRules: CommonExcelStyleRule
	}
];
