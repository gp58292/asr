export class CSADetails {
	constructor(public agreementId: number, public csaDetailsName: string, public csaStatus: string) {}
}

// export interface CSADetails {
// 	agreementId: number,
// 	csaDetailsName: string
// }
