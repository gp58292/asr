import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { FormArray, FormGroup, NgForm } from "@angular/forms";
import { MatDialog, MatDialogRef } from "@angular/material";
import { ConfirmationDialogComponent } from "@aqua/filters/data-finder/confirmation-dialog/confirmation-dialog.component";
import {
	FilterDisplayService,
	SearchFieldStates
} from "@aqua/filters/data-finder/search/controls/filter-display";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { Agreement, SearchField } from "@aqua/filters/models";
import { DataTreeStorageService } from "@aqua/filters/services";
import { EnvironmentVersion } from "@aqua/models/dto";
import { ReferencesDataService } from "@aqua/services";
import * as lodash from "lodash";
import { Subject, Subscription } from "rxjs";
import { debounceTime, distinctUntilChanged, takeUntil } from "rxjs/operators";

import { BookmarkService } from "../bookmark";

@Component({
	selector: "aqua-search",
	templateUrl: "./search.component.html",
	styleUrls: ["./search.component.scss"]
})
export class SearchComponent implements OnInit {
	@ViewChild("advanceSearchForm")
	set setForm(myForm: FormGroup) {
		console.debug("SearchComponent::setForm::", myForm);
		if (myForm && this.previousForm !== myForm) {
			console.debug("SearchComponent::setting new Form Instance::");
			if (this.formSubscription) {
				this.formSubscription.unsubscribe();
				this.formSubscription = undefined;
			}
			this.previousForm = myForm;
			this.formSubscription = myForm.valueChanges
				.pipe(
					takeUntil(this.alive),
					debounceTime(700),
					distinctUntilChanged()
				)
				.subscribe(data => {
					// Don't use get Current Criteria, as it filter outs empty records
					this.filterDisplayService.updateRecords(
						new SearchFieldStates(this.fields, this.getCurrentCriteria())
					);
					// this._isBookmarkChanged = !this.bookmarkService.isCurrentBookmarkModified(
					// 	this.fields
					// );
					console.debug(
						"SearchComponent::setForm::data::",
						Object.keys(data),
						this._isBookmarkChanged
					);
				});
		}
	}

	@ViewChild("advanceSearchForm")
	public searchForm: ElementRef;

	public get isBookmatkChanged(): boolean {
		return this._isBookmarkChanged;
	}
	public bookmarkList = [];
	public selectedBookmarkKey: number;
	public saveAsCriteriaName: string;
	public fieldsWhoCan: SearchField[] = [];
	public fieldsWhoHas: SearchField[] = [];
	public fields: SearchField[] = [];

	public payLoad = "";
	public form: FormGroup;
	public resultList: Agreement[];
	public env: EnvironmentVersion;

	public bookmarkLoaded: boolean = false;
	private alive: Subject<void> = new Subject<void>();
	private dialogRef: MatDialogRef<ConfirmationDialogComponent, null>;

	/* REQUIRED: PERFORMANCE FIX: This is getting multiple times, so those many subscription are generating */
	private formSubscription: Subscription;
	private previousForm: FormGroup;
	private _isBookmarkChanged: boolean = false;

	constructor(
		private bookmarkService: BookmarkService,
		private dataStorageTreeService: DataTreeStorageService,
		private searchService: SearchService,
		private filterDisplayService: FilterDisplayService,
		private referencesData: ReferencesDataService,
		private dialog: MatDialog
	) {
		this.listenForFilteredField();
	}

	// DON"T DO: Never enable track by using trackByKey, it causes problem while removing item
	public trackByKey(item) {
		return item.key;
	}

	public ngOnInit() {
		this.listenBookmark();
		this.listenRefrenceData();
    this.listenNodeUpdatedState();
    this.listenResetFormState();
	}

	public findInvalidControls(
		controls: any = this.form.controls,
		invalid: any[] = []
	) {
		// tslint:disable-next-line:forin
		for (const name in controls) {
			if (
				controls[name] instanceof FormGroup ||
				controls[name] instanceof FormArray
			) {
				this.findInvalidControls(controls[name].controls, invalid);
			}
			if (controls[name].invalid) {
				invalid.push(name);
			}
		}
		return invalid;
	}

	public renderSearchData(responseData) {
		console.debug("SearchComponent::listenBookmark::renderSearchData");

		if (this.form) {
			this.form.reset();
		}
		// If no fields exist in the resposne. Clear all the filters
		if (responseData.length === 0) {
			this.dataStorageTreeService.clearAllFilters();
			this.fields = [];
			return;
		}

		// console.debug("SearchComponent::listenBookmark::renderSearchData", responseData);

		// <=== Below line is commented because this.dataStorageTreeService.setFiltersBasedOfBookmark(responseData) ultimately has listner
		// whichi builds form, doesn't make sense to have 2 calls for building form ===>

		this.form = this.searchService.toFormGroup(responseData, this.form);

		// This function calls updateNode which will handle adding the appropiate filters to this.fields
		this.dataStorageTreeService.setFiltersBasedOfBookmark(responseData);

		// Execute the search once the new fields are rendered
		// this.onSearchClick();
	}

	// Determines wether or not to remove item from the list depending if it exists or not in passed in list.
	public addOrRemoveFromArray(fieldList: any[], fieldIn: any) {
		// console.debug("SearchComponent::listenBookmark::addOrRemoveFromArray::", fieldList,(fieldList.findIndex((field) => { return field.key == fieldIn.key }) >= 0));
		if (
			!(
				fieldList.findIndex(field => {
					return field.key === fieldIn.key;
				}) >= 0
			)
		) {
			fieldList.push(fieldIn);
		} else {
			fieldList.splice(
				fieldList.findIndex(field => {
					return field.key === fieldIn.key;
				}),
				1
			);
		}
	}

	public onDeleteField(field: any) {
		console.debug("SearchComponent::onDeleteField");
		this.dataStorageTreeService.updateNode(field, "filter");
	}

	// ====================== Event Handlers ============================================

	// TODO : what about non standard values like exclude, range component
	// Needs to be further investigated as I did not create thie onSearch function. It does search with those filters though if you examine network traffic
	public onSearchClick(advanceSearchForm?: NgForm) {
		console.debug("SearchComponent::onSearchClick");
		console.debug("SearchComponent::onSearchClick", advanceSearchForm);
		console.debug(
			"SearchComponent::onSearchClick: Payload of search Result:",
			this.payLoad
		);
		console.debug("SearchComponent::onSearchClick: fields", this.fields);

		const critieria = this.getCurrentCriteria();
		this.payLoad = JSON.stringify(critieria);

		if (critieria && critieria.length > 0) {
			this.searchService.find(critieria, []);
			// alway update the bookmark even the criteria list is empty
			this.bookmarkService.onSearchCreateOrModifyBookmark(this.fields);
		}
	}

	// [FIXME] The reset function is not working.
	public openConfirmationDialog() {
		// OnResetClick() {
		console.debug("SearchComponent::openConfirmationDialog ::for Reset ");

		this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
			width: "300px",
			data: { confirmationMessage: "Are you sure you want to reset ?" },
			disableClose: false
		});

		this.dialogRef
			.afterClosed()
			.pipe(takeUntil(this.alive))
			.subscribe((result: boolean) => {
				console.debug(
					"SearchComponent::openConfirmationDialog ::User Result:: ",
					result
				);
				if (result) {
					const group: any = {};
					this.fields.forEach(field => {
						group[field.fieldName + "-" + field.key] = null;
					});
					this.form.patchValue(group, { emitEvent: false });
					this.form.markAsTouched();
					this.form.reset();
					this.dialogRef = null;
				}
			});
	}

	// ========= helper methods=============================

	public getCurrentCriteria(): SearchField[] {
		console.debug(
			"SearchComponent::getCurrentCriteria ::User criteria:: ",
			this.fields.filter(field => field.value)
		);
		return this.fields.filter(field => field.value && field.value !== "");
	}

	public ngOnDestroy() {
		console.debug("SearchComponent::ngOnDestroy::", this.payLoad);
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
		this.alive = undefined;
	}

	private listenRefrenceData(): void {
		console.debug("SearchComponent::listenRefrenceData");
		this.referencesData
			.subscribeEnvDetails()
			.pipe(takeUntil(this.alive))
			.subscribe((env: EnvironmentVersion) => {
				if (env.envName.indexOf("prod") === -1) {
					this.env = env;
				}
			});
	}

	private listenBookmark(): void {
		console.debug("SearchComponent::listenBookmark");
		this.bookmarkService
			.getBookmarkDataNotification()
			.pipe(takeUntil(this.alive))
			.subscribe(bookmark => {
				console.debug(
					"SearchComponent::listenBookmark::Got new bookmark::",
					bookmark
				);
				if (bookmark) {
					this.renderSearchData(bookmark);
				}
				if (!this.bookmarkLoaded) {
					this.bookmarkLoaded = true;
				}
			});
	}

	private listenForFilteredField(): void {
		console.debug("SearchComponent::listenForFilteredField");
		this.dataStorageTreeService
			.listenForFilteredField()
			.pipe(
				takeUntil(this.alive),
				distinctUntilChanged()
			)
			.subscribe(filter => this.onFilter(filter));
	}

	// TO DO : NOTE: This method need immeditae attention to improve performance
	private onFilter(
		fieldAdd: { fieldIn: any; section: "can" | "has" } | "Clear All"
	): void {
		console.debug("SearchComponent::listenForFilteredField::onFilter");
		console.debug(
			"SearchComponent::listenForFilteredField::onFilter field in",
			fieldAdd
		);

		if (fieldAdd === "Clear All") {
			if (this.form) {
				this.form.reset();
			}
			this.fieldsWhoCan = [];
			this.fieldsWhoHas = [];
			this.fields = [];

			this.payLoad = "";
			console.debug(
				"SearchComponent::listenForFilteredField::onFilter got here"
			);
			return;
		}

		// We are changing the whoHasFlag value in case it drop in can panel.
		if (fieldAdd.section === "can") {
			fieldAdd.fieldIn.whoHasFlag = 0;
		}

		// TODO Fields object concatanates both arrays. We will use the fields value when searching
		console.debug(
			"SearchComponent::listenForFilteredField::onFilter concatanated",
			this.fieldsWhoCan,
			this.fieldsWhoHas
		);

		// <=== Delay here is important, which give ample time remove or complet component Life cycle ===>
		setTimeout(() => {
			this.addOrRemoveFromArray(
				fieldAdd.fieldIn.whoHasFlag === 1
					? this.fieldsWhoHas
					: this.fieldsWhoCan,
				fieldAdd.fieldIn
			);
			this.fields = this.fieldsWhoCan.concat(this.fieldsWhoHas);
			this.form = this.searchService.toFormGroup(this.fields, this.form);
			this.filterDisplayService.updateRecords(
				new SearchFieldStates(this.fields, this.getCurrentCriteria())
			);
		}, 200);
	}

	/*############## Start: Connecting to Python ############### */
	private listenNodeUpdatedState(): void {
    console.debug("AQUA-ASR::SearchComponent::listenNodeUpdatedState");
		this.dataStorageTreeService
			.listenNodeUpdatedState()
			.pipe(takeUntil(this.alive))
			.subscribe(status => {
				if (status && this.searchForm) {
					this.onSearchClick(this.searchForm.nativeElement);
				}
			});
  }

  private listenResetFormState(): void {
		console.debug("SearchComponent::listenResetFormState");
		this.dataStorageTreeService
			.listenResetFormState()
			.pipe(takeUntil(this.alive))
			.subscribe(status => {
				if (status && this.form) {
					const group: any = {};
					this.fields.forEach(field => {
						group[field.fieldName + "-" + field.key] = null;
					});
					this.form.patchValue(group, { emitEvent: false });
					this.form.markAsTouched();
					this.form.reset();
				}
			});
	}
	/*############## End: Connecting to Python ############### */
}
