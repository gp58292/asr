import { Injectable } from "@angular/core";
import { SearchField } from "@aqua/filters/models/search-field";
import { Observable } from "rxjs";
import { BehaviorSubject } from "rxjs";
import { filter } from "rxjs/operators";

@Injectable()
export class FilterDisplayService {
	private recordFields: BehaviorSubject<
		SearchFieldStates
	> = new BehaviorSubject(undefined);

	public updateRecords(searchFieldStates: SearchFieldStates): void {
		this.recordFields.next(searchFieldStates);
	}

	public getAsObservable(): Observable<SearchFieldStates> {
		return this.recordFields.asObservable().pipe(filter(p => !!p));
	}
}

// tslint:disable-next-line:max-classes-per-file
export class SearchFieldStates {
	// tslint:disable-next-line:no-empty
	constructor(
		public fields: SearchField[],
		public dataWithoutEmptyValue: SearchField[]
	) {}
}
