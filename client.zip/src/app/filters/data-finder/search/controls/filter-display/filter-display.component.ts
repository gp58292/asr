import { DatePipe, TitleCasePipe, UpperCasePipe } from "@angular/common";
import { Component, Input, OnDestroy, OnInit } from "@angular/core";
import {
	IncludeExcludeListModel,
	IncludeExcludeModel,
	OPERATOR,
	RangeWrapperModel,
	RatingRangeListModel,
	RatingRangeListWrapperModel,
	TenorRangeModel
} from "@aqua/aqua-component/models";
import { RangeValue } from "@aqua/aqua-component/models/range-value";
import { ComponentType, SearchField } from "@aqua/filters/models";
import { Subject } from "rxjs";
import { debounceTime, distinctUntilChanged, takeUntil } from "rxjs/operators";

import {
	FilterDisplayService,
	SearchFieldStates
} from "./filter-display.service";

@Component({
	selector: "derivz-filter-display",
	templateUrl: "./filter-display.component.html",
	styleUrls: ["./filter-display.component.scss"]
})
export class FilterDisplayComponent implements OnInit, OnDestroy {
	public searchRecords: SearchField[];

	@Input("whoHas")
	public whoHasFlag: number = 0;

	public displayCriteria: Map<string, Set<string>>;
	private alive: Subject<void> = new Subject();

	private titleCasePipe: TitleCasePipe = new TitleCasePipe();
	private upperCasePipe: UpperCasePipe = new UpperCasePipe();
	private datePipe: DatePipe = new DatePipe("en-US");

	constructor(private filterDisplayService: FilterDisplayService) {}

	public ngOnInit() {
		this.observeData();
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	private observeData(): void {
		this.filterDisplayService
			.getAsObservable()
			.pipe(
				takeUntil(this.alive),
				debounceTime(500),
				distinctUntilChanged()
			)
			.subscribe((searchFieldStates: SearchFieldStates) => {
				// console.debug(
				// 	"FilterDisplayComponent::observeData::subscribe::",
				// 	searchFieldStates
				// );
				if (
					searchFieldStates.dataWithoutEmptyValue &&
					searchFieldStates.dataWithoutEmptyValue.length > 0
				) {
					this.searchRecords = searchFieldStates.dataWithoutEmptyValue;
					this.prepareCriteria();
				} else {
					if (this.displayCriteria) {
						this.displayCriteria.clear();
						this.displayCriteria = undefined;
					}
				}
			});
	}

	private prepareNewSet(nameOfCriteria: string): Set<string> {
		let alertCriteria: Set<string> = this.displayCriteria.get(nameOfCriteria);
		if (alertCriteria) {
			alertCriteria.clear();
			this.displayCriteria.delete(nameOfCriteria);
			alertCriteria = undefined;
		}

		alertCriteria = new Set<string>();
		this.displayCriteria.set(nameOfCriteria, alertCriteria);
		return alertCriteria;
	}

	private prepareCriteria(): void {
		/*console.debug(
			"FilterDisplayComponent::prepareCriteria:: Called",
			this.searchRecords
		);*/
		if (this.displayCriteria) {
			delete this.displayCriteria;
		}
		this.displayCriteria = new Map<string, Set<string>>();
		const currentRecords = this.searchRecords.filter(
			p =>
				// tslint:disable-next-line:triple-equals
				p.whoHasFlag == this.whoHasFlag && p.value && p.value !== ""
		);
		// console.debug(
		// 	"REQUIRED::FilterDisplayComponent::prepareCriteria:: criteria:",
		// 	this.whoHasFlag,
		// 	currentRecords
		// );

		for (let idx = 0; currentRecords && idx < currentRecords.length; idx++) {
			const field: SearchField = currentRecords[idx];

			switch (field.componentType) {
				case ComponentType.DROPDOWN:
					this.prepareDropDown(field);
					break;
				case ComponentType.TYPEAHEAD_TEXTBOX:
					this.prepareTypeAhead(field);
					break;
				case ComponentType.NUMERIC_RANGE_FILTER:
					this.prepareNumberRange(field);
					break;
				case ComponentType.DATE_RANGE_FILTER:
					this.prepareDateRange(field);
					break;
				case ComponentType.INCLUDE_EXCLUDE:
					this.prepareIncludeExclude(field);
					break;
				case ComponentType.FREE_FORM_TEXT:
					this.prepareFreeForm(field);
					break;
				case ComponentType.RATING_RANGE:
					this.prepareRatingRangeList(field);
					break;
				case ComponentType.TENOR_RANGE:
					this.prepareTerm(field);
					break;
				case ComponentType.MULTI_INCLUDE_EXCLUDE:
					this.prepareMultiIncludeExclude(field);
					break;
			}
		}
		// console.debug('REQUIRED::FilterDisplayComponent::prepareCriteria:: Final Result::',this.displayCriteria);
	}
	private prepareFreeForm(field: SearchField): void {
		if (field.value) {
			const freeForm = this.prepareNewSet(field.name);
			// console.debug("FilterDisplayComponent::prepareFreeForm::",field.value;
			freeForm.add(field.value);
		}
	}
	private prepareDropDown(field: SearchField): void {
		if (field.value) {
			const dropdown = this.prepareNewSet(field.name);
			// console.debug("FilterDisplayComponent::prepareDropDown::",field.value;
			field.value.forEach(element => {
				dropdown.add(element.value);
			});
		}
	}

	private prepareTypeAhead(field: SearchField): void {
		if (field.value) {
			const typeAhead = this.prepareNewSet(field.name);
			field.value.forEach(element => {
				typeAhead.add(element.value);
			});
		}
	}

	private prepareIncludeExclude(field: SearchField): void {
		if (field.value) {
			const includeExcludeSet = this.prepareNewSet(field.name);
			const includeExclude: IncludeExcludeModel = field.value;
			let outStr;
			if (includeExclude.value && includeExclude.value.length > 0) {
				const str = includeExclude.value.map(f => f.value).join(", ");
				outStr =
					' <font style="color:black">' +
					this.formatData(includeExclude.operation, true) +
					" Values</font> [<b>" +
					str +
					"</b>]<br/><br/>";
			}
			if (includeExclude.butNotValue && includeExclude.butNotValue.length > 0) {
				const str = includeExclude.butNotValue.map(f => f.value).join(", ");
				outStr =
					outStr +
					'<font style="color:black"> BUT NOT Values</font> [<b>' +
					str +
					"</b>]";
			}
			if (outStr) {
				includeExcludeSet.add(outStr);
			}
		}
	}

	private prepareMultiIncludeExclude(field: SearchField): void {
		if (field.value) {
			// console.debug(
			// 	"FilterDisplayComponent::prepareMultiIncludeExclude::",
			// 	field.value
			// );
			const includeExcludeSet = this.prepareNewSet(field.name);
			const includeExcludeList: IncludeExcludeListModel = field.value;
			let outStr = "";
			if (includeExcludeList) {
				if (
					includeExcludeList.valueList &&
					includeExcludeList.valueList.length > 0
				) {
					includeExcludeList.valueList.forEach(element => {
						const includeExclude: IncludeExcludeModel = element;
						if (includeExclude.value && includeExclude.value.length > 0) {
							const str = includeExclude.value.map(f => f.value).join(", ");
							outStr =
								outStr +
								' <font style="color:black">' +
								this.formatData(includeExclude.operation, true) +
								" Values</font> [<b>" +
								str +
								"</b>]<br/>";
						}
						if (
							includeExclude.butNotValue &&
							includeExclude.butNotValue.length > 0
						) {
							const str = includeExclude.butNotValue
								.map(f => f.value)
								.join(", ");
							outStr =
								outStr +
								'<font style="color:black"> BUT NOT Values</font> [<b>' +
								str +
								"</b>]<br/><br/>";
						}
					});
					if (outStr) {
						includeExcludeSet.add(outStr);
					}
				}
			}
		}
	}

	private prepareRatingRangeList(field: SearchField): void {
		// console.debug(
		// 	"FilterDisplayComponent::prepareRatingRangeList::",
		// 	field.value
		// );
		if (field.value) {
			const ratingRangeWrapper: RatingRangeListWrapperModel = field.value;
			let outStr1: string;
			let outStr2: string;
			let outStrComp: string;
			if (ratingRangeWrapper.inValueList) {
				outStr1 = this.parepareInValueOrNotInValue(
					outStr1,
					ratingRangeWrapper.inValueList
				);
			}
			if (ratingRangeWrapper.notInValueList) {
				outStr2 = this.parepareInValueOrNotInValue(
					outStr2,
					ratingRangeWrapper.notInValueList
				);
			}
			outStrComp =
				(outStr1 !== undefined ? outStr1 : "") +
				(outStr2 !== undefined ? outStr2 : "");
			if (outStrComp) {
				const rartingRangeList = this.prepareNewSet(field.name);
				rartingRangeList.add(outStrComp);
			}
		}
	}

	private parepareInValueOrNotInValue(
		outStr: string,
		ratingRange: RatingRangeListModel
	): string {
		let operationForList: string = "";
		for (const rangeModel of ratingRange.valueList) {
			if (rangeModel.agencyName || rangeModel.period || rangeModel.value) {
				operationForList = "<div> ";
			}
			if (
				rangeModel.operation === OPERATOR.AND &&
				(rangeModel.agencyName || rangeModel.period || rangeModel.value)
			) {
				operationForList =
					operationForList +
					"<span class='rating-list-name'> AND LIST :</span><br/>";
				break;
			}
			if (
				rangeModel.operation === OPERATOR.OR &&
				(rangeModel.agencyName || rangeModel.period || rangeModel.value)
			) {
				operationForList =
					operationForList +
					"<span class='rating-list-name'> OR LIST :</span><br/>";
				break;
			}
			if (
				rangeModel.operation === OPERATOR.BUT_NOT &&
				(rangeModel.agencyName || rangeModel.period || rangeModel.value)
			) {
				operationForList =
					operationForList +
					"<span class='rating-list-name'> BUT NOT LIST :</span><br/>";
				break;
			}
			operationForList =
				operationForList !== "" ? operationForList + "</div>" : "";
		}
		outStr = (outStr !== undefined ? outStr + "<br/>" : "") + operationForList;

		for (const rangeModel of ratingRange.valueList) {
			if (rangeModel.agencyName || rangeModel.period || rangeModel.value) {
				outStr = outStr + "<div><table>";
				if (rangeModel.agencyName) {
					outStr =
						outStr +
						"<tr><td>Agency Name :  </td> <td>" +
						this.formatData(rangeModel.agencyName, true) +
						"</td></tr>";
				}

				if (rangeModel.period) {
					outStr =
						outStr +
						"<tr><td>Period :  </td> <td>" +
						this.formatData(rangeModel.period, true) +
						"</td></tr>";
				}

				if (
					rangeModel.value &&
					(rangeModel.value.start || rangeModel.value.end)
				) {
					outStr = outStr + "<tr><td>Range :  </td><td>[";

					if (rangeModel.value.start) {
						outStr = outStr + "Start:" + rangeModel.value.start.value;
					}

					if (rangeModel.value.end) {
						outStr = outStr + "End:" + rangeModel.value.end.value;
					}

					outStr = outStr + "]" + "</td></tr>";
				}
				outStr = outStr + "</table></div> \n";
			}
		}

		return outStr;
	}

	private prepareNumberRange(field: SearchField): void {
		if (field.value) {
			const numberRange = this.prepareNewSet(field.name);
			const range: RangeValue<number> = field.value;
			let outStr;
			if (range.start) {
				outStr = "From [" + range.start + "] ";
			}
			if (range.end) {
				if (outStr) {
					outStr = outStr + " till [" + range.end + "]";
				} else {
					outStr = " All matching record below this [" + range.end + "]";
				}
			} else {
				outStr = outStr + " till all highest record.";
			}
			numberRange.add(outStr);
		}
	}

	private prepareDateRange(field: SearchField): void {
		if (field.value) {
			const numberRange = this.prepareNewSet(field.name);
			const range: RangeValue<Date> = field.value;
			let outStr;
			if (range.start) {
				outStr = "From [" + this.datePipe.transform(range.start) + "] ";
			}
			if (range.end) {
				if (outStr) {
					outStr =
						outStr + " till [" + this.datePipe.transform(range.end) + "] dates";
				} else {
					outStr = " All matching record before this [" + range.end + "] date";
				}
			} else {
				outStr = outStr + " till max date.";
			}
			numberRange.add(outStr);
		}
	}

	private prepareTerm(field: SearchField): void {
		// console.debug("FilterDisplayComponent::prepareTerm::", field);
		if (field.value) {
			const tenorRangeSet = this.prepareNewSet(field.name);
			const tenorRangeList: RangeWrapperModel<any> = field.value;
			if (tenorRangeList) {
				const tenorRangeInValue: TenorRangeModel<any> = tenorRangeList.inValue;
				const tenorRangeNotInValue: TenorRangeModel<any> =
					tenorRangeList.notInValue;
				let outStr = "";
				if (tenorRangeInValue) {
					if (
						tenorRangeInValue.rangeValue &&
						(tenorRangeInValue.rangeValue.start ||
							tenorRangeInValue.rangeValue.end)
					) {
						outStr = " TERM IN: {";
						outStr = outStr + " Range: [";
						if (tenorRangeInValue.rangeValue.start) {
							outStr = outStr + "Start: " + tenorRangeInValue.rangeValue.start;
						}
						if (tenorRangeInValue.rangeValue.start) {
							outStr = outStr + " End: " + tenorRangeInValue.rangeValue.end;
						}
						outStr = outStr + "]";
					}
					if (
						tenorRangeInValue.period &&
						(tenorRangeInValue.period.key || tenorRangeInValue.period.value)
					) {
						outStr =
							outStr + " PERIOD: " + tenorRangeInValue.period.value + "}<br/>";
					}
				}
				// term not in values
				if (tenorRangeNotInValue) {
					if (
						tenorRangeNotInValue.rangeValue &&
						(tenorRangeNotInValue.rangeValue.start ||
							tenorRangeNotInValue.rangeValue.end)
					) {
						outStr = outStr + " TERM NOT IN: {";
						outStr = outStr + " Range: [";
						if (tenorRangeNotInValue.rangeValue.start) {
							outStr =
								outStr + "Start: " + tenorRangeNotInValue.rangeValue.start;
						}
						if (tenorRangeNotInValue.rangeValue.start) {
							outStr = outStr + " End: " + tenorRangeNotInValue.rangeValue.end;
						}
						outStr = outStr + "]";
					}
					if (
						tenorRangeNotInValue.period &&
						(tenorRangeNotInValue.period.key ||
							tenorRangeNotInValue.period.value)
					) {
						outStr =
							outStr + " PERIOD:  " + tenorRangeNotInValue.period.value + "}";
					}
				}

				tenorRangeSet.add(outStr);

				// console.debug(
				// 	"FilterDisplayComponent::prepareTerm::",
				// 	tenorRangeSet,
				// 	this.displayCriteria
				// );
			}
		}
	}

	private formatData(
		rec: string,
		isUpcase: boolean = false,
		skipCaseFormatting: boolean = false
	): string {
		return skipCaseFormatting
			? rec.toString()
			: isUpcase
			? this.upperCasePipe.transform(rec.toString())
			: this.titleCasePipe.transform(rec.toString());
	}
}
