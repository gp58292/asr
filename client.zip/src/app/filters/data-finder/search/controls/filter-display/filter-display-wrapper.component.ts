import { Component } from "@angular/core";

@Component({
	selector: "fiter-display-wrapper",
	template: `
		<div class="current-selection-container">
			<div class="who-container who-can-container">
				<div class="current-selection-label">
					<label>Contractual Eligibility Filters</label>
				</div>
				<derivz-filter-display
					class="current-seleciton-container"
				></derivz-filter-display>
			</div>
			<div class="who-container who-has-container">
				<div class="current-selection-label">
					<label>Actual Postings Filters</label>
				</div>
				<derivz-filter-display
					class="current-seleciton-container"
					whoHas="1"
				></derivz-filter-display>
			</div>
		</div>
	`,
	styles: [
		`
			:host {
				width: 100%;
				height: 100%;
				min-width: 0;
				display: flex;
			}
			.current-selection-container {
				display: flex;
				flex-direction: row;
				align-items: center;
			}
			.who-container {
				display: flex;
				flex: 1 1 auto;
				min-width: 20em;
				height: 100%;
				border: 0.03rem solid lightgray;
				flex-direction: column;
			}
			.current-selection-label {
				display: flex;
				width: 100%;
				//height:100%;
				background-color: #0f233e;
				color: white;
				justify-content: center;
				& > label {
					display: flex;
				}
			}
		`
	]
})
export class FilterDisplayWrapperComponent {}
