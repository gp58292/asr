import {
	ChangeDetectorRef,
	Component,
	Input,
	OnDestroy,
	OnInit
} from "@angular/core";
import { FormGroup } from "@angular/forms";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { ReferenceData } from "@aqua/filters/models";
import { SearchField } from "@aqua/filters/models/search-field";
import { Subject } from "rxjs";
import { takeUntil } from "rxjs/operators";

@Component({
	selector: "derivz-dropdown",
	templateUrl: "./dropdown.component.html",
	styleUrls: ["./dropdown.component.scss"]
	// changeDetection:ChangeDetectionStrategy.OnPush
})
export class DropdownComponent implements OnInit, OnDestroy {
	@Input("field") public field: SearchField;
	@Input() public form: FormGroup;
	public refernceData: ReferenceData[];

	private alive: Subject<void> = new Subject();

	constructor(
		private searchService: SearchService,
		private changeDetection: ChangeDetectorRef
	) {}

	public ngOnInit() {
		console.debug("DropdownComponent::ngOnInit");
		// this.changeDetection.detach();
		this.loadReferenceData();
	}

	public loadReferenceData() {
		console.debug("DropdownComponent::loadReferenceData", this.field);
		this.searchService
			.getReferenceData(this.field)
			.pipe(takeUntil(this.alive))
			.subscribe((response: any) => {
				this.refernceData = response;
				this.changeDetection.detectChanges();
				// this.changeDetection.markForCheck();
			});
	}
	public ngOnChanges(values) {
		console.debug(
			"DropdownComponent::ngOnChanges::",
			values,
			this.field,
			this.form
		);
		// this.changeDetection.detectChanges();
	}
	// ngAfterViewInit() {
	//   this.changeDetection.detectChanges();
	// }
	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}
}
