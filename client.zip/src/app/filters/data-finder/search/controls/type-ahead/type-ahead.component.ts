import { Component, Input, OnDestroy, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { Options } from "@aqua/aqua-component/models";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { SearchField } from "@aqua/filters/models/search-field";
import { empty, Subject } from "rxjs";
import {
	debounceTime,
	defaultIfEmpty,
	filter,
	finalize,
	switchMap,
	takeUntil
} from "rxjs/operators";

@Component({
	selector: "derivz-type-ahead",
	templateUrl: "./type-ahead.component.html",
	styleUrls: ["./type-ahead.component.scss"]
})
export class TypeAheadComponent implements OnInit, OnDestroy {
	@Input("field") public field: SearchField;
	@Input() public form: FormGroup;

	public options: any[] = [];
	public isPasting: boolean = false;

	public pasteProcessedData: { FOUND: Options[]; NOT_FOUND: Options[] };
	private textChange: Subject<string>;
	private alive: Subject<void> = new Subject();

	constructor(private searchService: SearchService) {}
	public ngOnInit() {
		this.textChange = new Subject<string>();
		this.monitorText();
	}

	public filterText(text: string) {
		// console.debug('TypeAheadComponent::filterText::' , text);
		this.textChange.next(text);
	}
	public pastedValues(pasteValues: string[]): void {
		console.debug("TypeAheadComponent::pastedValues::", pasteValues);
		this.textChange.next(undefined);
		// this.alive.next();
		this.isPasting = true;
		this.searchService
			.getTypeAheadDataByPastedValue(this.field, pasteValues)
			.pipe(
				takeUntil(this.alive),
				finalize(() => {
					this.isPasting = false;
				})
			)
			.subscribe(data => {
				this.pasteProcessedData = data;

				console.debug(
					"TypeAheadComponent::pastedValues:: Goto Data::",
					this.pasteProcessedData
				);
			});
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	private monitorText(): void {
		this.textChange
			.pipe(
				takeUntil(this.alive),
				filter(term => !this.isPasting),
				debounceTime(400),
				switchMap(term => {
					if (term != null && term !== "") {
						return this.searchService.getTypeAheadData(this.field, term);
					} else {
						return empty().pipe(defaultIfEmpty([]));
					}
				})
			)
			.subscribe(data => (this.options = data));
	}
}
