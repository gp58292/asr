import { SearchField } from "@aqua/filters/models";
import { CommonUtils } from "@aqua/util";

export class BookmarkRequest {
	public userId: string;
	public bookmarkId: number;
	public bookmarkData: any[];
	public bookmarkName: string;
	public parentBookmarkId: number;
	public isSilent: boolean = false;
	public isReload: boolean = false;
	public searchCriteria: SearchField[];

	public addSearchCriteria(fields: SearchField[]): void {
		this.searchCriteria = CommonUtils.deepClone(fields);
		this.bookmarkData = this.transformBookmarkState(this.searchCriteria);
	}

	public transformBookmarkState(list: SearchField[]): any[] {
		console.debug("BookmarkRequest::transformBookmarkState");
		return list.map(item => {
			if (
				item.value &&
				((item.value instanceof Array && item.value.length > 0) ||
					(item.value instanceof String && item.value.length > 0) ||
					item.value instanceof Object)
			) {
				return {
					key: item.key,
					value: item.value,
					whoHasFlag: item.whoHasFlag
				};
			} else {
				return { key: item.key, value: "", whoHasFlag: item.whoHasFlag };
			}
		});
	}
}
