import {
	Component,
	OnDestroy,
	OnInit,
	ChangeDetectionStrategy,
	ChangeDetectorRef
} from "@angular/core";
import { FormBuilder, FormControl, FormGroup } from "@angular/forms";
import { MatDialog } from "@angular/material";
import { Router } from "@angular/router";
import { SearchField } from "@aqua/filters/models/search-field";
import { AuthService, VizNotificationService } from "@aqua/services";
import { ConfirmationDialogComponent } from "app/filters/data-finder/confirmation-dialog/confirmation-dialog.component";
import { DataTreeStorageService } from "app/filters/services/datatree-storage.service";
import { Subject } from "rxjs";
import { debounceTime, distinctUntilChanged, takeUntil } from "rxjs/operators";

import { SettingsService } from "./settings.service";

@Component({
	selector: "aqua-settings",
	templateUrl: "./settings.component.html",
	styleUrls: ["./settings.component.scss"],
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class SettingsComponent implements OnInit, OnDestroy {
	public copyGroupMap: any[] = [];
	public tableNodes: any[] = [];
	public filterFieldSearch: string = "";
	public whoCanWhoHasToggleCtrl: FormControl = new FormControl("can");
	public filterControl: FormControl = new FormControl();

	public firstFormGroup: FormGroup;
	public secondFormGroup: FormGroup;

	public groupMap: any[] = [];

	private selectedFields: SearchField[] = [];
	private selectedFieldsKeys: string[] = [];
	private selectedGroupIndex = null;

	private filtering: boolean = false;

	private timeout: any;

	private alive: Subject<void> = new Subject();

	constructor(
		private router: Router,
		private searchSettingService: SettingsService,
		private dataTreeService: DataTreeStorageService,
		private vizNotification: VizNotificationService,
		private authService: AuthService,
		private formBuilder: FormBuilder,
		private dialog: MatDialog,
		private _changeDetectorRef: ChangeDetectorRef
	) {
		console.debug("SettingsComponent::constructor");
		this.selectedGroupIndex = 0;
		const me = this;
		this.dataTreeService
			.listenStateGroupTree()
			.pipe(
				takeUntil(this.alive),
				debounceTime(300)
			)
			.subscribe(response => {
				// 	console.debug("SettingsComponent::constructor subscriber", response);
				if (response) {
					me.copyGroupMap = response;
					// Apply filter on fields list since it was changed if filtering=true
					if (me.filtering) {
						me.filterItem();
					} else {
						me.groupMap = response;
						me.tableNodes = me.getFilteredGroup(
							me.groupMap,
							me.whoCanWhoHasToggleCtrl.value
						)[me.selectedGroupIndex].children;
						me._changeDetectorRef.markForCheck();
					}
				}
			});
		this.dataTreeService
			.listenForWhoHasWhoCanChanged()
			.pipe(takeUntil(this.alive))
			.subscribe(status => {
				this.whoCanWhoHasToggleCtrl.setValue(status);
				this._changeDetectorRef.markForCheck();
			});

		// ------------------ Search term change Set Component state and load data  ---------------
		// Bind search call to formControl
		this.filterControl.valueChanges
			.pipe(
				takeUntil(this.alive),
				debounceTime(300),
				distinctUntilChanged()
			)
			.subscribe(term => {
				console.debug(
					"SettingsSidePanelComponent::termvalue Events::searchTerm ",
					term
				);
				if (term !== undefined) {
					this.filterItem();
				}
			});
		// ------------------ Search term change Set Component state and load data  ---------------
	}

	public ngOnInit() {
		console.debug("SettingsComponent::ngOnInit");

		this.firstFormGroup = this.formBuilder.group({ firstCtrl: [""] });
		this.secondFormGroup = this.formBuilder.group({ secondCtrl: [""] });
		this.getUserSettings();
	}

	public onGroupClick(event, nodes, index) {
		console.debug(
			"SettingsComponent::onGroupClick",
			index,
			nodes,
			this.groupMap
		);
		this.selectedGroupIndex = index;

		// Filter selected nodes on group switch if filtering active.
		if (this.filtering) {
			this.filterItem();
		} else {
			this.tableNodes = nodes;
		}
	}

	public loadFieldsKeys(): void {
		console.debug("SettingsComponent:: loadFieldsKeys");
		if (this.selectedFields && this.selectedFields.length > 0) {
			for (const field of this.selectedFields) {
				this.selectedFieldsKeys.push(field.key + "");
			}
		}
	}

	public findIfSelected(field: SearchField): boolean {
		let checkedstatus = false;
		if (this.selectedFields && this.selectedFields.length > 0) {
			const indexOfField = this.selectedFields.findIndex(
				item => item.key === field.key
			);
			if (indexOfField > -1) {
				checkedstatus = true;
				field.selected = true;
			} else {
				checkedstatus = false;
				field.selected = false;
			}
		}
		return checkedstatus;
	}

	public saveUserSettings(): void {
		console.debug("SettingsComponent:: saveUserSettings");
		this.loadFieldsKeys();
		if (this.selectedFieldsKeys.length < 1) {
			this.vizNotification.showError("Please select at least one attribute");
			return;
		}
		const userSoeId = this.authService.getUserSoeId();
		const settingsName = "default";
		this.searchSettingService
			.saveUserSettings(userSoeId, settingsName, this.selectedFieldsKeys)
			.pipe(takeUntil(this.alive))
			.subscribe((response: any) => {
				if (response.responseStatus === "201") {
					this.vizNotification.showMessage(
						"Settings for user " + userSoeId + " saved successfully"
					);
					const href = this.router.url;
					if (href === "/datafinder") {
						this.router.navigate(["/acl/dashboard"]);
					} else {
						this.router.navigate(["/datafinder"]);
					}
				} else {
					this.vizNotification.showError(
						"Settings for user " + userSoeId + " not saved"
					);
				}
			});
	}

	public getUserSettings(): void {
		console.debug("SettingsComponent:: getUserSettings");
		const userSoeId = this.authService.getUserSoeId();
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	// TODO :: We need to split this method and push the common processing logic to service. We need to do some clean up for better maintainability
	// Code cleaned up. Please verify if it is more clear
	public filterItem() {
		console.debug("SettingsComponent::filterItem inputChange");

		// Get the selectedIndex
		this.selectedGroupIndex = this.selectedGroupIndex
			? this.selectedGroupIndex
			: 0;
		this.filtering = true;
		// If value in input is empty , filtering=false;
		if (this.filterFieldSearch.length === 0) {
			this.filtering = false;
			this.tableNodes = this.groupMap[this.selectedGroupIndex]
				? this.groupMap[this.selectedGroupIndex].children
				: undefined;
			return;
		}

		if (this.timeout) {
			clearTimeout(this.timeout);
		}

		this.timeout = setTimeout(() => {
			console.debug("SettingsComponent::filterItem inputChange setTimeout");

			// Filter only selected node
			const treeD = this.copyGroupMap[this.selectedGroupIndex].children;

			const filteredTreeResult: any[] = [];
			this.dataTreeService.treeIterator(
				this.filterFieldSearch,
				treeD,
				"",
				filteredTreeResult,
				"grouped"
			);

			// If search criteria is blank set TableNodes to original value.
			if (this.filterFieldSearch.length === 0) {
				this.tableNodes = this.copyGroupMap[this.selectedGroupIndex].children;
			} else {
				// Else set the table nodes to the filtered results;
				this.tableNodes = filteredTreeResult;
			}
		}, 300);
	}

	public onClear() {
		console.debug("SettingsComponent::onClear");
		// Confirm dialog
		const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
			data: { confirmationMessage: "Clear All Filters?" }
		});

		dialogRef
			.afterClosed()
			.pipe(takeUntil(this.alive))
			.subscribe(confirmed => {
				// console.debug("The dialog was closed, user has selected:" + confirmed);
				if (!confirmed) {
					return;
				} else {
					this.dataTreeService.clearAllFilters();
				}
			});
	}
	public whoCanHasToggleChange(event) {
		console.debug("SettingsComponent::whoCanHasToggleChange", event);
		if (event.value === "has") {
			this.getTreeByWhoCanWhoHas("has");
		} else if (event.value === "can") {
			this.getTreeByWhoCanWhoHas("can");
		}
		this.selectedGroupIndex = 0;
	}

	public getTreeByWhoCanWhoHas(type: "can" | "has") {
		console.debug("SettingsComponent::getTreeByWhoCanWhoHas");
		this.dataTreeService.toggleWhoCanWhoHasTree(type);
	}
	// Checks that nodes are present because some nodes may be hidden due to who can/who has toggle
	public checkWhoHasWhoCanChildNodesPresent(nodes) {
		// console.debug("SettingsComponent::checkWhoHasWhoCanChildNodesPresent",this.whoCanWhoHasToggleCtrl.value);
		if (this.whoCanWhoHasToggleCtrl.value === "can") {
			return true;
		} else if (this.whoCanWhoHasToggleCtrl.value === "has") {
			if (
				nodes.children.find(field => {
					return field.whoHasFlag === 1;
				})
			) {
				return true;
			}
			return false;
		}
	}
	public getViewAbleChildrenCount(nodes) {
		// if (this.whoCanWhoHasToggleCtrl.value === "can")
		//   return nodes.children.length;
		if (this.whoCanWhoHasToggleCtrl.value === "can") {
			return nodes.children.filter(field => {
				if (field.filterOnlyFlag === 1) {
					return field.whoHasFlag === 1;
				} else {
					return true;
				}
			}).length;
		} else if (this.whoCanWhoHasToggleCtrl.value === "has") {
			return nodes.children.filter(field => {
				return field.whoHasFlag === 1;
			}).length;
		}
	}

	public getFilteredGroup(groups: any[], value: string): any[] {
		return groups.filter(
			group =>
				((group.name !== "Current Posting" && value === "can") ||
					value !== "can") &&
				this.checkAnyChilds(group)
		);
	}

	public checkAnyChilds(records: any): boolean {
		let returnFlag: boolean;

		if (records && "children" in records) {
			if (records.children.length > 0) {
				let count: number = 0;
				// tslint:disable-next-line:prefer-for-of
				for (let i = 0; i < records.children.length; i++) {
					returnFlag = this.checkAnyChilds(records.children[i]);
					if (!returnFlag) {
						count++;
					}
				}
				// console.debug(
				// 	"SettingsComponent::getFilteredGroup::Macthing::",
				// 	count,
				// 	records.children.length,
				// 	count === records.children.length,
				// 	records.name
				// );
				if (count === records.children.length) {
					return false;
				} else {
					return true;
				}
			} else {
				returnFlag = false;
			}
			return returnFlag;
		} else {
			return true;
		}
	}

	public onFilter(field) {
		// console.debug("SettingsComponent::onFilter", field);
		// Use service to update node
		this.dataTreeService.updateNode(field, "filter");
	}
}
