import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { AppPanelLayoutComponent } from "./app-panel-layout.component";

describe("AppPanelLayoutComponent", () => {
	let component: AppPanelLayoutComponent;
	let fixture: ComponentFixture<AppPanelLayoutComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [AppPanelLayoutComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(AppPanelLayoutComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
