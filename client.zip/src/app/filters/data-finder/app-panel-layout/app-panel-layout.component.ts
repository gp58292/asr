import { Component, OnInit } from "@angular/core";

@Component({
	selector: "app-panel-layout",
	templateUrl: "./app-panel-layout.component.html",
	styleUrls: ["./app-panel-layout.component.scss"]
})
export class AppPanelLayoutComponent implements OnInit {
	public fieldsStage: string = "normal";
	public extraTreeStage: string = "shrunk";
	public extraTreeIcon: string = "keyboard_arrow_right";

	private normalTreeIcon: string = "keyboard_arrow_left";

	// -------------------------------------------------------------------------------------------------------------------
	constructor() {
		console.debug("AppPanelLayoutComponent::constructor");
	}

	public ngOnInit() {
		console.debug("AppPanelLayoutComponent::ngOnInit");
	}
	public ngAfterViewInit() {
		console.debug("AppPanelLayoutComponent::ngAfterViewInit");
	}
	public ngOnDestroy() {
		console.debug("AppPanelLayoutComponent::ngOnDestroy");
	}

	// [TODO] :: Can we extact this funcationality to common component
	public toggleSideBarStage(container: string) {
		console.debug("AppPanelLayoutComponent::toggleSideBarStage", container);

		if (container === "normalTree") {
			this.fieldsStage = this.fieldsStage === "normal" ? "shrunk" : "normal";

			this.normalTreeIcon =
				this.normalTreeIcon === "keyboard_arrow_left"
					? "keyboard_arrow_right"
					: "keyboard_arrow_left";
		} else if (container === "extraTree") {
			this.extraTreeStage =
				this.extraTreeStage === "shrunk" ? "expanded" : "shrunk";
			this.extraTreeIcon =
				this.extraTreeIcon === "keyboard_arrow_left"
					? "keyboard_arrow_right"
					: "keyboard_arrow_left";
		}
	}
}
