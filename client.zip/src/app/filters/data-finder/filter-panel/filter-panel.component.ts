import { Component, OnInit } from "@angular/core";
import { FormControl } from "@angular/forms";
import { FilterDisplayService } from "@aqua/filters/data-finder/search/controls/filter-display";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { UserDataset } from "@aqua/filters/models";
import { VizNotificationService } from "@aqua/services";
import { Subject } from "rxjs";
import { finalize, takeUntil } from "rxjs/operators";

import { BookmarkService } from "../bookmark";

@Component({
	selector: "filter-panel",
	templateUrl: "./filter-panel.component.html",
	styleUrls: ["./filter-panel.component.scss"]
})
export class FilterPanelComponent implements OnInit {
	public resultsExpanded: boolean = true;
	public filtersExpanded: boolean = true;
	public resultSetCount: number;
	public titleToggleCtrl: FormControl = new FormControl("can");
	public voyagerNavigationLinks: string[] = ["", "", "", "", "", ""];
	public datasetTypes: string[] = [
		"curr_post",
		"capac",
		"fmtm",
		"hmtm",
		"gsst",
		"frtb"
	];

	public location: string;

	public activeTab: string;
	public cobDate: string;
	// All form inputs feilds required variable, data and methods start here

	public voyagerServerUrl: string;
	public userDatasets: UserDataset[] = [];
	public userDatasetsSrc: UserDataset[] = [];
	public isFiltered: boolean = false;
	public isLoadingDataSets: boolean = false;
	private alive: Subject<void> = new Subject();

	// -------------------------------------------------------------------------------------------------------------------
	constructor(
		private searchService: SearchService,
		private bookmarkService: BookmarkService,
		private filterDisplayService: FilterDisplayService,
		private vizNotification: VizNotificationService
	) {
		console.debug("FilterPanelComponent::constructor");
	}

	public ngOnInit() {
		console.debug("FilterPanelComponent::ngOnInit");
		this.titleToggleCtrl.setValue("can");
		this.resultChangeListener();
		this.filterFlagChangeListener();
	}
	public ngAfterViewInit() {
		console.debug("FilterPanelComponent::ngAfterViewInit");
	}

	public tabChanged(tabName: string): void {
		console.debug("FilterPanelComponent::tabChanged::", tabName);
		this.activeTab = tabName;
	}

	public determineSelectedTab(tabSelected) {
		console.debug("FilterPanelComponent::determineSelectedTab", tabSelected);
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	public expandShrinkPanel(panel: string) {
		console.debug("FilterPanelComponent::expandShrinkPanel");

		if (panel === "filters") {
			this.filtersExpanded = !this.filtersExpanded;
		} else if (panel === "results") {
			this.resultsExpanded = !this.resultsExpanded;
		}
		console.debug(
			"FilterPanelComponent::expandShrinkPanel",
			this.resultsExpanded
		);
	}

	public getExpandShrinkIcon(type: string) {
		if ("filters" === type) {
			return this.filtersExpanded ? "keyboard_arrow_up" : "keyboard_arrow_down";
		} else if ("results" === type) {
			// return (((!this.resultsExpanded && !this.filtersExpanded)) || (((this.resultsExpanded && this.filtersExpanded)) ) )? 'keyboard_arrow_down' :  'keyboard_arrow_up' ;
			return this.resultsExpanded ? "keyboard_arrow_down" : "keyboard_arrow_up";
		}
	}

	public onNavigate(link: string) {
		console.debug(
			"session storage soeid:",
			link,
			sessionStorage.getItem("userParams_soeid")
		);
		window.open(link, "_blank");
	}

	public pullDataSetId(): void {
		console.debug("FilterPanelComponent::pullDataSetId::");
		this.userDatasets = [];
		this.configureVoyagerNavigationUrl();
	}

	private resultChangeListener(): void {
		this.searchService
			.searchResultChangeNotification()
			.pipe(takeUntil(this.alive))
			.subscribe((result: any) => {
				console.debug(
					"FilterPanelComponent::resultChangeListener::Got new result::",
					result
				);
				if (result != null) {
					this.resultSetCount = result ? result.count : 0;
					this.cobDate = result.cobDate;
					this.searchService.batchReportDate = this.cobDate;
				} else {
					this.resultSetCount = 0;
				}
				this.userDatasets = [];

				// Configure the new Voyager links
			});
	}

	private filterFlagChangeListener(): void {
		this.searchService
			.filterFlagChangeNotification()
			.pipe(takeUntil(this.alive))
			.subscribe(flag => {
				this.isFiltered = flag;
				if (this.userDatasetsSrc) {
					if (flag) {
						this.userDatasets = this.userDatasetsSrc.filter(tab => {
							console.debug(
								"SearchResultComponent::listenResultDataChange::If" +
									tab.shortName
							);
							const name = tab.shortName + "";
							return name !== "curr_post";
						});
					} else {
						this.userDatasets = this.userDatasetsSrc.filter(tab => {
							console.debug(
								"SearchResultComponent::listenResultDataChange::else::" +
									tab.shortName
							);
							const name = tab.shortName + "";
							return name !== "curr_post_filtered";
						});
					}
				}
			});
	}

	// private configureVoyagerNavigationLinks() {
	// 	console.debug("FilterPanelComponent::configureVoyagerNavigationLinks");
	// 	this.voyagerNavigationLinks = [];
	// 	for (const type of this.datasetTypes) {
	// 		this.searchService
	// 			.getDatasetId(sessionStorage.getItem("userParams_soeid"), type)
	// 			.pipe(takeUntil(this.alive))
	// 			.subscribe(resp => {
	// 				console.debug(
	// 					"FilterPanelComponent::configureVoyagerNavigationLinks dataset URL link " +
	// 						resp
	// 				);
	// 				const mappedIndex: number = this.datasetTypes.findIndex(obj => {
	// 					return obj === type;
	// 				});
	// 				if (resp.responseStatus === 404) {
	// 					this.vizNotification.showError(resp.message);
	// 					this.voyagerNavigationLinks[mappedIndex] = "-1";
	// 				} else if (resp.responseData.datasetId === -1) {
	// 					this.vizNotification.showError(
	// 						"Unable to get datasetid for " +
	// 							type +
	// 							" dataset type.Cannot navigate to Voyager."
	// 					);
	// 					this.voyagerNavigationLinks[mappedIndex] = "-1";
	// 				} else {
	// 					// this.vizNotification.showMessage("Found datasetid for " + type + " dataset type.");
	// 					console.debug(
	// 						"FilterPanelComponent::configureVoyagerNavigationLinks ",
	// 						resp.message
	// 					);
	// 					this.voyagerNavigationLinks[mappedIndex] =
	// 						"http://" + resp.responseData.navigationLink;
	// 				}
	// 			});
	// 	}
	// }

	private configureVoyagerNavigationUrl() {
		console.debug("FilterPanelComponent::configureVoyagerNavigationUrl");
		this.userDatasets = [];
		this.isLoadingDataSets = true;
		this.searchService
			.getUserDataset()
			.pipe(
				takeUntil(this.alive),
				finalize(() => (this.isLoadingDataSets = false))
			)
			.subscribe(resp => {
				if (resp.responseStatus !== 404 && resp.responseData) {
					this.userDatasetsSrc = resp.responseData;
					this.userDatasets = this.userDatasetsSrc;
					if (this.isFiltered) {
						this.userDatasets = this.userDatasetsSrc.filter(tab => {
							console.debug("if" + tab.shortName);
							const name = tab.shortName + "";
							return name !== "curr_post";
						});
					} else {
						this.userDatasets = this.userDatasetsSrc.filter(tab => {
							console.debug("else::" + tab.shortName);
							const name = tab.shortName + "";
							return name !== "curr_post_filtered";
						});
					}
				} else {
					this.vizNotification.showError(
						"Unable to get datasets for user " +
							sessionStorage.getItem("userParams_soeid")
					);
				}
			});
	}
}
