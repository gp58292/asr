import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatButtonToggleModule } from "@angular/material/button-toggle";
import { MatSlideToggleModule } from "@angular/material/slide-toggle";
import { MaterialModule } from "@aqua/material.module";

import { AquaComponentModule } from "@aqua/aqua-component/aqua-component.module";
import { PipeModule } from "@aqua/aqua-component/pipes";
import { TreeStructComponent } from "@aqua/treestruct/treestruct.component";

import { FiltersRoutingModule } from "@aqua/filters/filters.routing";

import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { SettingsService } from "@aqua/filters/data-finder/settings/settings.service";
import { DataTreeStorageService } from "@aqua/filters/services/datatree-storage.service";
import { FiltersUrlConfig } from "@aqua/filters/services/filters-url-config.service";

import { BookmarkComponent } from "@aqua/filters/data-finder/bookmark/bookmark.component";
import { DataFinderComponent } from "@aqua/filters/data-finder/data-finder.component";
import { FilterPanelComponent } from "@aqua/filters/data-finder/filter-panel/filter-panel.component";
import { SearchComponent } from "@aqua/filters/data-finder/search/search.component";
import { SettingsSidePanelComponent } from "@aqua/filters/data-finder/settings-side-panel/settings-side-panel.component";
import { SettingsComponent } from "@aqua/filters/data-finder/settings/settings.component";

import { DialogSaveAsComponent } from "@aqua/filters/data-finder/bookmark/dialog-save-as/dialog-save-as.component";
import { ConfirmationDialogComponent } from "@aqua/filters/data-finder/confirmation-dialog/confirmation-dialog.component";
import { DateRangeComponent } from "@aqua/filters/data-finder/search/controls/date-range/date-range.component";
import { DropdownComponent } from "@aqua/filters/data-finder/search/controls/dropdown/dropdown.component";
import { FreeFormTextComponent } from "@aqua/filters/data-finder/search/controls/free-form-text/free-form-text.component";
import { IncludeExcludeComponent } from "@aqua/filters/data-finder/search/controls/include-exclude/include-exclude.component";
import { NumberRangeComponent } from "@aqua/filters/data-finder/search/controls/number-range/number-range.component";
import { TypeAheadComponent } from "@aqua/filters/data-finder/search/controls/type-ahead/type-ahead.component";
import { SearchResultComponent } from "@aqua/filters/data-finder/search/search-result/search-result.component";

import {
	MatPaginatorModule,
	MatSortModule,
	MatTableModule
} from "@angular/material";
import { PopupModule } from "@aqua/aqua-component/popup";
import { AppPanelLayoutComponent } from "@aqua/filters/data-finder/app-panel-layout/app-panel-layout.component";
import {
	FilterDisplayService,
	FilterDisplayWrapperComponent
} from "@aqua/filters/data-finder/search/controls/filter-display";
import { FilterDisplayComponent } from "@aqua/filters/data-finder/search/controls/filter-display/filter-display.component";
import { RatingRankingComponent } from "@aqua/filters/data-finder/search/controls/rating-ranking/rating-ranking.component";
import { TenorRangeComponent } from "@aqua/filters/data-finder/search/controls/tenor-range-wrapper/tenor-range-wrapper.component";
import {
	AggrementPopinComponent,
	MasterAgreementDetailsComponent
} from "@aqua/filters/data-finder/search/search-result/filter-popin";
import {
	FilterCancelService,
	SearchResultColumnService
} from "@aqua/filters/services";
import { CollateralTypeLookupComponent } from "./data-finder/search/collateral-type-lookup/collateral-type-lookup.component";
import { CsaAgreementDetailsComponent } from "./data-finder/search/search-result/filter-popin/csa-agreement-details/csa-agreement-details.component";

import { BatchReportComponent } from "@aqua/batch-report/batch-report.component";

import { TenorRangeInNotInWrapperModule } from "@aqua/aqua-component/tenor-range-innotin-wrapper";
import { BookmarkService } from "./data-finder/bookmark";
import { MultiIncludeExcludeComponent } from "./data-finder/search/controls/multi-include-exclude/multi-include-exclude.component";

@NgModule({
	imports: [
		CommonModule,
		FiltersRoutingModule,
		MaterialModule,
		FormsModule,
		MatSlideToggleModule,
		MatButtonToggleModule,
		ReactiveFormsModule,
		AquaComponentModule,
		PipeModule,
		MatTableModule,
		MatSortModule,
		MatPaginatorModule,
		PopupModule,
		TenorRangeInNotInWrapperModule
	],
	entryComponents: [
		DialogSaveAsComponent,
		ConfirmationDialogComponent,
		CollateralTypeLookupComponent,
		AggrementPopinComponent,
		BatchReportComponent
	],
	declarations: [
		SettingsComponent,
		SearchComponent,
		SettingsSidePanelComponent,
		FilterPanelComponent,
		TypeAheadComponent,
		TreeStructComponent,
		AppPanelLayoutComponent,
		DataFinderComponent,
		DropdownComponent,
		NumberRangeComponent,
		DateRangeComponent,
		FreeFormTextComponent,
		BookmarkComponent,
		IncludeExcludeComponent,
		SearchResultComponent,
		DialogSaveAsComponent,
		ConfirmationDialogComponent,
		FilterDisplayComponent,
		FilterDisplayWrapperComponent,
		CollateralTypeLookupComponent,
		AggrementPopinComponent,
		RatingRankingComponent,
		TenorRangeComponent,
		MasterAgreementDetailsComponent,
		CsaAgreementDetailsComponent,
		BatchReportComponent,
		MultiIncludeExcludeComponent
	],
	exports: [],
	providers: [
		FiltersUrlConfig,
		SearchResultColumnService,
		SearchService,
		SettingsService,
		DataTreeStorageService,
		FilterDisplayService,
	FilterCancelService,
	BookmarkService
	]
})
export class FiltersModule {}
