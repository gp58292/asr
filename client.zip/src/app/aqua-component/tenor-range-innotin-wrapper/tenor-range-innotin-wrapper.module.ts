import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
	MatButtonToggleModule,
	MatFormFieldModule,
	MatOptionModule,
	MatSelectModule
} from "@angular/material";
import { TenorRangeModule } from "../tenor-range";
import { TenorRangeInNotInWrapper } from "./tenor-range-innotin-wrapper";

@NgModule({
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatFormFieldModule,
		MatButtonToggleModule,
		MatOptionModule,
		MatSelectModule,
		TenorRangeModule
	],
	exports: [TenorRangeInNotInWrapper],
	declarations: [TenorRangeInNotInWrapper]
})
export class TenorRangeInNotInWrapperModule {}
