import {
	FieldNames,
	SearchField,
	SearchResultColumns
} from "@aqua/filters/models";
import * as moment from "moment";

import { CommonExcelStyleRule } from "../excel-styles";
import { NumericExcelStyleRule } from "../excel-styles/numeric.excel-styles";
import { ColumnsDefinationGrid } from "../model/columns-definations.grid";
import { HyperlinkRenderer, NumberRenderer } from "./../inline-cell-renderer";

export class GridUtils {
	// This is absoulte method, don't use, use buildColumns2
	public static buildColumns(
		displayColumns: SearchField[] | ColumnsDefinationGrid[],
		isDefaultSelectedLogic: boolean = false
	): ColumnsDefinationGrid[] {
		const columnsList: ColumnsDefinationGrid[] = [];
		if (displayColumns && displayColumns.length > 0) {
			for (let field of displayColumns) {
				let columnsDef: ColumnsDefinationGrid;
				if (field instanceof ColumnsDefinationGrid) {
					columnsDef = { ...field };
				} else {
					columnsDef = new ColumnsDefinationGrid(field.name, field.fieldName);
				}

				columnsDef = Object.assign(columnsDef, field);
				if (isDefaultSelectedLogic) {
					field = field as SearchField;
					columnsDef.hide =
						field.defaultSelected && field.defaultSelected === 1 ? false : true;
				}

				if (field.dataType === "NUMERIC") {
					columnsDef.type = "numericColumn";
					columnsDef.cellRendererFramework = NumberRenderer;
					columnsDef.cellClassRules = NumericExcelStyleRule;
				}
				if (field.dataType && field.dataType.toUpperCase() === "STRING") {
					// columnsDef.cellRendererFramework = TooltipRenderer;
					columnsDef.tooltipValueGetter = GridUtils.tooltip;
				}
				columnsList.push(columnsDef);
			}
		}
		// console.debug(
		// 	"GridUtils::buildColumns::",
		// 	isDefaultSelectedLogic,
		// 	columnsList[0],
		// 	columnsList[0].hide
		// );
		return columnsList;
	}

	public static buildColumns2(
		resultColumnsList: SearchResultColumns[],
		isIgnoreDefaultDisplay: boolean = false
	): ColumnsDefinationGrid[] {
		const columnsList: ColumnsDefinationGrid[] = [];
		if (resultColumnsList && resultColumnsList.length > 0) {
			for (const resultColumn of resultColumnsList) {
				const columnsDef: ColumnsDefinationGrid = new ColumnsDefinationGrid(
					resultColumn.displayName,
					resultColumn.fieldName
				);
				if (!isIgnoreDefaultDisplay) {
					columnsDef.hide = !resultColumn.isDefaultDisplay;
				}

				if (
					resultColumn.fieldType === "NUMERIC" ||
					resultColumn.fieldType === "DOUBLE"
				) {
					columnsDef.type = "numericColumn";
					columnsDef.cellRendererFramework = NumberRenderer;
					columnsDef.cellClassRules = NumericExcelStyleRule;
					// cellRendererFramework: NumberRenderer,
					// cellClassRules: NumericExcelStyleRule
				}
				if (resultColumn.fieldType === "STRING") {
					// columnsDef.cellRendererFramework = TooltipRenderer;
					columnsDef.tooltipValueGetter = GridUtils.tooltip;
				}
				// This codes need to be moved outside, as this is very specfic application
				if (FieldNames.AGREEMENT_ID === resultColumn.fieldName) {
					columnsDef.cellRendererFramework = HyperlinkRenderer;
				}

				// Common excel export styles are like font size , color etc
				columnsDef.cellClassRules = columnsDef.cellClassRules
					? { ...CommonExcelStyleRule, ...columnsDef.cellClassRules }
					: CommonExcelStyleRule;

				columnsList.push(columnsDef);
			}
		}
		return columnsList;
	}

	public static mergeColumnsIfNotExistOtherwiseIgnore(
		source: SearchResultColumns[],
		dest: SearchResultColumns[]
	): SearchResultColumns[] {
		const finalColumns: SearchResultColumns[] = [];
		for (const resultColumn of source) {
			if (!GridUtils.checkColumnExist(resultColumn.fieldName, dest)) {
				finalColumns.push(resultColumn);
			}
			// else {
			// 	finalColumns.push(foundColumn);
			// 	dest.splice(dest.indexOf(foundColumn), 1);
			// }
		}
		return [...finalColumns, ...dest];
	}

	public static checkColumnExist(
		fieldName: string,
		dest: SearchResultColumns[]
	): boolean {
		const foundColumn = dest.find(
			(col: SearchResultColumns) => col.fieldName === fieldName
		);
		return foundColumn ? true : false;
	}

	public static tooltip(data: any): string {
		return data.value;
	}

	public static getDefaultExcelExportParam(name: string): any {
		return {
			defaultExportParams: {
				fileName:
					name + " exported on " + moment().format("Do MMMM YYYY h:mm a"),
				sheetName: name
			}
		};
	}
}
