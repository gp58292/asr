import { Component } from "@angular/core";
import { FilterCancelService } from "@aqua/filters/services";
import { ILoadingOverlayAngularComp } from "ag-grid-angular";

@Component({
	selector: "aqua-grid-loading-overlay",
	template: `
		<aqua-spinner
			isCancel="true"
			(cancel)="spinnerCancelled($event, 'Listed')"
			style="margin:0 auto;top:30%; pointer-events:all; cursor:pointer;"
		></aqua-spinner>
	`,
	styles: [
		`
			:host {
				display: flex;
				flex-direction: column;
				height: auto;
				width: auto;
			}
		`
	]
})
export class CustomLoadingOverlay implements ILoadingOverlayAngularComp {
	constructor(private filterCancelService: FilterCancelService) {}
	public getGui(): HTMLElement {
		throw new Error("Method not implemented.");
	}
	// tslint:disable-next-line:no-empty
	public agInit(): void {}

	public spinnerCancelled(event: Event, name?: string) {
		console.debug("AquaGrid::spinnerCancelled::", event, name);
		this.filterCancelService.cancelSubject();
	}
}
