import { Component, OnInit } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
	selector: "aqua-tooltip-renderer",
	template: `
		<span [title]="params.value">{{ params.value }}</span>
	`,
	styleUrls: ["./tooltip-renderer.scss"]
})
export class TooltipRenderer implements ICellRendererAngularComp {
	public params: any;
	public agInit(params: any): void {
		this.params = params;
	}

	public refresh(): boolean {
		return false;
	}
}
