// tslint:disable-next-line:variable-name
export const NumericExcelStyles: any = [
	{
		id: "redFont",
		font: {
			color: "#ff0000"
		}
	},
	{
		id: "NumberFormat",
		numberFormat: { format: "_(* #,##0_);_(* (#,##0);_(@_)" }
	}
];

// tslint:disable-next-line:variable-name
export const NumericExcelStyleRule: any = {
	redFont(params) {
		return params.value < 0;
	},
	NumberFormat(params) {
		return true;
	}
};
