// tslint:disable-next-line:variable-name
export const CommonExcelStyles: any = [
	{
		id: "fontsize",
		font: {
			fontName: "Calibri",
			color: "#000",
			size: 11
		}
	},
	{
		id: "header",
		alignment: {
			horizontal: "Center",
			vertical: "Center"
		},
		font: {
			fontName: "Calibri",
			color: "#000",
			size: 11
		}
	}
];

// tslint:disable-next-line:variable-name
export const CommonExcelStyleRule: any = {
	fontsize(params) {
		return true;
	}
};
