export class ColumnsDefinationGrid {
	public width?: number = 0;
	public minWidth?: number = 50;
	public maxWidth?: number = 500;
	public checkboxSelection?: boolean;
	public suppressSorting?: boolean;
	public suppressMenu?: boolean;
	public headerCheckboxSelection?: boolean;
	public headerCheckboxSelectionFilteredOnly?: boolean;
	public pinned?: boolean;
	public hide?: boolean = false;
	public cellRenderer?: string[];
	public cellRendererFramework?: any;
	public valueFormatter?: any;
	public type?: string;
	public dataType?: string;
	public cellClassRules?: any;
	public enablePivot?: boolean;
	public enableValue?: boolean;
	public enableRowGroup?: boolean;
	public tooltipValueGetter?: any;
	public filter?: boolean = true;
	public resizable?: boolean = true;
	public sortable?: boolean = true;
	public value?: string;
	constructor(public headerName: string, public field: string) {}
}
