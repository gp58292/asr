import { Component, Input, OnInit } from "@angular/core";
import { MapKeys } from "@aqua/aqua-component/pipes";

@Component({
	selector: "aqua-current-selection-filters",
	templateUrl: "./current-selection-filters.html",
	styleUrls: ["./current-selection-filters.scss"]
})
export class CurrentSelectionFilters implements OnInit {
	@Input("data")
	set currentSelection(data: Map<string, Set<string>>) {
		// console.debug("REQUIRED::CurrentSelectionFilters::currentSelection::", data);
		this._currrentSel = data;
	}
	public _currrentSel: Map<string, Set<string>>;
	public mapKeys: MapKeys = new MapKeys();

	public ngOnInit() {
		// console.debug("REQUIRED::CurrentSelectionFilters::ngOnInit::");
	}

	public getHTML(text: string, isLast: boolean): string {
		// console.debug("REQUIRED::CurrentSelectionFilters::getHTML::",isLast,text && text.length)
		if (!isLast && text && text.length > 0) {
			text = text + "<I>,&nbsp;&nbsp;</I>";
		}

		return text;
	}

	public getSelectedValue(
		value: Map<string, any> | Set<string | number>
	): string {
		return this.mapKeys.transform(value, undefined).join(", ");
	}
	public getSelectedLength(
		value: Map<string, any> | Set<string | number>
	): number {
		return value ? this.mapKeys.transform(value, undefined).length : 0;
	}
}
