import { Component, Input, Optional } from "@angular/core";

@Component({
	selector: "derivz-tree-view-recursive",
	templateUrl: "./tree-view-recursive.component.html"
})
export class TreeViewRecursiveComponent {
	@Input("item") public item: any;
	@Optional() @Input() public selected: boolean = false;
}
