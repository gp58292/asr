import {
	animate,
	state,
	style,
	transition,
	trigger
} from "@angular/animations";
import {
	Component,
	EventEmitter,
	Input,
	OnDestroy,
	Optional,
	Output,
	SkipSelf
} from "@angular/core";

import { AbstractTreeSelection } from "./abstract-tree-selection";
import { clrTreeSelectionProviderFactory } from "./providers/tree-selection.provider";
import { TreeSelectionService } from "./providers/tree-selection.service";

import { Expand } from "@aqua/aqua-component/expand/providers/expand";
import { LoadingListener } from "@aqua/aqua-component/loading";

@Component({
	selector: "clr-tree-node",
	templateUrl: "./tree-node.html",
	providers: [
		Expand,
		{ provide: LoadingListener, useExisting: Expand },
		{
			provide: TreeSelectionService,
			useFactory: clrTreeSelectionProviderFactory,
			deps: [[new Optional(), new SkipSelf(), TreeSelectionService]]
		}
	],
	animations: [
		trigger("childNodesState", [
			state("expanded", style({ height: "*", "overflow-y": "hidden" })),
			state("collapsed", style({ height: 0, "overflow-y": "hidden" })),
			transition("expanded <=> collapsed", animate("0.2s ease-in-out"))
		])
	],
	host: { class: ".clr-tree-node" }
})
export class TreeNode extends AbstractTreeSelection implements OnDestroy {
	get children(): TreeNode[] {
		return this.innerChildren;
	}

	@Input("clrSelected")
	public set nodeSelected(value: boolean) {
		// required for recursive trees to discard unset inputs.
		this.activateSelection();
		if (value === undefined || value === null) {
			return;
		}
		if (this.selected !== value) {
			this.selected = value;
		}
	}

	get selectable(): boolean {
		if (this.treeSelectionService) {
			return this.treeSelectionService.selectable;
		}
		return false;
	}

	@Input("clrIndeterminate")
	set nodeIndeterminate(value: boolean) {
		this.indeterminate = value;
		this.activateSelection();
	}

	public get caretDirection(): string {
		return this.nodeExpand.expanded
			? "keyboard_arrow_down"
			: "keyboard_arrow_right";
	}

	get expanded(): boolean {
		return this.nodeExpand.expanded;
	}

	set expanded(value: boolean) {
		value = !!value;
		if (this.nodeExpand.expanded !== value) {
			this.nodeExpand.expanded = value;
		}
	}

	get state(): string {
		return this.expanded && !this.nodeExpand.loading ? "expanded" : "collapsed";
	}

	@Output("clrSelectedChange") public nodeSelectedChange: EventEmitter<
		boolean
	> = new EventEmitter<boolean>(true);

	@Output("clrIndeterminateChange")
	public nodeIndeterminateChanged: EventEmitter<boolean> = new EventEmitter<
		boolean
	>(true);

	private innerChildren: TreeNode[] = [];
	constructor(
		public nodeExpand: Expand,
		@Optional() @SkipSelf() public parent: TreeNode,
		public treeSelectionService: TreeSelectionService
	) {
		super(parent);
		if (this.parent) {
			this.parent.register(this);
		}
	}

	/* Registration */

	public checkIfChildNodeRegistered(node: TreeNode): boolean {
		return this.children.indexOf(node) > -1;
	}

	// TODO: This should ideally be in AbstractTreeSelection
	// Tried doing this but ran into some issues and also ran out of time.
	// Will get this done later.
	public register(node: TreeNode): void {
		if (!this.checkIfChildNodeRegistered(node)) {
			this.children.push(node);
			if (this.selectable) {
				if (this.selected) {
					node.parentChanged(this.selected);
				}
			}
		}
	}

	// TODO: This should ideally be in AbstractTreeSelection
	// Tried doing this but ran into some issues and also ran out of time.
	// Will get this done later.
	public unregister(node: TreeNode): void {
		const index = this.children.indexOf(node);
		if (index > -1) {
			this.children.splice(index, 1);
		}
	}

	/* Selection */

	public activateSelection(): void {
		if (this.treeSelectionService && !this.treeSelectionService.selectable) {
			this.treeSelectionService.selectable = true;
		}
	}

	public selectedChanged(): void {
		this.nodeSelectedChange.emit(this.selected);
	}

	public indeterminateChanged(): void {
		this.nodeIndeterminateChanged.emit(this.indeterminate);
	}

	/* Expansion */

	public toggleExpand(): void {
		this.nodeExpand.expanded = !this.nodeExpand.expanded;
	}

	/* Lifecycle */

	public ngOnDestroy() {
		if (this.parent) {
			this.parent.unregister(this);
		}
	}
}
