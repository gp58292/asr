import { FocusMonitor } from "@angular/cdk/a11y";
import {
	Component,
	ElementRef,
	Input,
	OnDestroy,
	Optional,
	Renderer2
} from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { NgModelCommon } from "@aqua/aqua-component/common";
import { RangeValue } from "@aqua/aqua-component/models/range-value";
import * as lodash from "lodash";
import { debounceTime, distinctUntilChanged, takeUntil } from "rxjs/operators";
import { DropDownModel } from "./drop-down.model";

@Component({
	// tslint:disable-next-line:component-selector
	selector: "aqua-dropdown-range",
	templateUrl: "./dropdown-range.html",
	styleUrls: ["./dropdown-range.scss"],
	providers: [
		NgModelCommon.CUSTOM_CONTROL_VALUE_ACCESSOR(DropDownRange),
		NgModelCommon.CUSTOM_MAT_FORM_FIELD(DropDownRange)
	]
})
// tslint:disable-next-line:component-class-suffix
export class DropDownRange extends NgModelCommon<RangeValue<DropDownModel>>
	implements OnDestroy {
	@Input()
	set referenceData(options: DropDownModel[]) {
		// console.debug("DropDownRange::referenceData::", this.id, options.length);
		this._referenceData = options;
		this.startReferenceData = lodash.cloneDeep(this._referenceData);
		this.endtReferenceData = lodash.cloneDeep(this._referenceData);
	}

	@Input()
	get value(): RangeValue<DropDownModel> | null {
		/*console.debug(
			"DropDownRange::get Value::[" + this.id + "]::",
			this.numberRangeFormGroup.value
		);*/
		const n = this.numberRangeFormGroup.value;
		if (n.start || n.end) {
			return new RangeValue(n.start, n.end);
		}
		return null;
	}
	set value(numberRange: RangeValue<DropDownModel> | null) {
		numberRange = numberRange || new RangeValue<DropDownModel>();
		// console.debug("DropDownRange::Set Value::[" + this.id + "]::", numberRange);
		if (
			this.value !== numberRange ||
			this.value.start.key !== numberRange.start.key ||
			this.value.end.key !== numberRange.end.key
		) {
			numberRange = RangeValue.undefineValuesIfNull(numberRange); // This will remove value if null
			this.onChangedCallback(numberRange);
			this.stateChanges && this.stateChanges.next();
		}
	}
	get empty() {
		return false;
		// return !this.value || (!this.value.start && !this.value.end);
	}
	public numberRangeFormGroup: FormGroup;

	public _referenceData: DropDownModel[];

	public startReferenceData: DropDownModel[];
	public endtReferenceData: DropDownModel[];

	constructor(
		public fb: FormBuilder,
		private fm: FocusMonitor,
		private elRef: ElementRef,
		private render2: Renderer2
	) {
		super(elRef, render2);
		if (fm && elRef) {
			fm.monitor(elRef.nativeElement, true).subscribe(origin => {
				this.focused = !!origin;
				this.stateChanges.next();
			});
		}
		this.updateControlType("aqua-dropdpwn-range");
		this.numberRangeFormGroup = this.fb.group({
			start: undefined,
			end: undefined
		});
		this.numberRangeFormGroup.valueChanges
			.pipe(
				takeUntil(this.alive),
				debounceTime(300),
				distinctUntilChanged()
			)
			.subscribe(value => {
				this.value = value;
			});
		this.focused = false;
	}

	public writeValue(newValue: any) {
		// console.debug(
		// 	"DropDownRange::writeValue::Writing new value form:BEFORE::[" +
		// 		this.id +
		// 		"]::",
		// 	newValue,
		// 	this.numberRangeFormGroup.value
		// );
		if (
			(newValue &&
				newValue !== this.numberRangeFormGroup.value &&
				newValue.start !== null &&
				newValue.end !== null) ||
			(newValue !== undefined && newValue !== null)
		) {
			newValue = this.initValue(newValue);
			// this.numberRangeFormGroup.setValue(newValue);
			this.numberRangeFormGroup.setValue(newValue);
		} else {
			this.numberRangeFormGroup.setValue({ start: null, end: null });
		}
	}
	// Focus first child input element
	public onContainerClick(event: MouseEvent) {
		if ((event.srcElement as any).name !== "end") {
			const startInput: HTMLElement = this.elRef.nativeElement.querySelector(
				'[name="start"]'
			);
			startInput.focus();
		}
		super.onContainerClick(event);
	}

	public ngOnDestroy() {
		this.fm.stopMonitoring(this.elRef.nativeElement);
		super.ngOnDestroy();
	}
	public trackByKey(index, item) {
		return item.key;
	}

	public compareObjects(o1: DropDownModel, o2: DropDownModel): boolean {
		return o1 && o2 && o1.key === o2.key && o1.value === o2.value;
	}

	private initValue(
		range: RangeValue<DropDownModel>
	): RangeValue<DropDownModel> {
		// console.debug(
		// 	"DropDownRange::initValue::",
		// 	range,
		// 	JSON.stringify(range),
		// 	range === undefined,
		// 	range === null
		// );
		if (range === undefined || range === null || range === "") {
			range = new RangeValue<DropDownModel>(null, null);
		} else {
			// console.debug("DropDownRange::initValue::", range);
			if (!range.start) {
				range.start = null;
			}
			if (!range.end) {
				range.end = null;
			}
		}
		return range;
	}
}
