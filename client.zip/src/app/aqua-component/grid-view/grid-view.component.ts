import { SelectionModel } from "@angular/cdk/collections";
import {
	Component,
	EventEmitter,
	Input,
	OnDestroy,
	Output,
	ViewChild
} from "@angular/core";
import { FormControl } from "@angular/forms";
import { MatPaginator, MatSort, MatTableDataSource } from "@angular/material";

import { Subject } from "rxjs";

import { DataTableExportFormatter } from "@aqua/aqua-component/pipes";
import { VizNotificationService } from "@aqua/services";
import { NumberFormatPipe } from "app/aqua-component/pipes/number-formating-pipe";
import { debounceTime, distinctUntilChanged, takeUntil } from "rxjs/operators";
import { DataGridUtil } from "./datagrid-util";

@Component({
	selector: "aqua-grid-view",
	templateUrl: "./grid-view.component.html",
	styleUrls: ["./grid-view.component.scss"],
	providers: [NumberFormatPipe]
})
export class GridViewComponent implements OnDestroy {
	get displayColumns() {
		return this._displayColumns;
	}

	@Input("displayColumns")
	set displayColumns(data: any[]) {
		console.debug("GridViewComponent::setDisplayColumns ", data);
		if (data !== undefined) {
			this._displayColumns = data;
			this.selectedColumns = this._displayColumns.filter(
				field => field.defaultSelected
			);
			console.debug(
				"GridViewComponent::selectedColumns ",
				this.selectedColumns
			);
		}
	}

	get dataSource() {
		return this._dataSource;
	}

	@Input("datasource")
	set dataSource(data: any[]) {
		if (data !== undefined && data != null) {
			this.resultCount = data.length;
			if (this.resultCount === 0) {
				this.vizNotification.showWarning(
					"Search criteria returned an empty result "
				);
			}
			this.filteredDataSource = new MatTableDataSource(data);
			this.filteredDataSource.sort = this.sort;

			this.filteredDataSource.paginator = this.paginator;

			this.filteredDataSource.sortingDataAccessor = (
				innerData: any,
				col: any
			) => {
				// console.debug("GridViewComponent::setDataSource ",data[col]);

				const colObject = this.selectedColumns.find(column => {
					return column.fieldName === col;
				});

				// console.debug("GridViewComponent::setDataSource ",col,colObject,data,data[col]);

				switch (colObject.dataType) {
					case "NUMERIC": {
						return 1 * innerData[col];
					}

					default:
						return innerData[col];
				}
				// if(parseInt(data[col])<0)
				//   return 1;
				// return parseInt(data[col]);
			};
		}
		console.debug("GridViewComponent::dataSource setter" + this.resultCount);
	}
	@ViewChild(MatPaginator) public paginator: MatPaginator;
	@ViewChild(MatSort) public sort: MatSort;

	public _dataSource = [];
	public columnFilter: FormControl;
	public filteredDataSource: MatTableDataSource<any> = new MatTableDataSource(
		[]
	);

	public toggleColumns = new FormControl();

	public _displayColumns = [];
	public filteredDisplayColumns: any[] = [];
	public selectedColumns = [];
	public selection = new SelectionModel<any>(true, []);

	public resultCount: number;

	@Input("exportFileNamePrefix")
	public exportFileNamePrefix: string = "Agreement";

	// This should emit the export event to parent
	@Output("exportToExcelClick") public exportToExcelClick: EventEmitter<
		boolean
	> = new EventEmitter<boolean>(true);

	private alive: Subject<void> = new Subject();

	constructor(private vizNotification: VizNotificationService) {
		this.columnFilter = new FormControl();
		this.columnFilter.valueChanges
			.pipe(
				takeUntil(this.alive),
				debounceTime(300),
				distinctUntilChanged()
			)
			.subscribe(filterString => {
				console.debug(
					"GridViewComponent::termvalue Events::searchTerm ",
					filterString
				);
				if (filterString !== undefined) {
					this.filteredDisplayColumns = this._displayColumns.filter(column => {
						// console.debug('SearchResultComponent::filtering', column.name.toLowerCase().indexOf(filterString.toLowerCase())>=0);
						return (
							column.name.toLowerCase().indexOf(filterString.toLowerCase()) >= 0
						);
						// Show filtered columns. And show selected items too
					});
				}
			});
	}

	/** Whether the number of selected elements matches the total number of rows. */
	public isAllSelected() {
		const numSelected = this.selection.selected.length;
		const numRows = this.filteredDataSource.data.length;
		return numSelected === numRows;
	}

	/** Selects all rows if they are not all selected; otherwise clear selection. */
	public masterToggle() {
		this.isAllSelected()
			? this.selection.clear()
			: this.filteredDataSource.data.forEach(row => this.selection.select(row));
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
	}

	public ngAfterViewInit() {
		this.filteredDataSource.sort = this.sort;
		// this.filteredDataSource.sortData= (a,b) =>{

		//   return a<b;
		// };

		this.filteredDataSource.paginator = this.paginator;
	}

	public onToggleChange(event) {
		this.selectedColumns = this._displayColumns.filter(
			field => field.defaultSelected
		);
		console.debug(
			"GridViewComponent::onToggleChange" +
				event +
				"--- " +
				this.selectedColumns
		);
	}

	public filterDisplayColumn() {
		return this.selectedColumns.map(field => field.fieldName);
	}
	public exportToExcel() {
		console.debug("GridViewComponent::exportToExcel");

		this.exportToExcelClick.emit(true);
	}

	public exportToCSV(datasource) {
		// console.debug('SearchComponent::exportToCSV');
		if (datasource && datasource.data && datasource.data.length > 0) {
			const data = datasource.data;
			const exprtcsv: any[] = [];
			data.forEach(x => {
				const obj = new Object();
				const frmt = new DataTableExportFormatter();
				for (const item of this.selectedColumns) {
					const transfrmVal = frmt.transform(x[item.fieldName], item.name);
					obj[item.name] = transfrmVal;
				}
				exprtcsv.push(obj);
			});
			DataGridUtil.downloadcsv(exprtcsv, this.exportFileNamePrefix);
		}
	}

	public linkDataSetToVoyager(datasource) {
		console.debug("GridViewComponent::linkDataSetToVoyager");
	}

	public applyFilter(filterValue: string) {
		filterValue = filterValue.trim(); // Remove whitespace
		filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
		this.filteredDataSource.filter = filterValue;
	}
	// FIXME: Temporary Fix
	public getTableHeightSettings() {
		// console.debug('GridViewComponent::getTableHeightSettings');
		const mtable: any = document.getElementsByClassName("mat-table");
		// console.debug('SearchResultComponent::getTableHeightSettings table' ,mtable);

		if (!mtable[0]) {
			return;
		}
		if (document.getElementsByClassName("filters-shrunk").length > 0) {
			mtable[0].setAttribute("style", "max-height:50vh;");
			return;
		} else {
			mtable[0].setAttribute("style", "max-height:28vh;");
			return;
		}
	}
	// Used to hide columns not in the fitlered results if we are filtering.
	public checkIfColumnInFilteredList(col: any) {
		// console.debug('SearchResultComponent::checkIfColumnInFilteredList');
		if (this.columnFilter.value) {
			if (
				this.filteredDisplayColumns.find(c => {
					return c.name === col.name;
				})
			) {
				return true;
			} else {
				return false;
			}
		}
		return true;
	}
	// ngAfterContentChecked(){
	//   console.debug('SearchResultComponent::ngAfterContentChecked');
	// }
	// ngAfterViewChecked(){
	//   console.debug('SearchResultComponent::ngAfterViewChecked');
	// }
}
