import { Directive, forwardRef } from "@angular/core";
import { AbstractControl, NG_VALIDATORS, Validator } from "@angular/forms";
import { RangeValue } from "@aqua/aqua-component/models";
@Directive({
	selector: "[validateDateRange][ngModel],[validateDateRange][formControl]",
	providers: [
		{
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => DateRangeValidator),
			multi: true
		}
	]
})
export class DateRangeValidator implements Validator {
	public static validateDateRange() {
		return (c: AbstractControl) => {
			const range: RangeValue<any> = c.value;
			// console.debug("DateRangeValidator::validateRange::value",range,!RangeValidator.isValid(range));
			if (DateRangeValidator.isValid(range)) {
				return { validateDateRange: { valid: false } };
			}

			return null;
		};
	}

	public static isValid(range: RangeValue<string>): boolean {
		let valid: boolean = false;
		if (range && range.start && range.end) {
			const start: number = Date.parse(range.start);
			const end: number = Date.parse(range.end);
			valid = start > end;
			// console.debug("DateRangeValidator::isValid::value",valid,range,start,end);
		}
		return valid;
	}
	// tslint:disable-next-line:ban-types
	public validator: Function;

	constructor() {
		this.validator = DateRangeValidator.validateDateRange();
		// console.debug("DateRangeValidator::constructor:: initializing ");
	}

	public validate(c: AbstractControl) {
		return this.validator(c);
	}
}
