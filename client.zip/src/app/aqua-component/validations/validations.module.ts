import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatCommonModule } from "@angular/material/core";
import { PipeModule } from "@aqua/aqua-component/pipes";
import { DateRangeValidator } from "./date-range.validator";
import { NumberRangeValidator } from "./number-range.validator";
import { RatingRangeListValidator } from "./rating-range-list.validator";
import { TenorRangeValidator } from "./tenor-range.validator";

@NgModule({
	imports: [
		CommonModule,
		MatCommonModule,
		FormsModule,
		ReactiveFormsModule,
		PipeModule
	],
	exports: [
		NumberRangeValidator,
		DateRangeValidator,
		RatingRangeListValidator,
		TenorRangeValidator
	],
	declarations: [
		NumberRangeValidator,
		DateRangeValidator,
		RatingRangeListValidator,
		TenorRangeValidator
	]
})
export class ValidationModule {}
