import { Directive, forwardRef } from "@angular/core";
import { AbstractControl, NG_VALIDATORS, Validator } from "@angular/forms";
import { DropDownModel } from "@aqua/aqua-component/dropdown-range";
import {
	RangeValue,
	RatingRangeListModel,
	RatingRangeListWrapperModel
} from "@aqua/aqua-component/models";

@Directive({
	selector:
		// tslint:disable-next-line:directive-selector
		"[validateRatingRangeList][ngModel],[validateRatingRangeList][formControl]",
	providers: [
		{
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => RatingRangeListValidator),
			multi: true
		}
	]
})
export class RatingRangeListValidator implements Validator {
	public static validateRatingRangeList() {
		return (c: AbstractControl) => {
			console.debug("RatingRangeListValidator::validateRange::value", c.value);
			const ratingList: RatingRangeListWrapperModel = c.value;
			if (ratingList) {
				const inValue = ratingList.inValueList as RatingRangeListModel;
				const notInValue = ratingList.notInValueList as RatingRangeListModel;

				console.debug(
					"RatingRangeListValidator::validateRange::value",
					ratingList,
					RatingRangeListValidator.isValid(inValue),
					RatingRangeListValidator.isValid(notInValue)
				);
				if (
					RatingRangeListValidator.isValid(inValue) ||
					RatingRangeListValidator.isValid(notInValue)
				) {
					c.markAsTouched();
					c.markAsDirty();
					return { validateRatingRangeList: { valid: false } };
				}
			}
			return null;
		};
	}

	public static isValid(ratingList: RatingRangeListModel): boolean {
		const map: Map<string, number> = new Map<string, number>();
		let isValid = true;
		if (ratingList && ratingList.valueList) {
			const valueList = ratingList.valueList;
			// tslint:disable-next-line:prefer-for-of
			for (let i = 0; i < valueList.length; i++) {
				const range: RangeValue<DropDownModel> = valueList[i].value;
				if (
					range &&
					range.start &&
					range.end &&
					!RatingRangeListValidator.isRangeValid(range)
				) {
					isValid = false;
					break;
				}
				if (valueList[i].agencyName && valueList[i].period) {
					let count = map.get(valueList[i].agencyName + valueList[i].period);
					console.debug(
						"RatingRangeListValidator::isValid::value::count",
						count
					);
					if (!count || count === 0) {
						count = 1;
						map.set(valueList[i].agencyName + valueList[i].period, count);
					} else {
						isValid = false;
						break;
					}
				}
			}
		}
		// console.debug(
		// 	"RatingRangeListValidator::isValid::value",
		// 	ratingList,
		// 	isValid
		// );
		return !isValid;
	}

	public static isRangeValid(range: RangeValue<DropDownModel>): boolean {
		return range.start.key > range.end.key;
	}
	// tslint:disable-next-line:ban-types
	public validator: Function;

	constructor() {
		this.validator = RatingRangeListValidator.validateRatingRangeList();
		console.debug("RatingRangeListValidator::constructor:: initializing ");
	}

	public validate(c: AbstractControl) {
		return this.validator(c);
	}
}
