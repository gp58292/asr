import { Directive, forwardRef } from "@angular/core";
import { AbstractControl, NG_VALIDATORS, Validator } from "@angular/forms";
import { TenorRangeModel } from "@aqua/aqua-component/models";

@Directive({
	// tslint:disable-next-line:directive-selector
	selector: "[validateTenorRange][ngModel],[validateTenorRange][formControl]",
	providers: [
		{
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => TenorRangeValidator),
			multi: true
		}
	]
})
export class TenorRangeValidator implements Validator {
	public static validateNumberRange() {
		return (c: AbstractControl) => {
			const range: TenorRangeModel<number> = c.value;
			// console.debug("NumberRangeValidator::validateRange::value",range,!NumberRangeValidator.isValid(range));
			if (TenorRangeValidator.isValid(range)) {
				c.markAsTouched();
				c.markAsDirty();
				return { validateNumberRange: { valid: false } };
			}

			return null;
		};
	}

	public static isValid(range: TenorRangeModel<number>): boolean {
		return (
			range &&
			range.rangeValue &&
			range.rangeValue.start &&
			range.rangeValue.end &&
			range.rangeValue.start > range.rangeValue.end
		);
	}
	// tslint:disable-next-line:ban-types
	public validator: Function;

	constructor() {
		this.validator = TenorRangeValidator.validateNumberRange();
		// console.debug("NumberRangeValidator::constructor:: initializing ");
	}

	public validate(c: AbstractControl) {
		return this.validator(c);
	}
}
