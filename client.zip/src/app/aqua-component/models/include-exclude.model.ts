import { DropDownModel } from "../dropdown-range";
import { OPERATOR } from "./operator.enum";

export class IncludeExcludeModel {
	public static undefineValuesIfNull(includeXclude: IncludeExcludeModel): void {
		if (!includeXclude || includeXclude == null) {
			return undefined;
		}
		if (includeXclude.value == null && includeXclude.butNotValue == null) {
			includeXclude = undefined;
		} else if (includeXclude.value == null) {
			includeXclude.value = undefined;
		} else if (includeXclude.butNotValue == null) {
			includeXclude.butNotValue = undefined;
		}
	}
	constructor(
		public operation: OPERATOR = OPERATOR.OR,
		public value?: DropDownModel[],
		public butNotValue?: DropDownModel[]
	) {}
}
