export enum OPERATOR {
	AND = "and",
	OR = "or",
	BUT_NOT = "or_n"
}
