import { DropDownModel } from "../dropdown-range";

export class Options extends DropDownModel {
	public id?: string;
	constructor(
		private _key: string,
		private _value: string,
		public selected?: boolean
	) {
		super(_key, _value);
	}
}
