import { DropDownModel } from "@aqua/aqua-component/dropdown-range";
import { RangeValue } from "@aqua/aqua-component/models";
import { OPERATOR } from "./operator.enum";

export class RatingRangeListModel {
	public static undefineValuesIfNull(
		ratingRangeModels: RatingRangeListModel
	): RatingRangeListModel {
		if (!ratingRangeModels || ratingRangeModels == null) {
			return undefined;
		}
		if (
			ratingRangeModels.valueList == null ||
			ratingRangeModels.valueList === undefined ||
			ratingRangeModels.valueList.length === 0
		) {
			return undefined;
		}
		const valueList = ratingRangeModels.valueList;
		for (const value of valueList) {
			if (value.agencyName == null) {
				value.agencyName = undefined;
			}
			if (value.period == null) {
				value.period = undefined;
			}
			if (value.value == null) {
				value.value = undefined;
			}
		}

		return ratingRangeModels;
	}
	constructor(public valueList?: RatingRangeModel[]) {}
}

// tslint:disable-next-line:max-classes-per-file
export class RatingRangeModel {
	public operation: OPERATOR = OPERATOR.OR;
	public value: RangeValue<DropDownModel> = null;
	public agencyName: string = null;
	public numIndex: number = 1;
	public period: string = null;
}
