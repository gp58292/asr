import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { PastedNotMacthing } from "./pasted-not-macthing";

describe("PastedNotMacthing", () => {
	let component: PastedNotMacthing;
	let fixture: ComponentFixture<PastedNotMacthing>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [PastedNotMacthing]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(PastedNotMacthing);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it("should create", () => {
		expect(component).toBeTruthy();
	});
});
