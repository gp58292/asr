import { Component, Inject } from "@angular/core";
import {
	MAT_DIALOG_DATA,
	MAT_DIALOG_DEFAULT_OPTIONS,
	MatDialogRef
} from "@angular/material";
import { Options } from "@aqua/components/models";

@Component({
	selector: "dataviz-pasted-not-macthing",
	templateUrl: "./pasted-not-macthing.html",
	// styleUrls: ["./../auto-complete.scss"],
	styleUrls: ["./../auto-complete.scss", "./pasted-not-macthing.scss"],
	providers: [
		{ provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { hasBackdrop: false } }
	]
})
// tslint:disable-next-line:component-class-suffix
export class PastedNotMacthing {
	public notMatching: Options[];
	constructor(
		public dialogRef: MatDialogRef<PastedNotMacthing>,
		@Inject(MAT_DIALOG_DATA) public data: any
	) {
		this.notMatching = data.NOT_FOUND;
	}

	public closeDialog() {
		console.debug(
			"PastedNotMacthingComponent::closeDialog:: You closed pasted value not macthing dialog.."
		);
		this.dialogRef.close();
	}
}
