import { OverlayModule } from "@angular/cdk/overlay";
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatDatepickerModule, MatNativeDateModule } from "@angular/material";
import { MatCommonModule } from "@angular/material/core";
import { MatFormFieldModule } from "@angular/material/form-field";
import { DateRange } from "./date-range";

@NgModule({
	imports: [
		CommonModule,
		OverlayModule,
		MatCommonModule,
		FormsModule,
		ReactiveFormsModule,
		MatNativeDateModule,
		MatDatepickerModule
	],
	exports: [MatFormFieldModule, MatCommonModule, DateRange],
	declarations: [DateRange],
	providers: []
})
export class DateRangeModule {}
