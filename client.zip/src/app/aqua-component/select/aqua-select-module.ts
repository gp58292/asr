import { OverlayModule } from "@angular/cdk/overlay";
import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import {
	MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
	MatChipsModule,
	MatSelectModule
} from "@angular/material";
import { MatCommonModule, MatOptionModule } from "@angular/material/core";
import { ErrorStateMatcher } from "@angular/material/core";
import { MatFormFieldModule } from "@angular/material/form-field";
import { PipeModule } from "@aqua/aqua-component/pipes";
import { AquaFilterSelect, AquaSelect } from "@aqua/aqua-component/select";

@NgModule({
	imports: [
		CommonModule,
		OverlayModule,
		MatOptionModule,
		MatCommonModule,
		MatChipsModule,
		FormsModule,
		ReactiveFormsModule,
		MatSelectModule,
		PipeModule
	],
	exports: [
		MatFormFieldModule,
		AquaFilterSelect,
		AquaSelect,
		MatOptionModule,
		MatCommonModule
	],
	declarations: [AquaFilterSelect, AquaSelect],
	providers: [MAT_SELECT_SCROLL_STRATEGY_PROVIDER, ErrorStateMatcher]
})
export class AquaSelectModule {}
