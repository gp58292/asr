import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { InputResizerDirective } from "./input-resizer.directive";

@NgModule({
	imports: [CommonModule],
	exports: [InputResizerDirective],
	declarations: [InputResizerDirective],
	providers: []
})
export class DirectiveModule {}
