export * from "./input-resizer.directive";
