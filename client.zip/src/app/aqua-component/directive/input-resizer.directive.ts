import { Input } from "@angular/core";
import { ContentChild, OnInit, Renderer } from "@angular/core";
import {
	Directive,
	DoCheck,
	ElementRef,
	HostBinding,
	HostListener,
	Renderer2
} from "@angular/core";

@Directive({
	selector: "[aquaInputResizer]"
})
export class InputResizerDirective implements DoCheck, OnInit {
	@HostBinding("style.width") public eleWidth: number;

	@ContentChild(Input) public childInput;

	private _inputValue: any;
	private _inputValueLen: number;
	private _childElement: any;

	constructor(public el: ElementRef, public renderer: Renderer2) {
		// console.debug('InputResizerDirective::constructor:: ',el.nativeElement,renderer);
	}

	public ngOnInit() {
		this._inputValue = this.el.nativeElement.value;
		this._childElement = this.el.nativeElement.children[0]; // Get child input element
		console.debug("InputResizerDirective::ngOnInit:: ", this.eleWidth);
	}

	public ngDoCheck() {
		this._inputValue = this._childElement.value
			? this._childElement.value.length
			: 0;

		this.calculateWidth();
		console.debug(
			"InputResizerDirective::ngDoCheck::valLength ",
			this._inputValue
		);
	}
	// @HostListener('keyup', ['$event']) keyup(e:KeyboardEvent) {
	//   let inputElement:any=e.srcElement;
	//   this._inputValue=inputElement.value;
	//   this.calculateWidth()
	//   this._childElement.setAttribute("style",this.eleWidth+"em");
	//   console.debug('InputResizerDirective::HostListener::Value:',this._inputValue,this.eleWidth);
	// }

	private calculateWidth(): void {
		if (this._inputValue && this._inputValue.length > 3) {
			if (this._inputValue.length > this._inputValueLen) {
				this.eleWidth += 0.2;
			} else {
				this.eleWidth += 0.2;
			}

			this._inputValueLen = this._inputValue.length;
		} else {
			this.eleWidth = 2;
			this._inputValueLen = this._inputValue ? this._inputValue.length : 0;
		}
		this.renderer.setStyle(this.el.nativeElement, "width", this.eleWidth);
	}
}
