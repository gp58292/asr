import { MapKeys } from './map.Keys.pipe';
import { TruncatePipe } from './truncate.pipe';
import { FilterOptionsPipe } from './filter-options.pipe';
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import { EscapeHtmlPipe } from './escape-html.pipe';
import { DataTableExportFormatter } from './data-table-export-formatter.pipe';
import {ArraySortPipe} from './array-sort.pipe';

@NgModule({
  imports: [
    CommonModule,
  ],
  exports: [
            FilterOptionsPipe,TruncatePipe,MapKeys,EscapeHtmlPipe,DataTableExportFormatter,ArraySortPipe
          ],
  declarations: [ FilterOptionsPipe,TruncatePipe,MapKeys,EscapeHtmlPipe,DataTableExportFormatter,ArraySortPipe],
  providers: [FilterOptionsPipe,MapKeys,EscapeHtmlPipe,DataTableExportFormatter,ArraySortPipe],
})
export class PipeModule {}
