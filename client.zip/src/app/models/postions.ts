export enum SnackBarPosition {
	START = "start",
	CENTER = "center",
	END = "end",
	LEFT = "left",
	RIGHT = "right",
	TOP = "top",
	BOTTOM = "bottom"
}
