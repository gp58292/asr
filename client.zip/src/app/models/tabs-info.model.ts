export class TabsInfo {
	public static comparator(a: TabsInfo, b: TabsInfo): number {
		return a.tabOrder > b.tabOrder ? 1 : 0;
	}
	// public tabId: string;
	// public tabName: string;
	// public tabOrder: number;
	constructor(
		public tabId: string,
		public tabName: string,
		public tabOrder: number
	) {}

	public equals(obj: TabsInfo) {
		if (this.tabOrder === obj.tabOrder) {
			return true;
		}
		if (obj == null) {
			return false;
		}

		return true;
	}
}
