import { AppHttpError } from "./app-http-error";
export class AppHttpResponse<T> {
	public responseStatus: number;
	public restError: AppHttpError;
	public responseData: T;
	public message: string;
}
