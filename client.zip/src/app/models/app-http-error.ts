export class AppHttpError {
	public errorCode: string;
	public errorMessage: string;
}
