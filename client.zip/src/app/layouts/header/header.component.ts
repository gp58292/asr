import { Component, OnDestroy, OnInit } from "@angular/core";
import { MatDialog } from "@angular/material";
import { BatchReportComponent } from "@aqua/batch-report/batch-report.component";
import { BookmarkService } from "@aqua/filters/data-finder/bookmark";
import { ConfirmationDialogComponent } from "@aqua/filters/data-finder/confirmation-dialog/confirmation-dialog.component";
import { SearchService } from "@aqua/filters/data-finder/search/search.service";
import { SearchField } from "@aqua/filters/models";
import { DataTreeStorageService } from "@aqua/filters/services";
import { AppHttpResponse } from "@aqua/models";
import { EnvironmentVersion, UserParams } from "@aqua/models/dto";
import {
	AuthService,
	ReferencesDataService,
	SpeechRecognitionService,
  UrlConfig,
  VizNotificationService
} from "@aqua/services";
import { environment } from "environments/environment";
import { Subject } from "rxjs";
import { finalize, takeUntil } from "rxjs/operators";

declare function startRecording(): void;
declare function stopRecording(any): void;

@Component({
	selector: "app-header",
	templateUrl: "./header.component.html",
	styleUrls: ["./header.component.scss"]
})
export class HeaderComponent implements OnInit, OnDestroy {
	public userImageSrc: string;
	public userName: string;
	public env: EnvironmentVersion;
	public showUserMenu: boolean = false;

	/*############## Start: Connecting to Python ############### */
	public isStartDisable: boolean;
	public isStopDisable: boolean;
	public soeId: string;
	public response: any;
	public duration: number = 10;
	public timeLeft: number = this.duration;
	private fieldsData: any[];
	private pythonApiUrl: string;
	private interval;
	private command: string;
	private aquaAudio: any;
	private clearAudio: any;
	private resetAudio: any;
	private searchAudio: any;
	/*############## End: Connecting to Python ############### */

	private alive: Subject<void> = new Subject();

	constructor(
		public dialog: MatDialog,
		private authService: AuthService,
		private urlConfig: UrlConfig,
		private referencesData: ReferencesDataService,
		private vizNotification: VizNotificationService,
		private bookmarkService: BookmarkService,
		private dataStorageTreeService: DataTreeStorageService,
		private searchService: SearchService,
		private speechRecognitionService: SpeechRecognitionService
	) {
		this.authService
			.subscribeToGEIDUpdate()
			.pipe(takeUntil(this.alive))
			.subscribe((geid: any) => {
				this.setUserPic(geid);
			});
		this.isStartDisable = false;
		this.isStopDisable = true;
		this.pythonApiUrl = environment.pythonApiUrl;
		this.aquaAudio = new Audio("/assets/media/aqua.wav");
		this.clearAudio = new Audio("/assets/media/clear.wav");
		this.resetAudio = new Audio("/assets/media/reset.wav");
		this.searchAudio = new Audio("/assets/media/search.wav");
	}

	public ngOnInit() {
		console.debug("HeaderComponent::ngOnInit");
		this.authService
			.subscribeToUserChange()
			.pipe(takeUntil(this.alive))
			.subscribe((user: UserParams) => {
				this.toggleUserName(user);
			});
		if (this.authService.isSignedIn()) {
			this.toggleUserName(this.authService.getUserParams());
		}
		this.referencesData
			.subscribeEnvDetails()
			.pipe(takeUntil(this.alive))
			.subscribe((env: EnvironmentVersion) => {
				if (env.envName.indexOf("prod") === -1) {
					this.env = env;
				}
			});
		this.dataStorageTreeService
			.listenState()
			.pipe(takeUntil(this.alive))
			.subscribe(state => {
				this.fieldsData = state;
			});
		this.startSpeechRecognition();
	}

	public logout() {
		console.debug("HeaderComponent::logout");

		if (this.bookmarkService.isAnyTemporaryBookmarkExist()) {
			const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
				width: "300px",
				minWidth: "27rem",
				panelClass: "confirm-dailog-container",
				data: {
					confirmationMessage: `Do you want to delete your temporary bookmarks ?
            \n Post any action you will be logged out`
				},
				disableClose: true
			});

			dialogRef
				.afterClosed()
				.pipe(takeUntil(this.alive))
				.subscribe(result => {
					if (result) {
						this.bookmarkService
							.deleteAllTemporaryBookmarkByUserId()
							.pipe(
								takeUntil(this.alive),
								finalize(() => {
									this.authService.logout();
									this.toggleUserName(this.authService.getUserParams());
								})
							)
							.subscribe((response: AppHttpResponse<boolean>) => {
								if (response.responseStatus === 200) {
									this.vizNotification.showMessage(
										"All your temporary bookmark removed successfully."
									);
								} else {
									this.vizNotification.showError(
										"Interal error occured while removing temporary bookmark, please contact support team."
									);
								}
							});
					} else {
						this.authService.logout();
						this.toggleUserName(this.authService.getUserParams());
					}
				});
		} else {
			this.authService.logout();
			this.toggleUserName(this.authService.getUserParams());
		}
	}
	public openBatchStatus(): void {
		const dialogRef = this.dialog.open(BatchReportComponent, {
			width: "95%",
			height: "95%"
		});

		dialogRef.afterClosed().subscribe(result => {
			console.debug("HeaderComponent::openBatchStatus::The dialog was closed");
		});
	}

	public ngOnDestroy() {
		this.alive.next();
		this.alive.complete();
		this.alive.unsubscribe();
		this.speechRecognitionService.stop();
	}

	/*############## Start: Connecting to Python ############### */
	public start() {
		console.debug("AQUA-ASR::HeaderComponent::start");
		// this.vizNotification.showMessage("I am listening");
		startRecording();
		this.isStartDisable = true;
		this.isStopDisable = false;
		this.initStopTimer();
	}

	public stop() {
		console.debug("AQUA-ASR::HeaderComponent::stop");
		this.isStartDisable = false;
		this.isStopDisable = true;
		this.timeLeft = 0;
	}

	public startByCommand() {
		this.start();
	}

	public initStopTimer() {
		this.interval = setInterval(() => {
			if (this.timeLeft > 0) {
				this.timeLeft--;
			} else {
				this.timeLeft = this.duration;
				stopRecording(this);
				this.isStartDisable = false;
				this.isStopDisable = true;
				this.destroyStopTimer();
			}
		}, 1000);
	}

	public destroyStopTimer() {
		if (this.interval) {
			clearInterval(this.interval);
		}
	}

	public renderComponent(data) {
		console.debug("AQUA-ASR::HeaderComponent::renderComponent: data:", data);
		this.response = data;
		this.buildFields(data);
	}

	public search() {
		console.debug("AQUA-ASR::::HeaderComponent:search");
		// this.vizNotification.showMessage("I am searching");
		/* const audio = new Audio("/assets/media/search.wav");
		audio.play(); */
		this.dataStorageTreeService.setNodeUpdated(true);
	}

	public reset() {
		console.debug("AQUA-ASR::::HeaderComponent:reset bookmark");
		// this.vizNotification.showMessage("I am reseting");
		/* const audio = new Audio("/assets/media/reset.wav");
		audio.play(); */
		this.dataStorageTreeService.setResetFormStatus(true);
	}

	public clear() {
		console.debug("AQUA-ASR::::HeaderComponent:clear bookmark");
		// this.vizNotification.showMessage("I am clearing");
		/* const audio = new Audio("/assets/media/clear.wav");
		audio.play(); */
		this.bookmarkService.selectedBookmarkKeyChangeNotifier$.next(-1);
		this.dataStorageTreeService.clearAllFilters();
		this.searchService.clearSearchResult();
		this.bookmarkService.loadBookmark(-1);
	}

	public doAsyncTask(cb, audio, message) {
		this.vizNotification.showMessageWithoutDismiss(message, 2000);
		audio.play();
		setTimeout(() => {
			cb();
		}, 2000);
	}

	public startSpeechRecognition(): void {
		this.speechRecognitionService.speechToText().subscribe(
			text => {
				text = text.toLowerCase();
				this.command = text.replace(/\s/g, "");
				if (
					this.command === "hello" ||
					this.command === "hi" ||
					this.command === "hey" ||
					this.command === "aqua" ||
					this.command === "helloaqua" ||
					this.command === "hiaqua" ||
					this.command === "heyaqua" ||
					this.command === "hello  aqua" ||
					this.command === "hi aqua"
				) {
					this.doAsyncTask(
						() => {
							this.startByCommand();
						},
						this.aquaAudio,
						"I am listening."
					);
				} else if (
					this.command === "aquasearch" ||
					this.command === "helloaquasearch" ||
					this.command === "hiaquasearch" ||
					this.command === "heyaquasearch" ||
					this.command === "search" ||
					this.command === "aqua search"
				) {
					this.doAsyncTask(
						() => {
							this.search();
						},
						this.searchAudio,
						"I am searching."
					);
				} else if (
					this.command === "aquaclear" ||
					this.command === "helloaquaclear" ||
					this.command === "hiaquaclear" ||
					this.command === "heyaquaclear" ||
					this.command === "clear" ||
					this.command === "aqua clear" ||
					this.command === "aquagear" ||
					this.command === "aquacare"
				) {
					this.doAsyncTask(
						() => {
							this.clear();
						},
						this.clearAudio,
						"I am clearing bookmark."
					);
				} else if (
					this.command === "aquareset" ||
					this.command === "helloaquareset" ||
					this.command === "hiaquareset" ||
					this.command === "heyaquareset" ||
					this.command === "reset" ||
					this.command === "aqua reset"
				) {
					this.doAsyncTask(
						() => {
							this.reset();
						},
						this.resetAudio,
						"I am reseting field values."
					);
				} else {
					this.vizNotification.showErrorWithoutDismiss(
						"Command is not recognized - Please try again", 2000
					);
					console.debug(
						"AQUA-ASR::{" +
							this.command +
							"} Command is not recognized - Please try again"
					);
				}
			},
			err => {
				console.debug(err);
				if (err.error === "no-speech") {
					this.startSpeechRecognition();
				}
			},
			() => {
				if (
					this.command === "hello" ||
					this.command === "hi" ||
					this.command === "hey" ||
					this.command === "aqua" ||
					this.command === "helloaqua" ||
					this.command === "hiaqua" ||
					this.command === "heyaqua" ||
					this.command === "hello  aqua" ||
					this.command === "hi aqua"
				) {
					console.debug("command already running");
				} else {
					this.startSpeechRecognition();
				}
			}
		);
	}

	private buildFields(data: SearchField[]): void {
		console.debug("AQUA-ASR::HeaderComponent::buildFields started ");
		this.command = "";
		this.startSpeechRecognition();
		// tslint:disable-next-line:prefer-for-of
		for (let i = 0; i < data.length; i++) {
			const field = this.findFields(this.fieldsData, data[i].fieldName);
			if (field) {
				field.value = data[i].value;
				field.whoHasFlag = data[i].whoHasFlag;
				console.debug("AQUA-ASR::HeaderComponent::buildFields:: ", field);
				this.dataStorageTreeService.updateNode(field, "filter");
			}
		}
		setTimeout(() => {
			this.dataStorageTreeService.setNodeUpdated(true);
		}, 2000);
		console.debug("AQUA-ASR::HeaderComponent::buildFields completed ");
	}

	private findFields(listOfField: any[], fName: string): SearchField {
		console.debug("AQUA-ASR::HeaderComponent::findFields started");
		// tslint:disable-next-line:prefer-for-of
		for (let i = 0; i < listOfField.length; i++) {
			const arrayOfFields = listOfField[i].children as SearchField[];
			const finalFiled: SearchField[] = arrayOfFields.filter(
				f => f.fieldName === fName
			);
			console.debug(
				"AQUA-ASR::HeaderComponent::findFields:: ",
				finalFiled,
				arrayOfFields
			);
			if (finalFiled && finalFiled.length > 0) {
				return finalFiled[0];
			}
		}
		console.debug("AQUA-ASR::HeaderComponent::findFields end");
		return undefined;
	}

	/*############## Stop: Connecting to Python ############### */

	private setUserPic(geid): void {
		console.debug("HeaderComponent::setUserPic ", geid);
		if (geid) {
			this.userImageSrc = this.urlConfig.EP_CITI_REMOTE_USER_PIC.replace(
				"{#geid}",
				geid
			);
		}
	}

	private toggleUserName(userParams: UserParams) {
		console.debug("HeaderComponent::toggleUserName subscribed: ", userParams);
		if (!userParams || userParams == null) {
			this.userName = "";
			this.showUserMenu = false;
		} else {
			console.debug("Welcome %s", userParams.name);
			this.userName = userParams.name;
			this.showUserMenu = true;
			this.setUserPic(userParams.geid);
			this.soeId = userParams.soeid;
		}
	}
}
