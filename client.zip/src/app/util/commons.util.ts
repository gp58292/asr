export class CommonUtils {
	public static removeFalsyProperties(source: object): object {
		Object.keys(source).forEach(
			key =>
				(source[key] &&
					typeof source[key] === "object" &&
					CommonUtils.removeFalsyProperties(source[key])) ||
				((source[key] === undefined ||
					source[key] === "" ||
					source[key] === null) &&
					delete source[key])
		);
		return source;
	}

	public static omitFalsyAndProps(
		source: any,
		props: string[],
		isNestedOmit: boolean = false
	): any[] {
		console.debug(
			"CommonUtils:: omitFalsyAndProps::",
			source,
			props,
			isNestedOmit
		);
		// Nullyfing class association like Type, Reference, good for nested object comparision
		source = CommonUtils.deepClone(source);

		// Remove undefined properties whos value is not defined yet //lodash.cloneDeep(source)
		source = CommonUtils.removeFalsyProperties(source) as any[];

		// exclude provided properties
		source = CommonUtils.omitPropties(source, props, isNestedOmit);

		return source;
	}

	public static omitPropties(
		source: any[],
		props: string[],
		isNestedOmit: boolean = false
	): any[] {
		Object.keys(source).forEach(
			key =>
				(source[key] &&
					typeof source[key] === "object" &&
					isNestedOmit &&
					CommonUtils.omitPropties(source[key], props, isNestedOmit)) ||
				(props.includes(key) && delete source[key])
		);
		return source;
	}

	public static deepClone(source: any): any {
		return source ? JSON.parse(JSON.stringify(source)) : source;
	}
}
